package com.zhongan.app.run.cms.common.excelutil.annotion;

import com.zhongan.app.run.cms.common.excelutil.format.DefaultCellValueFormat;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.ANNOTATION_TYPE, ElementType.FIELD })
public @interface PropertyCell {

    /**
     * @Title: title
     * @Description: 标题
     * @author lichao002
     * @return
     */
    String title();

    /**
     * @Title: order
     * @Description: 排序
     * @author lichao002
     * @return
     */
    int order() default 0;

    /**
     * @Title: format
     * @Description: 格式化
     * @author lichao002
     * @return
     */
    Class<? extends CellValueFormat> format() default DefaultCellValueFormat.class;

    /**
     * @Title: formatParam
     * @Description: 配合format的参数  如果formatParam有值 但是format 为默认值得花 那么采取DateCellValueFormat 来处理
     * @author lichao002
     * @return
     */
    String formatParam() default "";
}
