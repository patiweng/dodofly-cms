package com.zhongan.app.run.cms.service.qrcode.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoScanQrcodeLogDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoScanQrcodeLogDO;
import com.zhongan.app.run.cms.bean.repo.AwardRecordRepo;
import com.zhongan.app.run.cms.bean.web.AwardRecordDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.dao.qrcode.BububaoScanQrcodeLogDao;
import com.zhongan.app.run.cms.service.qrcode.BububaoScanQrcodeLogService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;

@Slf4j
@Service
public class BububaoScanQrcodeLogServiceImpl implements BububaoScanQrcodeLogService {

    @Resource
    private BububaoScanQrcodeLogDao bububaoScanQrcodeLogDao;

    @Override
    public void batchSaveScanQrcodeLog() {
        // TODO Auto-generated method stub

    }

    @Override
    public List findScanQrcodeLogsPage() {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * 插入扫码日志记录
     */
    @Override
    public BaseResult<Integer> insertScanQrcodeLog(BububaoScanQrcodeLogDto bububaoScanQrcodeLogDTO) {
        BaseResult<Integer> result = new BaseResult<Integer>();
        BububaoScanQrcodeLogDO qrcodeLogDO =new BububaoScanQrcodeLogDO();
        try {
            if (StringUtil.isBlank(bububaoScanQrcodeLogDTO.getCreator())) {
                bububaoScanQrcodeLogDTO.setCreator("system");
            }
            if (StringUtil.isBlank(bububaoScanQrcodeLogDTO.getModifier())) {
                bububaoScanQrcodeLogDTO.setModifier("system");
            }
            bububaoScanQrcodeLogDTO.setGmtCreated(new Date());
            bububaoScanQrcodeLogDTO.setGmtModified(new Date());
            BeanUtils.copyProperties(bububaoScanQrcodeLogDTO, qrcodeLogDO);
            int count=bububaoScanQrcodeLogDao.insertSelective(qrcodeLogDO);
            result.setResult(count);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.info("异常===BububaoScanQrcodeLogServiceImpl.insertScanQrcodeLog fail", e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 查询
     */
    @Override
    public BaseResult<List<BububaoScanQrcodeLogDto>> selectScanQrcodeLog(BububaoScanQrcodeLogDto scanQrcodeLogDTO) {
        log.info("{}--BububaoScanQrcodeLogServiceImpl.selectScanQrcodeLog……start,param==={}",
                ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(scanQrcodeLogDTO));
        BaseResult<List<BububaoScanQrcodeLogDto>> result = new BaseResult<List<BububaoScanQrcodeLogDto>>();
        List<BububaoScanQrcodeLogDto> dtoList = Lists.newArrayList();
        BububaoScanQrcodeLogDto qrcodeLog=null;
        try {
            BububaoScanQrcodeLogDO scanQrcodeLogDO = new BububaoScanQrcodeLogDO();
            BeanUtils.copyProperties(scanQrcodeLogDTO, scanQrcodeLogDO);
            List<BububaoScanQrcodeLogDO> doList = bububaoScanQrcodeLogDao.selectDataByCdt(scanQrcodeLogDO);
            for (BububaoScanQrcodeLogDO out:doList) {
                qrcodeLog=new BububaoScanQrcodeLogDto();
                BeanUtils.copyProperties(out, qrcodeLog);
                dtoList.add(qrcodeLog);
            }
            result.setResult(dtoList);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.error("{}--BububaoScanQrcodeLogServiceImpl.selectScanQrcodeLog……fail==={}",
                    ThreadLocalUtil.getRequestNo(), e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

}
