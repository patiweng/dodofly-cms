package com.zhongan.app.run.cms.service.qrcode.impl;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.taobao.tddl.client.sequence.Sequence;
import com.taobao.tddl.client.sequence.exception.SequenceException;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.StatisticsParamDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserInsuranceDTO;
import com.zhongan.app.run.cms.common.constants.QrCodeConstants;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.csvutil.CSVUtil;
import com.zhongan.app.run.cms.common.csvutil.conver.DefaultConvert;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.thread.export.InsureDetailThread;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.StreamUtil;
import com.zhongan.app.run.cms.common.utils.UserUtil;
import com.zhongan.app.run.cms.dao.qrcode.BububaoExportLogDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoScanQrcodeLogDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoThirdOrgDao;
import com.zhongan.app.run.cms.service.client.RunPolicyFeignClient;
import com.zhongan.app.run.cms.service.qrcode.StatisticsDetailService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

@Slf4j
@Service("statisticsDetailServiceImpl")
public class StatisticsDetailServiceImpl implements StatisticsDetailService {

    @Resource
    private BububaoThirdOrgDao      bububaoThirdOrgDao;
    @Resource
    private BububaoExportLogDao     bububaoExportLogDao;
    @Resource
    private BububaoScanQrcodeLogDao bububaoScanQrcodeLogDao;

    @Resource
    private RunPolicyFeignClient    runPolicyFeignClient;
    @Resource
    private OssTool                 ossTool;
    @Resource
    private ThreadPoolTaskExecutor  threadPoolDetail;
    @Value("${qrcode.downLoadNums}")
    private String                  downLoadNums;
    @Value("${qrcode.downLoadFile}")
    private String                  downLoadFile;


    /**
     * 导出excel
     */
    @Override
    public BaseResult<String> downLoadReports(StatisticsParamDto param) {
        BaseResult<String> result = new BaseResult<String>();
        List<ResultInsureDto> resultOrgDtos = Lists.newArrayList();
        try {
            //1.根据条件查询数据的条数
            List<ResultInsureDto> allOrgs=bububaoScanQrcodeLogDao.selectStatisticsDetailPage(param);
            //组装保单详细信息
            if (CollectionUtils.isNotEmpty(allOrgs)) {
                AssemblePolicyInfo(allOrgs, resultOrgDtos);
            }
            //2.如果大于2万条异步下载
            if (resultOrgDtos.size() > Integer.valueOf(downLoadNums)) {
                //插入导出管理记录
                Long id = insert(param);
                threadPoolDetail
                        .execute(new InsureDetailThread(bububaoExportLogDao, resultOrgDtos, ossTool, id, downLoadFile));
                result.setMessage(AppErrEnum.SUCCESS_QRCODE_20000.getValue());
                result.setCode(AppErrEnum.SUCCESS_QRCODE_20000.getCode());
                return result;
            }
            String url = doExportExcel(resultOrgDtos);
            result.setResult(url);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.error(
                    "{}-ExportLog delete fail,please find error to...。"
                            + "error StatisticsDetailServiceImpl--downLoadReports()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 插入导出管理表数据
     * 
     * @param param
     * @throws SequenceException
     */
    public long insert(StatisticsParamDto param) throws SequenceException {
        BububaoExportLogDO exportLogDO = new BububaoExportLogDO();
        Date date = new Date();
        exportLogDO.setModuleCode(4);
        exportLogDO.setCondition(selectByPrimaryKey(param));
        exportLogDO.setStatus(1);
        exportLogDO.setUseTime(date);
        exportLogDO.setCreator(UserUtil.getUserInfo().getOperatorName());
        exportLogDO.setModifier(UserUtil.getUserInfo().getOperatorName());
        exportLogDO.setGmtCreated(date);
        exportLogDO.setGmtModified(date);
        exportLogDO.setIsDeleted("N");
        bububaoExportLogDao.insertSelective(exportLogDO);
        return exportLogDO.getId();
    }

    /**
     * 组装查询条件
     * 
     * @param param
     * @return
     */
    public String selectByPrimaryKey(StatisticsParamDto param) {
        StringBuffer conditionBuf = new StringBuffer();
        conditionBuf.append(bububaoThirdOrgDao.selectByPrimaryKey(param.getOneOrgId()).getOrgName());
        if (param.getTwoOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getTwoOrgId()).getOrgName());
        }
        if (param.getThreeOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getThreeOrgId()).getOrgName());
        }
        if (param.getFourOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getFourOrgId()).getOrgName());
        }
        if (param.getFiveOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getFiveOrgId()).getOrgName());
        }

        conditionBuf.append("_" + param.getSdate().replaceAll("\\-", "/") + "-");
        conditionBuf.append(param.getEdate().replaceAll("\\-", "/"));
        if (StringUtil.isNotBlank(param.getSalesCode())) {
            conditionBuf.append("_" + param.getSalesCode());
        }
        return conditionBuf.toString();

    }

    public String doExportExcel(List<ResultInsureDto> allOrgs) {
        log.info("{}-StatisticsDetailServiceImpl.doExportExcel start...", ThreadLocalUtil.getRequestNo());
        ByteArrayOutputStream outputStream = null;
        String qrCodeUrl = null;
        try {
            outputStream = new ByteArrayOutputStream();
            CSVUtil.writeCSV(outputStream, ',', "utf-8", new DefaultConvert(), QrCodeConstants.getDetailExportTitle(),
                    allOrgs, QrCodeConstants.getDetailExportEnTitle(), ResultInsureDto.class);
            String nowTime = DateTimeUtils.formatCurrentTime(DateTimeUtils.NOMARK_DATETIME_PATTERN);
            String fileName = RunConstants.UPLOAD_FILE_DETAILS + nowTime;
            ossTool.uploadFile(StreamUtil.parse(outputStream), fileName);
            //组织下载url
            qrCodeUrl = downLoadFile + RunConstants.DOWNLOAD_URL + fileName;
        } catch (Exception e) {
            log.error("Exception:", e);
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (Exception e) {
                log.error("Exception:", e);
            }
        }
        return qrCodeUrl;
    }


    @Override
    public BaseResult<PageDTO<ResultInsureDto>> selectStatisticsDetailPage(StatisticsParamDto param) {
        BaseResult<PageDTO<ResultInsureDto>> baseResult = new  BaseResult<PageDTO<ResultInsureDto>>();
        PageDTO<ResultInsureDto> resultPage = new PageDTO<ResultInsureDto>();
        List<ResultInsureDto> resultOrgDtos = Lists.newArrayList();
        try {
            //计算分页开始索引
            Integer currentPage = param.getCurrentPage();
            Integer pageSize = param.getPageSize();
            if (currentPage == null || currentPage == 0) {
                currentPage = 1;
            }
            if (pageSize == null || pageSize == 0) {
                pageSize = 50;
            }
            Integer start = (currentPage - 1) * pageSize;
            Integer end = currentPage * pageSize;
            param.setStart(start);
            param.setEnd(end);
            //获取符合条件的统计数据
            int totleSize= bububaoScanQrcodeLogDao.selectStatisticsDetailCount(param);
            List<ResultInsureDto> resultList=bububaoScanQrcodeLogDao.selectStatisticsDetailPage(param);
            //组装保单详细信息
            if(CollectionUtils.isNotEmpty(resultList)){
                AssemblePolicyInfo(resultList,resultOrgDtos);
            }
            //组织返回数据
            resultPage.setCurrentPage(currentPage);
            resultPage.setPageSize(pageSize);
            resultPage.setStartRow(start);
            resultPage.setTotalItem(totleSize);
            resultPage.setResultList(resultOrgDtos);
            baseResult.setResult(resultPage);
            baseResult.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            baseResult.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.info("异常===ScanInsureStatisticsServiceImpl.selectStatisticsPage fail", e);
            baseResult.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            baseResult.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return baseResult;
    }

    /*
     * 组装保单详细信息
     */
    private void AssemblePolicyInfo(List<ResultInsureDto> resultList, List<ResultInsureDto> resultOrgDtos) {
      //查询对应的保单详细信息
        for(ResultInsureDto resultOut:resultList){
            ResultInsureDto insureOut = resultOut.clone();
            //查询保单明细
            UserInsuranceDTO userInsuranceDTO = new UserInsuranceDTO();
            userInsuranceDTO.setPolicyNo(insureOut.getScanPolicyNo());
            userInsuranceDTO.setUnionid(insureOut.getScanUnionId());
            ResultBase<UserInsuranceDTO> policyRs = runPolicyFeignClient.selectPolicyByCdt(userInsuranceDTO);
            if (policyRs.getValue() != null) {
                userInsuranceDTO = policyRs.getValue();
                insureOut.setHolderName(userInsuranceDTO.getHolderName());
                insureOut.setHolderIdentity(userInsuranceDTO.getHolderIdentity());
                insureOut.setHolderPhone(userInsuranceDTO.getHolderPhone());
                insureOut.setPolicyStartTime(userInsuranceDTO.getPolicyStartTime());
                insureOut.setPolicyEndTime(userInsuranceDTO.getPolicyEndTime());
                insureOut.setOriginPremium(userInsuranceDTO.getOriginPremium());
                insureOut.setOriginSum(userInsuranceDTO.getOriginSum());
            }
            resultOrgDtos.add(insureOut);
        }
        
    }
}
