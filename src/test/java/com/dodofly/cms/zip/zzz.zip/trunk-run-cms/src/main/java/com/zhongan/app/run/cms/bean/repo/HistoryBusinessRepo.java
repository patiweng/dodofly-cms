package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class HistoryBusinessRepo implements Cloneable {
    private Long   id;
    private String source_code;
    private String source_name;
    private Long   alluser_shouquan;
    private Long   alluser_insure;
    private Long   xbuser_all;
    private Long   xbuser_premium;
    private Long   zaibao_user;

    private String sdate;
    private String edate;
    private String bopsFlag;

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            log.error("clone  fail===={}", e);
        }
        return null;
    }
}
