package com.zhongan.app.run.cms.bean.web;

import java.math.BigDecimal;
import java.util.Date;

public class HistoryBusinessQueryDTO {

    private Long       id;

    /**
     * 统计时间
     */
    private Date       bizTime;

    /**
     * 渠道码
     */
    private String     sourceCode;

    /**
     * 渠道名
     */
    private String     sourceName;

    /**
     * 累计授权用户数
     */
    private BigDecimal accNum;

    /**
     * 累计投保用户数
     */
    private BigDecimal insNum;

    /**
     * 累计续保用户数
     */
    private BigDecimal renNum;

    /**
     * 累计付费续保用户数
     */
    private BigDecimal renPayNum;

    /**
     * 累计保费收入
     */
    private BigDecimal renPayFee;

    /**
     * 扩展信息,json格式
     */
    private String     extraInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Date getBizTime() {
        return bizTime;
    }

    public void setBizTime(Date bizTime) {
        this.bizTime = bizTime;
    }

    public String getSourceCode() {
        return sourceCode;
    }

    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }

    public String getSourceName() {
        return sourceName;
    }

    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    public BigDecimal getAccNum() {
        return accNum;
    }

    public void setAccNum(BigDecimal accNum) {
        this.accNum = accNum;
    }

    public BigDecimal getInsNum() {
        return insNum;
    }

    public void setInsNum(BigDecimal insNum) {
        this.insNum = insNum;
    }

    public BigDecimal getRenNum() {
        return renNum;
    }

    public void setRenNum(BigDecimal renNum) {
        this.renNum = renNum;
    }

    public BigDecimal getRenPayNum() {
        return renPayNum;
    }

    public void setRenPayNum(BigDecimal renPayNum) {
        this.renPayNum = renPayNum;
    }

    public BigDecimal getRenPayFee() {
        return renPayFee;
    }

    public void setRenPayFee(BigDecimal renPayFee) {
        this.renPayFee = renPayFee;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

}
