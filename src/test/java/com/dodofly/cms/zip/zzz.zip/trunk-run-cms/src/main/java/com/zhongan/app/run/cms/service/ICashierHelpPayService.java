package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.CashierHelpPayDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayResDTO;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类ICashierHelpPayService.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年1月29日 下午2:10:49
 */
public interface ICashierHelpPayService {
    /**
     * 查询代收代付列表
     * 
     * @param queryDTO
     * @return
     */
    public PageDTO<CashierHelpPayResDTO> queryCashierHelpPayList(CashierHelpPayQueryDTO queryDTO) throws Exception;

    /**
     * 保存、更新
     * 
     * @param cashierHelpPayDTO
     * @return
     */
    public Long saveOrUpdateCashierHelpPay(CashierHelpPayDTO cashierHelpPayDTO) throws Exception;

    /**
     * 查询
     * 
     * @param cashierHelpPayDTO
     * @return
     */
    public List<CashierHelpPayDTO> queryByCondition(CashierHelpPayDTO cashierHelpPayDTO) throws Exception;

    /**
     * 根据id删除数据
     * 
     * @param id
     * @return
     * @throws Exception
     */
    public Integer deleteById(Long id) throws Exception;

    public Integer getUserCashierHelpPayCount(CashierHelpPayQueryDTO queryDTO) throws Exception;
}
