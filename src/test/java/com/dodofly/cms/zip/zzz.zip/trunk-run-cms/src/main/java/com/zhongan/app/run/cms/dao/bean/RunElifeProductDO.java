package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class RunElifeProductDO {
    /**
     * This field corresponds to the column run_elife_product.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 业务规则 This field corresponds to the column run_elife_product.biz_rule
     *
     * @mbggenerated
     */
    private String bizRule;

    /**
     * 业务参数 This field corresponds to the column run_elife_product.biz_value
     *
     * @mbggenerated
     */
    private String bizValue;

    /**
     * 产品ID This field corresponds to the column run_elife_product.product_id
     *
     * @mbggenerated
     */
    private Long   productId;

    /**
     * 产品名称 This field corresponds to the column run_elife_product.product_name
     *
     * @mbggenerated
     */
    private String productName;

    /**
     * 产品版本 This field corresponds to the column
     * run_elife_product.product_version
     *
     * @mbggenerated
     */
    private String productVersion;

    /**
     * 产品连接 This field corresponds to the column run_elife_product.product_link
     *
     * @mbggenerated
     */
    private String productLink;

    /**
     * 产品描述 This field corresponds to the column run_elife_product.product_desc
     *
     * @mbggenerated
     */
    private String productDesc;

    /**
     * 扩展信息,json格式 This field corresponds to the column
     * run_elife_product.extra_info
     *
     * @mbggenerated
     */
    private String extraInfo;

    /**
     * 创建人 This field corresponds to the column run_elife_product.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 创建时间 This field corresponds to the column run_elife_product.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改人 This field corresponds to the column run_elife_product.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 修改时间 This field corresponds to the column run_elife_product.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * This field corresponds to the column run_elife_product.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /** @mbggenerated
     */
    public RunElifeProductDO(Long id, String bizRule, String bizValue, Long productId, String productName,
                             String productVersion, String productLink, String productDesc, String extraInfo,
                             String creator, Date gmtCreated, String modifier, Date gmtModified, String isDeleted) {
        this.id = id;
        this.bizRule = bizRule;
        this.bizValue = bizValue;
        this.productId = productId;
        this.productName = productName;
        this.productVersion = productVersion;
        this.productLink = productLink;
        this.productDesc = productDesc;
        this.extraInfo = extraInfo;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /** @mbggenerated
     */
    public RunElifeProductDO() {
        super();
    }

    /**
     * This method returns the value of the database column run_elife_product.id
     *
     * @return the value of run_elife_product.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column run_elife_product.id
     *
     * @param id the value for run_elife_product.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.biz_rule
     *
     * @return the value of run_elife_product.biz_rule
     * @mbggenerated
     */
    public String getBizRule() {
        return bizRule;
    }

    /**
     * Sets the value of the database column run_elife_product.biz_rule
     *
     * @param bizRule the value for run_elife_product.biz_rule
     * @mbggenerated
     */
    public void setBizRule(String bizRule) {
        this.bizRule = bizRule;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.biz_value
     *
     * @return the value of run_elife_product.biz_value
     * @mbggenerated
     */
    public String getBizValue() {
        return bizValue;
    }

    /**
     * Sets the value of the database column run_elife_product.biz_value
     *
     * @param bizValue the value for run_elife_product.biz_value
     * @mbggenerated
     */
    public void setBizValue(String bizValue) {
        this.bizValue = bizValue;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.product_id
     *
     * @return the value of run_elife_product.product_id
     * @mbggenerated
     */
    public Long getProductId() {
        return productId;
    }

    /**
     * Sets the value of the database column run_elife_product.product_id
     *
     * @param productId the value for run_elife_product.product_id
     * @mbggenerated
     */
    public void setProductId(Long productId) {
        this.productId = productId;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.product_name
     *
     * @return the value of run_elife_product.product_name
     * @mbggenerated
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the database column run_elife_product.product_name
     *
     * @param productName the value for run_elife_product.product_name
     * @mbggenerated
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.product_version
     *
     * @return the value of run_elife_product.product_version
     * @mbggenerated
     */
    public String getProductVersion() {
        return productVersion;
    }

    /**
     * Sets the value of the database column run_elife_product.product_version
     *
     * @param productVersion the value for run_elife_product.product_version
     * @mbggenerated
     */
    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.product_link
     *
     * @return the value of run_elife_product.product_link
     * @mbggenerated
     */
    public String getProductLink() {
        return productLink;
    }

    /**
     * Sets the value of the database column run_elife_product.product_link
     *
     * @param productLink the value for run_elife_product.product_link
     * @mbggenerated
     */
    public void setProductLink(String productLink) {
        this.productLink = productLink;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.product_desc
     *
     * @return the value of run_elife_product.product_desc
     * @mbggenerated
     */
    public String getProductDesc() {
        return productDesc;
    }

    /**
     * Sets the value of the database column run_elife_product.product_desc
     *
     * @param productDesc the value for run_elife_product.product_desc
     * @mbggenerated
     */
    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.extra_info
     *
     * @return the value of run_elife_product.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column run_elife_product.extra_info
     *
     * @param extraInfo the value for run_elife_product.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.creator
     *
     * @return the value of run_elife_product.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column run_elife_product.creator
     *
     * @param creator the value for run_elife_product.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.gmt_created
     *
     * @return the value of run_elife_product.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column run_elife_product.gmt_created
     *
     * @param gmtCreated the value for run_elife_product.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.modifier
     *
     * @return the value of run_elife_product.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column run_elife_product.modifier
     *
     * @param modifier the value for run_elife_product.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.gmt_modified
     *
     * @return the value of run_elife_product.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column run_elife_product.gmt_modified
     *
     * @param gmtModified the value for run_elife_product.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * run_elife_product.is_deleted
     *
     * @return the value of run_elife_product.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column run_elife_product.is_deleted
     *
     * @param isDeleted the value for run_elife_product.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
