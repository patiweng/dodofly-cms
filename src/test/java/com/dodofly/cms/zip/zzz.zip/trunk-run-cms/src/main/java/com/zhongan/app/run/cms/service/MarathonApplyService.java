package com.zhongan.app.run.cms.service;


public interface MarathonApplyService {

    String drawBigPrizes(String chromosphere, String flag);

}
