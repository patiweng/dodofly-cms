package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.zhongan.app.run.cms.bean.web.HistoryBusinessDTO;
import com.zhongan.app.run.cms.bean.web.HistoryBusinessQueryDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.service.HistoryBusinessService;

@RestController
@RequestMapping("/run/cms/historyBusiness")
@Slf4j
public class HistoryBusinessController {
    @Resource
    private HistoryBusinessService businessService;

    @RequestMapping(value = "/queryByCondition", method = RequestMethod.POST)
    public ResultBase<List<HistoryBusinessDTO>> queryByCondition(@RequestBody HistoryBusinessQueryDTO queryDTO) {
        log.info("HistoryBusinessController queryByCondition param:{}", JSON.toJSONString(queryDTO));
        ResultBase<List<HistoryBusinessDTO>> resultBase = new ResultBase<List<HistoryBusinessDTO>>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(businessService.queryByCondition(queryDTO));
        } catch (Exception e) {
            resultBase.setSuccess(Boolean.FALSE);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }
}
