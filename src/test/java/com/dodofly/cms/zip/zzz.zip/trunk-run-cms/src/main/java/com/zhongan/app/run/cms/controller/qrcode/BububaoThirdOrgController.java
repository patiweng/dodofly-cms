package com.zhongan.app.run.cms.controller.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultOrgDto;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdOrgService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.List;

@RestController
@RequestMapping(value = "/run/cms/qrcode/org")
@Slf4j
public class BububaoThirdOrgController {

    @Resource
    private BububaoThirdOrgService bububaoThirdOrgServiceImpl;

    @Resource
    private OssTool                ossTool;

    /**
     * 批量保存机构信息，csv文件导入
     *
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/csv/saveOrgs", method = RequestMethod.POST)
    public BaseResult<String> saveOrgs(HttpServletRequest request, HttpServletResponse response) {
        log.info("{}------------BububaoThirdOrgController.saveOrgs---------start", ThreadLocalUtil.getRequestNo());
        BaseResult<String> result = null;
        try {
            result = bububaoThirdOrgServiceImpl.insertBatchOrgs(request, "files", "csv");
        } catch (Exception e) {
            log.error("{}------------BububaoThirdOrgController.saveOrgs---------exception:", ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdOrgController.saveOrgs---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 分页查询机构信息
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/select/page", method = RequestMethod.POST)
    public BaseResult<PageDTO<ResultOrgDto>> findOrgsPage(@RequestBody ParamDto param) {
        log.info("{}------------BububaoThirdOrgController.findOrgsPage---------start,param:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<PageDTO<ResultOrgDto>> result = null;
        try {
            result = bububaoThirdOrgServiceImpl.findOrgsPage(param);
        } catch (Exception e) {
            log.error("{}------------BububaoThirdOrgController.findOrgsPage---------exception：",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<PageDTO<ResultOrgDto>>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdOrgController.findOrgsPage---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 删除机构信息
     *
     * @param params
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public BaseResult<String> deleteOrgs(@RequestBody List<ParamDto> params) {
        log.info("{}------------BububaoThirdOrgController.deleteOrgs---------start,params:{}",
                ThreadLocalUtil.getRequestNo(), params);
        BaseResult<String> result = null;
        try {
            result = bububaoThirdOrgServiceImpl.deleteBatchOrgs(params);
        } catch (Exception e) {
            log.error("{}------------BububaoThirdOrgController.deleteOrgs---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdOrgController.deleteOrgs---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 导出机构信息
     *
     * @param param
     * @return
     */
    @RequestMapping(value = "/export", method = RequestMethod.POST)
    public BaseResult<String> exportOrgs(@RequestBody ParamDto param) {
        log.info("{}------------BububaoThirdOrgController.exportOrgs---------start,param:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<String> result = null;
        try {
            result = bububaoThirdOrgServiceImpl.exportOrgs(param);
        } catch (Exception e) {
            log.error("{}------------BububaoThirdOrgController.exportOrgs---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdOrgController.exportOrgs---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

}
