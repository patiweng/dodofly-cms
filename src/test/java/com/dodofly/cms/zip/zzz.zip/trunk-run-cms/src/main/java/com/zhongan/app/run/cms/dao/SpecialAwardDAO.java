package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import com.zhongan.app.run.cms.bean.dataobject.SpecialAwardDO;

public interface SpecialAwardDAO {

    /**
     * 根据id查询特殊奖品信息
     * 
     * @param id
     * @return
     */
    SpecialAwardDO selectDataById(Long id);

    /**
     * 根据多个requireid和抽奖次数查询特殊奖品信息
     * 
     * @param map
     * @return
     */
    List<SpecialAwardDO> selectDataByRequireidsAndTimes(Map map);

    /**
     * 新增特殊奖品信息
     * 
     * @param record
     * @return
     */
    long insert(SpecialAwardDO record);

    /**
     * 更新特殊奖品信息
     * 
     * @param record
     * @return
     */
    int update(SpecialAwardDO record);

    /**
     * 分页查询活动奖品规则
     * 
     * @param map
     * @return
     */
    List<SpecialAwardDO> selectSpecialAwardListPage(Map<String, Object> map);

    /**
     * 分页查询总条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map<String, Object> map);

    /**
     * 更具id删除
     * 
     * @param id
     */
    void deleteById(Long id);
}
