package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.web.CashierPayTradeDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeResDTO;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类ICashierHelpPayService.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年1月29日 下午2:10:49
 */
public interface ICashierPayTradeService {
    /**
     * 查询代收代付列表
     * 
     * @param queryDTO
     * @return
     */
    public PageDTO<CashierPayTradeResDTO> queryCashierPayTradeList(CashierPayTradeQueryDTO queryDTO) throws Exception;

    /**
     * 保存，更新
     * 
     * @param payTradeDTO
     * @return
     */
    public Long saveOrUpdateCashierPayTrade(CashierPayTradeDTO payTradeDTO) throws Exception;

    /**
     * 根据条件查询
     * 
     * @param policyNo
     * @return
     */
    public CashierPayTradeResDTO queryCashierPayTradeByCondition(CashierPayTradeDTO payTradeDTO) throws Exception;
}
