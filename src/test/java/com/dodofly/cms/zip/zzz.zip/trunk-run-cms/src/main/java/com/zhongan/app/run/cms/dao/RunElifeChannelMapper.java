package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelCriteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelDO;

public interface RunElifeChannelMapper {
    /** @mbggenerated
     */
    int countByCriteria(RunElifeChannelCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(RunElifeChannelCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from run_elife_channel", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into run_elife_channel (id, channel_type, ", "channel_type_name, channel_id, ",
            "channel_code, channel_name, ", "channel_contact_name, channel_contact__phone, ", "status, extra_info, ",
            "creator, gmt_created, modifier, ", "gmt_modified, is_deleted)",
            "values (#{id,jdbcType=BIGINT}, #{channelType,jdbcType=VARCHAR}, ",
            "#{channelTypeName,jdbcType=VARCHAR}, #{channelId,jdbcType=BIGINT}, ",
            "#{channelCode,jdbcType=VARCHAR}, #{channelName,jdbcType=VARCHAR}, ",
            "#{channelContactName,jdbcType=VARCHAR}, #{channelContactPhone,jdbcType=VARCHAR}, ",
            "#{status,jdbcType=CHAR}, #{extraInfo,jdbcType=VARCHAR}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), #{isDeleted,jdbcType=CHAR})" })
    int insert(RunElifeChannelDO record);

    /** @mbggenerated
     */
    int insertSelective(RunElifeChannelDO record);

    /** @mbggenerated
     */
    List<RunElifeChannelDO> selectByCriteriaWithPage(@Param("criteria") RunElifeChannelCriteria criteria,
                                                     @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<RunElifeChannelDO> selectByCriteria(RunElifeChannelCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select", "id, channel_type, channel_type_name, channel_id, channel_code, channel_name, ",
            "channel_contact_name, channel_contact__phone, status, extra_info, creator, gmt_created, ",
            "modifier, gmt_modified, is_deleted", "from run_elife_channel", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    RunElifeChannelDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") RunElifeChannelDO record,
                                  @Param("criteria") RunElifeChannelCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") RunElifeChannelDO record, @Param("criteria") RunElifeChannelCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(RunElifeChannelDO record);

    /** @mbggenerated
     */
    @Update({ "update run_elife_channel", "set channel_type = #{channelType,jdbcType=VARCHAR},",
            "channel_type_name = #{channelTypeName,jdbcType=VARCHAR},", "channel_id = #{channelId,jdbcType=BIGINT},",
            "channel_code = #{channelCode,jdbcType=VARCHAR},", "channel_name = #{channelName,jdbcType=VARCHAR},",
            "channel_contact_name = #{channelContactName,jdbcType=VARCHAR},",
            "channel_contact__phone = #{channelContactPhone,jdbcType=VARCHAR},", "status = #{status,jdbcType=CHAR},",
            "extra_info = #{extraInfo,jdbcType=VARCHAR},", "creator = #{creator,jdbcType=VARCHAR},",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(RunElifeChannelDO record);
}
