package com.zhongan.app.run.cms.service.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhongan.app.run.cms.bean.client.UserSourceCountClient;
import com.zhongan.app.run.cms.bean.web.ResultBase;

@FeignClient(name = "za-run-user", url = "${za.run.user.feignclient.url}")
public interface RunUserFeignClient {

    @RequestMapping(value = "/run/user/business/queryusersourcebydate/{userDate}", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryUserSourceByDate(@PathVariable("userDate") String userDate);

    @RequestMapping(value = "/run/user/business/queryusersourceall", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryUserSourceAll();

}
