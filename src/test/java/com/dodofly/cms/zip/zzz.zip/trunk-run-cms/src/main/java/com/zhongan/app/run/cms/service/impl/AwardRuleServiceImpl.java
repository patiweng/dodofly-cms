package com.zhongan.app.run.cms.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.stereotype.Service;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.ActivityPresentRepo;
import com.zhongan.app.run.cms.bean.repo.AwardRuleRepo;
import com.zhongan.app.run.cms.bean.repo.BububaoPresentRepo;
import com.zhongan.app.run.cms.bean.web.AwardRuleDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.JodaTimeUtil;
import com.zhongan.app.run.cms.repository.ActivityPresentRepository;
import com.zhongan.app.run.cms.repository.AwardRuleRepository;
import com.zhongan.app.run.cms.repository.RafflePresentRepository;
import com.zhongan.app.run.cms.service.AwardRuleService;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Service("awardRuleServiceImpl")
public class AwardRuleServiceImpl implements AwardRuleService {

    @Resource
    private AwardRuleRepository       awardRuleRepository;
    @Resource
    private RafflePresentRepository   rafflePresentRepository;
    @Resource
    private ActivityPresentRepository activityPresentRepository;
    @Resource
    private RedisUtil                 redisUtil;

    @Override
    public Page<AwardRuleDTO> selectAwardRuleListPage(Page<AwardRuleDTO> page) {
        log.info("{}-AwardRuleRepository.selectAwardRuleListPage start...");
        try {
            Page<AwardRuleRepo> pageRepo = new Page<AwardRuleRepo>();
            BeanUtils.copyProperties(page, pageRepo);
            pageRepo = awardRuleRepository.selectAwardRuleListPage(pageRepo);
            List<AwardRuleRepo> resultList = pageRepo.getResultList();
            List<AwardRuleDTO> awardRuleDTOList = Lists.newArrayList();
            if (resultList != null && resultList.size() > 0) {
                AwardRuleDTO awardRuleDTO = new AwardRuleDTO();
                for (AwardRuleRepo awardRuleRepo : resultList) {
                    AwardRuleDTO clone = (AwardRuleDTO) awardRuleDTO.clone();
                    BeanUtils.copyProperties(awardRuleRepo, clone);
                    clone.setEarliestTime_(formatDate("yyyy-MM-dd HH:mm:ss", clone.getEarliestTime()));
                    clone.setLastestTime_(formatDate("yyyy-MM-dd HH:mm:ss", clone.getLastestTime()));
                    ActivityPresentRepo activityPresentRepo = activityPresentRepository.selectDataById(clone
                            .getActivityPresentId());
                    if (null != activityPresentRepo) {
                        BububaoPresentRepo bububaoPresentRepo = rafflePresentRepository.selectOneDataById(String
                                .valueOf(activityPresentRepo.getPresentId()));
                        if (null != bububaoPresentRepo) {
                            clone.setPresentName(bububaoPresentRepo.getName());//奖品名称，活动奖品规则列表需要展示
                        }
                    }
                    awardRuleDTOList.add(clone);
                }
            }
            page.setResultList(awardRuleDTOList);
            page.setTotalItem(pageRepo.getTotalItem());
            return page;
        } catch (Exception e) {
            log.error("异常AwardRuleServiceImpl.selectAwardRuleListPage  fail……{}", e);
        }
        return null;
    }

    /**
     * 日期格式化字符串
     * 
     * @param date
     * @return
     */
    private String formatDate(String pattern, Date date) {
        if (null == date) {
            return null;
        }
        return new JodaTimeUtil(pattern).format(date);
    }

    private Date parseDateStr(String pattern, String dateStr) {
        if (StringUtil.isBlank(dateStr)) {
            return null;
        }
        return new JodaTimeUtil(pattern).parse(dateStr);
    }

    @Override
    public ResultBase<String> insertAwardRule(AwardRuleDTO awardRuleDTO) {
        log.info("{}-AwardRuleRepository.insertAwardRule start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            if (null != awardRuleDTO) {
                awardRuleDTO.setEarliestTime(parseDateStr("yyyy-MM-dd HH:mm:ss", awardRuleDTO.getEarliestTime_()));
                awardRuleDTO.setLastestTime(parseDateStr("yyyy-MM-dd HH:mm:ss", awardRuleDTO.getLastestTime_()));
            }
            AwardRuleRepo awardRuleRepo = new AwardRuleRepo();
            BeanUtils.copyProperties(awardRuleDTO, awardRuleRepo);
            //新增活动奖品规则表
            awardRuleRepository.insertAwardRule(awardRuleRepo);

            /******* 存入redis *******/
            String key = String.format("bububao_award_rule:%s", awardRuleRepo.getActivityPresentId());
            List<AwardRuleRepo> repoList = awardRuleRepository.selectAllDataByCdt(new AwardRuleRepo(awardRuleRepo
                    .getActivityPresentId()));
            log.info("新增AwardRuleServiceImpl.insertAwardRule,存入redis中的key=={},value=={}", key,
                    JSONObject.toJSONString(repoList));
            redisUtil.put(key, JSONObject.toJSONString(repoList));
            /*
             * String jsonarr = redisUtil.getString(key); if
             * (StringUtil.isNotBlank(jsonarr)) { JSONArray arr =
             * JSONObject.parseArray(jsonarr); arr.add(awardRuleRepo);
             * redisUtil.put(key, arr.toJSONString()); } else { JSONArray arr =
             * new JSONArray(); arr.add(awardRuleRepo); redisUtil.put(key,
             * arr.toJSONString()); }
             */

            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            resultBase.setSuccess(true);
            resultBase.setValue("新增成功");
            return resultBase;
        } catch (BeansException e) {
            log.error("新增异常AwardRuleServiceImpl.insertAwardRule  fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setSuccess(false);
            resultBase.setValue("新增异常");
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> deleteById(Long id) {
        log.info("{}-AwardRuleRepository.deleteById start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            if (null != id) {
                AwardRuleRepo awardRuleRepo = awardRuleRepository.selectAwardRuleOne(String.valueOf(id));
                awardRuleRepository.deleteById(id);//删除

                /******* 更新redis *******/
                String key = String.format("bububao_award_rule:%s", awardRuleRepo.getActivityPresentId());
                List<AwardRuleRepo> repoList = awardRuleRepository.selectAllDataByCdt(new AwardRuleRepo(awardRuleRepo
                        .getActivityPresentId()));
                log.info("删除AwardRuleServiceImpl.deleteById,存入redis中的key=={},value=={}", key,
                        JSONObject.toJSONString(repoList));
                redisUtil.put(key, JSONObject.toJSONString(repoList));
                /*
                 * String jsonarr = redisUtil.getString(key); if
                 * (StringUtil.isNotBlank(jsonarr)) { JSONArray arr =
                 * JSONObject.parseArray(jsonarr); for (int i = 0; i <
                 * arr.size(); i++) { JSONObject obj = (JSONObject) arr.get(i);
                 * String idStr = awardRuleRepo.getId().toString(); if
                 * (idStr.equals(obj.getString("id"))) { arr.remove(i); } }
                 * redisUtil.put(key, arr.toJSONString()); }
                 */

                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
                resultBase.setSuccess(true);
                resultBase.setValue("删除成功");
            } else {
                resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
                resultBase.setSuccess(false);
                resultBase.setValue("id不能为空");
            }
            return resultBase;
        } catch (Exception e) {
            log.error("删除异常AwardRuleServiceImpl.deleteById  fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> updateById(AwardRuleDTO awardRuleDTO) {
        log.info("{}-AwardRuleRepository.updateById start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            if (null != awardRuleDTO && null != awardRuleDTO.getId()) {
                awardRuleDTO.setEarliestTime(parseDateStr("yyyy-MM-dd HH:mm:ss", awardRuleDTO.getEarliestTime_()));
                awardRuleDTO.setLastestTime(parseDateStr("yyyy-MM-dd HH:mm:ss", awardRuleDTO.getLastestTime_()));
                AwardRuleRepo awardRuleRepo = new AwardRuleRepo();
                BeanUtils.copyProperties(awardRuleDTO, awardRuleRepo);
                awardRuleRepository.updateById(awardRuleRepo);

                /******* 存入redis *******/
                String key = String.format("bububao_award_rule:%s", awardRuleRepo.getActivityPresentId());
                List<AwardRuleRepo> repoList = awardRuleRepository.selectAllDataByCdt(new AwardRuleRepo(awardRuleRepo
                        .getActivityPresentId()));
                log.info("更新AwardRuleServiceImpl.updateById,存入redis中的key=={},value=={}", key,
                        JSONObject.toJSONString(repoList));
                redisUtil.put(key, JSONObject.toJSONString(repoList));
                /*
                 * String jsonarr = redisUtil.getString(key); if
                 * (StringUtil.isNotBlank(jsonarr)) { JSONArray arr =
                 * JSONObject.parseArray(jsonarr); for (int i = 0; i <
                 * arr.size(); i++) { JSONObject obj = (JSONObject) arr.get(i);
                 * String id = awardRuleRepo.getId().toString(); if
                 * (id.equals(obj.getString("id"))) { arr.remove(i);
                 * arr.add(awardRuleRepo); } } arr.add(awardRuleRepo);
                 * redisUtil.put(key, arr.toJSONString()); }
                 */

                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
                resultBase.setSuccess(true);
            } else {
                resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
                resultBase.setSuccess(false);
                resultBase.setValue("id不能为空");
            }
        } catch (Exception e) {
            log.error("更新异常AwardRuleServiceImpl.updateById  fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<AwardRuleDTO> selectAwardRuleOne(String id) {
        log.info("{}-AwardRuleRepository.selectAwardRuleOne start...", ThreadLocalUtil.getRequestNo());
        ResultBase<AwardRuleDTO> resultBase = new ResultBase<AwardRuleDTO>();
        try {
            AwardRuleRepo awardRuleRepo = awardRuleRepository.selectAwardRuleOne(id);
            if (null != awardRuleRepo) {
                AwardRuleDTO awardRuleDTO = new AwardRuleDTO();
                BeanUtils.copyProperties(awardRuleRepo, awardRuleDTO);
                awardRuleDTO.setEarliestTime_(formatDate("yyyy-MM-dd HH:mm:ss", awardRuleDTO.getEarliestTime()));
                awardRuleDTO.setLastestTime_(formatDate("yyyy-MM-dd HH:mm:ss", awardRuleDTO.getLastestTime()));
                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
                resultBase.setSuccess(true);
                resultBase.setValue(awardRuleDTO);
                return resultBase;
            }
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
        } catch (Exception e) {
            log.info("AwardRuleRepository.selectAwardRuleOne fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public List<RafflePresentDTO> selectPresentNameList(String activityId) {
        log.info("AwardRuleRepository.selectPresentNameList start……{}", ThreadLocalUtil.getRequestNo());
        List<RafflePresentDTO> dtoList = Lists.newArrayList();
        try {
            List<BububaoPresentRepo> repoList = rafflePresentRepository.selectPresentNameList(activityId);
            if (null != repoList && repoList.size() > 0) {
                RafflePresentDTO rafflePresentDTO = null;
                for (BububaoPresentRepo bububaoPresentRepo : repoList) {
                    rafflePresentDTO = new RafflePresentDTO();
                    BeanUtils.copyProperties(bububaoPresentRepo, rafflePresentDTO);
                    dtoList.add(rafflePresentDTO);
                }
            }
        } catch (Exception e) {
            log.info("AwardRuleRepository.selectPresentNameList fail……{}", e);
        }
        return dtoList;
    }
}
