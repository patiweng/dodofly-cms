package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoEnterpriseShownameDO {
	
	private String id;
	private String enterpriseCode;
	private String showname1;
	private String showname2;
	private String showname3;
	private String showname4;
	private String createTime;
	private String modifyTime;
	

}
