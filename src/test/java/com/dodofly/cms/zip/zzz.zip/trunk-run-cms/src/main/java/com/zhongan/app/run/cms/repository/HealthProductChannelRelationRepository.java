package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.HealthProductChannelRelationDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.HealthProductChannelRelationRepo;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.dao.HealthProductChannelRelationDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Component
public class HealthProductChannelRelationRepository {

    @Resource
    private HealthProductChannelRelationDAO healthProductChannelRelationDAO;

    @Resource
    private Sequence                        seqHealthProductChannelRelation;

    public ResultBase<List<HealthProductChannelRelationDTO>> selectRunCampaignDataRepo(HealthProductChannelRelationRepo healthProductChannelRelationRepo) {
        log.info("{}-select  CampaignList。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        ResultBase<List<HealthProductChannelRelationDTO>> result = new ResultBase<List<HealthProductChannelRelationDTO>>();
        List<HealthProductChannelRelationDTO> listresult = new ArrayList<HealthProductChannelRelationDTO>();

        HealthProductChannelRelationDO healthProductChannelRelationDO = new HealthProductChannelRelationDO();
        BeanUtils.copyProperties(healthProductChannelRelationRepo, healthProductChannelRelationDO);
        List<HealthProductChannelRelationDO> resultlist = healthProductChannelRelationDAO
                .selectDataByCdt(healthProductChannelRelationDO);
        if (resultlist.size() > 0) {
            for (HealthProductChannelRelationDO HealthCampaignListDO : resultlist) {
                HealthProductChannelRelationDTO healthProductChannelRelationDTO = new HealthProductChannelRelationDTO();
                BeanUtils.copyProperties(HealthCampaignListDO, healthProductChannelRelationDTO);
                listresult.add(healthProductChannelRelationDTO);
            }
        }
        result.setSuccess(true);
        result.setValue(listresult);
        return result;
    }

    //分页查询 
    public Page<HealthProductChannelRelationRepo> selectCampaignListPage(Page<HealthProductChannelRelationRepo> healthProductChannelRelationRepoPage) {
        HealthProductChannelRelationDO healthProductChannelRelationDO = new HealthProductChannelRelationDO();
        if (null != healthProductChannelRelationRepoPage.getParam()) {
            BeanUtils.copyProperties(healthProductChannelRelationRepoPage.getParam(), healthProductChannelRelationDO);
        }
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", healthProductChannelRelationRepoPage.getStartRow());
        map.put("pageSize", healthProductChannelRelationRepoPage.getPageSize());
        map.put("healthProductChannelRelationDO", healthProductChannelRelationDO);
        List<HealthProductChannelRelationDO> healthProductChannelRelationDOList = healthProductChannelRelationDAO
                .selectHealthCampaign(map);
        List<HealthProductChannelRelationRepo> bububaoCampaignListRepoList = Lists.newArrayList();
        if (null != healthProductChannelRelationDOList && 0 != healthProductChannelRelationDOList.size()) {
            HealthProductChannelRelationRepo healthProductChannelRelationRepodo = null;
            for (HealthProductChannelRelationDO healthProductChannelRelationDOs : healthProductChannelRelationDOList) {
                healthProductChannelRelationRepodo = new HealthProductChannelRelationRepo();
                BeanUtils.copyProperties(healthProductChannelRelationDOs, healthProductChannelRelationRepodo);
                bububaoCampaignListRepoList.add(healthProductChannelRelationRepodo);
            }
        }
        healthProductChannelRelationRepoPage.setResultList(bububaoCampaignListRepoList);
        Integer counts = healthProductChannelRelationDAO.selectCounts(map);
        healthProductChannelRelationRepoPage.setTotalItem(counts);
        return healthProductChannelRelationRepoPage;
    }

    //插入一条新的记录
    public ResultBase<String> saveCampaignList(HealthProductChannelRelationRepo healthProductChannelRelationRepo)
            throws Exception {
        log.info("{}-insert bububaoCampaignList。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        HealthProductChannelRelationDO healthProductChannelRelationDO = new HealthProductChannelRelationDO();
        BeanUtils.copyProperties(healthProductChannelRelationRepo, healthProductChannelRelationDO);
        Long id = seqHealthProductChannelRelation.nextValue();
        healthProductChannelRelationDO.setId(id.toString());
        healthProductChannelRelationDAO.insert(healthProductChannelRelationDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    //根据主键修改营销活动信息
    public ResultBase<String> updateCampaignList(HealthProductChannelRelationRepo healthProductChannelRelationRepo)
            throws Exception {
        ResultBase<String> result = new ResultBase<String>();
        log.info("{}-update bububaoCampaignList。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        HealthProductChannelRelationDO healthProductChannelRelationDO = new HealthProductChannelRelationDO();
        BeanUtils.copyProperties(healthProductChannelRelationRepo, healthProductChannelRelationDO);
        healthProductChannelRelationDAO.update(healthProductChannelRelationDO);
        result.setSuccess(true);
        result.setValue(RunConstants.UPDATE_TRUE);
        return result;
    }

    //根据id 查询一个对象信息
    public HealthProductChannelRelationRepo selectOneData(String id) {
        HealthProductChannelRelationRepo healthProductChannelRelationRepo = new HealthProductChannelRelationRepo();
        HealthProductChannelRelationDO healthProductChannelRelationDO = healthProductChannelRelationDAO
                .selectOneDataById(id);
        if (healthProductChannelRelationDO != null) {
            BeanUtils.copyProperties(healthProductChannelRelationDO, healthProductChannelRelationRepo);
        }
        return healthProductChannelRelationRepo;
    }

    //根据id 删除信息
    public ResultBase<String> deleteDataById(String id) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            log.info("deleteDataById..id={}", id);
            healthProductChannelRelationDAO.deleteCampaignListById(id);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("Exception when deleteCampaignListById..,e={}", e);
            result.setSuccess(false);
        }
        return result;
    }
}
