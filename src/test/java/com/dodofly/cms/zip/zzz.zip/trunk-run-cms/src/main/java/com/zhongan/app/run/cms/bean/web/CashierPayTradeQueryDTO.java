package com.zhongan.app.run.cms.bean.web;

import java.math.BigDecimal;

import com.zhongan.health.common.share.bean.PageDTO;

public class CashierPayTradeQueryDTO extends PageDTO<CashierHelpPayQueryDTO> {
    /**
     * 
     */
    private static final long serialVersionUID = 1921882240174214677L;

    /**
     * 手机号
     */
    private String            phone;
    /**
     * 身份证号
     */
    private String            certNo;
    /**
     * 渠道
     */
    private String            openChannel;
    /**
     * 保单号
     */
    private String            policyNo;

    /**
     * 扣款金额
     */
    private BigDecimal        deductionsPay;

    /**
     * 扣款次数
     */
    private Long              deductionsNum;

    /**
     * 扣款开始日期
     */
    private String            startTime;

    /**
     * 扣款结束日期
     */
    private String            endTime;

    /**
     * 扣款状态
     */
    private Long              deductionsStatus;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    public String getOpenChannel() {
        return openChannel;
    }

    public void setOpenChannel(String openChannel) {
        this.openChannel = openChannel;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public BigDecimal getDeductionsPay() {
        return deductionsPay;
    }

    public void setDeductionsPay(BigDecimal deductionsPay) {
        this.deductionsPay = deductionsPay;
    }

    public Long getDeductionsNum() {
        return deductionsNum;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public void setDeductionsNum(Long deductionsNum) {
        this.deductionsNum = deductionsNum;
    }

    public Long getDeductionsStatus() {
        return deductionsStatus;
    }

    public void setDeductionsStatus(Long deductionsStatus) {
        this.deductionsStatus = deductionsStatus;
    }

}
