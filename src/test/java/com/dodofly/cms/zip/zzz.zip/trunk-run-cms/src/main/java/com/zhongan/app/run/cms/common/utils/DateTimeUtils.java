package com.zhongan.app.run.cms.common.utils;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Interval;
import org.joda.time.LocalDate;
import org.joda.time.Minutes;
import org.joda.time.Months;
import org.joda.time.Seconds;
import org.joda.time.Years;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

public class DateTimeUtils {
    /**
     * yyyyMMdd
     */
    public static final String DATE_FORMAT_YYYYMMDD          = "yyyyMMdd";
    /**
     * yyyy-MM-dd
     */
    public static final String ZH_CN_DATE_PATTERN            = "yyyy-MM-dd";

    /**
     * yyyy-MM-dd HH:mm:ss:S
     */
    public static final String ZH_CN_DATETIME_PATTERN_SSS    = "yyyy-MM-dd HH:mm:ss.SSS";

    /**
     * yyyy-MM-dd HH:mm:ss
     */
    public static final String ZH_CN_DATETIME_PATTERN        = "yyyy-MM-dd HH:mm:ss";

    /**
     * yyyyMMddHHmmss
     */
    public static final String NOMARK_DATETIME_PATTERN       = "yyyyMMddHHmmss";
    /**
     * yyyy-MM-dd HH:mm
     */
    public static final String ZH_CN_HH_MM_DATETIME_PATTERN  = "yyyy-MM-dd HH:mm";
    /**
     * yyyyMMddHHmm
     */
    public static final String NOMARK_HH_MM_DATETIME_PATTERN = "yyyyMMddHHmm";

    /**
     * 将时间字符串转换为指定格式DateTime
     * 
     * @param patternStr 转换时间格式
     * @param timeStr 转换的时间字符串
     * @return DateTime
     */
    public static DateTime parseTime(String patternStr, String timeStr) {
        DateTimeFormatter format = DateTimeFormat.forPattern(patternStr);
        DateTime dateTime = DateTime.parse(timeStr, format);
        return dateTime;
    }

    /**
     * 将时间字符串转换为指定格式字符串
     * 
     * @param patternStr 转换时间格式
     * @param timeStr 转换的时间字符串
     * @return String
     */
    public static String formatTime(String patternStr, String timeStr) {
        DateTimeFormatter format = DateTimeFormat.forPattern(patternStr);
        DateTime dateTime = DateTime.parse(timeStr, format);
        return dateTime.toString(patternStr);
    }

    /**
     * 将DateTime转换为指定地区的时间格式字符串
     * 
     * @param time 初始化的DateTime时间对象
     * @param patternStr 转换时间格式
     * @param locale 地区编码
     * @return String
     */
    public static String formatTime(DateTime time, String patternStr, Locale locale) {
        String formatTime = time.toString(patternStr, locale);
        return formatTime;

    }

    /**
     * 将初始化的datetime转换为指定格式的DateTime对象
     * 
     * @param dateTime 初始化的DateTime对象
     * @param patternStr 指定的时间转换格式
     * @return DateTime
     */
    public static DateTime parseTime(DateTime dateTime, String patternStr) {
        DateTimeFormatter format = DateTimeFormat.forPattern(patternStr);
        String dateTimeStr = dateTime.toString(patternStr);
        DateTime returnTime = DateTime.parse(dateTimeStr, format);
        return returnTime;
    }

    /**
     * 获取指定格式的当前时间DateTime
     * 
     * @param patternStr 指定时间格式
     * @return DateTime
     */
    public static DateTime parseCurrentTime(String patternStr) {
        DateTime dateTime = new DateTime();
        return parseTime(dateTime, patternStr);
    }

    /**
     * 获取指定格式的当前时间的字符串
     * 
     * @param patternStr 指定时间格式
     * @return String
     */
    public static String formatCurrentTime(String patternStr) {
        DateTime dateTime = new DateTime();
        return dateTime.toString(patternStr);
    }

    /**
     * 获取当前系统时间(String类型的yyyy-MM-dd HH:mm:ss)
     * 
     * @return
     */
    public static String getCurrentTimeString() {
        Date currentDate = new Date();
        JodaTimeUtil jt = new JodaTimeUtil(ZH_CN_DATETIME_PATTERN);
        String dateString = jt.format(currentDate);
        return dateString;
    }

    /**
     * 获取两个日期之间的间隔天数
     * 
     * @param start
     * @param end
     * @return
     */
    public static int getDays(LocalDate start, LocalDate end) {
        int days = Days.daysBetween(start, end).getDays();
        return days;
    }

    /**
     * 判断是否闰月
     * 
     * @param dateTime
     * @return
     */
    public static boolean isLeapMonth(DateTime dateTime) {
        org.joda.time.DateTime.Property month = dateTime.monthOfYear();
        return month.isLeap();
    }

    /**
     * 判断是否闰年
     * 
     * @param dateTime
     * @return
     */
    public static boolean isLeapYear(DateTime dateTime) {
        return dateTime.year().isLeap();
    }

    /**
     * 获取两个时间之间的毫秒数
     * 
     * @param beginDateTime
     * @param endDateTime
     * @return
     */
    public static long getMillis(DateTime beginDateTime, DateTime endDateTime) {
        Interval interval = new Interval(beginDateTime, endDateTime);
        return interval.toDurationMillis();
    }

    /**
     * 获取两个时间具体相隔数 时，分，秒，年，月，日
     * 
     * @param startDate
     * @param endDate
     * @param pattern
     * @return
     */
    public static int getDateTimeBetween(DateTime startDate, DateTime endDate, String pattern) {
        if ("Y".equals(pattern)) {
            return Years.yearsBetween(startDate, endDate).getYears();
        } else if ("MM".equals(pattern)) {
            return Months.monthsBetween(startDate, endDate).getMonths();
        } else if ("D".equals(pattern)) {
            return Days.daysBetween(startDate, endDate).getDays();
        } else if ("H".equals(pattern)) {
            return Hours.hoursBetween(startDate, endDate).getHours();
        } else if ("MI".equals(pattern)) {
            return Minutes.minutesBetween(startDate, endDate).getMinutes();
        } else if ("S".equals(pattern)) {
            return Seconds.secondsBetween(startDate, endDate).getSeconds();
        }
        return 0;
    }

    /**
     * date to string
     * 
     * @param date
     * @param format
     * @return
     */
    public static String convertDate2String(Date date, String format) {

        if (date == null) {
            return "";
        }

        if (StringUtils.isEmpty(format)) {
            format = ZH_CN_DATE_PATTERN;
        }

        DateTime dateTime = new DateTime(date);
        String dateStr = dateTime.toString(format);

        return dateStr;
    }

    /**
     * @param time1
     * @param time2
     * @return
     */
    public static int compare_time(String time1, String time2) throws Exception {
        SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
        Date date1 = df.parse(time1);
        Date date2 = df.parse(time2);
        if (date1.getTime() > date2.getTime()) {
            return 1;
        } else if (date1.getTime() < date2.getTime()) {
            return -1;
        } else {
            return 0;
        }
    }

    /**
     * 将date转化成String(yyyy-MM-dd)
     * 
     * @param date
     * @return
     */
    public static String covertDateToString(Date date) {
        if (date == null)
            return null;
        JodaTimeUtil jt = new JodaTimeUtil(ZH_CN_DATE_PATTERN);
        return jt.format(date);
    }

    /**
     * 将date转化成String(yyyy-MM-dd hh:mi:ss)
     * 
     * @param date
     * @return
     */
    public static String covertTimeToString(Date date) {
        if (date == null)
            return null;
        JodaTimeUtil jt = new JodaTimeUtil(ZH_CN_DATETIME_PATTERN);
        return jt.format(date);
    }

    /**
     * 将String转化成date(yyyy-MM-dd hh:mm:ss)
     * 
     * @param date
     * @return
     */
    public static Date covertStringToTime(String date) {
        if (StringUtils.isBlank(date)) {
            return null;
        }
        JodaTimeUtil jt = new JodaTimeUtil(ZH_CN_DATETIME_PATTERN);
        return jt.parse(date);
    }

    /**
     * 将String转化成date(yyyy-MM-dd)
     * 
     * @param date
     * @return
     */
    public static Date covertStringToDate(String date) {
        if (StringUtils.isBlank(date)) {
            return null;
        }
        JodaTimeUtil jt = new JodaTimeUtil(ZH_CN_DATE_PATTERN);
        return jt.parse(date);
    }

    /**
     * 增加若干天数后的日期(String类型yyyy-MM-dd)
     * 
     * @param dateString
     * @param months
     * @return
     */
    public static String dateStringAddDays(String dateString, int days) {
        Date date = covertStringToDate(dateString);
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_YEAR, days);
        return covertDateToString(cal.getTime());
    }

    public static String getCurrentDateString() {
        Date currentDate = new Date();
        JodaTimeUtil jt = new JodaTimeUtil(ZH_CN_DATE_PATTERN);
        String dateString = jt.format(currentDate);
        return dateString;
    }

    public static List<Date> getDatesBetweenTwoDate(Date beginDate, Date endDate) {
        List<Date> lDate = new ArrayList<Date>();
        lDate.add(beginDate);// 把开始时间加入集合        
        Calendar cal = Calendar.getInstance(); // 使用给定的 Date 设置此 Calendar 的时间        
        cal.setTime(beginDate);
        boolean bContinue = true;
        while (bContinue) { // 根据日历的规则，为给定的日历字段添加或减去指定的时间量           
            cal.add(Calendar.DAY_OF_YEAR, 1); // 测试此日期是否在指定日期之后            
            if (endDate.after(cal.getTime())) {
                lDate.add(cal.getTime());
            } else {
                break;
            }
        }
        lDate.add(endDate);// 把结束时间加入集合        return lDate;
        return lDate;
    }

    /**
     * 将String转化成date
     * 
     * @param date
     * @return
     */
    public static Date covertStringToTime(String date, String format) {
        if (StringUtils.isBlank(date)) {
            return null;
        }
        if (StringUtils.isBlank(format)) {
            format = ZH_CN_DATETIME_PATTERN;
        }
        JodaTimeUtil jt = new JodaTimeUtil(format);
        return jt.parse(date);
    }
}
