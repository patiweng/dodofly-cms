package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.web.CashierNotifyDetailDTO;
import com.zhongan.app.run.cms.conver.CashierNotifyDetailConvert;
import com.zhongan.app.run.cms.dao.CashierNotifyDetailMapper;
import com.zhongan.app.run.cms.dao.bean.CashierNotifyDetailCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierNotifyDetailCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.CashierNotifyDetailDO;
import com.zhongan.app.run.cms.service.ICashierNotifyDetailService;

@Service("cashierNotifyDetailService")
public class CashierNotifyDetailServiceImpl implements ICashierNotifyDetailService {

    @Resource
    private CashierNotifyDetailMapper cashierNotifyDetailMapper;

    @Resource
    private Sequence                  seqCashierNotifyDetail;

    @Override
    public Long saveOrUpdate(CashierNotifyDetailDTO notifyDetailDTO) throws Exception {
        List<CashierNotifyDetailDO> cashierNotifyDetailDOs = cashierNotifyDetailMapper
                .selectByCriteria(buildCriteria(notifyDetailDTO));
        if (CollectionUtils.isEmpty(cashierNotifyDetailDOs)) {
            long nextValue = seqCashierNotifyDetail.nextValue();
            CashierNotifyDetailDO cashierNotifyDetailDO = CashierNotifyDetailConvert.convertToDO(notifyDetailDTO);
            cashierNotifyDetailDO.setId(nextValue);
            cashierNotifyDetailMapper.insert(cashierNotifyDetailDO);
            return nextValue;
        } else {
            notifyDetailDTO.setId(cashierNotifyDetailDOs.get(0).getId());
            cashierNotifyDetailMapper.updateByPrimaryKeySelective(CashierNotifyDetailConvert
                    .convertToDO(notifyDetailDTO));
            return cashierNotifyDetailDOs.get(0).getId();
        }
    }

    @Override
    public List<CashierNotifyDetailDTO> queryByCondition(CashierNotifyDetailDTO notifyDetailDTO) {
        List<CashierNotifyDetailDO> cashierNotifyDetailDOs = cashierNotifyDetailMapper
                .selectByCriteria(buildCriteria(notifyDetailDTO));
        return CashierNotifyDetailConvert.convertToDTOs(cashierNotifyDetailDOs);
    }

    private CashierNotifyDetailCriteria buildCriteria(CashierNotifyDetailDTO notifyDetailDTO) {
        CashierNotifyDetailCriteria detailCriteria = new CashierNotifyDetailCriteria();
        Criteria createCriteria = detailCriteria.createCriteria();
        if (StringUtils.isNotEmpty(notifyDetailDTO.getThirdOrderNo())) {
            createCriteria.andThirdOrderNoEqualTo(notifyDetailDTO.getThirdOrderNo());
        }
        return detailCriteria;
    }

}
