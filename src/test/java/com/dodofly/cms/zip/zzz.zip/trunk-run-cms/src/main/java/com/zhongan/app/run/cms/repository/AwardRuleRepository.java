package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.dataobject.AwardRuleDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.AwardRuleRepo;
import com.zhongan.app.run.cms.dao.AwardRuleDAO;

@Repository
public class AwardRuleRepository {

    @Resource
    private AwardRuleDAO awardRuleDAO;

    public Page<AwardRuleRepo> selectAwardRuleListPage(Page<AwardRuleRepo> page) throws CloneNotSupportedException {
        AwardRuleDO awardRuleDO = new AwardRuleDO();
        BeanUtils.copyProperties(page.getParam(), awardRuleDO);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", page.getStartRow());
        map.put("pageSize", page.getPageSize());
        map.put("awardRuleDO", awardRuleDO);
        List<AwardRuleDO> awardRuleDOList = awardRuleDAO.selectAwardRuleListPage(map);
        List<AwardRuleRepo> awardRuleRepoList = Lists.newArrayList();
        if (awardRuleDOList != null && awardRuleDOList.size() > 0) {
            AwardRuleRepo awardRuleRepo = new AwardRuleRepo();
            for (AwardRuleDO awardRuleDO__ : awardRuleDOList) {
                AwardRuleRepo clone = (AwardRuleRepo) awardRuleRepo.clone();
                BeanUtils.copyProperties(awardRuleDO__, clone);
                awardRuleRepoList.add(clone);
            }
        }
        page.setResultList(awardRuleRepoList);
        Integer count = awardRuleDAO.selectCounts(map);
        page.setTotalItem(count);
        return page;
    }

    public Long insertAwardRule(AwardRuleRepo awardRuleRepo) {
        AwardRuleDO awardRuleDO = new AwardRuleDO();
        BeanUtils.copyProperties(awardRuleRepo, awardRuleDO);
        return awardRuleDAO.insert(awardRuleDO);
    }

    public void deleteById(Long id) {
        awardRuleDAO.deleteById(id);
    }

    public void updateById(AwardRuleRepo awardRuleRepo) {
        AwardRuleDO awardRuleDO = new AwardRuleDO();
        BeanUtils.copyProperties(awardRuleRepo, awardRuleDO);
        awardRuleDAO.update(awardRuleDO);
    }

    public AwardRuleRepo selectAwardRuleOne(String id) {
        if (StringUtil.isNotBlank(id)) {
            AwardRuleDO awardRuleDO = awardRuleDAO.selectDataById(Long.valueOf(id));
            if (null != awardRuleDO) {
                AwardRuleRepo awardRuleRepo = new AwardRuleRepo();
                BeanUtils.copyProperties(awardRuleDO, awardRuleRepo);
                return awardRuleRepo;
            }
        }
        return null;
    }

    public List<AwardRuleRepo> selectAllDataByCdt(AwardRuleRepo awardRuleRepo) {
        List<AwardRuleRepo> repoList = Lists.newArrayList();
        AwardRuleRepo repo = null;
        AwardRuleDO awardRuleDO = new AwardRuleDO();
        BeanUtils.copyProperties(awardRuleRepo, awardRuleDO);
        List<AwardRuleDO> doList = awardRuleDAO.selectAllDataByCdt(awardRuleDO);
        if (null != doList && doList.size() > 0) {
            for (AwardRuleDO awardRuleDO2 : doList) {
                repo = new AwardRuleRepo();
                BeanUtils.copyProperties(awardRuleDO2, repo);
                repoList.add(repo);
            }
        }
        return repoList;
    }
}
