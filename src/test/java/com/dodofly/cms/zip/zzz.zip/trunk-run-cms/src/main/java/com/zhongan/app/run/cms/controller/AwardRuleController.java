package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AwardRuleDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.AwardRuleService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 类AwardRuleController.java的实现描述：活动奖品规则controller
 * 
 * @author panchuanhe 2017年3月10日 上午11:38:20
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class AwardRuleController {

    @Resource
    private AwardRuleService awardRuleServiceImpl;

    /**
     * 分页查询活动奖品规则列表
     * 
     * @param awardRuleDTO
     * @param request
     * @return
     */
    @RequestMapping(value = "/select/selectawardrulelistpage")
    public ModelAndView selectAwardRuleListPage(AwardRuleDTO awardRuleDTO, HttpServletRequest request) {
        log.info("{}-info/select/selectawardrulelistpage,param={" + awardRuleDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        Page<AwardRuleDTO> page = new Page<AwardRuleDTO>(awardRuleDTO.getPageSize(), awardRuleDTO.getCurrentPage());
        page.setParam(awardRuleDTO);
        page = awardRuleServiceImpl.selectAwardRuleListPage(page);
        /*  List<RafflePresentDTO> presentDTOList = awardRuleServiceImpl
                  .selectPresentNameList(awardRuleDTO.getActivityId());*/
        Map<String, Object> model = Maps.newHashMap();
        model.put("awardRuleList", page.getResultList());
        model.put("awardRuleDTO", awardRuleDTO);
        //        model.put("presentList", presentDTOList);
        model.put("page", page);
        log.info("{}-/select/selectawardrulelistpage return, data={" + page.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/awardrule", model);
    }

    /**
     * 新增活动奖品规则
     * 
     * @param awardRuleDTO
     * @return
     */
    @RequestMapping(value = "/insert/insertawardrule", method = RequestMethod.POST)
    public ResultBase<String> insertAwardRule(AwardRuleDTO awardRuleDTO) {
        log.info("{}-info/insert/insertawardrule,param={" + awardRuleDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        if (null != awardRuleDTO.getId()) {
            //更新
            return awardRuleServiceImpl.updateById(awardRuleDTO);
        }
        //新增
        return awardRuleServiceImpl.insertAwardRule(awardRuleDTO);
    }

    @RequestMapping(value = "/delete/deletebyid", method = RequestMethod.POST)
    public ResultBase<String> deleteById(AwardRuleDTO awardRuleDTO) {
        log.info("{}-info/delete/deleteById", ThreadLocalUtil.getRequestNo());
        return awardRuleServiceImpl.deleteById(awardRuleDTO.getId());
    }

    /**
     * 根据id查询一条
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/select/selectawardruleone", method = RequestMethod.GET)
    public AwardRuleDTO selectAwardRuleOne(String id) {
        ResultBase<AwardRuleDTO> selectAwardRuleOne = awardRuleServiceImpl.selectAwardRuleOne(id);
        return selectAwardRuleOne.getValue();
    }
}
