package com.zhongan.app.run.cms.common.excelutil.cellconver;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.zhongan.app.run.cms.common.excelutil.annotion.CellConvert;
import com.zhongan.app.run.cms.common.excelutil.utils.BeanAnnotionUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DefaultCellConvert implements CellConvert {

    private static final Logger log = LoggerFactory.getLogger(DefaultCellConvert.class);

    public <T> T readConvert(Map<String, Cell> map, Class<T> clazz) {

        try {
            T t = clazz.newInstance();
            Iterator<java.util.Map.Entry<String, Cell>> it= map.entrySet().iterator();

            Map<String, BeanAnnotionUtils.PropertyDesc> proMap = BeanAnnotionUtils.getBeanAnnotion(clazz);
            boolean isAllNull = true;
            while(it.hasNext()){
                java.util.Map.Entry<String, Cell> entry = it.next();
                BeanAnnotionUtils.PropertyDesc pd = proMap.get(entry.getKey());
                if(pd != null){
                    if(pd.setValue(t, entry.getValue())){
                        isAllNull = false;
                    };
                }
            }
            if(isAllNull){
                return null;
            }
            return t;
        } catch (Exception e) {
            log.error("error",e);
            throw new RuntimeException("cell转换bean失败", e);
        }

    }

    @Override
    public <T> void writeConvertHead(Class<T> clazz, Sheet sheet) {
        Row head = sheet.createRow(0);
        Set<String> set = BeanAnnotionUtils.getBeanAnnotion(clazz).keySet();
        int i = 0;
        for(String title : set){
            head.createCell(i++).setCellValue(title);
        }
    }

    @Override
    public <T> void writeConvertContent(List<T> dataList, Class<T> clazz, Sheet sheet) {

        Collection<BeanAnnotionUtils.PropertyDesc> coll = BeanAnnotionUtils.getBeanAnnotion(clazz).values();
        for(int i = 0; i < dataList.size(); i++){
            Row dataRow = sheet.createRow(i + 1);
            int j = 0;
            for(BeanAnnotionUtils.PropertyDesc pd : coll){
                dataRow.createCell(j++).setCellValue(pd.getValue(dataList.get(i)));
            }
        }
    }

}
