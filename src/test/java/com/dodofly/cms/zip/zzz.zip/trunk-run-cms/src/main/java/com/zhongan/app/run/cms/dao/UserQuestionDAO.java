package com.zhongan.app.run.cms.dao;

import java.util.List;

import com.zhongan.app.run.cms.bean.dataobject.UserQuestionDO;

public interface UserQuestionDAO {
    /**
     * 根据id查询
     * 
     * @param id
     * @return
     */
    UserQuestionDO selectDataById(Long id);

    /**
     * 根据条件查询
     * 
     * @param userQuestionDO
     * @return
     */
    List<UserQuestionDO> selectDataByCdt(UserQuestionDO userQuestionDO);

    /**
     * 插入
     * 
     * @param userQuestionDO
     */
    void insert(UserQuestionDO userQuestionDO);
}
