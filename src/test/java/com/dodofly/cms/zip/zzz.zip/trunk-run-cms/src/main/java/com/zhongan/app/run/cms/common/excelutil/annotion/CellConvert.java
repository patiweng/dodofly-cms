package com.zhongan.app.run.cms.common.excelutil.annotion;

import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;

/**
 * @Description: Convert  将cell转换成bean
 * @author lichao002 2016年7月5日 下午6:16:12
 */
public interface CellConvert {

    /**
     * @Title: readConvert
     * @Description: 读取转换
     * @author lichao002
     * @param map
     * @param clazz
     * @return
     */
    public <T> T readConvert(Map<String, Cell> map, Class<T> clazz);

    /**
     * @Title: writeConvertHead
     * @Description: 写入excel头
     * @author lichao002
     * @param clazz
     * @param sheet
     */
    public <T> void writeConvertHead(Class<T> clazz, Sheet sheet);

    /**
     * @Title: writeConvertContent
     * @Description: 写入excel行
     * @author lichao002
     * @param dataList
     * @param clazz
     * @param sheet
     */
    public <T> void writeConvertContent(List<T> dataList, Class<T> clazz, Sheet sheet);
}
