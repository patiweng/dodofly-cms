package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.bean.dataobject.BububaoEmployeePinyinDO;

@Component
public interface BububaoEmployeePinyinDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoEmployeePinyinDO> selectDataByCdt(BububaoEmployeePinyinDO bububaoEmployeePinyinDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoEmployeePinyinDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoEmployeePinyinDO
	    */
	   void insert(BububaoEmployeePinyinDO bububaoEmployeePinyinDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoEmployeePinyinDO
	    */
	   void update(BububaoEmployeePinyinDO bububaoEmployeePinyinDO);
}
