package com.zhongan.app.run.cms.dao;

import java.util.List;

import com.zhongan.app.run.cms.bean.dataobject.CmsAuthorityDO;

public interface CmsAuthorityDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<CmsAuthorityDO> selectDataByCdt(CmsAuthorityDO cmsAuthorityDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   CmsAuthorityDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param CmsAuthorityDO
	    */
	   void insert(CmsAuthorityDO cmsAuthorityDO);
	   
	   /**
	    * 更新数据
	    * @param CmsAuthorityDO
	    */
	   void update(CmsAuthorityDO cmsAuthorityDO);
}
