package com.zhongan.app.run.cms.common.utils;

import java.util.Date;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;

/**
 * 用joda-time替代SimpleDateFormat
 * @author songchengsong
 *
 */
public class JodaTimeUtil {

    private String pattern;

    /**
     * 用此构造函数new对象
     * 
     * @param pattern 类似SimpleDateFormat的用法，如："E yyyy-MM-dd HH:mm:ss.SSS"
     */
    public JodaTimeUtil(String pattern) {
        this.pattern = pattern;
    }

    /**
     * String -> Date
     * 
     * @param source
     * @return
     */
    public Date parse(String source) {
        return DateTimeFormat.forPattern(this.pattern).parseLocalDateTime(source).toDate();
    }

    /**
     * Date -> String
     * 
     * @param date
     * @return
     */
    public String format(Date date) {
        return new DateTime(date).toString(this.pattern);
    }

}
