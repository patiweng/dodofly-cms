package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class UserLoginDTO {
	private String userName;
	private String userPassword;
	private String errCode;
	private String errMsg;
}
