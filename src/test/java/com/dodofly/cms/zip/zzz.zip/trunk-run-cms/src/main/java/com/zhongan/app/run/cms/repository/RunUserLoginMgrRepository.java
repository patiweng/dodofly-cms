package com.zhongan.app.run.cms.repository;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.CmsUserDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCmsUserDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.MD5Util;
import com.zhongan.app.run.cms.dao.CmsUserDAO;

@Component
@Slf4j
public class RunUserLoginMgrRepository {
    @Resource
    private CmsUserDAO cmsUserDAO;

    /**
     * 验证用户名密码是否正确
     * 
     * @param userName
     * @param password
     * @return
     */
    public ResultBase<RunCmsUserDTO> checkLogin(String userName, String password) {
        ResultBase<RunCmsUserDTO> result = new ResultBase<RunCmsUserDTO>();
        try {
            password = MD5Util.md5(password);
        } catch (Exception e) {
            log.error("checkLogin  fail===={}", e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100011.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100011.getValue());
            return result;
        }
        CmsUserDO qryDO = new CmsUserDO();
        qryDO.setLoginName(userName);
        qryDO.setLoginPassword(password);
        CmsUserDO userDO = cmsUserDAO.selectByNameAndPwd(qryDO);
        if (userDO == null) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100001.getValue());
            return result;
        }
        RunCmsUserDTO runCmsUserDTO = new RunCmsUserDTO();
        runCmsUserDTO.setUserId(userDO.getId());
        result.setValue(runCmsUserDTO);
        result.setSuccess(true);
        return result;
    }

    /**
     * 修改密码
     * 
     * @param userName
     * @param oPwd
     * @param nPwd
     * @return
     */
    public ResultBase<String> editPasswd(String userName, String oPwd, String nPwd) {
        ResultBase<String> result = new ResultBase<String>();
        /* 查询原密码是否正确 */
        ResultBase<RunCmsUserDTO> checkRs = checkLogin(userName, oPwd);
        if (!checkRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100001.getValue());
            return result;
        }
        RunCmsUserDTO userDTO = checkRs.getValue();
        String id = userDTO.getUserId();
        String newPassword = "";
        try {
            newPassword = MD5Util.md5(nPwd);
        } catch (Exception e) {
            log.error("editPasswd  fail===={}", e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100011.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100011.getValue());
            return result;
        }
        CmsUserDO cmsUserDO = new CmsUserDO();
        cmsUserDO.setId(id);
        cmsUserDO.setLoginPassword(newPassword);
        cmsUserDAO.update(cmsUserDO);
        result.setSuccess(true);
        return result;
    }

}
