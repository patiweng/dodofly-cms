package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoUserSourceDO {
    private String id;
    private String unionId;
    private String source;
    private String openId;
    private String accessToken;
    private String refreshToken;
    private String refreshTokenEndTime;
    private String identityName;
    private String identity;
    private String phone;
    private String sex;
    private String birthday;
    private String card;
    private String nickName;
    private String headImgUrl;
    private String tempIdentity;
    private String tempIdentityName;
    private String tempPhone;
    private String status;
    private String createTime;
    private String modifyTime;
}
