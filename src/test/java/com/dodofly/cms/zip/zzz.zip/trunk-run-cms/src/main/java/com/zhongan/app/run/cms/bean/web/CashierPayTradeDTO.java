package com.zhongan.app.run.cms.bean.web;

import java.math.BigDecimal;

public class CashierPayTradeDTO {
    /**
     * 主键
     */
    private Long       id;

    /**
     * 代收代付ID
     */
    private Long       cashierId;

    /**
     * 保单号
     */
    private String     policyNo;

    /**
     * 订单号
     */
    private String     insuredId;

    /**
     * 扣款金额
     */
    private BigDecimal deductionsPay;

    /**
     * 扣款次数
     */
    private Long       deductionsNum;

    /**
     * 扣款日期
     */
    private String     deductionsDate;

    /**
     * 扣款状态
     */
    private Long       deductionsStatus;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCashierId() {
        return cashierId;
    }

    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public BigDecimal getDeductionsPay() {
        return deductionsPay;
    }

    public void setDeductionsPay(BigDecimal deductionsPay) {
        this.deductionsPay = deductionsPay;
    }

    public Long getDeductionsNum() {
        return deductionsNum;
    }

    public void setDeductionsNum(Long deductionsNum) {
        this.deductionsNum = deductionsNum;
    }

    public String getDeductionsDate() {
        return deductionsDate;
    }

    public void setDeductionsDate(String deductionsDate) {
        this.deductionsDate = deductionsDate;
    }

    public Long getDeductionsStatus() {
        return deductionsStatus;
    }

    public void setDeductionsStatus(Long deductionsStatus) {
        this.deductionsStatus = deductionsStatus;
    }

    public String getInsuredId() {
        return insuredId;
    }

    public void setInsuredId(String insuredId) {
        this.insuredId = insuredId;
    }
}
