package com.zhongan.app.run.cms.bean.web;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class AnalysisBusinessDTO implements Cloneable {

    private Long    id;
    private String  sourceCode;   //渠道编码
    private String  sourceName;   //渠道名称
    private String  analysDate;   //统计日期
    private Long    addGrant;     //新增授权数
    private Long    addInsure;    //新增投保数
    private String  insureRate;   //投保转化率
    private Long    grantAll;     //累计授权数
    private Long    insureAll;    //累计投保数
    private String  insureAllRate; //累计投保转化率
    private String  isDone;       //是否完成 0-否  1-是
    private String  activeCount;  //活跃人数
    private String  activePercent; //活跃度

    private Integer pageSize;
    private Integer currentPage;
    private String  sdate;
    private String  edate;
    private String  bopsFlag;

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            log.error("clone  fail===={}", e);
        }
        return null;
    }

}
