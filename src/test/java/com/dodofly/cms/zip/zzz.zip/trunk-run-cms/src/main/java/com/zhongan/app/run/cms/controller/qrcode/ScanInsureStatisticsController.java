package com.zhongan.app.run.cms.controller.qrcode;


import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoExportLogDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.StatisticsParamDto;
import com.zhongan.app.run.cms.service.qrcode.ScanInsureStatisticsService;
import com.zhongan.app.run.cms.service.qrcode.StatisticsDetailService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类ScanInsureStatisticsController.java的实现描述：统计接口
 * 
 * @author zhangjin 2018年6月5日 下午4:35:13
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/qrcode")
public class ScanInsureStatisticsController {

    @Resource
    private ScanInsureStatisticsService scanInsureStatisticsServiceImpl;

    @Resource
    private StatisticsDetailService     statisticsDetailServiceImpl;

    /**
     * 分页查询扫码投保统计
     * 
     * @param param
     * @return
     */
    @RequestMapping(value = "/selectScanInsureStatisticsPage", method = RequestMethod.POST)
    public BaseResult<PageDTO<ResultInsureDto>> selectScanInsureStatisticsPage(@RequestBody StatisticsParamDto param) {
        log.info("{}-info/selectScanInsureStatisticsPageDTO,param={" + param.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        BaseResult<PageDTO<ResultInsureDto>> result = new BaseResult<PageDTO<ResultInsureDto>>();
            result = scanInsureStatisticsServiceImpl.selectStatisticsPage(param);
        log.info("{}-/select/selectScanInsureStatisticsPageDTO return, data={" + result.getResult() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }
    /**
     * 分页查询扫码投保统计明细
     * 
     * @param param
     * @return
     */
    @RequestMapping(value = "/selectStatisticsDetailPage", method = RequestMethod.POST)
    public BaseResult<PageDTO<ResultInsureDto>> selectStatisticsDetailPage(@RequestBody StatisticsParamDto param) {
        log.info("{}-info/selectStatisticsDetailPageDTO,param={" + param.toString() + "}", ThreadLocalUtil.getRequestNo());
        BaseResult<PageDTO<ResultInsureDto>> result = new BaseResult<PageDTO<ResultInsureDto>>();
            result = statisticsDetailServiceImpl.selectStatisticsDetailPage(param);
        log.info("{}-/select/selectScanInsureStatisticsPageDTO return, data={" +  result.getResult() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 异步查询历史页面（导出管理表查询）
     * 
     * @param bububaoExportLogDto
     * @return
     */
    @RequestMapping(value = "/asyncQueryHistory", method = RequestMethod.POST)
    public BaseResult<PageDTO<BububaoExportLogDto>> asyncQueryHistory(@RequestBody BububaoExportLogDto bububaoExportLogDto) {
        log.info("{}-info/asyncQueryHistory,param={" + bububaoExportLogDto.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        BaseResult<PageDTO<BububaoExportLogDto>> result = new BaseResult<PageDTO<BububaoExportLogDto>>();
        result = scanInsureStatisticsServiceImpl.asyncQueryHistory(bububaoExportLogDto);
        log.info("{}-/asyncQueryHistory return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据主键删除导出管理表,并删除OSS里的文件
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/deleteExportLog/{id}", method = RequestMethod.GET)
    public BaseResult<String> deleteExportLog(@PathVariable Long id) {
        log.info("{}-/deleteExportLog, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        BaseResult<String> result = new BaseResult<String>();
        result = scanInsureStatisticsServiceImpl.deleteExportLog(id);
        log.info("{}-/deleteExportLog return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 导出扫码投保统计excel
     * 
     * @param statisticsParamDto
     * @return
     */
    @RequestMapping(value = "/downLoadReports", method = RequestMethod.POST)
    public BaseResult<String> downLoadReports(@RequestBody StatisticsParamDto statisticsParamDto) {
        log.info("{}-info/doExportExcel--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(statisticsParamDto));
        BaseResult<String> result = new BaseResult<String>();
        result = scanInsureStatisticsServiceImpl.downLoadReports(statisticsParamDto);
        log.info("{}-/doexportexcel return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 导出扫码投保统计明细excel
     * 
     * @param statisticsParamDto
     * @return
     */
    @RequestMapping(value = "/downLoadReportsDetail", method = RequestMethod.POST)
    public BaseResult<String> downLoadReportsDetail(@RequestBody StatisticsParamDto statisticsParamDto) {
        log.info("{}-info/downLoadReportsDetail--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(statisticsParamDto));
        BaseResult<String> result = new BaseResult<String>();
        result = statisticsDetailServiceImpl.downLoadReports(statisticsParamDto);
        log.info("{}-/downLoadReportsDetail return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }


}
