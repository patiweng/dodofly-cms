package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.service.MarathonApplyService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 小米马拉松
 * 
 * @author zhangjin 2017年9月5日 下午4:28:38
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/marathon")
public class MarathonApplyController {
    @Resource
    private MarathonApplyService marathonApplyServiceImpl;

    /*
     * 马拉松大奖中奖号
     */
    @RequestMapping(value = "/generativeaward/{chromosphere}/{flag}", method = RequestMethod.GET)
    public String drawBigPrizes(@PathVariable String chromosphere, @PathVariable String flag) {
        log.info("{}-/generativeaward/{chromosphere}, chromosphere={ " + chromosphere + " },flag={ " + flag + " }",
                ThreadLocalUtil.getRequestNo());
        String result = marathonApplyServiceImpl.drawBigPrizes(chromosphere, flag);
        log.info("{}-/generativeaward/{chromosphere} return, data={" + result + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

}
