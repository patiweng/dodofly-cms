package com.zhongan.app.run.cms.dao.bean;

import java.math.BigDecimal;
import java.util.Date;

public class CashierNotifyDetailDO {
    /**
     * 主键 This field corresponds to the column bububao_cashier_notify_detail.id
     *
     * @mbggenerated
     */
    private Long       id;

    /**
     * 代收代付ID This field corresponds to the column
     * bububao_cashier_notify_detail.cashier_id
     *
     * @mbggenerated
     */
    private Long       cashierId;

    /**
     * 订单号 This field corresponds to the column
     * bububao_cashier_notify_detail.order_no
     *
     * @mbggenerated
     */
    private String     orderNo;

    /**
     * 订单号 This field corresponds to the column
     * bububao_cashier_notify_detail.third_order_no
     *
     * @mbggenerated
     */
    private String     thirdOrderNo;

    /**
     * 渠道用户号 This field corresponds to the column
     * bububao_cashier_notify_detail.pay_channel_user_no
     *
     * @mbggenerated
     */
    private String     payChannelUserNo;

    /**
     * 订单金额 This field corresponds to the column
     * bububao_cashier_notify_detail.amt
     *
     * @mbggenerated
     */
    private BigDecimal amt;

    /**
     * 订单时间 This field corresponds to the column
     * bububao_cashier_notify_detail.order_time
     *
     * @mbggenerated
     */
    private Date       orderTime;

    /**
     * 回调信息,json格式 This field corresponds to the column
     * bububao_cashier_notify_detail.notify_info
     *
     * @mbggenerated
     */
    private String     notifyInfo;

    /**
     * 扩展信息,json格式 This field corresponds to the column
     * bububao_cashier_notify_detail.extra_info
     *
     * @mbggenerated
     */
    private String     extraInfo;

    /**
     * 创建人 This field corresponds to the column
     * bububao_cashier_notify_detail.creator
     *
     * @mbggenerated
     */
    private String     creator;

    /**
     * 创建时间 This field corresponds to the column
     * bububao_cashier_notify_detail.gmt_created
     *
     * @mbggenerated
     */
    private Date       gmtCreated;

    /**
     * 修改人 This field corresponds to the column
     * bububao_cashier_notify_detail.modifier
     *
     * @mbggenerated
     */
    private String     modifier;

    /**
     * 修改时间 This field corresponds to the column
     * bububao_cashier_notify_detail.gmt_modified
     *
     * @mbggenerated
     */
    private Date       gmtModified;

    /**
     * 是否删除 This field corresponds to the column
     * bububao_cashier_notify_detail.is_deleted
     *
     * @mbggenerated
     */
    private String     isDeleted;

    /** @mbggenerated
     */
    public CashierNotifyDetailDO(Long id, Long cashierId, String orderNo, String thirdOrderNo, String payChannelUserNo,
                                 BigDecimal amt, Date orderTime, String notifyInfo, String extraInfo, String creator,
                                 Date gmtCreated, String modifier, Date gmtModified, String isDeleted) {
        this.id = id;
        this.cashierId = cashierId;
        this.orderNo = orderNo;
        this.thirdOrderNo = thirdOrderNo;
        this.payChannelUserNo = payChannelUserNo;
        this.amt = amt;
        this.orderTime = orderTime;
        this.notifyInfo = notifyInfo;
        this.extraInfo = extraInfo;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /** @mbggenerated
     */
    public CashierNotifyDetailDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.id
     *
     * @return the value of bububao_cashier_notify_detail.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_cashier_notify_detail.id
     *
     * @param id the value for bububao_cashier_notify_detail.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.cashier_id
     *
     * @return the value of bububao_cashier_notify_detail.cashier_id
     * @mbggenerated
     */
    public Long getCashierId() {
        return cashierId;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.cashier_id
     *
     * @param cashierId the value for bububao_cashier_notify_detail.cashier_id
     * @mbggenerated
     */
    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.order_no
     *
     * @return the value of bububao_cashier_notify_detail.order_no
     * @mbggenerated
     */
    public String getOrderNo() {
        return orderNo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.order_no
     *
     * @param orderNo the value for bububao_cashier_notify_detail.order_no
     * @mbggenerated
     */
    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.third_order_no
     *
     * @return the value of bububao_cashier_notify_detail.third_order_no
     * @mbggenerated
     */
    public String getThirdOrderNo() {
        return thirdOrderNo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.third_order_no
     *
     * @param thirdOrderNo the value for
     *            bububao_cashier_notify_detail.third_order_no
     * @mbggenerated
     */
    public void setThirdOrderNo(String thirdOrderNo) {
        this.thirdOrderNo = thirdOrderNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.pay_channel_user_no
     *
     * @return the value of bububao_cashier_notify_detail.pay_channel_user_no
     * @mbggenerated
     */
    public String getPayChannelUserNo() {
        return payChannelUserNo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.pay_channel_user_no
     *
     * @param payChannelUserNo the value for
     *            bububao_cashier_notify_detail.pay_channel_user_no
     * @mbggenerated
     */
    public void setPayChannelUserNo(String payChannelUserNo) {
        this.payChannelUserNo = payChannelUserNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.amt
     *
     * @return the value of bububao_cashier_notify_detail.amt
     * @mbggenerated
     */
    public BigDecimal getAmt() {
        return amt;
    }

    /**
     * Sets the value of the database column bububao_cashier_notify_detail.amt
     *
     * @param amt the value for bububao_cashier_notify_detail.amt
     * @mbggenerated
     */
    public void setAmt(BigDecimal amt) {
        this.amt = amt;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.order_time
     *
     * @return the value of bububao_cashier_notify_detail.order_time
     * @mbggenerated
     */
    public Date getOrderTime() {
        return orderTime;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.order_time
     *
     * @param orderTime the value for bububao_cashier_notify_detail.order_time
     * @mbggenerated
     */
    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.notify_info
     *
     * @return the value of bububao_cashier_notify_detail.notify_info
     * @mbggenerated
     */
    public String getNotifyInfo() {
        return notifyInfo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.notify_info
     *
     * @param notifyInfo the value for bububao_cashier_notify_detail.notify_info
     * @mbggenerated
     */
    public void setNotifyInfo(String notifyInfo) {
        this.notifyInfo = notifyInfo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.extra_info
     *
     * @return the value of bububao_cashier_notify_detail.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.extra_info
     *
     * @param extraInfo the value for bububao_cashier_notify_detail.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.creator
     *
     * @return the value of bububao_cashier_notify_detail.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.creator
     *
     * @param creator the value for bububao_cashier_notify_detail.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.gmt_created
     *
     * @return the value of bububao_cashier_notify_detail.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.gmt_created
     *
     * @param gmtCreated the value for bububao_cashier_notify_detail.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.modifier
     *
     * @return the value of bububao_cashier_notify_detail.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.modifier
     *
     * @param modifier the value for bububao_cashier_notify_detail.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.gmt_modified
     *
     * @return the value of bububao_cashier_notify_detail.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.gmt_modified
     *
     * @param gmtModified the value for
     *            bububao_cashier_notify_detail.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_notify_detail.is_deleted
     *
     * @return the value of bububao_cashier_notify_detail.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_notify_detail.is_deleted
     *
     * @param isDeleted the value for bububao_cashier_notify_detail.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
