package com.zhongan.app.run.cms.bean.bo;

import java.util.Date;

import lombok.Data;

@Data
public class UserPropertyBO {

    private Long    id;

    private Long    unionid;

    private Date    registerTime;

    private Date    loginTime;

    private Integer renewalTimes;

    private Integer totalRenewalTimes;

    private Integer payTimes;

    private Double  payMoney;

    private Integer freeTimes;

    private Integer presentTimes;

    private Date    newPresentTime;

    private Integer totalAliveDays;

    private Integer newAliveDays;

    private Date    createtime;

    private Date    modifytime;

}
