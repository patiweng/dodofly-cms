package com.zhongan.app.run.cms.dao;

import java.util.List;

import com.zhongan.app.run.cms.bean.dataobject.UserPropertyDO;

public interface UserPropertyDAO {

    /**
     * 根据id查询用户属性
     * 
     * @param id
     * @return
     */
    UserPropertyDO selectDataById(Long id);

    /**
     * 根据条件查询用户属性
     * 
     * @param record
     * @return
     */
    List<UserPropertyDO> selectDataByCdt(UserPropertyDO record);

    /**
     * 新增用户属性
     * 
     * @param record
     * @return
     */
    long insert(UserPropertyDO record);

    /**
     * 更新用户属性
     * 
     * @param record
     * @return
     */
    int update(UserPropertyDO record);

}
