package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoPresentDO;

@Component
public interface BububaoActivityDAO {

    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<BububaoActivityDO> selectDataByCdt(BububaoActivityDO bububaoActivityDO);

    /**
     * 根据id查询数据
     * 
     * @param id
     * @return
     */
    BububaoActivityDO selectOneDataById(String id);
    /**
     * 分页查询BububaoActivityDO信息
     * 
     * @param map
     * @return
     */
    List<BububaoActivityDO> selectBububaoActivityList(Map map);
    /**
     * 查询BububaoActivityDO条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);
    /**
     * 插入数据
     * 
     * @param BububaoActivityDO
     */
    void insert(BububaoActivityDO bububaoActivityDO);

    /**
     * 更新数据
     * 
     * @param BububaoActivityDO
     */
    void update(BububaoActivityDO bububaoActivityDO);
    /**
     * 更新数据 - 后台
     * 
     * @param BububaoActivityDO
     */
    void updatedata(BububaoActivityDO bububaoActivityDO);

    /**
     * 更新数据 或奖次数 +1
     * 
     * @param BububaoActivityDO
     */
    void updateById(String id);
    
    /**
     * 更新数据为无效数据
     * 
     * @param id
     */
    void updateByid(String id);
}
