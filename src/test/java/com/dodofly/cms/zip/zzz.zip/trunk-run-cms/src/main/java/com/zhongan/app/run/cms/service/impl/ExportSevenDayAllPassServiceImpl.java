package com.zhongan.app.run.cms.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.dataobject.BububaoUserSourceDO;
import com.zhongan.app.run.cms.bean.dataobject.UserAllStepDO;
import com.zhongan.app.run.cms.bean.dataobject.UserStepCountDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.utils.ReadExcel;
import com.zhongan.app.run.cms.repository.RunUserSourceRepository;
import com.zhongan.app.run.cms.repository.UserStepRepository;
import com.zhongan.app.run.cms.repository.UserTargetRepository;
import com.zhongan.app.run.cms.service.ExportSevenDayAllPassService;
import com.zhongan.app.run.cms.service.client.RunStepFeignClient;
import com.zhongan.app.run.common.utils.AppUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class ExportSevenDayAllPassServiceImpl implements ExportSevenDayAllPassService {
    @Resource
    private RunUserSourceRepository runUserSourceRepository;
    @Resource
    private UserStepRepository      userStepRepository;
    @Resource
    private UserTargetRepository    userTargetRepository;
    @Resource
    private RunStepFeignClient      runStepFeignClient;

    @Override
    public void doExcelExportSevenDayAllPass(HttpServletResponse response, String sdate, String edate, String sourceCode) {
        // TODO Auto-generated method stub
        log.info("{}-doExcelExportSevenDayAllPass start……", ThreadLocalUtil.getRequestNo());
        try {

            DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            String nowDate = df.format(new Date());

            Map<String, String> sourceMap = new HashMap<String, String>();
            sourceMap.put("sourceCode", sourceCode);
            List<BububaoUserSourceDO> sourceList = runUserSourceRepository.selectUserSourceBySource(sourceMap);

            List<String> dateArray = Lists.newArrayList();
            dateArray = AppUtil.getDateArray(sdate, edate);
            log.info("----------------------选择时间范围内包含的天数：" + dateArray.size());

            Map<String, BububaoUserSourceDO> usersourceMap = new HashMap<String, BububaoUserSourceDO>();
            for (BububaoUserSourceDO sourceDO : sourceList) {
                usersourceMap.put(sourceDO.getUnionId(), sourceDO);
            }

            List<String> userIdList = Lists.newArrayList();
            for (String unionId : usersourceMap.keySet()) {
                Map<String, String> map = new HashMap<String, String>();
                map.put("sdate", sdate);
                map.put("edate", edate);
                map.put("unionId", unionId);
                map.put("isFree", "1");

                List<UserStepCountDO> stepCountList = userStepRepository.selectUserStepCountByDateAndUnionid(map);
                for (UserStepCountDO userStepCountDO : stepCountList) {
                    if (userStepCountDO.getCountStep() == dateArray.size()) {
                        userIdList.add(unionId);
                        break;
                    }
                }
            }

            //构建excel
            String path = this.getClass().getResource("/static/excel/SevenDayAllPassReg.xlsx").getPath();
            InputStream is = this.getClass().getResourceAsStream("/static/excel/SevenDayAllPassReg.xlsx");
            log.info("excel模版的路径为=================" + path);
            Workbook workbook = new XSSFWorkbook(is);
            if (workbook == null) {
                log.info("workbook对象为null");
            }
            Sheet sheet = workbook.getSheetAt(0);//获取页签
            BububaoUserSourceDO userSourceDo = null;
            Map<String, String> unionMap = new HashMap<String, String>();
            if (null != userIdList && userIdList.size() > 0) {
                for (int i = 0; i < userIdList.size(); i++) {
                    unionMap.put("unionId", userIdList.get(i));
                    unionMap.put("sourceCode", sourceCode);
                    List<BububaoUserSourceDO> userList = runUserSourceRepository.selectSourceByUnionId(unionMap);

                    userSourceDo = userList.get(0);

                    ResultBase<String> resultTarget = runStepFeignClient.getUserTargetStep(userIdList.get(i), nowDate);
                    if (resultTarget.getValue().equals("")) {
                        log.info("----------------七天全部达标：目标步数为空。unionId:" + userIdList.get(i));
                    }

                    //第一行不用copy
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    Row rowx = sheet.getRow(3 + i);
                    rowx.getCell(0).setCellValue(i + 1);//序列号
                    rowx.getCell(1).setCellValue(userSourceDo.getIdentityName());//用户名
                    rowx.getCell(2).setCellValue(userSourceDo.getPhone());//手机号
                    if (resultTarget == null || resultTarget.getValue() == null) {
                        rowx.getCell(3).setCellValue("");
                    } else {
                        rowx.getCell(3).setCellValue(resultTarget.getValue());
                    }

                }
            }

            String title = "七天全达标用户";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {
            log.error("{}-doExcelExportSevenDayAllPass fail……", e, ThreadLocalUtil.getRequestNo());
        }
    }

    @Override
    public void doExportExcelTop100AllSteps(HttpServletResponse response, String sdate, String edate, String sourceCode) {
        log.info("{}-doExportExcelTop100AllSteps start……", ThreadLocalUtil.getRequestNo());
        try {

            Map<String, String> map = new HashMap<String, String>();
            map.put("sdate", sdate);
            map.put("edate", edate);
            map.put("sourceCode", sourceCode);
            List<UserAllStepDO> stepList = userStepRepository.selectUserAllStepByDate(map);
            log.info("-----------------------------------stepList:" + stepList.toString());
            log.info("-----------------------------------stepListArray:" + stepList.toArray().toString());
            //构建excel
            String path = this.getClass().getResource("/static/excel/AllStepTop100.xlsx").getPath();
            InputStream is = this.getClass().getResourceAsStream("/static/excel/AllStepTop100.xlsx");
            log.info("excel模版的路径为=================" + path);
            Workbook workbook = new XSSFWorkbook(is);
            if (workbook == null) {
                log.info("workbook对象为null");
            }
            Sheet sheet = workbook.getSheetAt(0);//获取页签
            BububaoUserSourceDO userParam = new BububaoUserSourceDO();
            BububaoUserSourceDO userSourceDo = null;
            Map<String, String> unionMap = new HashMap<String, String>();
            if (null != stepList && stepList.size() > 0) {

                for (int i = 0; i < stepList.size(); i++) {

                    unionMap.put("userId", stepList.get(i).getUserId());
                    unionMap.put("sourceCode", sourceCode);
                    List<BububaoUserSourceDO> userList = runUserSourceRepository.selectSourceByUserId(unionMap);
                    userSourceDo = userList.get(0);
                    if (userSourceDo.getPhone().equals("")) {
                        log.info("--------------------------------phone is null。userid：" + stepList.get(i).getUserId());
                    }

                    //第一行不用copy
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    Row rowx = sheet.getRow(3 + i);

                    rowx.getCell(0).setCellValue(
                            userSourceDo.getIdentityName() == null ? "" : userSourceDo.getIdentityName());//用户名
                    rowx.getCell(1).setCellValue(userSourceDo.getPhone());//手机号
                    rowx.getCell(2).setCellValue(
                            stepList.get(i).getAllSteps() == null ? "" : stepList.get(i).getAllSteps());//累计用户步数
                    rowx.getCell(3).setCellValue(i + 1);//序列号

                }

            }

            String title = "累计步数排名前100名";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {
            log.error("{}-doExportExcelTop100AllSteps fail……", e, ThreadLocalUtil.getRequestNo());
        }
    }

}
