package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RaffleActivityRepo;
import com.zhongan.app.run.cms.bean.web.RaffleActivityDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.dao.BububaoActivityDAO;

@Slf4j
@Component
public class RaffleActivityRepository {

    @Resource
    private BububaoActivityDAO bububaoActivityDAO;

    @Resource
    private Sequence           seqActivity;

    public ResultBase<List<RaffleActivityDTO>> selectActivityList(RaffleActivityRepo raffleActivityRepo) {
        log.info("{}-select  RaffleActivity。。。Repository。。。");
        ResultBase<List<RaffleActivityDTO>> result = new ResultBase<List<RaffleActivityDTO>>();
        List<RaffleActivityDTO> listresult = new ArrayList<RaffleActivityDTO>();
        BububaoActivityDO bububaoActivityDO = new BububaoActivityDO();
        BeanUtils.copyProperties(raffleActivityRepo, bububaoActivityDO);
        List<BububaoActivityDO> resultlist = bububaoActivityDAO.selectDataByCdt(bububaoActivityDO);
        if (resultlist.size() > 0) {
            for (BububaoActivityDO bububaoActivity : resultlist) {
                RaffleActivityDTO raffleActivityDTO = new RaffleActivityDTO();
                BeanUtils.copyProperties(bububaoActivity, raffleActivityDTO);
                listresult.add(raffleActivityDTO);
            }
        }
        result.setSuccess(true);
        result.setValue(listresult);
        return result;
    }

    
  //分页
	
  	public Page<RaffleActivityRepo> selectActivityDataPage(Page<RaffleActivityRepo> raffleActivityRepoPage){
  		
  		BububaoActivityDO bububaoActivityDO = new BububaoActivityDO();
          if (null != raffleActivityRepoPage.getParam()) {
              BeanUtils.copyProperties(raffleActivityRepoPage.getParam(), bububaoActivityDO);
          }
          bububaoActivityDO.setIsDeleted(RunConstants.IS_STATUS);
          Map<String, Object> map = Maps.newHashMap();
          map.put("startRow", raffleActivityRepoPage.getStartRow());
          map.put("pageSize", raffleActivityRepoPage.getPageSize());
          map.put("bububaoActivityDO", bububaoActivityDO);
          List<BububaoActivityDO> bububaoActivityDOList = bububaoActivityDAO.selectBububaoActivityList(map);
          List<RaffleActivityRepo> raffleActivityRepoList = Lists.newArrayList();
          if (null != bububaoActivityDOList && 0 != bububaoActivityDOList.size()) {
        	  RaffleActivityRepo raffleActivity= null;
              for (BububaoActivityDO bububaoActivityDOlists : bububaoActivityDOList) {
            	  raffleActivity = new RaffleActivityRepo();
                  BeanUtils.copyProperties(bububaoActivityDOlists, raffleActivity);
                  raffleActivityRepoList.add(raffleActivity);
              }
          }
          raffleActivityRepoPage.setResultList(raffleActivityRepoList);
          Integer counts = bububaoActivityDAO.selectCounts(map);
          raffleActivityRepoPage.setTotalItem(counts);
          return raffleActivityRepoPage;	
  	}

    //根据ID查询单条记录	
    public RaffleActivityRepo selectRaffleActivityById(String id) {
        RaffleActivityRepo raffleActivityRepo = null;
        BububaoActivityDO bububaoActivityDO = bububaoActivityDAO.selectOneDataById(id);
        if (null != bububaoActivityDO) {
            raffleActivityRepo = new RaffleActivityRepo();
            BeanUtils.copyProperties(bububaoActivityDO, raffleActivityRepo);
        }
        return raffleActivityRepo;
    }
    
    //根据ID查询单条记录	后台
    public RaffleActivityDTO selectActivityByid(String id) {
    	RaffleActivityDTO raffleActivityDTO = new RaffleActivityDTO();
        log.info("select activitybyid ...Repository");
        BububaoActivityDO bububaoActivityDO = bububaoActivityDAO.selectOneDataById(id);
        if (bububaoActivityDO != null) {
            BeanUtils.copyProperties(bububaoActivityDO, raffleActivityDTO);
        }
        return raffleActivityDTO;
    }
    
    //删除信息
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        bububaoActivityDAO.updateByid(id);
        result.setSuccess(true);
        return result;
    }

    public List<RaffleActivityRepo> selectActivitiesByCdt(RaffleActivityRepo activityRepo) {
        BububaoActivityDO activityDO = new BububaoActivityDO();
        BeanUtils.copyProperties(activityRepo, activityDO);
        List<BububaoActivityDO> activityDOs = bububaoActivityDAO.selectDataByCdt(activityDO);
        List<RaffleActivityRepo> activityRepos = new ArrayList<RaffleActivityRepo>();
        if (0 != activityDOs.size()) {
            RaffleActivityRepo activityRepoOut = null;
            for (BububaoActivityDO activityDOOut : activityDOs) {
                activityRepoOut = new RaffleActivityRepo();
                BeanUtils.copyProperties(activityDOOut, activityRepoOut);
                activityRepos.add(activityRepoOut);
            }
        }
        return activityRepos;
    }

    //根据活动Id修改获奖次数+1	
    public void updateDataById(String id) {
        bububaoActivityDAO.updateById(id);
    }

    //插入一条新的记录
    public ResultBase<String> saveActivity(RaffleActivityRepo raffleActivityRepo) throws Exception {
        log.info("{}-insert bububaoActivity。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        BububaoActivityDO bububaoActivityDO = new BububaoActivityDO();
        BeanUtils.copyProperties(raffleActivityRepo, bububaoActivityDO);
        Long id = seqActivity.nextValue();
        bububaoActivityDO.setId(id.toString());
        bububaoActivityDAO.insert(bububaoActivityDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    //根据主键修改信息

    public ResultBase<String> updateActivityList(RaffleActivityRepo raffleActivityRepo) throws Exception {
        ResultBase<String> result = new ResultBase<String>();
        log.info("{}-update bububaoActivity。。。Repository。。。");
        BububaoActivityDO bububaoActivityDO = new BububaoActivityDO();
        BeanUtils.copyProperties(raffleActivityRepo, bububaoActivityDO);
        bububaoActivityDAO.updatedata(bububaoActivityDO);
        result.setSuccess(true);
        return result;
    }

}
