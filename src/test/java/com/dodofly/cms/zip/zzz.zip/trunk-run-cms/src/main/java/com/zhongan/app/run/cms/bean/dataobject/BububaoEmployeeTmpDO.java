package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
//企业用户企业架构及层级展示列表
public class BububaoEmployeeTmpDO {
	
	private String id;
	private String companyToken;
	private String level1;
	private String level2;
	private String level3;
	private String level4;
	private String phone;
	private String name;
	private String createTime;
	private String modifyTime;

}
