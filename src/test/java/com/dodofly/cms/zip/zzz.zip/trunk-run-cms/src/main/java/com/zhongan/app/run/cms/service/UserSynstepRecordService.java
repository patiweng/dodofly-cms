package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.BububaoUserSynstepRecordDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserCarveUpLoginRecordDTO;
import com.zhongan.app.run.cms.bean.web.UserCarveUpLoginRecordParamDTO;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 用户登陆记录
 * 
 * @author yangzhen001
 */
public interface UserSynstepRecordService {

    ResultBase<Integer> insertUserSynstepRecord(BububaoUserSynstepRecordDTO info);

    ResultBase<List<BububaoUserSynstepRecordDTO>> selectUserSynstepRecord(BububaoUserSynstepRecordDTO info);

    PageDTO<UserCarveUpLoginRecordDTO> selectUserCarveUpRewardDetilInfo(UserCarveUpLoginRecordParamDTO info);

    ResultBase<String> deleteSynStepRecordByDays(List<String> dateList, int days);

}
