package com.zhongan.app.run.cms.service.qrcode;

import java.util.List;

/**
 * 导出日志管理接口 service
 * 
 * @author lichao002
 * @date 2018-06-04
 */
public interface BububaoExportLogService {

    public void batchSaveExportLog();

    public List findExportLogsPage();
}
