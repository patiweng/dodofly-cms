package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoMarketingActivitiesDO {

    private String id;
    private String activitiesType;
    private String activityCode;
    private String activitiesName;
    private String activitiesIcon;
    private String activitiesUrl;
    private String isselfFlag;
    private String disOrder;
    private String startTime;
    private String endTime;
    private String minStep;
    private String maxStep;
    private String allChannel;
    private String creator;
    private String modifier;
    private String gmtCreated;
    private String gmtModified;
    private String isDeleted;
    private String userStep;
    private String activityId;
    private String activityMark;
}
