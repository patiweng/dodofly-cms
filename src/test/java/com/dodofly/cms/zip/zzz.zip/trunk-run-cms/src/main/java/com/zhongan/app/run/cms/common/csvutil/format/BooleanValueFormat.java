package com.zhongan.app.run.cms.common.csvutil.format;

import com.zhongan.app.run.cms.common.csvutil.annotion.ValueFormat;

public class BooleanValueFormat extends ValueFormat {
    @Override
    public Object readFormat(Object value, Class<?> propertyClass, String propertyName) {
        if(value == null){
            return null;
        }
        if("isFollowBububao".equals(propertyName) || "isLeader".equals(propertyName)){
            if("是".equals(value.toString()))
                return "Y";
            else
                return "N";
        }
        return value;
    }

    @Override
    public String writeFormat(Object value, Class<?> propertyClass, String propertyName) {
        if(value == null){
            return null;
        }

        return value.toString();
    }
}
