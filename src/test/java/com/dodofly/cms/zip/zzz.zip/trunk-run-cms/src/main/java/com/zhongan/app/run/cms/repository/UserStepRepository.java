package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.UserAllStepDO;
import com.zhongan.app.run.cms.bean.dataobject.UserStepCountDO;
import com.zhongan.app.run.cms.bean.dataobject.UserStepDO;
import com.zhongan.app.run.cms.dao.UserStepDAO;

/**
 * 用户步数组件
 * 
 * @author songchengsong 2016年11月21日 下午4:27:10
 */
@Component
@Slf4j
public class UserStepRepository {

    @Resource
    private UserStepDAO userStepDAO;

    public List<UserStepDO> selectUserStepByDate(Map map) {

        return userStepDAO.selectUserStepByDate(map);

    }

    public List<UserStepCountDO> selectUserStepCountByDateAndUnionid(Map map) {
        return userStepDAO.selectUserStepCountByDateAndUnionid(map);
    }

    public List<UserAllStepDO> selectUserAllStepByDate(Map map) {
        return userStepDAO.selectUserAllStepByDate(map);
    }

}
