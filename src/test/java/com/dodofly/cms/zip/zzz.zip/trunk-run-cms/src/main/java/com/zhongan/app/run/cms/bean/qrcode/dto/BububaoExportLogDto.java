package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

import java.util.Date;

/**
 * BububaoExportLogDto.java的实现描述：异步下载页面返回
 * 
 * @author zhangjin 2018年6月6日 上午10:53:03
 */
@Data
public class BububaoExportLogDto {

    /**
     * 导出id
     */
    private Long    id;

    /**
     * 模块code 1 机构 2 业务员 3 扫码统计 4 扫码明细
     */
    private Short   moduleCode;

    /**
     * 时间条件
     */
    private String  timeCondition;
    /**
     * 业务员条件
     */
    private String  salesCodeCondition;
    /**
     * 机构条件
     */
    private String  orgCondition;

    /**
     * 下载地址
     */
    private String  downloadUrl;

    /**
     * 创建时间
     */
    private String  gmtCreated;

    /**
     * 当前页
     */
    private Integer currentPage;

    /**
     * 每页条数
     */
    private Integer pageSize;

}
