package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.client.BububaoActivityRuleClient;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.ActivityRuleInfoDTO;
import com.zhongan.app.run.cms.bean.web.BububaoActivityRuleDTO;
import com.zhongan.app.run.cms.bean.web.BububaoActivityRulePageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.ActivityRuleService;
import com.zhongan.app.run.cms.service.client.RunActivityFeignClient;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.PageDTO;

@Service
@Slf4j
public class ActivityRuleServiceImpl implements ActivityRuleService {

    @Resource
    private RunActivityFeignClient   runActivityFeignClient;
    @Resource
    private RunChannelListRepository runChannelListRepository;

    /**
     * 查询活动规则配置信息
     */
    @Override
    public ResultBase<List<BububaoActivityRuleDTO>> queryActivityRuleByCdt(BububaoActivityRuleDTO info) {
        ResultBase<List<BububaoActivityRuleDTO>> result = new ResultBase<List<BububaoActivityRuleDTO>>();
        try {
            BububaoActivityRuleClient client = new BububaoActivityRuleClient();
            BeanUtils.copyProperties(info, client);
            result = runActivityFeignClient.queryActivityRuleByCdt(client);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-when queryActivityRuleByCdt, error:{}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 插入活动规则配置信息
     * 
     * @param info
     * @return
     */
    @Override
    public ResultBase<String> insertActivityRuleInfo(BububaoActivityRuleDTO info) {
        ResultBase<String> result = new ResultBase<>();
        try {
            result = runActivityFeignClient.insertActivityRuleInfo(info);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-when insertActivityRuleInfo, error:{}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 跟新活动规则配置信息
     * 
     * @param info
     * @return
     */
    @Override
    public ResultBase<String> updateActivityRuleInfo(BububaoActivityRuleDTO info) {
        ResultBase<String> result = new ResultBase<>();
        try {
            result = runActivityFeignClient.updateActivityRuleInfoById(info);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-when updateActivityRuleInfo, error:{}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 删除活动规则配置信息
     * 
     * @param info
     * @return
     */
    @Override
    public ResultBase<String> deleteActivityRuleById(Long id) {
        ResultBase<String> result = new ResultBase<>();
        try {
            BububaoActivityRuleDTO info = new BububaoActivityRuleDTO();
            info.setId(id);
            info.setIsDeleted("Y");
            result = runActivityFeignClient.updateActivityRuleInfoById(info);
        } catch (Exception e) {
            log.error("{}-when deleteActivityRuleById, error:{}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 查询活动规则配置信息分页
     */
    @Override
    public BububaoActivityRulePageDTO selectActivityRuleByCdtPage(BububaoActivityRuleDTO param) {
        BububaoActivityRulePageDTO pageDto = new BububaoActivityRulePageDTO();
        ResultBase<List<RunChannelListDTO>> resultchannel = new ResultBase<List<RunChannelListDTO>>();
        RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
        resultchannel = runChannelListRepository.selectRunChannelListDataList(runChannelListRepo);
        boolean reward = this.chackActivityRuleParam(param);
        List<BububaoActivityRuleDTO> list = Lists.newArrayList();
        PageDTO<BububaoActivityRuleDTO> page = new PageDTO<BububaoActivityRuleDTO>();
        /*
         * if (!reward) { page.setCurrentPage(param.getCurrentPage() == 0 ? 1 :
         * param.getCurrentPage()); page.setResultList(list);
         * page.setTotalItem(0); pageDto.setPage(page); return pageDto; }
         */
        int pageSize = param.getPageSize();
        Integer currentPage = param.getCurrentPage();
        BububaoActivityRuleClient client = new BububaoActivityRuleClient();
        BeanUtils.copyProperties(param, client);
        client.setSize(pageSize);
        client.setCurrentPage(currentPage == 0 ? 1 : param.getCurrentPage());
        ResultBase<List<BububaoActivityRuleDTO>> ruleByCdt = runActivityFeignClient.queryActivityRuleByCdt(client);
        ResultBase<Long> count = runActivityFeignClient.countActivityRuleInfo(param);
        if (ruleByCdt.isSuccess()) {
            page.setCurrentPage(param.getCurrentPage() == 0 ? 1 : param.getCurrentPage());
            page.setTotalItem(count.getValue().intValue());
            page.setResultList(ruleByCdt.getValue());
        }
        pageDto.setPage(page);
        pageDto.setChannelList(resultchannel.getValue());
        return pageDto;
    }

    private boolean chackActivityRuleParam(BububaoActivityRuleDTO param) {
        if (StringUtils.isNotBlank(param.getSource())) {
            return true;
        }
        if (null != param.getActivityId()) {
            return true;
        }
        return false;
    }

    @Override
    public ResultBase<String> insertorupdateActivityRule(BububaoActivityRuleDTO info) {
        ResultBase<String> result = new ResultBase<String>();
        String maxStandardDays = info.getMaxStandardDays();
        String minStandardDays = info.getMinStandardDays();
        String maxStepDay = info.getMaxStepDay();
        String minStepDay = info.getMinStepDay();
        ActivityRuleInfoDTO ruleInfo = new ActivityRuleInfoDTO();
        ruleInfo.setMaxStandardDays(maxStandardDays);
        ruleInfo.setMinStandardDays(minStandardDays);
        ruleInfo.setMinStepDay(minStepDay);
        ruleInfo.setMaxStepDay(maxStepDay);
        info.setRuleInfo(ruleInfo);
        if (null != info.getId()) {
            result = this.updateActivityRuleInfo(info);
        } else {
            result = this.insertActivityRuleInfo(info);
        }
        return result;
    }

    @Override
    public BububaoActivityRuleDTO selectActivityRuleOne(Long id) {
        BububaoActivityRuleDTO info = new BububaoActivityRuleDTO();
        info.setId(id);
        ResultBase<List<BububaoActivityRuleDTO>> ruleByCdt = this.queryActivityRuleByCdt(info);
        if (!ruleByCdt.isSuccess() || CollectionUtils.isEmpty(ruleByCdt.getValue())) {
            log.error("{}-when selectActivityRuleOne, error:{}", ThreadLocalUtil.getRequestNo(),
                    JSON.toJSONString(ruleByCdt));
            return null;
        }
        BububaoActivityRuleDTO bububaoActivityRuleDTO = ruleByCdt.getValue().get(0);
        ActivityRuleInfoDTO ruleInfo = bububaoActivityRuleDTO.getRuleInfo();
        bububaoActivityRuleDTO.setMaxStandardDays(ruleInfo.getMaxStandardDays());
        bububaoActivityRuleDTO.setMinStandardDays(ruleInfo.getMinStandardDays());
        bububaoActivityRuleDTO.setMinStepDay(ruleInfo.getMinStepDay());
        bububaoActivityRuleDTO.setMaxStepDay(ruleInfo.getMaxStepDay());
        return bububaoActivityRuleDTO;
    }

    /**
     * copy活动规则配置信息
     */
    @Override
    public ResultBase<String> copyActivityRuleById(Long id) {
        BububaoActivityRuleDTO info = new BububaoActivityRuleDTO();
        info.setId(id);
        ResultBase<List<BububaoActivityRuleDTO>> ruleByCdt = this.queryActivityRuleByCdt(info);
        if (!ruleByCdt.isSuccess() || CollectionUtils.isEmpty(ruleByCdt.getValue())) {
            log.error("{}-when selectActivityRuleOne, error:{}", ThreadLocalUtil.getRequestNo(),
                    JSON.toJSONString(ruleByCdt));
            return null;
        }
        BububaoActivityRuleDTO bububaoActivityRuleDTO = ruleByCdt.getValue().get(0);
        bububaoActivityRuleDTO.setId(null);
        bububaoActivityRuleDTO.setSource(null);
        ResultBase<String> insertActivityRuleInfo = this.insertActivityRuleInfo(bububaoActivityRuleDTO);
        return insertActivityRuleInfo;
    }

}
