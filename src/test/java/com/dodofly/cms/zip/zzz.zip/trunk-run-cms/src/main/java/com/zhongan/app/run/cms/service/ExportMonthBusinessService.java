package com.zhongan.app.run.cms.service;

import javax.servlet.http.HttpServletResponse;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.MonthBusinessDTO;
import com.zhongan.app.run.cms.bean.web.MonthBusinessPageDTO;

public interface ExportMonthBusinessService {

    public MonthBusinessPageDTO selectMonthBusinessList(Page<MonthBusinessDTO> monthBusinessPage);

    public void doExportExcelMonthBusiness(HttpServletResponse response);

}
