/*package com.zhongan.app.run.cms.service.impl;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.taobao.tair.DataEntry;
import com.zhongan.app.run.cms.bean.repository.RunUserPwdChkRepository;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunAccessPartyLoginDTO;
import com.zhongan.app.run.cms.bean.web.RunCmsUserDTO;
import com.zhongan.app.run.cms.bean.web.RunUserPassWdEditDTO;
import com.zhongan.app.run.cms.bean.web.UserLoginDTO;
import com.zhongan.app.run.cms.common.constants.B2gConstants;
import com.zhongan.app.run.cms.common.enums.B2gErrorCode;
import com.zhongan.app.run.cms.service.RunLoginService;


@Component("runLoginService")
@Slf4j
public class RunLoginServiceImpl implements RunLoginService {

    @Resource
    private B2gUserLoginFeignClient b2gUserLoginFeignClient;
    @Resource
    private B2gAccessPartyFeignClient b2gAccessPartyFeignClient;
	@Resource
	private B2gTairUtil b2gTairUtil;
	 @Resource
	 private RunUserPwdChkRepository runUserPwdChkRepository;
	
    @Override
    public ResultBase<RunCmsUserDTO> login(String username, String passwd) {
        log.info("user {} login start", username);
        ResultBase<RunCmsUserDTO> result = new ResultBase<RunCmsUserDTO>();
        *//** 参数校验 **//*
        if ("".equals(username) || "".equals(passwd)) {
            log.info("login fail,username or passwd is null");
            result.setSuccess(false);
            result.setErrorMessage(B2gErrorCode.ERROR_CODE_100001.getCode());
            result.setErrorDescription(B2gErrorCode.ERROR_CODE_100001.getDescription());
            return result;
        }
        *//** 登录用户信息 **//*
        UserLoginDTO userLoginDTO = new UserLoginDTO();
        userLoginDTO.setUserName(username);
        userLoginDTO.setUserPassword(passwd);
        ResultBase<RunCmsUserDTO> loginRS = runUserPwdChkRepository.checkLogin(userLoginDTO);
        if(!loginRS.isSuccess()){
        	log.info("user {} login fail {}",username,loginRS);
        	return loginRS;
        }
        String sid = loginRS.getValue().getLoginToken();
        if(!loginRS.isSuccess()){
        	log.info("login fail {}",loginRS.getErrorDescription());
        	return loginRS;
        }
        RunCmsUserDTO loginDto = loginRS.getValue();
        *//** 获取用户接入方信息 **//*
        Long partyId = Long.parseLong(loginDto.getAccessPartyId());
        ResultBase<B2gAccessPartyDTO> ptRS = b2gAccessPartyFeignClient.selectAccessPartiesById(partyId);
        *//**判断接入方权限**//*
        if(!ptRS.isSuccess()){
        	loginRS.setSuccess(false);
        	loginRS.setErrorMessage(ptRS.getErrorMessage());
        	loginRS.setErrorDescription(ptRS.getErrorDescription());
        	return loginRS;
        }
        B2gAccessPartyDTO partyDTO = ptRS.getValue();
        if(partyDTO.getAccessStatus().equals(AccessPtStEnum.ACCESSPTST_XJ.getCode())){
        	loginRS.setSuccess(false);
        	loginRS.setErrorMessage(B2gErrorCode.ERROR_CODE_100008.getCode());
        	loginRS.setErrorDescription(B2gErrorCode.ERROR_CODE_100008.getDescription());
        	return loginRS;
        }
        
        result.setValue(loginDto);
        result.setSuccess(true);
        log.info("token put to tair {}",B2gConstants.LoginModelConst.LOGIN_ZASID+sid);
        *//**用户信息存放tair**//*
        boolean tresult = b2gTairUtil.putWithFixedVersion(B2gConstants.LoginModelConst.LOGIN_ZASID+sid, loginDto,B2gConstants.LoginModelConst.LOGIN_OUT_TIME);
        log.info("tair result {}",tresult);
        log.info("user {} login end", username);
        return result;
    }

    @Override
    public ResultBase<RunCmsUserDTO> checkLogin(String token) {
        log.info("user {} check login start", token);
        ResultBase<RunCmsUserDTO> result = new ResultBase<RunCmsUserDTO>();
        *//**获取用户信息**//*
        DataEntry logData = b2gTairUtil.get(B2gConstants.LoginModelConst.LOGIN_ZASID+token);
        if(logData == null){
        	log.info("token {} checklogin fail,tair not exist",B2gConstants.LoginModelConst.LOGIN_ZASID+token);
        	result.setSuccess(false);
        	return result;
        }
        RunCmsUserDTO loginDto = (RunCmsUserDTO)logData.getValue();
        result.setSuccess(true);
        result.setValue(loginDto);
        *//**重新put一次tair更新登录有效时间**//*
        b2gTairUtil.putWithFixedVersion(B2gConstants.LoginModelConst.LOGIN_ZASID+token, loginDto,B2gConstants.LoginModelConst.LOGIN_OUT_TIME);
        log.info("user{} check login end", token);
        return result;
    }

    @Override
    public ResultBase<String> editPassWd(RunUserPassWdEditDTO b2gUserPassWdEditDTO) {
    	*//**测试tair问题**//*
    	b2gTairUtil.putWithFixedVersion("za_b2g_login_sidf5d97a4f-2ea5-42fd-804f-ffb0b4605524","1234");
    	DataEntry logData = b2gTairUtil.get("za_b2g_login_sidf5d97a4f-2ea5-42fd-804f-ffb0b4605524");
    	if(logData == null){
    		log.info("put 1 fail value is null");
    	}else{
    		log.info("put 1 success value is {}",JSONObject.toJSONString(logData));
    	}
    	b2gTairUtil.putWithFixedVersion("za_b2g_login_sid8263d770-9710-4633-aa7a-30427ac824a0","5678");
    	DataEntry logData2 = b2gTairUtil.get("za_b2g_login_sid8263d770-9710-4633-aa7a-30427ac824a0");
    	if(logData2 == null){
    		log.info("put 2 fail value is null");
    	}else{
    		log.info("put 2 success value is {}",JSONObject.toJSONString(logData2));
    	}
    	DataEntry logData3 = b2gTairUtil.get("za_b2g_login_sidf5d97a4f-2ea5-42fd-804f-ffb0b4605524");
    	if(logData3 == null){
    		log.info("put 1  value is null");
    	}else{
    		log.info("put 1  value is {}",JSONObject.toJSONString(logData3));
    	}
        // TODO Auto-generated method stub
        ResultBase<String> editRS = b2gUserLoginFeignClient.userPwdEdit(b2gUserPassWdEditDTO);
        log.info("editPassWd result is {}", editRS);
        return editRS;
    }

    @Override
    public ResultBase<String> createUser(RunAccessPartyLoginDTO b2gAccessPartyLoginDTO) {
        ResultBase<String> result = b2gUserLoginFeignClient.createUser(b2gAccessPartyLoginDTO);
        log.info("createUser result is {}", result);
        return result;
    }

}
*/