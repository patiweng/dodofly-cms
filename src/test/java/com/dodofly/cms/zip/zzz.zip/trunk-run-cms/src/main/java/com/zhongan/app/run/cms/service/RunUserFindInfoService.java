package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserFindInfoDTO;

public interface RunUserFindInfoService {
    /**
     * 接口说明：查询用户来源接口
     * 
     * @return
     */

    public ResultBase<List<RunUserFindInfoDTO>> findInfoSource(RunUserFindInfoDTO runUserFindInfoDTO);

    public ResultBase<List<RunUserFindInfoDTO>> findSourceInfoByCdt(RunUserFindInfoDTO runUserFindInfoDTO);
}
