package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserInviteInfoDTO;

/**
 * 用户好友信息
 * 
 * @author yangzhen001
 */
public interface UserInviteService {

    ResultBase<String> useFriendJoin(UserInviteInfoDTO info);

    ResultBase<List<UserInviteInfoDTO>> queryFriendsListByCdt(UserInviteInfoDTO info);

    ResultBase<String> insertFriendInfo(UserInviteInfoDTO info);

    ResultBase<Boolean> inseOrJudgeIsInvite(UserInviteInfoDTO info);

}
