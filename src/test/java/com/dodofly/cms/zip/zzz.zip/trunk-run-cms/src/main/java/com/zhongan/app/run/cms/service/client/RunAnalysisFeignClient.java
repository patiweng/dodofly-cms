package com.zhongan.app.run.cms.service.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhongan.app.run.cms.bean.client.AnalysisMonitorClient;
import com.zhongan.app.run.cms.bean.web.ResultBase;

@FeignClient(name = "za-run-analysis", url = "${za.run.analysis.feignclient.url}")
public interface RunAnalysisFeignClient {
    @RequestMapping(value = "/run/analysis/querylistforexcel/{sdate}/{edate}", method = RequestMethod.GET)
    public ResultBase<List<AnalysisMonitorClient>> queryListForExcel(@PathVariable("sdate") String sdate,
                                                                     @PathVariable("edate") String edate);

    @RequestMapping(value = "/run/analysis/addanalysismonitoroftodaydata", method = RequestMethod.GET)
    public ResultBase<String> addAnalysisMonitorOfTodayData();

    @RequestMapping(value = "/run/analysis/businessstatic", method = RequestMethod.GET)
    public ResultBase<String> businessStatic();

}
