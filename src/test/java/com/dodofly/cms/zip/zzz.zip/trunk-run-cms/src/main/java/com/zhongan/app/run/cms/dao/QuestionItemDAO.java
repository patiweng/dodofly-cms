package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.QuestionItemDO;

@Component
public interface QuestionItemDAO {
    /**
     * 根据id查询
     * 
     * @param id
     * @return
     */
    QuestionItemDO selectDataById(Long id);

    /**
     * 根据条件查询
     * 
     * @param questionItemDO
     * @return
     */
    List<QuestionItemDO> selectDataByCdt(QuestionItemDO questionItemDO);

    /**
     * 分页查询QuestionListItem信息
     * 
     * @param map
     * @return
     */
    List<QuestionItemDO> selectQuestionItemList(Map map);

    /**
     * 查询QuestionListItem条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 插入数据
     * 
     * @param questionItemDO
     */
    void insert(QuestionItemDO questionItemDO);

    /**
     * 更新数据
     * 
     * @param questionItemDO
     */
    void update(QuestionItemDO questionItemDO);

    /**
     * 更新数据为无效数据
     * 
     * @param id
     */
    void updateDeletedById(String id);
}
