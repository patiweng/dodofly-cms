package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.bo.RafflePresentBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.PresentListPageDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface RafflePresentService {
    public ResultBase<List<RafflePresentDTO>> selectPresentData(RafflePresentBO rafflePresentBO);

    public PresentListPageDTO selectPresentListPage(Page<RafflePresentDTO> rafflePresentListPage);

    public ResultBase<RafflePresentDTO> selectPresentDataByid(String id);

    public RafflePresentDTO selectDataByid(String id);

    public ResultBase<String> deletePresent(String id);

    public ResultBase<String> insertPresentData(RafflePresentBO rafflePresentBO);

    public ResultBase<String> updatePresentData(RafflePresentBO rafflePresentBO);

    /**
     * 根据活动id查询该活动下的所有奖品
     * 
     * @param activityPresentDTO
     * @return
     */
    public ResultBase<List<RafflePresentDTO>> selectPresentByActivityId(ActivityPresentDTO activityPresentDTO);
}
