package com.zhongan.app.run.cms.controller;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.RunMarketingActivitiesBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunAdvertHistoryDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesDTO;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesPageDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.utils.CustomMultipartFileEditor;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.service.RunMarketingActivitiesService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/marketingactivities")
@Slf4j
public class RunMarketingActivitiesController {
    @Resource
    private RunMarketingActivitiesService runMarketingActivitiesServiceImpl;

    @Resource
    private OssTool                       ossTool;

    @InitBinder
    protected void initBinder(DataBinder binder) throws ServletException {
        binder.registerCustomEditor(MultipartFile.class, new CustomMultipartFileEditor());
    }

    /**
     * cms运营活动信息查询接口C002
     * 
     * @return
     */

    @RequestMapping(value = "/select/marketingact", method = RequestMethod.POST)
    public ResultBase<List<RunMarketingActivitiesDTO>> selectMarketingActivities(@RequestBody RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        log.info("{}-/select/marketingact,param={" + runMarketingActivitiesDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        RunMarketingActivitiesBO RunMarketingActivitiesBO = new RunMarketingActivitiesBO();
        BeanUtils.copyProperties(runMarketingActivitiesDTO, RunMarketingActivitiesBO);
        result = runMarketingActivitiesServiceImpl.selectRunMarketingAct(RunMarketingActivitiesBO);
        log.info("{}-/select/marketingact  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 阿里渠道获取开屏广告
     * 
     * @return
     */
    @RequestMapping(value = "/select/marketingactalipop/{sourceCode}", method = RequestMethod.GET)
    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActAliPop(@PathVariable String sourceCode) {
        log.info("{}-/select/marketingactalipop,param={" + sourceCode + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        result = runMarketingActivitiesServiceImpl.selectRunMarketingActAliPop(sourceCode);
        log.info("{}-/select/marketingactalipop  return,data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    @RequestMapping(value = "/select/marketingactforthird", method = RequestMethod.POST)
    public ResultBase<List<RunMarketingActivitiesDTO>> selectMarketingActivitiesForThird(@RequestBody RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        log.info("{}-/select/marketingactforthird,param={" + runMarketingActivitiesDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        RunMarketingActivitiesBO RunMarketingActivitiesBO = new RunMarketingActivitiesBO();
        BeanUtils.copyProperties(runMarketingActivitiesDTO, RunMarketingActivitiesBO);
        result = runMarketingActivitiesServiceImpl.selectRunMarketingActForThird(RunMarketingActivitiesBO);
        log.info("{}-/select/marketingactforthird  return,data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 查询所有的活动信息 分页。。。
     * 
     * @return
     */
    @RequestMapping(value = "/select/activitiespage")
    public ModelAndView selectMarketingActivitiesPage(RunMarketingActivitiesDTO runMarketingActivitiesDTO,
                                                      HttpServletRequest request) {
        log.info("{}-into /select/activitiespage, param={ " + runMarketingActivitiesDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        validParam(runMarketingActivitiesDTO);
        Page<RunMarketingActivitiesDTO> runMarketingActivitiesPage = new Page<RunMarketingActivitiesDTO>(
                runMarketingActivitiesDTO.getPageSize(), runMarketingActivitiesDTO.getCurrentPage());
        runMarketingActivitiesPage.setParam(runMarketingActivitiesDTO);
        RunMarketingActivitiesPageDTO result = runMarketingActivitiesServiceImpl
                .selectRunMarketingActPage(runMarketingActivitiesPage);
        runMarketingActivitiesPage = result.getRunMarketingActivitiesDTOPage();

        Map<String, Object> model = Maps.newHashMap();
        if (null != runMarketingActivitiesPage) {
            model.put("marketingActivities", runMarketingActivitiesPage.getResultList());
        }
        //将活动类型转换
        for (RunChannelListDTO runChannelListDTO : result.getRunChannelListDTOList()) {
            if (runChannelListDTO.getType().equals(RunConstants.IS_ZHONGJI)) {
                runChannelListDTO.setTypeName(RunConstants.IS_ZHONGJI_NAME);
            } else {
                runChannelListDTO.setTypeName(RunConstants.IS_YIWAI);
            }
        }
        model.put("role", result.getRole());
        model.put("runMarketingActivitiesDTO", runMarketingActivitiesDTO);
        model.put("page", runMarketingActivitiesPage);
        model.put("channelList", result.getRunChannelListDTOList());
        log.info("{}-/select/activitiespage return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/marketing_activities", model);
    }

    //入参校验
    private RunMarketingActivitiesDTO validParam(RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        if ("0".equals(runMarketingActivitiesDTO.getAllChannel())) {
            runMarketingActivitiesDTO.setAllChannel(null);
            ;
        }
        if ("".equals(runMarketingActivitiesDTO.getActivitiesName())) {
            runMarketingActivitiesDTO.setActivitiesName(null);
        }
        if ("0".equals(runMarketingActivitiesDTO.getActivitiesType())) {
            runMarketingActivitiesDTO.setActivitiesType(null);
        }
        return runMarketingActivitiesDTO;
    }

    /**
     * 根据主键修改运营活动信息(添加一条新的运营活动)
     * 
     * @return
     */

    @RequestMapping(value = "/updateorinset", method = RequestMethod.POST)
    public ResultBase<String> updateOrInsertMarketingActivities(RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        log.info("{}-/updateorinset,param={" + runMarketingActivitiesDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        Map<String, Object> model = Maps.newHashMap();
        if ("".equals(runMarketingActivitiesDTO.getId())) {
            runMarketingActivitiesDTO.setId(null);
        }
        model.put("runMarketingActivitiesDTO", runMarketingActivitiesDTO);
        //新建
        if (null == runMarketingActivitiesDTO.getId()) {
            result = runMarketingActivitiesServiceImpl.insertMarketing(runMarketingActivitiesDTO);
            //修改  
        } else {
            result = runMarketingActivitiesServiceImpl.updateMarketing(runMarketingActivitiesDTO);
        }
        log.info("{}-/updateorinset  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据主键删除运营活动
     * 
     * @return
     */

    @RequestMapping(value = "/delete/marketingActivities/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteMarketingActOne(@PathVariable String id) {
        log.info("{}-/delete/marketingActivities/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = runMarketingActivitiesServiceImpl.deleteMarketingActivities(id);
        }
        log.info("{}-/delete/marketingActivities/{id} return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * cms运营活动根据ID 查询结果信息
     * 
     * @return
     */

    @RequestMapping(value = "/select/marketingone/{id}", method = RequestMethod.GET)
    public RunMarketingActivitiesDTO selectMarketingOne(@PathVariable String id) {
        log.info("{}-/select/marketingone/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        RunMarketingActivitiesDTO runMarketingActivitiesDTO = new RunMarketingActivitiesDTO();
        if (id != null) {
            runMarketingActivitiesDTO = runMarketingActivitiesServiceImpl.selectOneMarketingActivities(id);
        }
        log.info("{}-/select/marketingone/{id} return, data={" + runMarketingActivitiesDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return runMarketingActivitiesDTO;
    }

    /**
     * 根据id查询activityId，其他字段可能没有值
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/selectmarketingactivitybyid/{id}", method = RequestMethod.GET)
    public ResultBase<RunMarketingActivitiesDTO> selectMarketingActivityById(@PathVariable String id) {
        log.info("{}-/selectMarketingActivityById, param={ " + id + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<RunMarketingActivitiesDTO> result = runMarketingActivitiesServiceImpl
                .selectMarketingActivityById(id);
        log.info("{}-/selectMarketingActivityById return, data={" + result + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 从oss上获取图片
     * 
     * @return
     */

    @RequestMapping(value = "/getimg/marketing/{imgurl}", method = RequestMethod.GET)
    public void getImg(@PathVariable String imgurl, HttpServletResponse response) {
        log.info("{}-into /bops/getimg/marketing, param={ " + imgurl + " }", ThreadLocalUtil.getRequestNo());
        InputStream ins = null;
        OutputStream outs = null;
        try {
            response.setDateHeader("Expires", 0);
            response.addHeader("Cache-Control", "post-check=0, pre-check=0");
            response.setHeader("Pragma", "no-cache");
            response.setContentType("image/png");
            response.setCharacterEncoding("text/html;charaset=UTF-8");
            ins = ossTool.downloadFile(RunConstants.PROJECT + RunConstants.MARKETING_IMG_PATH + imgurl
                    + RunConstants.MARKETING_IMG_SUFFIX);
            outs = response.getOutputStream();
            int iread = 0;
            byte[] buf = new byte[1024];
            while ((iread = ins.read(buf, 0, 1024)) != -1) {
                outs.write(buf, 0, iread);
            }
            outs.flush();
        } catch (Exception exp) {
            log.error("{}-", exp.getMessage(), exp, ThreadLocalUtil.getRequestNo());
        } finally {
            if (ins != null) {
                try {
                    ins.close();
                } catch (Exception ex) {
                    log.error("{}-", ex.getMessage(), ex, ThreadLocalUtil.getRequestNo());
                }
            }
            if (outs != null) {
                try {
                    outs.close();
                } catch (Exception ex) {
                    log.error("{}-", ex.getMessage(), ex, ThreadLocalUtil.getRequestNo());
                }
            }
        }
        log.info("{}-/getimg/marketing/ return", ThreadLocalUtil.getRequestNo());
    }

    /**
     * 获取推广活动
     * 
     * @param runMarketingActivitiesDTO
     * @return
     */
    @RequestMapping(value = "/marketing/activities", method = RequestMethod.POST)
    public ResultBase<List<RunMarketingActivitiesDTO>> getActivities(@RequestBody RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        log.info("{}-/marketing/activities,param={}", ThreadLocalUtil.getRequestNo(), runMarketingActivitiesDTO);
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        RunMarketingActivitiesBO RunMarketingActivitiesBO = new RunMarketingActivitiesBO();
        BeanUtils.copyProperties(runMarketingActivitiesDTO, RunMarketingActivitiesBO);
        result = runMarketingActivitiesServiceImpl.selectRunMarketingActForThird(RunMarketingActivitiesBO);
        log.info("{}-/marketing/activities  return,data={}", ThreadLocalUtil.getRequestNo(), result);
        return result;
    }

    /**
     * 活动专属 根据条件查询活动
     * 
     * @param runMarketingActivitiesDTO
     * @return
     */
    @RequestMapping(value = "/select/marketingActivitiesByCdt", method = RequestMethod.POST)
    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActivitiesByCdt(@RequestBody RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        log.info("{}-/select/marketingActivitiesByCdt,param={}", ThreadLocalUtil.getRequestNo(),
                runMarketingActivitiesDTO);
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        RunMarketingActivitiesBO RunMarketingActivitiesBO = new RunMarketingActivitiesBO();
        BeanUtils.copyProperties(runMarketingActivitiesDTO, RunMarketingActivitiesBO);
        result = runMarketingActivitiesServiceImpl.marketingActivitiesByCdt(RunMarketingActivitiesBO);
        log.info("{}-/select/marketingActivitiesByCdt>return={}", ThreadLocalUtil.getRequestNo(),
                JSON.toJSONString(result));
        return result;
    }

    /**
     * 根据活动code查询活动
     * 
     * @param runMarketingActivitiesDTO
     * @return
     */
    @RequestMapping(value = "/select/marketingActivitiesByCode", method = RequestMethod.POST)
    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActivitiesByCode(@RequestBody RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        log.info("{}-/select/marketingActivitiesByCode,param={}", ThreadLocalUtil.getRequestNo(),
                runMarketingActivitiesDTO);
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        RunMarketingActivitiesBO RunMarketingActivitiesBO = new RunMarketingActivitiesBO();
        BeanUtils.copyProperties(runMarketingActivitiesDTO, RunMarketingActivitiesBO);
        result = runMarketingActivitiesServiceImpl.marketingActivitiesByCode(RunMarketingActivitiesBO);
        log.info("{}-/select/marketingActivitiesByCode>return={}", ThreadLocalUtil.getRequestNo(),
                JSON.toJSONString(result));
        return result;
    }

    /**
     * 查询用户是否开屏过
     * 
     * @return
     */
    @RequestMapping(value = "/select/advertHistoryByCdt", method = RequestMethod.POST)
    public ResultBase<Boolean> advertHistoryByCdt(@RequestBody RunAdvertHistoryDTO info) {
        log.info("{}-/select/advertHistoryByCdt,param={}", ThreadLocalUtil.getRequestNo(), JSON.toJSONString(info));
        ResultBase<Boolean> result = new ResultBase<>();
        result = runMarketingActivitiesServiceImpl.advertHistoryByCdt(info);
        log.info("{}-/select/advertHistoryByCdt>return={}", ThreadLocalUtil.getRequestNo(), JSON.toJSONString(result));
        return result;
    }

    /**
     * 删除开屏数据
     * 
     * @return
     */
    @RequestMapping(value = "/delete/deleteAdvertHistory/{days}", method = RequestMethod.GET)
    public ResultBase<String> deleteAdvertHistory(@PathVariable Integer days) {
        log.info("{}-/delete/deleteAdvertHistory,param={}", ThreadLocalUtil.getRequestNo(), days);
        ResultBase<String> result = new ResultBase<>();
        result = runMarketingActivitiesServiceImpl.deleteByExample(days);
        log.info("{}-/delete/deleteAdvertHistory>return={}", ThreadLocalUtil.getRequestNo(), JSON.toJSONString(result));
        return result;
    }
}
