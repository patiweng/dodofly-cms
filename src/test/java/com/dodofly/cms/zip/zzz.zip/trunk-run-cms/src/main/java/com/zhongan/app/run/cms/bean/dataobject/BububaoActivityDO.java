package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoActivityDO {
    private String id;
    private String name;
    private String identify;
    private String description;
    private String startTime;
    private String endTime;
    private String playTimes;
    private String everyPlayTimes;
    /**
     * 活动目标步数
     */
    private Long    targetStep;
    private String creator;
    private String modifier;
    private String createTime;
    private String modifyTime;
    private String isDeleted;
}
