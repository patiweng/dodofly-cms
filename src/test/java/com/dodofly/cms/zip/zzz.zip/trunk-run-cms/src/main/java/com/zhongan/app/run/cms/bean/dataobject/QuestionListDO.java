package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class QuestionListDO {
    private Long    id;
    private String  queryIcon;
    private String  queryTitle;
    private String  queryDes;
    private String  queryType;
    private Integer sort;
    private String  creator;
    private String  modifier;
    private String  createtime;
    private String  modifytime;
    private String  isDeleted;
}
