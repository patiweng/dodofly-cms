package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class CashierHelpPayDO {
    /**
     * 主键 This field corresponds to the column bububao_cashier_help_pay.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 用户ID This field corresponds to the column
     * bububao_cashier_help_pay.unionId
     *
     * @mbggenerated
     */
    private Long   unionid;

    /**
     * 用户名 This field corresponds to the column
     * bububao_cashier_help_pay.user_name
     *
     * @mbggenerated
     */
    private String userName;

    /**
     * 目标步数 This field corresponds to the column
     * bububao_cashier_help_pay.user_target
     *
     * @mbggenerated
     */
    private Long   userTarget;

    /**
     * 用户合同号 This field corresponds to the column
     * bububao_cashier_help_pay.user_contract_no
     *
     * @mbggenerated
     */
    private String userContractNo;

    /**
     * 支付渠道Code This field corresponds to the column
     * bububao_cashier_help_pay.pay_channel_code
     *
     * @mbggenerated
     */
    private String payChannelCode;

    /**
     * 原始渠道ID This field corresponds to the column
     * bububao_cashier_help_pay.original_channel_id
     *
     * @mbggenerated
     */
    private String originalChannelId;

    /**
     * 支付渠道账户号 This field corresponds to the column
     * bububao_cashier_help_pay.pay_channel_user_no
     *
     * @mbggenerated
     */
    private String payChannelUserNo;

    /**
     * 手机号 This field corresponds to the column bububao_cashier_help_pay.phone
     *
     * @mbggenerated
     */
    private String phone;

    /**
     * 证件类型 This field corresponds to the column
     * bububao_cashier_help_pay.cert_type
     *
     * @mbggenerated
     */
    private String certType;

    /**
     * 证件号码 This field corresponds to the column
     * bububao_cashier_help_pay.cert_no
     *
     * @mbggenerated
     */
    private String certNo;

    /**
     * 开通活动来源 This field corresponds to the column
     * bububao_cashier_help_pay.biz_activity
     *
     * @mbggenerated
     */
    private String bizActivity;

    /**
     * 业务来源：bububao,health This field corresponds to the column
     * bububao_cashier_help_pay.biz_source
     *
     * @mbggenerated
     */
    private String bizSource;

    /**
     * 代扣渠道：cashier(收银台),financial(金融) This field corresponds to the column
     * bububao_cashier_help_pay.dk_source
     *
     * @mbggenerated
     */
    private String dkSource;

    /**
     * 开通渠道 This field corresponds to the column
     * bububao_cashier_help_pay.open_channel
     *
     * @mbggenerated
     */
    private String openChannel;

    /**
     * 开通状态(1:已开通 2:未开通) This field corresponds to the column
     * bububao_cashier_help_pay.open_stauts
     *
     * @mbggenerated
     */
    private Long   openStauts;

    /**
     * 开通时间 This field corresponds to the column
     * bububao_cashier_help_pay.open_time
     *
     * @mbggenerated
     */
    private Date   openTime;

    /**
     * 关闭时间 This field corresponds to the column
     * bububao_cashier_help_pay.close_time
     *
     * @mbggenerated
     */
    private Date   closeTime;

    /**
     * 创建人 This field corresponds to the column bububao_cashier_help_pay.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 创建时间 This field corresponds to the column
     * bububao_cashier_help_pay.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改人 This field corresponds to the column
     * bububao_cashier_help_pay.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 修改时间 This field corresponds to the column
     * bububao_cashier_help_pay.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * 是否删除 This field corresponds to the column
     * bububao_cashier_help_pay.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /**
     * @mbggenerated
     */
    public CashierHelpPayDO(Long id, Long unionid, String userName, Long userTarget, String userContractNo,
                            String payChannelCode, String originalChannelId, String payChannelUserNo, String phone,
                            String certType, String certNo, String bizActivity, String bizSource, String dkSource,
                            String openChannel, Long openStauts, Date openTime, Date closeTime, String creator,
                            Date gmtCreated, String modifier, Date gmtModified, String isDeleted) {
        this.id = id;
        this.unionid = unionid;
        this.userName = userName;
        this.userTarget = userTarget;
        this.userContractNo = userContractNo;
        this.payChannelCode = payChannelCode;
        this.originalChannelId = originalChannelId;
        this.payChannelUserNo = payChannelUserNo;
        this.phone = phone;
        this.certType = certType;
        this.certNo = certNo;
        this.bizActivity = bizActivity;
        this.bizSource = bizSource;
        this.dkSource = dkSource;
        this.openChannel = openChannel;
        this.openStauts = openStauts;
        this.openTime = openTime;
        this.closeTime = closeTime;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /**
     * @mbggenerated
     */
    public CashierHelpPayDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.id
     *
     * @return the value of bububao_cashier_help_pay.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.id
     *
     * @param id the value for bububao_cashier_help_pay.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.unionId
     *
     * @return the value of bububao_cashier_help_pay.unionId
     * @mbggenerated
     */
    public Long getUnionid() {
        return unionid;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.unionId
     *
     * @param unionid the value for bububao_cashier_help_pay.unionId
     * @mbggenerated
     */
    public void setUnionid(Long unionid) {
        this.unionid = unionid;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.user_name
     *
     * @return the value of bububao_cashier_help_pay.user_name
     * @mbggenerated
     */
    public String getUserName() {
        return userName;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.user_name
     *
     * @param userName the value for bububao_cashier_help_pay.user_name
     * @mbggenerated
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.user_target
     *
     * @return the value of bububao_cashier_help_pay.user_target
     * @mbggenerated
     */
    public Long getUserTarget() {
        return userTarget;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.user_target
     *
     * @param userTarget the value for bububao_cashier_help_pay.user_target
     * @mbggenerated
     */
    public void setUserTarget(Long userTarget) {
        this.userTarget = userTarget;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.user_contract_no
     *
     * @return the value of bububao_cashier_help_pay.user_contract_no
     * @mbggenerated
     */
    public String getUserContractNo() {
        return userContractNo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.user_contract_no
     *
     * @param userContractNo the value for
     *            bububao_cashier_help_pay.user_contract_no
     * @mbggenerated
     */
    public void setUserContractNo(String userContractNo) {
        this.userContractNo = userContractNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.pay_channel_code
     *
     * @return the value of bububao_cashier_help_pay.pay_channel_code
     * @mbggenerated
     */
    public String getPayChannelCode() {
        return payChannelCode;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.pay_channel_code
     *
     * @param payChannelCode the value for
     *            bububao_cashier_help_pay.pay_channel_code
     * @mbggenerated
     */
    public void setPayChannelCode(String payChannelCode) {
        this.payChannelCode = payChannelCode;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.original_channel_id
     *
     * @return the value of bububao_cashier_help_pay.original_channel_id
     * @mbggenerated
     */
    public String getOriginalChannelId() {
        return originalChannelId;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.original_channel_id
     *
     * @param originalChannelId the value for
     *            bububao_cashier_help_pay.original_channel_id
     * @mbggenerated
     */
    public void setOriginalChannelId(String originalChannelId) {
        this.originalChannelId = originalChannelId;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.pay_channel_user_no
     *
     * @return the value of bububao_cashier_help_pay.pay_channel_user_no
     * @mbggenerated
     */
    public String getPayChannelUserNo() {
        return payChannelUserNo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.pay_channel_user_no
     *
     * @param payChannelUserNo the value for
     *            bububao_cashier_help_pay.pay_channel_user_no
     * @mbggenerated
     */
    public void setPayChannelUserNo(String payChannelUserNo) {
        this.payChannelUserNo = payChannelUserNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.phone
     *
     * @return the value of bububao_cashier_help_pay.phone
     * @mbggenerated
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.phone
     *
     * @param phone the value for bububao_cashier_help_pay.phone
     * @mbggenerated
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.cert_type
     *
     * @return the value of bububao_cashier_help_pay.cert_type
     * @mbggenerated
     */
    public String getCertType() {
        return certType;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.cert_type
     *
     * @param certType the value for bububao_cashier_help_pay.cert_type
     * @mbggenerated
     */
    public void setCertType(String certType) {
        this.certType = certType;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.cert_no
     *
     * @return the value of bububao_cashier_help_pay.cert_no
     * @mbggenerated
     */
    public String getCertNo() {
        return certNo;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.cert_no
     *
     * @param certNo the value for bububao_cashier_help_pay.cert_no
     * @mbggenerated
     */
    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.biz_activity
     *
     * @return the value of bububao_cashier_help_pay.biz_activity
     * @mbggenerated
     */
    public String getBizActivity() {
        return bizActivity;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.biz_activity
     *
     * @param bizActivity the value for bububao_cashier_help_pay.biz_activity
     * @mbggenerated
     */
    public void setBizActivity(String bizActivity) {
        this.bizActivity = bizActivity;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.biz_source
     *
     * @return the value of bububao_cashier_help_pay.biz_source
     * @mbggenerated
     */
    public String getBizSource() {
        return bizSource;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.biz_source
     *
     * @param bizSource the value for bububao_cashier_help_pay.biz_source
     * @mbggenerated
     */
    public void setBizSource(String bizSource) {
        this.bizSource = bizSource;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.dk_source
     *
     * @return the value of bububao_cashier_help_pay.dk_source
     * @mbggenerated
     */
    public String getDkSource() {
        return dkSource;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.dk_source
     *
     * @param dkSource the value for bububao_cashier_help_pay.dk_source
     * @mbggenerated
     */
    public void setDkSource(String dkSource) {
        this.dkSource = dkSource;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.open_channel
     *
     * @return the value of bububao_cashier_help_pay.open_channel
     * @mbggenerated
     */
    public String getOpenChannel() {
        return openChannel;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.open_channel
     *
     * @param openChannel the value for bububao_cashier_help_pay.open_channel
     * @mbggenerated
     */
    public void setOpenChannel(String openChannel) {
        this.openChannel = openChannel;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.open_stauts
     *
     * @return the value of bububao_cashier_help_pay.open_stauts
     * @mbggenerated
     */
    public Long getOpenStauts() {
        return openStauts;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.open_stauts
     *
     * @param openStauts the value for bububao_cashier_help_pay.open_stauts
     * @mbggenerated
     */
    public void setOpenStauts(Long openStauts) {
        this.openStauts = openStauts;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.open_time
     *
     * @return the value of bububao_cashier_help_pay.open_time
     * @mbggenerated
     */
    public Date getOpenTime() {
        return openTime;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.open_time
     *
     * @param openTime the value for bububao_cashier_help_pay.open_time
     * @mbggenerated
     */
    public void setOpenTime(Date openTime) {
        this.openTime = openTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.close_time
     *
     * @return the value of bububao_cashier_help_pay.close_time
     * @mbggenerated
     */
    public Date getCloseTime() {
        return closeTime;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.close_time
     *
     * @param closeTime the value for bububao_cashier_help_pay.close_time
     * @mbggenerated
     */
    public void setCloseTime(Date closeTime) {
        this.closeTime = closeTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.creator
     *
     * @return the value of bububao_cashier_help_pay.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.creator
     *
     * @param creator the value for bububao_cashier_help_pay.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.gmt_created
     *
     * @return the value of bububao_cashier_help_pay.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.gmt_created
     *
     * @param gmtCreated the value for bububao_cashier_help_pay.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.modifier
     *
     * @return the value of bububao_cashier_help_pay.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.modifier
     *
     * @param modifier the value for bububao_cashier_help_pay.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.gmt_modified
     *
     * @return the value of bububao_cashier_help_pay.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay.gmt_modified
     *
     * @param gmtModified the value for bububao_cashier_help_pay.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay.is_deleted
     *
     * @return the value of bububao_cashier_help_pay.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay.is_deleted
     *
     * @param isDeleted the value for bububao_cashier_help_pay.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
