package com.zhongan.app.run.cms.bean.web;

import java.util.List;

import lombok.Data;

import com.zhongan.app.run.cms.bean.page.Page;
@Data
public class RunCampaignListPageDTO {
    private String                  role;
    private Page<RunCampaignListDTO>      runCampaignListDTODTOPage;
    private List<RunChannelListDTO> runChannelListDTOList;
}
