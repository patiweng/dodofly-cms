package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.bean.dataobject.BububaoAddCouponsRecordsDO;

@Component
public interface BububaoAddCouponsRecordsDAO {

	 /**
     * 根据条件查询数据
     * @return
     */
    List<BububaoAddCouponsRecordsDO> selectDataByCdt(BububaoAddCouponsRecordsDO bububaoAddCouponsRecordsDO);
    
    /**
     * 根据id查询数据
     * @param id
     * @return
     */
    BububaoAddCouponsRecordsDO selectOneDataById(String id);
    
    /**
     * 插入数据
     * @param BububaoAddCouponsRecordsDO
     */
    void insert(BububaoAddCouponsRecordsDO bububaoAddCouponsRecordsDO);
    
    /**
     * 更新数据
     * @param BububaoAddCouponsRecordsDO
     */
    void update(BububaoAddCouponsRecordsDO bububaoAddCouponsRecordsDO);
}
