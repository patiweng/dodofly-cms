package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class RunUserCouponsDTO {
    private String id;
    private String unionId;
    private String value;
    private String endDate;
    private String expired;
    private String used;
    private String startTime;
    private String endTime;
    private String createTime;
    private String modifyTime;
    private String type;
    private String status;
    /** 免费天数 */
    private int    freeDays;
}
