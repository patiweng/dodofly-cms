package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class UserInviteDO {
    /**
     * 主键 This field corresponds to the column bububao_user_invite.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 用户id This field corresponds to the column bububao_user_invite.unionid
     *
     * @mbggenerated
     */
    private Long   unionid;

    /**
     * 一级活动id This field corresponds to the column
     * bububao_user_invite.activity_id
     *
     * @mbggenerated
     */
    private String activityId;

    /**
     * 用户来源 This field corresponds to the column
     * bububao_user_invite.channel_from
     *
     * @mbggenerated
     */
    private String channelFrom;

    /**
     * 被邀请活动来源 This field corresponds to the column
     * bububao_user_invite.activity_type
     *
     * @mbggenerated
     */
    private String activityType;

    /**
     * 被邀请用户在来源方的Openid This field corresponds to the column
     * bububao_user_invite.join_openid
     *
     * @mbggenerated
     */
    private String joinOpenid;

    /**
     * 昵称,非必须,初始化为用户第一次有的昵称 This field corresponds to the column
     * bububao_user_invite.nick_name
     *
     * @mbggenerated
     */
    private String nickName;

    /**
     * 与要邀请人关系 默认0(好友) This field corresponds to the column
     * bububao_user_invite.relation
     *
     * @mbggenerated
     */
    private String relation;

    /**
     * 生效1,未生效0 This field corresponds to the column bububao_user_invite.state
     *
     * @mbggenerated
     */
    private String state;

    /**
     * 头像,非必须,初始化为用户第一次有的头像 This field corresponds to the column
     * bububao_user_invite.headimgurl
     *
     * @mbggenerated
     */
    private String headimgurl;

    /**
     * 创建者 This field corresponds to the column bububao_user_invite.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 修改者 This field corresponds to the column bububao_user_invite.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 创建时间 This field corresponds to the column bububao_user_invite.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改时间 This field corresponds to the column
     * bububao_user_invite.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * 是否删除(Y/N，默认为:N) This field corresponds to the column
     * bububao_user_invite.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /**
     * 扩展信息 This field corresponds to the column bububao_user_invite.extra_info
     *
     * @mbggenerated
     */
    private String extraInfo;

    /**
     * 被邀请用户id This field corresponds to the column
     * bububao_user_invite.join_unionid
     *
     * @mbggenerated
     */
    private Long   joinUnionid;

    /**
     * 用户Openid This field corresponds to the column bububao_user_invite.openId
     *
     * @mbggenerated
     */
    private String openid;

    /**
     * @mbggenerated
     */
    public UserInviteDO(Long id, Long unionid, String activityId, String channelFrom, String activityType,
                        String joinOpenid, String nickName, String relation, String state, String headimgurl,
                        String creator, String modifier, Date gmtCreated, Date gmtModified, String isDeleted,
                        String extraInfo, Long joinUnionid, String openid) {
        this.id = id;
        this.unionid = unionid;
        this.activityId = activityId;
        this.channelFrom = channelFrom;
        this.activityType = activityType;
        this.joinOpenid = joinOpenid;
        this.nickName = nickName;
        this.relation = relation;
        this.state = state;
        this.headimgurl = headimgurl;
        this.creator = creator;
        this.modifier = modifier;
        this.gmtCreated = gmtCreated;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
        this.extraInfo = extraInfo;
        this.joinUnionid = joinUnionid;
        this.openid = openid;
    }

    /**
     * @mbggenerated
     */
    public UserInviteDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.id
     *
     * @return the value of bububao_user_invite.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_user_invite.id
     *
     * @param id the value for bububao_user_invite.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.unionid
     *
     * @return the value of bububao_user_invite.unionid
     * @mbggenerated
     */
    public Long getUnionid() {
        return unionid;
    }

    /**
     * Sets the value of the database column bububao_user_invite.unionid
     *
     * @param unionid the value for bububao_user_invite.unionid
     * @mbggenerated
     */
    public void setUnionid(Long unionid) {
        this.unionid = unionid;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.activity_id
     *
     * @return the value of bububao_user_invite.activity_id
     * @mbggenerated
     */
    public String getActivityId() {
        return activityId;
    }

    /**
     * Sets the value of the database column bububao_user_invite.activity_id
     *
     * @param activityId the value for bububao_user_invite.activity_id
     * @mbggenerated
     */
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.channel_from
     *
     * @return the value of bububao_user_invite.channel_from
     * @mbggenerated
     */
    public String getChannelFrom() {
        return channelFrom;
    }

    /**
     * Sets the value of the database column bububao_user_invite.channel_from
     *
     * @param channelFrom the value for bububao_user_invite.channel_from
     * @mbggenerated
     */
    public void setChannelFrom(String channelFrom) {
        this.channelFrom = channelFrom;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.activity_type
     *
     * @return the value of bububao_user_invite.activity_type
     * @mbggenerated
     */
    public String getActivityType() {
        return activityType;
    }

    /**
     * Sets the value of the database column bububao_user_invite.activity_type
     *
     * @param activityType the value for bububao_user_invite.activity_type
     * @mbggenerated
     */
    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.join_openid
     *
     * @return the value of bububao_user_invite.join_openid
     * @mbggenerated
     */
    public String getJoinOpenid() {
        return joinOpenid;
    }

    /**
     * Sets the value of the database column bububao_user_invite.join_openid
     *
     * @param joinOpenid the value for bububao_user_invite.join_openid
     * @mbggenerated
     */
    public void setJoinOpenid(String joinOpenid) {
        this.joinOpenid = joinOpenid;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.nick_name
     *
     * @return the value of bububao_user_invite.nick_name
     * @mbggenerated
     */
    public String getNickName() {
        return nickName;
    }

    /**
     * Sets the value of the database column bububao_user_invite.nick_name
     *
     * @param nickName the value for bububao_user_invite.nick_name
     * @mbggenerated
     */
    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.relation
     *
     * @return the value of bububao_user_invite.relation
     * @mbggenerated
     */
    public String getRelation() {
        return relation;
    }

    /**
     * Sets the value of the database column bububao_user_invite.relation
     *
     * @param relation the value for bububao_user_invite.relation
     * @mbggenerated
     */
    public void setRelation(String relation) {
        this.relation = relation;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.state
     *
     * @return the value of bububao_user_invite.state
     * @mbggenerated
     */
    public String getState() {
        return state;
    }

    /**
     * Sets the value of the database column bububao_user_invite.state
     *
     * @param state the value for bububao_user_invite.state
     * @mbggenerated
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.headimgurl
     *
     * @return the value of bububao_user_invite.headimgurl
     * @mbggenerated
     */
    public String getHeadimgurl() {
        return headimgurl;
    }

    /**
     * Sets the value of the database column bububao_user_invite.headimgurl
     *
     * @param headimgurl the value for bububao_user_invite.headimgurl
     * @mbggenerated
     */
    public void setHeadimgurl(String headimgurl) {
        this.headimgurl = headimgurl;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.creator
     *
     * @return the value of bububao_user_invite.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column bububao_user_invite.creator
     *
     * @param creator the value for bububao_user_invite.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.modifier
     *
     * @return the value of bububao_user_invite.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column bububao_user_invite.modifier
     *
     * @param modifier the value for bububao_user_invite.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.gmt_created
     *
     * @return the value of bububao_user_invite.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column bububao_user_invite.gmt_created
     *
     * @param gmtCreated the value for bububao_user_invite.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.gmt_modified
     *
     * @return the value of bububao_user_invite.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column bububao_user_invite.gmt_modified
     *
     * @param gmtModified the value for bububao_user_invite.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.is_deleted
     *
     * @return the value of bububao_user_invite.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column bububao_user_invite.is_deleted
     *
     * @param isDeleted the value for bububao_user_invite.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.extra_info
     *
     * @return the value of bububao_user_invite.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column bububao_user_invite.extra_info
     *
     * @param extraInfo the value for bububao_user_invite.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.join_unionid
     *
     * @return the value of bububao_user_invite.join_unionid
     * @mbggenerated
     */
    public Long getJoinUnionid() {
        return joinUnionid;
    }

    /**
     * Sets the value of the database column bububao_user_invite.join_unionid
     *
     * @param joinUnionid the value for bububao_user_invite.join_unionid
     * @mbggenerated
     */
    public void setJoinUnionid(Long joinUnionid) {
        this.joinUnionid = joinUnionid;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_invite.openId
     *
     * @return the value of bububao_user_invite.openId
     * @mbggenerated
     */
    public String getOpenid() {
        return openid;
    }

    /**
     * Sets the value of the database column bububao_user_invite.openId
     *
     * @param openid the value for bububao_user_invite.openId
     * @mbggenerated
     */
    public void setOpenid(String openid) {
        this.openid = openid;
    }
}
