package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessDTO;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.ExportExcelBusinessService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/excelbusiness")
@Slf4j
public class ExportExcelBusinessController {

    @Resource
    private ExportExcelBusinessService exportExcelBusinessServiceImpl;

    /**
     * 查询分页
     * 
     * @param request
     * @param analysisBusinessDTO
     * @return
     */
    @RequestMapping(value = "/select/selectanalysisbusinessmonitorlistpage")
    public ModelAndView selectAnalysisBusinessMonitorListPage(HttpServletRequest request,
                                                              AnalysisBusinessDTO analysisBusinessDTO) {
        log.info("{}-into /select/selectAnalysisMonitorlistpage,param={ " + analysisBusinessDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<AnalysisBusinessDTO> analysisBusinessPage = new Page<AnalysisBusinessDTO>(
                analysisBusinessDTO.getPageSize(), analysisBusinessDTO.getCurrentPage());
        analysisBusinessPage.setParam(analysisBusinessDTO);
        AnalysisBusinessPageDTO result = exportExcelBusinessServiceImpl
                .selectAnalysisBusinessList(analysisBusinessPage);
        analysisBusinessPage = result.getAnalysisBusinessDTOPage();
        Map<String, Object> model = Maps.newHashMap();
        if (analysisBusinessPage != null) {
            model.put("analysisBusinessList", analysisBusinessPage.getResultList());
        }

        model.put("role", result.getRole());
        model.put("analysisBusinessDTO", analysisBusinessDTO);
        model.put("page", analysisBusinessPage);
        return new ModelAndView("cms/analysisBusiness", model);
    }

    @RequestMapping(value = "/doexportexcelbusiness/{sdate}/{edate}", method = RequestMethod.GET)
    public void doExportExcelBusiness(HttpServletResponse response, @PathVariable String sdate,
                                      @PathVariable String edate) {
        log.info("{}-/doExportExcelBusiness,doExportExcelBusiness start……", ThreadLocalUtil.getRequestNo());
        exportExcelBusinessServiceImpl.doExportExcelBusiness(response, sdate, edate);
    }

    @RequestMapping(value = "/gettodaydataanalysisbusiness", method = RequestMethod.POST)
    public ResultBase<String> getTodayDataAnalysisBusiness() {
        log.info("{}-/getTodayDataAnalysisBusiness,getTodayDataAnalysisBusiness start……",
                ThreadLocalUtil.getRequestNo());
        return exportExcelBusinessServiceImpl.getTodayDataAnalysisBusiness();
    }

}
