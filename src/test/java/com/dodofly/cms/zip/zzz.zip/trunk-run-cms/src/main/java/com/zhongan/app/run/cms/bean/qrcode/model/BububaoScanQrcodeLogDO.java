package com.zhongan.app.run.cms.bean.qrcode.model;

import lombok.Data;

import java.util.Date;

/**
 * 扫码日志
 * 
 * @author lichao002
 * @data 2018-06-01
 */
@Data
public class BububaoScanQrcodeLogDO {

    /**
     * 日志id
     */
    private Long   id;

    /**
     * 数据id
     */
    private Long   scanDataId;

    /**
     * 数据类型 1 机构 2 个人
     */
    private Short  scanDataType;

    /**
     * 用户openId
     */
    private String scanOpenId;

    /**
     * 步步保统一id
     */
    private Long   scanUnionId;

    /**
     * 日志类型 1 扫码 2 投保
     */
    private Short  scanLogType;

    /**
     * 保单号
     */
    private String scanPolicyNo;

    /**
     * 是否删除 N、Y
     */
    private String isDeleted;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date   gmtCreated;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 更新时间
     */
    private Date   gmtModified;

}
