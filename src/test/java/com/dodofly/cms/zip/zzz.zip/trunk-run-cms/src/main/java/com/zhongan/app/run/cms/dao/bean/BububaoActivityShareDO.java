package com.zhongan.app.run.cms.dao.bean;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 续保分享邀请DO
 */
@Data
public class BububaoActivityShareDO implements Serializable {
    private Long              id;

    /**
     * 步步保用户统一信息表id
     */

    private Long              unionid;

    /**
     * 用户来源
     */

    private String            channelFrom;

    /**
     * 活动来源标识
     */

    private String            activityCode;

    /**
     * 分享标识
     */
    private String            shareCode;

    /**
     * 链接是否分享过 1是 0否
     */

    private String            isShared;

    /**
     * 链接是否过期 1是 0否
     */

    private String            isOverdue;

    /**
     * 用户分享的链接
     */

    private String            shareUrl;

    /**
     * 生效时间
     */
    private Date              effectiveTime;

    /**
     * 失效时间
     */
    private Date              expiryTime;

    /**
     * 扩展信息
     */
    private String            extraInfo;

    /**
     * 删除标识 N-未;Y-已
     */

    private String            isDeleted;

    /**
     * 创建时间
     */

    private Date              gmtCreated;

    /**
     * 修改时间
     */

    private Date              gmtModified;

    /**
     * 创建者
     */

    private String            creator;

    /**
     * 修改者
     */

    private String            modifier;

    private static final long serialVersionUID = 1L;

}
