package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

import com.zhongan.health.common.share.bean.PageDTO;

/**
 * @author yangzhen001
 */
@Data
public class BububaoActivityRuleDTO extends PageDTO<BububaoActivityRuleDTO> {

    private static final long   serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long                id;

    /**
     * 活动id
     */
    private Long                activityId;

    /**
     * 规则名称
     */
    private String              ruleName;

    /**
     * 渠道
     */
    private String              source;

    /**
     * 规则
     */
    private String              activityRule;

    /**
     * 创建者
     */
    private String              creator;

    /**
     * 修改者
     */
    private String              modifier;

    /**
     * 创建时间
     */
    private String              gmtCreated;

    /**
     * 修改时间
     */
    private String              gmtModified;

    /**
     * 是否删除(Y/N，默认为:N)
     */
    private String              isDeleted;

    /**
     * 扩展信息
     */
    private String              extraInfo;
    /**
     * 规则详细信息
     */
    private ActivityRuleInfoDTO ruleInfo;

    /**
     * 每天最大步数
     */
    private String              maxStepDay;
    /**
     * 每天最小步数
     */
    private String              minStepDay;
    /**
     * 最大达标天数
     */
    private String              maxStandardDays;
    /**
     * 最小达标天数
     */
    private String              minStandardDays;

}
