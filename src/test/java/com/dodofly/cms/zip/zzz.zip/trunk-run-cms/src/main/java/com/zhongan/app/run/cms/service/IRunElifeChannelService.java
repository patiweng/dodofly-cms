package com.zhongan.app.run.cms.service;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelResDTO;
import com.zhongan.health.common.share.bean.PageDTO;

public interface IRunElifeChannelService {

    /**
     * 查询列表
     * 
     * @param dto
     * @return
     */
    public PageDTO<RunElifeChannelResDTO> queryList(RunElifeChannelQueryDTO dto) throws Exception;

    /**
     * 保存或更新
     * 
     * @param dto
     * @return
     */
    public Integer saveOrUpdate(RunElifeChannelDTO dto) throws Exception;

    /**
     * 根据条件查询
     * 
     * @param dto
     * @return
     */
    public JSONObject queryByCondition(RunElifeChannelDTO dto) throws Exception;

    /**
     * 查询总数
     * 
     * @param dto
     * @return
     */
    public Integer getCount(RunElifeChannelDTO dto) throws Exception;

    /**
     * 删除记录
     * 
     * @param id
     * @return
     */
    public Integer deleteById(Long id) throws Exception;

}
