package com.zhongan.app.run.cms.bean.dataobject;

import java.util.Date;

import lombok.Data;

@Data
public class SpecialAwardDO implements Cloneable {

    private Long    id;

    private Integer requireid;

    private String  description;

    private Integer minPlayTimes;

    private Integer maxPlayTimes;

    private String  isWon;

    private String  creator;

    private String  modifier;

    private Date    createtime;

    private Date    modifytime;

    private String  isDeleted;

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
