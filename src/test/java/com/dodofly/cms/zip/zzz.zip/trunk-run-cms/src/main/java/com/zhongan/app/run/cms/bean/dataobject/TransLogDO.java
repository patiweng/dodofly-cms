package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class TransLogDO {

    private String id;
    private String transUnionId;
    private String transUserId;
    private String transSourceCode;
    private String transCode;
    private String transName;
    private String transUrl;
    private String transResult;
    private String transSdate;
    private String transEdate;
    private String transTime;
}
