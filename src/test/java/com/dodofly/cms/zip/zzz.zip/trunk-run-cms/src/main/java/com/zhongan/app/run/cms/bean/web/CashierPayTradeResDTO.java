package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;
import java.math.BigDecimal;

public class CashierPayTradeResDTO implements Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = -4396243776712042473L;

    /**
     * 主键
     */
    private Long              id;

    /**
     * 用户名
     */
    private String            userName;
    /**
     * 手机号
     */
    private String            phone;
    /**
     * 身份证
     */
    private String            CertNo;

    /**
     * 保单号
     */
    private String            policyNo;

    /**
     * 扣款金额
     */
    private BigDecimal        deductionsPay;

    /**
     * 扣款日期
     */
    private String            deductionsDate;

    /**
     * 扣款状态
     */
    private Long              deductionsStatus;
    /**
     * 开通渠道
     */
    private String            openChannel;
    /**
     * 开通状态
     */
    private Long              openStatus;

    /**
     * 扣款次数
     */
    private Long              deductionsNum;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCertNo() {
        return CertNo;
    }

    public void setCertNo(String certNo) {
        CertNo = certNo;
    }

    public String getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    public BigDecimal getDeductionsPay() {
        return deductionsPay;
    }

    public void setDeductionsPay(BigDecimal deductionsPay) {
        this.deductionsPay = deductionsPay;
    }

    public String getDeductionsDate() {
        return deductionsDate;
    }

    public void setDeductionsDate(String deductionsDate) {
        this.deductionsDate = deductionsDate;
    }

    public Long getDeductionsStatus() {
        return deductionsStatus;
    }

    public void setDeductionsStatus(Long deductionsStatus) {
        this.deductionsStatus = deductionsStatus;
    }

    public String getOpenChannel() {
        return openChannel;
    }

    public void setOpenChannel(String openChannel) {
        this.openChannel = openChannel;
    }

    public Long getOpenStatus() {
        return openStatus;
    }

    public void setOpenStatus(Long openStatus) {
        this.openStatus = openStatus;
    }

    public Long getDeductionsNum() {
        return deductionsNum;
    }

    public void setDeductionsNum(Long deductionsNum) {
        this.deductionsNum = deductionsNum;
    }
}
