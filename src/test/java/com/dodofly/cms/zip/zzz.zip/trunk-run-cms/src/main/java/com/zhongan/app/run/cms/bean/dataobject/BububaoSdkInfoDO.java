package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoSdkInfoDO {
	private String id;
	private String appId;
	private String appSerect;
	private String createTime;
	private String modifyTime;
	private String status;
	private String campaigndefId;
	private String packagedefId;
	private String versionId;
	private String des;
}
