package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.bo.RunChannelListBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListPageDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.AppUtil;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.RunChannelListService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RunChannelListServiceImpl implements RunChannelListService {

    @Resource
    private RunChannelListRepository runChannelListRepository;

    @Resource
    private OssTool                  ossTool;

    @Override
    public ResultBase<RunChannelListDTO> selectChannelListInfo(RunChannelListBO runChannelListBO) {
        ResultBase<RunChannelListDTO> result = new ResultBase<RunChannelListDTO>();
        log.info("{}-ChannelList...select...begin...", ThreadLocalUtil.getRequestNo());
        //参数的校验
        ResultBase<String> valResult = CheckBitparam(runChannelListBO);
        if (!valResult.isSuccess()) {
            log.info("{}-fail--param:" + valResult.getErrorCode() + "-" + valResult.getErrorMessage(),
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
            BeanUtils.copyProperties(runChannelListBO, runChannelListRepo);
            result = runChannelListRepository.selectRunChannelListData(runChannelListRepo);
            if (result.getValue() != null) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(false);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-RunChannelList select fail,please find error to..."
                    + "error location polynomial : RunChannelListServiceImpl--selectChannelListInfo()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    //入参数的校验
    @SuppressWarnings({ "unchecked" })
    private ResultBase<String> CheckBitparam(RunChannelListBO runChannelListBO) {
        log.info("{}-param check code...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        //渠道号
        if (StringUtils.isEmpty(runChannelListBO.getNo())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100009, result);
        }
        result.setSuccess(true);
        return result;
    }

    //分页查询渠道信息
    @Override
    public RunChannelListPageDTO selectRunChannelListPage(Page<RunChannelListDTO> runChannelListPage) {
        RunChannelListPageDTO runChannelListPageDTO = new RunChannelListPageDTO();
        Page<RunChannelListRepo> runChannelListRepoPage = new Page<RunChannelListRepo>();
        BeanUtils.copyProperties(runChannelListPage, runChannelListRepoPage);
        runChannelListRepoPage = runChannelListRepository.selectChannelListPage(runChannelListRepoPage);
        List<RunChannelListRepo> runChannelListRepolist = runChannelListRepoPage.getResultList();
        List<RunChannelListDTO> runChannelListDTOList = Lists.newArrayList();
        if (runChannelListRepolist != null && runChannelListRepolist.size() > 0) {
            RunChannelListDTO runChannelListDTO = null;
            for (RunChannelListRepo runChannelListRepos : runChannelListRepolist) {
                runChannelListDTO = new RunChannelListDTO();
                BeanUtils.copyProperties(runChannelListRepos, runChannelListDTO);
                runChannelListDTOList.add(runChannelListDTO);
            }
        }
        runChannelListPage.setResultList(runChannelListDTOList);
        runChannelListPage.setTotalItem(runChannelListRepoPage.getTotalItem());
        runChannelListPageDTO.setRunChannelListDTODTOPage(runChannelListPage);
        return runChannelListPageDTO;
    }

    //插入一条新的渠道信息
    @Override
    public ResultBase<String> insertChannelList(RunChannelListDTO runChannelListDTO) {
        ResultBase<String> result = new ResultBase<String>();
        //验证渠道号和 活动类型的重复校验
        RunChannelListRepo runChannelList = new RunChannelListRepo();
        runChannelList.setNo(runChannelListDTO.getNo());
        runChannelList.setType(runChannelListDTO.getType());
        ResultBase<RunChannelListDTO> resulte = runChannelListRepository.selectRunChannelListData(runChannelList);
        if (resulte.getValue() != null) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10004.getValue());
            return result;
        }
        try {
            RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
            BeanUtils.copyProperties(runChannelListDTO, runChannelListRepo);
            result = runChannelListRepository.saveChannelList(runChannelListRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save--ChannelList...."
                    + "error location polynomial : RunChannelListServiceImpl--insertChannelList()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    //根据 主键ID修改渠道信息
    @Override
    public ResultBase<String> updateChannelList(RunChannelListDTO runChannelListDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
            BeanUtils.copyProperties(runChannelListDTO, runChannelListRepo);
            result = runChannelListRepository.updateChannelList(runChannelListRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-更新失败{}" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    /*
     * //图片大小不能超过256k private boolean extendSize(MultipartFile marketingImgFile)
     * { long imgSize = marketingImgFile.getSize(); double d = imgSize / 1024;
     * if (d > 256) { return false; } return true; }
     */

    //真假主键 ID删除渠道信息
    @Override
    public ResultBase<String> deleteChannelList(String id) {
        log.info("{}-delete ChannelList info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            runChannelListRepository.deleteByid(id);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-ChannelList delete fail,please find error to...。"
                    + "error location polynomial:RunChannelListServiceImpl--deleteChannelList()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    //根据ID 查询单个对象的信息
    @Override
    public RunChannelListDTO selectOneChannelList(String id) {
        log.info("{}-select one RunChannelList info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        RunChannelListDTO runChannelListDTO = new RunChannelListDTO();
        try {
            RunChannelListRepo runChannelListRepo = runChannelListRepository.selectOneData(id);
            if (runChannelListRepo != null) {
                BeanUtils.copyProperties(runChannelListRepo, runChannelListDTO);
            }
        } catch (Exception e) {
            log.error("{}-RunChannelList select one  fail,please find error to...。"
                    + "error location polynomial:RunChannelListServiceImpl--selectOneChannelList()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
        }
        return runChannelListDTO;
    }

}
