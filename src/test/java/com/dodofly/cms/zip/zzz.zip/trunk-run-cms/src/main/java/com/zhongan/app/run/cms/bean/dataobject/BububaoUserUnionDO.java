package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoUserUnionDO {

	 private String id;
	 private String identity;
	 private String identityName;
	 private String sex;
	 private String phone;
	 private String nickName;
	 private String headImgUrl;
	 private String employeeId;
	 private String createTime;
	 private String modifyTime;
	 private String isFirst;
	 private String card;
	 private String birthday;
}
