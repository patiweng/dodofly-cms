package com.zhongan.app.run.cms.bean.bo;

import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

@Data
public class RafflePresentBO {
    private String        id;
    private String        name;
    private String        identify;
    private String        identifyBig;
    private String        description;
    private String        price;
    private String        url;
    private String        integral;
    private String        type;
    private String        creator;
    private String        modifier;
    private String        createTime;
    private String        modifyTime;
    private String        isDeleted;
    private MultipartFile presentImgFile;   //上传到OSS小的图片
    private MultipartFile presentImgFileTwo; //上传到OSS大的图片
    private Integer       pageSize;
    private Integer       currentPage;
    private String        typeCode;         //礼物标识code
}
