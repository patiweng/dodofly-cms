package com.zhongan.app.run.cms.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.ActivityShareDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.dao.BububaoActivityShareMapper;
import com.zhongan.app.run.cms.dao.bean.BububaoActivityShareDO;
import com.zhongan.app.run.cms.dao.bean.BububaoActivityShareExample;
import com.zhongan.app.run.cms.dao.bean.BububaoActivityShareExample.Criteria;
import com.zhongan.app.run.cms.service.ActivityShareService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.enm.YesOrNo;

@Service
@Slf4j
public class ActivityShareServiceImpl implements ActivityShareService {

    @Resource
    private BububaoActivityShareMapper userRenewalShareMapper;

    /**
     * 根据条件查询续保用户分享信息
     * 
     * @param info
     * @return
     */
    @Override
    public ResultBase<List<ActivityShareDTO>> queryActivityShareInfoByCdt(ActivityShareDTO info) {
        ResultBase<List<ActivityShareDTO>> result = new ResultBase<List<ActivityShareDTO>>();
        try {
            List<BububaoActivityShareDO> selectByExample = userRenewalShareMapper.selectByExample(this
                    .buildUserRenewalShareInfoCriteria(info));
            List<ActivityShareDTO> list = null;
            if (CollectionUtils.isNotEmpty(selectByExample)) {
                list = Lists.newArrayList();
                ActivityShareDTO dto = null;
                for (BububaoActivityShareDO userRenewalShareDO : selectByExample) {
                    dto = new ActivityShareDTO();
                    BeanUtils.copyProperties(userRenewalShareDO, dto);
                    list.add(dto);
                }
            }
            result.setValue(list);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-queryActivityShareInfoByCdt,e={}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            return result;
        }
        return result;
    }

    private BububaoActivityShareExample buildUserRenewalShareInfoCriteria(ActivityShareDTO dto) {
        BububaoActivityShareExample userRenewalShareExample = new BububaoActivityShareExample();
        userRenewalShareExample.setOrderByClause("id DESC");
        Criteria criteria = userRenewalShareExample.createCriteria();
        if (null != dto.getId()) {
            criteria.andIdEqualTo(dto.getId());
        }
        if (null != dto.getUnionid()) {
            criteria.andUnionidEqualTo(dto.getUnionid());
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (StringUtils.isNoneBlank(dto.getActivityCode())) {
            criteria.andActivityCodeEqualTo(dto.getActivityCode());
        }
        if (StringUtils.isNoneBlank(dto.getIsShared())) {
            criteria.andIsSharedEqualTo(dto.getIsShared());
        }
        if (StringUtils.isNoneBlank(dto.getIsOverdue())) {
            criteria.andIsOverdueEqualTo(dto.getIsOverdue());
        }
        if (StringUtils.isNoneBlank(dto.getShareUrl())) {
            criteria.andShareUrlEqualTo(dto.getShareUrl());
        }
        if (StringUtils.isNoneBlank(dto.getShareCode())) {
            criteria.andShareCodeEqualTo(dto.getShareCode());
        }
        if (null != dto.getNowTime()) {
            criteria.andEffectiveTimeLessThanOrEqualTo(dto.getNowTime());
            criteria.andExpiryTimeGreaterThanOrEqualTo(dto.getNowTime());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userRenewalShareExample;
    }

    /**
     * 根据条件查询插入或者更新
     * 
     * @param info
     * @return
     */
    @Override
    public ResultBase<String> inOrUpUserActivityShareInfoByCdt(ActivityShareDTO info) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            ActivityShareDTO dto = new ActivityShareDTO();
            dto.setId(info.getId());
            dto.setActivityCode(info.getActivityCode());
            dto.setChannelFrom(info.getChannelFrom());
            dto.setUnionid(info.getUnionid());
            dto.setShareCode(info.getShareCode());
            ResultBase<List<ActivityShareDTO>> infoByCdt = this.queryActivityShareInfoByCdt(dto);
            if (!infoByCdt.isSuccess()) {
                log.error("{}-inOrUpUserActivityShareInfoByCdt>>>>queryActivityShareInfoByCdt",
                        ThreadLocalUtil.getRequestNo());
                result.setSuccess(false);
                result.setErrorCode(infoByCdt.getErrorCode());
                result.setErrorMessage(infoByCdt.getErrorMessage());
                return result;
            }
            log.info("{}-inOrUpUserActivityShareInfoByCdt>>>>queryActivityShareInfoByCdt,param={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(infoByCdt));
            BububaoActivityShareDO activityShare = new BububaoActivityShareDO();
            BeanUtils.copyProperties(info, activityShare);
            if (CollectionUtils.isEmpty(infoByCdt.getValue())) {
                BeanUtils.copyProperties(info, activityShare);
                activityShare.setGmtModified(new Date());
                activityShare.setGmtCreated(new Date());
                userRenewalShareMapper.insertSelective(activityShare);
            } else {
                ActivityShareDTO userRenewalShareDTO = infoByCdt.getValue().get(0);
                activityShare.setId(userRenewalShareDTO.getId());
                activityShare.setGmtModified(new Date());
                userRenewalShareMapper.updateByPrimaryKeySelective(activityShare);
            }
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-inOrUpUserActivityShareInfoByCdt", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            return result;
        }
        return result;

    }
}
