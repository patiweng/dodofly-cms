package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

@Data
public class RunMarketingActivitiesDTO {
    private String        id;
    private String        activitiesType;
    private String        activitiesName;
    private String        activityCode;
    private String        activitiesIcon;
    private String        activitiesUrl;
    private String        isselfFlag;
    private String        disOrder;
    private String        startTime;
    private String        endTime;
    private String        minStep;
    private String        maxStep;
    private String        allChannel;
    private String        creator;
    private String        modifier;
    private String        gmtCreated;
    private String        gmtModified;
    private String        isDeleted;
    private String        unionId;         //用户ID 	 
    private Integer       pageSize;
    private Integer       currentPage;
    private MultipartFile marketingImgFile; //上传到OSS 的图片
    private String        userStep;
    private String        activityId;
    private String        activityMark;
    /**
     * 扩展参数
     */
    private String        extraParam;
}
