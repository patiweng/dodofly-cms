package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

public class CashierHelpPayDetailResDTO {
    /**
     * 主键
     */
    private Long   id;

    /**
     * 代收代付ID
     */
    private Long   cashierId;

    /**
     * 用户合同号
     */
    private String userContractNo;

    /**
     * 代扣渠道
     */
    private String dkSource;

    /**
     * 业务时间
     */
    private String bizTime;

    /**
     * 业务状态(1:已开通 2:未开通)
     */
    private Long   bizStatus;

    /**
     * 渠道信息
     */
    private String bizChannel;

    /**
     * 扩展信息,json格式
     */
    private String extraInfo;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date   gmtCreated;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 修改时间
     */
    private Date   gmtModified;

    /**
     * 是否删除
     */
    private String isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCashierId() {
        return cashierId;
    }

    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    public String getUserContractNo() {
        return userContractNo;
    }

    public void setUserContractNo(String userContractNo) {
        this.userContractNo = userContractNo;
    }

    public String getDkSource() {
        return dkSource;
    }

    public void setDkSource(String dkSource) {
        this.dkSource = dkSource;
    }

    public String getBizTime() {
        return bizTime;
    }

    public void setBizTime(String bizTime) {
        this.bizTime = bizTime;
    }

    public Long getBizStatus() {
        return bizStatus;
    }

    public void setBizStatus(Long bizStatus) {
        this.bizStatus = bizStatus;
    }

    public String getBizChannel() {
        return bizChannel;
    }

    public void setBizChannel(String bizChannel) {
        this.bizChannel = bizChannel;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

}
