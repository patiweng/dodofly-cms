package com.zhongan.app.run.cms.bean.web;

public class RunElifeChannelProductDTO {

    private Long   id;

    /**
     * 渠道id
     */
    private Long   channelId;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 产品ID
     */
    private Long   productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 营销活动ID
     */
    private Long   campaignDefId;

    /**
     * 营销活动名称
     */
    private String campaignDefName;

    /**
     * 扩展信息,json格式
     */
    private String extraInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Long getCampaignDefId() {
        return campaignDefId;
    }

    public void setCampaignDefId(Long campaignDefId) {
        this.campaignDefId = campaignDefId;
    }

    public String getCampaignDefName() {
        return campaignDefName;
    }

    public void setCampaignDefName(String campaignDefName) {
        this.campaignDefName = campaignDefName;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }
}
