package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class CmsAuthorityDO {
	private String id;
	private String userId;
	private String menuId;
	private String creator;
	private String modifier;
	private String gmtCreated;
	private String gmtModified;
	private String isDeleted;
}
