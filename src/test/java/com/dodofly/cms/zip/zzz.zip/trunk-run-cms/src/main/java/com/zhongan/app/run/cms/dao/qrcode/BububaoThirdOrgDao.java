package com.zhongan.app.run.cms.dao.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultOrgDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdOrgDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * 组织机构管理 Dao层
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Component
public interface BububaoThirdOrgDao {

    /**
     * 根据组织id删除组织机构
     * 
     * @param id
     * @return
     */
    Integer deleteByPrimaryKey(Long id);

    /**
     * 保存组织机构
     * 
     * @param record
     * @return
     */
    Integer insert(BububaoThirdOrgDO record);

    /**
     * 保存组织机构
     * 
     * @param record
     * @return
     */
    Integer insertSelective(BububaoThirdOrgDO record);

    /**
     * 根据组织id查询组织机构
     * 
     * @param id
     * @return
     */
    BububaoThirdOrgDO selectByPrimaryKey(Long id);

    /**
     * 更新组织机构
     * 
     * @param record
     * @return
     */
    Integer updateByPrimaryKeySelective(BububaoThirdOrgDO record);

    /**
     * 根据组织id更新组织机构
     * 
     * @param record
     * @return
     */
    Integer updateByPrimaryKey(BububaoThirdOrgDO record);

    /**
     * 根据父机构id查询子机构
     * 
     * @param record
     * @return
     */
    List<BububaoThirdOrgDO> selectByParentIdAndId(BububaoThirdOrgDO record);

    /**
     * 根据机构信息查询机构信息
     * 
     * @param map
     * @return
     */
    List<BububaoThirdOrgDO> selectByInfo(Map<String, Object> map);

    /**
     * 根据code正则表达式匹配数
     * 
     * @param orgCode
     * @param parentId
     * @return
     */
    Integer selectByCode(@Param("orgCode") String orgCode, @Param("parentOrgId") Long parentId);

    /**
     * 逻辑删除机构信息
     * 
     * @param id
     * @param modifier
     * @return
     */
    Integer deleteByOrgId(@Param("id") Long id, @Param("modifier") String modifier);

    /**
     * 根据机构id查询机构名称
     * 
     * @param id
     * @return
     */
    String selectNameById(Long id);

    /**
     * 五级机构分页查询
     * @param paramDto
     * @return
     */
    List<ResultOrgDto> selectOrgsPage(ParamDto paramDto);

    /**
     * 五级机构查询总数
     * @param paramDto
     * @return
     */
    Integer selectOrgsCount(ParamDto paramDto);
}
