package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoCampaignListDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoMarketingActivitiesDO;

@Component
public interface BububaoCampaignListDAO {

	 /**
    * 根据条件查询数据
    * @return
    */
   List<BububaoCampaignListDO> selectDataByCdt(BububaoCampaignListDO bububaoCampaignListDO);
   
   /**
    * 根据id查询数据
    * @param id
    * @return
    */
   BububaoCampaignListDO selectOneDataById(String id);
   
   /**
    * 插入数据
    * @param BububaoCampaignListDO
    */
   void insert(BububaoCampaignListDO bububaoCampaignListDO);
   
   /**
    * 更新数据
    * @param BububaoCampaignListDO
    */
   void update(BububaoCampaignListDO bububaoCampaignListDO);
   /**
    * 分页查询BububaoCampaignList信息
    * 
    * @param map
    * @return
    */
   List<BububaoCampaignListDO> selectBububaoCampaign(Map map);
   
   /**
    * 查询BububaoCampaignList条数
    * 
    * @param map
    * @return
    */
   Integer selectCounts(Map map);
   
   /**
    * 删除BububaoCampaignList
    * 
    * @param  id
    * @return
    */
   void deleteCampaignListById(String id);
   
   /**
    * 更新数据为无效数据
    * @param id
    */
   void updateByid(String id);
}
