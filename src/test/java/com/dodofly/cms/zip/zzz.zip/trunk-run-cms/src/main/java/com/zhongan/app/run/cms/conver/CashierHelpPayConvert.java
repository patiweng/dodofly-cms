package com.zhongan.app.run.cms.conver;

import java.util.Date;
import java.util.List;

import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayResDTO;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDO;
import com.zhongan.health.common.share.enm.YesOrNo;
import com.zhongan.health.common.utils.DateUtils;

public class CashierHelpPayConvert {

    public static List<CashierHelpPayResDTO> convertResDTO(List<CashierHelpPayDO> list) {
        List<CashierHelpPayResDTO> cashierHelpPayResDTOs = Lists.newArrayList();
        CashierHelpPayResDTO cashierHelpPayResDTO = null;
        for (CashierHelpPayDO cashierHelpPayDO : list) {
            cashierHelpPayResDTO = new CashierHelpPayResDTO();
            BeanUtils.copyProperties(cashierHelpPayDO, cashierHelpPayResDTO);
            cashierHelpPayResDTO.setOpenTime(DateUtils.shortFormat(cashierHelpPayDO.getOpenTime()));
            cashierHelpPayResDTO.setCloseTime(DateUtils.shortFormat(cashierHelpPayDO.getCloseTime()));
            cashierHelpPayResDTOs.add(cashierHelpPayResDTO);
        }
        return cashierHelpPayResDTOs;
    }

    public static CashierHelpPayDO convertDO(CashierHelpPayDTO cashierHelpPayDTO) {
        CashierHelpPayDO cashierHelpPayDO = new CashierHelpPayDO();
        BeanUtils.copyProperties(cashierHelpPayDTO, cashierHelpPayDO);
        if (null == cashierHelpPayDTO.getId()) {
            cashierHelpPayDO.setCreator("system");
            cashierHelpPayDO.setGmtCreated(new Date());
            cashierHelpPayDO.setModifier("system");
            cashierHelpPayDO.setGmtModified(new Date());
            cashierHelpPayDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            cashierHelpPayDO.setModifier("system");
            cashierHelpPayDO.setGmtModified(new Date());
        }
        return cashierHelpPayDO;
    }

    public static List<CashierHelpPayDTO> convertDTO(List<CashierHelpPayDO> list) {
        List<CashierHelpPayDTO> cashierHelpPayResDTOs = Lists.newArrayList();
        CashierHelpPayDTO cashierHelpPayResDTO = null;
        for (CashierHelpPayDO cashierHelpPayDO : list) {
            cashierHelpPayResDTO = new CashierHelpPayDTO();
            BeanUtils.copyProperties(cashierHelpPayDO, cashierHelpPayResDTO);
            cashierHelpPayResDTOs.add(cashierHelpPayResDTO);
        }
        return cashierHelpPayResDTOs;
    }
}
