package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.RunElifeProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductResDTO;
import com.zhongan.app.run.cms.conver.RunElifeConvert;
import com.zhongan.app.run.cms.dao.RunElifeProductMapper;
import com.zhongan.app.run.cms.dao.bean.RunElifeProductCriteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeProductCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeProductDO;
import com.zhongan.app.run.cms.service.IRunElifeProductService;
import com.zhongan.health.common.share.bean.PageDTO;
import com.zhongan.health.common.share.enm.YesOrNo;

@Service("runElifeProductService")
public class RunElifeProductServiceImpl implements IRunElifeProductService {

    @Resource
    private RunElifeProductMapper mapper;

    @Resource
    private Sequence              seqRunElifeProduct;

    @Override
    public PageDTO<RunElifeProductResDTO> queryList(RunElifeProductQueryDTO dto) throws Exception {
        PageDTO<RunElifeProductResDTO> pageDTO = new PageDTO<RunElifeProductResDTO>();
        int size = dto.getPageSize();
        int currentPage = dto.getCurrentPage() < 1 ? 1 : dto.getCurrentPage();
        pageDTO.setCurrentPage(currentPage);
        pageDTO.setPageSize(size);
        RunElifeProductCriteria criteria = buildCriteria(RunElifeConvert.convertProductDTO(dto));
        int count = mapper.countByCriteria(criteria);
        if (count > 0) {
            int start = (currentPage - 1) * size;
            PageInfo pageInfo = new PageInfo();
            pageInfo.setOffset(start);
            pageInfo.setSize(size);
            List<RunElifeProductDO> selectByCriteriaWithPage = mapper.selectByCriteriaWithPage(criteria, pageInfo);
            pageDTO.setResultList(RunElifeConvert.convertProductResDTOs(selectByCriteriaWithPage));
            pageDTO.setTotalItem(count);
        }
        return pageDTO;
    }

    @Override
    public Integer saveOrUpdate(RunElifeProductDTO dto) throws Exception {
        List<RunElifeProductDO> elifeProductDOs = mapper.selectByCriteria(buildCriteria(dto));
        if (CollectionUtils.isEmpty(elifeProductDOs)) {
            RunElifeProductDO converProductDo = RunElifeConvert.converProductDo(dto);
            converProductDo.setId(seqRunElifeProduct.nextValue());
            return mapper.insert(converProductDo);
        } else {
            return mapper.updateByPrimaryKeySelective(RunElifeConvert.converProductDo(dto));
        }
    }

    @Override
    public RunElifeProductResDTO queryByCondition(RunElifeProductDTO dto) throws Exception {
        return RunElifeConvert.convertProductResDTO(mapper.selectByCriteria(buildCriteria(dto)));
    }

    @Override
    public Integer getRunElifeProductCount(RunElifeProductDTO dto) throws Exception {
        return mapper.countByCriteria(buildCriteria(dto));
    }

    private RunElifeProductCriteria buildCriteria(RunElifeProductDTO dto) {
        RunElifeProductCriteria elifeProductCriteria = new RunElifeProductCriteria();
        Criteria criteria = elifeProductCriteria.createCriteria();
        if (null != dto.getId()) {
            criteria.andIdEqualTo(dto.getId());
        }
        if (StringUtils.isNotEmpty(dto.getProductName())) {
            criteria.andProductNameEqualTo(dto.getProductName());
        }
        if (null != dto.getProductId()) {
            criteria.andProductIdEqualTo(dto.getProductId());
        }
        if (StringUtils.isNotEmpty(dto.getBizRule())) {
            criteria.andBizRuleEqualTo(dto.getBizRule());
        }
        if (StringUtils.isNotEmpty(dto.getBizValue())) {
            criteria.andBizValueEqualTo(dto.getBizValue());
        }
        return elifeProductCriteria;
    }

    @Override
    public Integer deleteById(Long id) {
        RunElifeProductDO dto = new RunElifeProductDO();
        dto.setId(id);
        dto.setIsDeleted(YesOrNo.YES.getCode());
        return mapper.updateByPrimaryKeySelective(dto);
    }

    @Override
    public RunElifeProductResDTO queryById(Long id) throws Exception {
        return RunElifeConvert.convertProductResDTO(mapper.selectByPrimaryKey(id));
    }
}
