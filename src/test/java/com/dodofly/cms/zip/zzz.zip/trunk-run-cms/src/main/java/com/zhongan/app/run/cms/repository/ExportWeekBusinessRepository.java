package com.zhongan.app.run.cms.repository;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.icu.text.DecimalFormat;
import com.zhongan.app.run.cms.bean.dataobject.WeekBusinessDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.WeekBusinessRepo;
import com.zhongan.app.run.cms.bean.web.WeekBusinessDTO;
import com.zhongan.app.run.cms.dao.ExportWeekBusinessDAO;

@Repository
public class ExportWeekBusinessRepository {

    @Resource
    private ExportWeekBusinessDAO exportWeekBusinessDAO;

    public Page<WeekBusinessRepo> selectWeekBusinessPage(Page<WeekBusinessDTO> weekBusinessPage) {
        Map<String, Object> map = Maps.newHashMap();
        getParamMap(weekBusinessPage, map);
        List<WeekBusinessDO> weekBusinessDOList = exportWeekBusinessDAO.selectWeekBusinessList(map);
        List<WeekBusinessRepo> weekBusinessRepoList = Lists.newArrayList();
        if (null != weekBusinessDOList && weekBusinessDOList.size() > 0) {
            WeekBusinessRepo weekBusinessRepo = new WeekBusinessRepo();
            Long count_one = 0L;
            Long count_two = 0L;
            Long count_three = 0L;
            Long count_four = 0L;
            Long count_five = 0L;
            Long count_seven = 0L;
            Long count_eight = 0L;
            Long count_nine = 0L;
            Long count_ten = 0L;

            for (WeekBusinessDO weekBusinessDO : weekBusinessDOList) {
                WeekBusinessRepo clone = (WeekBusinessRepo) weekBusinessRepo.clone();
                BeanUtils.copyProperties(weekBusinessDO, clone);
                weekBusinessRepoList.add(clone);
                count_one = count_one + clone.getNew_shouquan_user();
                count_two = count_two + clone.getNew_insure_user();
                count_three = count_three + clone.getActive_all_user();
                count_four = count_four + clone.getActive_old_user();
                count_five = count_five + clone.getActive_new_user();
                count_seven = count_seven + clone.getPremium_xubao_user();
                count_eight = count_eight + clone.getPremium_mianfei_user();
                count_nine = count_nine + clone.getPremium_fufei_user();
                count_ten = count_ten + Long.parseLong(clone.getPremium_shouru());
            }
            WeekBusinessRepo weekRepo = new WeekBusinessRepo();
            weekRepo.setSource_name("总计");
            weekRepo.setNew_shouquan_user(count_one);
            weekRepo.setNew_insure_user(count_two);
            weekRepo.setActive_all_user(count_three);
            weekRepo.setActive_old_user(count_four);
            weekRepo.setActive_new_user(count_five);
            //weekRepo.setActive_persent(countRate());
            weekRepo.setPremium_xubao_user(count_seven);
            weekRepo.setPremium_mianfei_user(count_eight);
            weekRepo.setPremium_fufei_user(count_nine);
            weekRepo.setPremium_shouru(count_ten.toString());
            weekRepo.setPremium_ARPU(countNum(count_ten, count_nine));
            weekBusinessRepoList.add(weekRepo);
        }
        Page<WeekBusinessRepo> weekBusinessRepoPage = new Page<WeekBusinessRepo>();
        weekBusinessRepoPage.setResultList(weekBusinessRepoList);
        Integer counts = exportWeekBusinessDAO.selectCounts(map);
        weekBusinessRepoPage.setTotalItem(counts + 1);
        return weekBusinessRepoPage;
    }

    public List<WeekBusinessDO> queryWeekListForExcel() {
        //获取当前日期的上周周一至上周周日
        String[] dateArray = getLastTimeInterval();
        String beginDate = dateArray[0];
        String endDate = dateArray[1];
        Map<String, String> map = new HashMap<String, String>();
        map.put("sdate", beginDate);
        map.put("edate", endDate);
        return exportWeekBusinessDAO.queryWeekListForExcel(map);
    }

    private void getParamMap(Page<WeekBusinessDTO> weekBusinessDTOPage, Map<String, Object> map) {
        WeekBusinessDTO weekMonitorDTO = weekBusinessDTOPage.getParam();
        String bopsFlag = weekMonitorDTO.getBopsFlag();
        map.put("startRow", weekBusinessDTOPage.getStartRow());
        map.put("pageSize", weekBusinessDTOPage.getPageSize());

        //获取当前日期的上周周一至上周周日
        String[] dateArray = getLastTimeInterval();
        String beginDate = dateArray[0];
        String endDate = dateArray[1];

        //从左侧菜单点过来的,列表不显示数据
        if ("1".equals(bopsFlag)) {
            map.put("sdate", "null");
            map.put("edate", "null");
        } else {
            map.put("sdate", beginDate);
            map.put("edate", endDate);
        }
    }

    /**
     * 根据当前日期获得上周起始日期和上周结束日期
     * 
     * @return
     */
    public String[] getLastTimeInterval() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calendar1 = Calendar.getInstance();
        Calendar calendar2 = Calendar.getInstance();
        int dayOfWeek = calendar1.get(Calendar.DAY_OF_WEEK) - 1;
        int offset1 = 1 - dayOfWeek;
        int offset2 = 7 - dayOfWeek;
        calendar1.add(Calendar.DATE, offset1 - 7);
        calendar2.add(Calendar.DATE, offset2 - 7);
        String lastBeginDate = sdf.format(calendar1.getTime());
        String lastEndDate = sdf.format(calendar2.getTime());
        String[] dateArray = new String[2];
        dateArray[0] = lastBeginDate;
        dateArray[1] = lastEndDate;
        return dateArray;
    }

    /**
     * 字符串转百分比
     * 
     * @param rate
     * @return
     */
    private String formatPercentum(String rate) {
        NumberFormat nf = NumberFormat.getPercentInstance();
        String format = nf.format(Double.valueOf(rate));
        return format;
    }

    private String countRate(Long index, Long count) {
        if (index == 0 || count == 0) {
            return "0%";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return formatPercentum(s);
    }

    private String countNum(Long index, Long count) {
        if (index == 0 || count == 0) {
            return "0";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return s;
    }

}
