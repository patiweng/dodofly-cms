package com.zhongan.app.run.cms.service;

import javax.servlet.http.HttpServletResponse;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.WeekBusinessDTO;
import com.zhongan.app.run.cms.bean.web.WeekBusinessPageDTO;

public interface ExportWeekBusinessService {

    WeekBusinessPageDTO selectWeekBusinessList(Page<WeekBusinessDTO> weekBusinessPage);

    void doExportExcelWeekBusiness(HttpServletResponse response);

}
