package com.zhongan.app.run.cms.bean.web;

import com.zhongan.health.common.share.bean.PageDTO;

public class RunElifeProductQueryDTO extends PageDTO<CashierHelpPayQueryDTO> {

    /**
     * 
     */
    private static final long serialVersionUID = 4892420922494389010L;

    private Long              id;

    /**
     * 业务规则
     */
    private String            bizRule;

    /**
     * 业务参数
     */
    private String            bizValue;

    /**
     * 产品ID
     */
    private Long              productId;

    /**
     * 产品名称
     */
    private String            productName;

    /**
     * 产品版本
     */
    private String            productVersion;

    /**
     * 产品连接
     */
    private String            productLink;

    /**
     * 产品描述
     */
    private String            productDesc;

    /**
     * 扩展信息,json格式
     */
    private String            extraInfo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBizRule() {
        return bizRule;
    }

    public void setBizRule(String bizRule) {
        this.bizRule = bizRule;
    }

    public String getBizValue() {
        return bizValue;
    }

    public void setBizValue(String bizValue) {
        this.bizValue = bizValue;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getProductVersion() {
        return productVersion;
    }

    public void setProductVersion(String productVersion) {
        this.productVersion = productVersion;
    }

    public String getProductLink() {
        return productLink;
    }

    public void setProductLink(String productLink) {
        this.productLink = productLink;
    }

    public String getProductDesc() {
        return productDesc;
    }

    public void setProductDesc(String productDesc) {
        this.productDesc = productDesc;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

}
