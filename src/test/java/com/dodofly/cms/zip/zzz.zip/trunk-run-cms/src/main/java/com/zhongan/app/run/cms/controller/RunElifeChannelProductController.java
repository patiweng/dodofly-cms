package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductResDTO;
import com.zhongan.app.run.cms.service.IRunElifeChannelProductService;
import com.zhongan.app.run.common.utils.AppRunRuntimeException;
import com.zhongan.app.run.common.utils.BusinessErrorCode;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类RunElifeChannelProductController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月27日 下午2:11:54
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/elifeChannelProduct")
public class RunElifeChannelProductController {

    @Resource
    private IRunElifeChannelProductService runElifeChannelProductService;

    @RequestMapping(value = "/queryList")
    public BaseResult<PageDTO<RunElifeChannelProductResDTO>> queryList(@RequestBody RunElifeChannelProductQueryDTO dto) {
        log.info("RunElifeChannelProductController queryList param{}", JSON.toJSONString(dto));
        BaseResult<PageDTO<RunElifeChannelProductResDTO>> baseResult = new BaseResult<PageDTO<RunElifeChannelProductResDTO>>();
        try {
            baseResult.setSuccess(runElifeChannelProductService.queryList(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelProductController queryList param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelProductController queryList param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/saveOrUpdate")
    public BaseResult<Integer> saveOrUpdate(@RequestBody RunElifeChannelProductDTO dto) {
        log.info("RunElifeChannelProductController saveOrUpdate param{}", JSON.toJSONString(dto));
        BaseResult<Integer> baseResult = new BaseResult<Integer>();
        try {
            baseResult.setSuccess(runElifeChannelProductService.saveOrUpdate(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelProductController saveOrUpdate param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelProductController saveOrUpdate param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/delete")
    public BaseResult<Integer> delete(@RequestParam(name = "id", required = true) Long id) {
        log.info("RunElifeChannelProductController delete id:{}", id);
        BaseResult<Integer> baseResult = new BaseResult<Integer>();
        try {
            baseResult.setSuccess(runElifeChannelProductService.deleteById(id));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelProductController delete id{} exception{}", id, e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelProductController delete id{} exception{}", id, e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }
}
