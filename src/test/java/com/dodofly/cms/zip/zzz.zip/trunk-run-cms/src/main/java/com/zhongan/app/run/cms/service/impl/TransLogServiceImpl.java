package com.zhongan.app.run.cms.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.TransLogRepository;
import com.zhongan.app.run.cms.service.TransLogService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class TransLogServiceImpl implements TransLogService {
    @Resource
    private TransLogRepository transLogRepository;

    @Override
    public ResultBase<List<TransLogDO>> queryTransLogByDate(String sourceCode, String sdate, String edate) {
        // TODO Auto-generated method stub
        ResultBase<List<TransLogDO>> result = new ResultBase<List<TransLogDO>>();
        try {
            Map<String, String> map = new HashMap<String, String>();
            map.put("sourceCode", sourceCode);
            map.put("sdate", sdate);
            map.put("edate", edate);
            List<TransLogDO> list = transLogRepository.selectTransLogByDate(map);
            result.setSuccess(true);
            result.setValue(list);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
        } catch (Exception e) {
            log.error("{}-queryTransLogByDate select fail,please find error to..."
                    + "error location polynomial : TransLogServiceImpl--queryTransLogByDate()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

}
