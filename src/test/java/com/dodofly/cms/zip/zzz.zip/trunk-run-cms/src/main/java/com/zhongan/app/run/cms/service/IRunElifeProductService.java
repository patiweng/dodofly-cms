package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.web.RunElifeProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductResDTO;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类IRunElifeProductService.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月29日 下午3:55:11
 */
public interface IRunElifeProductService {

    /**
     * 查询列表
     * 
     * @param dto
     * @return
     */
    public PageDTO<RunElifeProductResDTO> queryList(RunElifeProductQueryDTO dto) throws Exception;

    /**
     * 保存或更新
     * 
     * @param dto
     * @return
     */
    public Integer saveOrUpdate(RunElifeProductDTO dto) throws Exception;

    /**
     * 根据条件查询
     * 
     * @param dto
     * @return
     */
    public RunElifeProductResDTO queryByCondition(RunElifeProductDTO dto) throws Exception;

    /**
     * 根据条件查询
     * 
     * @param dto
     * @return
     */
    public RunElifeProductResDTO queryById(Long id) throws Exception;

    /**
     * 查询总数
     * 
     * @param dto
     * @return
     */
    public Integer getRunElifeProductCount(RunElifeProductDTO dto) throws Exception;

    /**
     * 删除记录
     * 
     * @param id
     * @return
     */
    public Integer deleteById(Long id) throws Exception;
}
