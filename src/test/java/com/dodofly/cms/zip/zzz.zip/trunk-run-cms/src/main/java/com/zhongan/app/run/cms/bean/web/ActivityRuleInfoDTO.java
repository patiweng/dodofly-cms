package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;

import lombok.Data;

/**
 * @author yangzhen001
 */
@Data
public class ActivityRuleInfoDTO implements Serializable {

    private static final long serialVersionUID = 1L;
    /**
     * 活动规则主键
     */
    private Long              activityRuleId;
    /**
     * 每天最大步数
     */
    private String            maxStepDay;
    /**
     * 每天最小步数
     */
    private String            minStepDay;
    /**
     * 最大达标天数
     */
    private String            maxStandardDays;
    /**
     * 最小达标天数
     */
    private String            minStandardDays;

}
