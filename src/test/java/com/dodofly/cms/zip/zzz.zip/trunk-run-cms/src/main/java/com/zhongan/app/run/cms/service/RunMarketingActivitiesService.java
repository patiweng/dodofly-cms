package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.bo.RunMarketingActivitiesBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunAdvertHistoryDTO;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesDTO;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesPageDTO;

public interface RunMarketingActivitiesService {

    public ResultBase<List<RunMarketingActivitiesDTO>> selectRunMarketingAct(RunMarketingActivitiesBO RunMarketingActivitiesBO);

    public ResultBase<List<RunMarketingActivitiesDTO>> selectRunMarketingActAliPop(String sourceCode);

    public RunMarketingActivitiesPageDTO selectRunMarketingActPage(Page<RunMarketingActivitiesDTO> runMarketingActivitiesPage);

    public ResultBase<String> insertMarketing(RunMarketingActivitiesDTO runMarketingActivitiesDTO);

    public ResultBase<String> updateMarketing(RunMarketingActivitiesDTO runMarketingActivitiesDTO);

    public ResultBase<String> deleteMarketingActivities(String id);

    public RunMarketingActivitiesDTO selectOneMarketingActivities(String id);

    public ResultBase<RunMarketingActivitiesDTO> selectMarketingActivityById(String id);

    public ResultBase<List<RunMarketingActivitiesDTO>> selectRunMarketingActForThird(RunMarketingActivitiesBO RunMarketingActivitiesBO);

    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActivitiesByCdt(RunMarketingActivitiesBO runMarketingActivitiesBO);

    /**
     * 根据code查
     * 
     * @param runMarketingActivitiesBO
     * @return
     */
    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActivitiesByCode(RunMarketingActivitiesBO runMarketingActivitiesBO);

    public ResultBase<Boolean> advertHistoryByCdt(RunAdvertHistoryDTO info);

    public ResultBase<String> deleteByExample(Integer days);

}
