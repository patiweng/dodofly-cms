package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.QuestionItemDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.QuestionItemRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.dao.QuestionItemDAO;

@Slf4j
@Repository
public class QuestionItemRepository {

    @Resource
    private QuestionItemDAO questionItemDAO;

    @Resource
    private Sequence        seqQuestionItem;

    @Resource
    private OssTool         ossTool;

    @Value("${za.run.img.domain.url}")
    private String          imgDomain;

    public QuestionItemRepo selectDataById(Long id) {
        QuestionItemDO questionItemDO = questionItemDAO.selectDataById(id);
        QuestionItemRepo qRepo = null;
        if (null != questionItemDO) {
            qRepo = new QuestionItemRepo();
            BeanUtils.copyProperties(questionItemDO, qRepo);
        }
        return qRepo;
    }

    public List<QuestionItemRepo> selectDataByCdt(QuestionItemRepo questionItemRepo) {
        List<QuestionItemRepo> repoList = Lists.newArrayList();
        QuestionItemDO questionItemDO = new QuestionItemDO();
        BeanUtils.copyProperties(questionItemRepo, questionItemDO);
        List<QuestionItemDO> doList = questionItemDAO.selectDataByCdt(questionItemDO);
        if (null != doList && doList.size() > 0) {
            QuestionItemRepo repo = null;
            for (QuestionItemDO qdo : doList) {
                repo = new QuestionItemRepo();
                BeanUtils.copyProperties(qdo, repo);
                repoList.add(repo);
            }
        }
        return repoList;
    }

    /**
     * 分页查询
     * 
     * @param questionItemRepo
     * @return
     */
    public Page<QuestionItemRepo> selectQuestionItemDataPage(Page<QuestionItemRepo> questionItemRepo) {
        QuestionItemDO questionItemDO = new QuestionItemDO();
        if (null != questionItemRepo.getParam()) {
            BeanUtils.copyProperties(questionItemRepo.getParam(), questionItemDO);
        }
        questionItemDO.setIsDeleted(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", questionItemRepo.getStartRow());
        map.put("pageSize", questionItemRepo.getPageSize());
        map.put("questionItemDO", questionItemDO);
        List<QuestionItemDO> questionItemDOList = questionItemDAO.selectQuestionItemList(map);
        List<QuestionItemRepo> questionItemRepoList = Lists.newArrayList();
        if (null != questionItemDOList && 0 != questionItemDOList.size()) {
            QuestionItemRepo questionItemList = null;
            for (QuestionItemDO questionItemDOlists : questionItemDOList) {
                questionItemList = new QuestionItemRepo();
                BeanUtils.copyProperties(questionItemDOlists, questionItemList);
                questionItemRepoList.add(questionItemList);
            }
        }
        questionItemRepo.setResultList(questionItemRepoList);
        Integer counts = questionItemDAO.selectCounts(map);
        questionItemRepo.setTotalItem(counts);
        return questionItemRepo;
    }

    /**
     * 删除
     * 
     * @param id
     * @return
     */
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        questionItemDAO.updateDeletedById(id);
        result.setSuccess(true);
        return result;
    }

    /**
     * 插入一条新的记录
     * 
     * @param questionItemRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> saveQuestionItem(QuestionItemRepo questionItemRepo) throws Exception {
        log.info("{}-insert questionItem。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        QuestionItemDO questionItemDO = new QuestionItemDO();
        BeanUtils.copyProperties(questionItemRepo, questionItemDO);
        Long id = seqQuestionItem.nextValue();
        /** 文件上传 **/
        ResultBase<String> flagRs = ossTool.handleImg(String.valueOf(id), questionItemRepo.getMarketingImgFile());
        if (!flagRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
            return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        questionItemDO.setQueryIcon(fileUrl);
        questionItemDO.setId(id);
        questionItemDO.setCreator(RunConstants.SYSTEM_NAME);
        questionItemDAO.insert(questionItemDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    /**
     * 根据主键修改信息
     * 
     * @param questionItemRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> updateQuestionItemList(QuestionItemRepo questionItemRepo) throws Exception {
        ResultBase<String> result = new ResultBase<String>();
        log.info("{}-update questionItem。。。Repository。。。");
        QuestionItemDO questionItemDO = new QuestionItemDO();
        BeanUtils.copyProperties(questionItemRepo, questionItemDO);
        /** 文件上传 **/
        String id = questionItemDO.getId().toString();
        ResultBase<String> flagRs = ossTool.handleImg(id, questionItemRepo.getMarketingImgFile());
        if (!flagRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
            return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        questionItemDO.setQueryIcon(fileUrl);
        questionItemDAO.update(questionItemDO);
        result.setSuccess(true);
        return result;
    }
}
