package com.zhongan.app.run.cms.bean.qrcode.dto;

import com.zhongan.app.run.cms.common.csvutil.annotion.Property;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

import java.util.Date;

/**
 * 机构返回数据
 * 
 * @author lichao002
 * @date 2018-06-05
 */
@Slf4j
@Data
public class ResultOrgDto implements Cloneable {

    /**
     * 一级组织id
     */
    private Long   oneOrgId;
    /**
     * 一级组织名称
     */
    @Property(title = "oneOrgName")
    private String oneOrgName;
    /**
     * 二级组织id
     */
    private Long   twoOrgId;
    /**
     * 二级组织名称
     */
    @Property(title = "twoOrgName")
    private String twoOrgName;
    /**
     * 三级组织id
     */
    private Long   threeOrgId;
    /**
     * 三级组织名称
     */
    @Property(title = "threeOrgName")
    private String threeOrgName;
    /**
     * 四级组织id
     */
    private Long   fourOrgId;
    /**
     * 四级组织名称
     */
    @Property(title = "fourOrgName")
    private String fourOrgName;
    /**
     * 五级组织id
     */
    private Long   fiveOrgId;
    /**
     * 五级组织名称
     */
    @Property(title = "fiveOrgName")
    private String fiveOrgName;

    /**
     * 是否关注步步保
     */
    private String isFollowBububao;

    /**
     * 二维码id
     */
    private Long   qrcodeId;
    /**
     * 公司（机构）连接
     */
    private String qrcodeUrl;

    /**
     * 创建时间
     */
    private Date   gmtCreated;

    /**
     * 深克隆
     * 
     * @return
     */
    public ResultOrgDto clone() {
        ResultOrgDto resultOrgDto = null;
        try {
            resultOrgDto = (ResultOrgDto) super.clone();
        } catch (Exception e) {
            resultOrgDto = new ResultOrgDto();
            BeanUtils.copyProperties(this, resultOrgDto);
        }
        return resultOrgDto;
    }

    public String getGmtCreated(){
        if(this.gmtCreated == null)
            return null;
        return DateTimeUtils.convertDate2String(gmtCreated, DateTimeUtils.ZH_CN_DATETIME_PATTERN);
    }

}
