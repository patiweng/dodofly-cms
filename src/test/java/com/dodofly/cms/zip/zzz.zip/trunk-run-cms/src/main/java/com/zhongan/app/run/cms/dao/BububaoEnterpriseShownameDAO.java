package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoEmployeeTmpDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoEnterpriseShownameDO;

@Component
public interface BububaoEnterpriseShownameDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoEnterpriseShownameDO> selectDataByCdt(BububaoEnterpriseShownameDO bububaoEnterpriseShownameDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoEnterpriseShownameDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoEnterpriseShownameDO
	    */
	   void insert(BububaoEnterpriseShownameDO bububaoEnterpriseShownameDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoEnterpriseShownameDO
	    */
	   void update(BububaoEnterpriseShownameDO bububaoEnterpriseShownameDO);
}
