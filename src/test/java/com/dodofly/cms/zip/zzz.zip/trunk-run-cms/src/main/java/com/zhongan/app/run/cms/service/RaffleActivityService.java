package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.bo.RaffleActivityBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ActivityListPageDTO;
import com.zhongan.app.run.cms.bean.web.RaffleActivityDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface RaffleActivityService {

    public ResultBase<List<RaffleActivityDTO>> selectActivityData(RaffleActivityBO raffleActivityBO);
    
    public ActivityListPageDTO selectActivityListPage(Page<RaffleActivityDTO> raffleActivityListPage);

    public ResultBase<String> insertActivityData(RaffleActivityBO raffleActivityBO);
    
    public RaffleActivityDTO selectDataByid(String id);

    public ResultBase<String> deleteActivity(String id);
    
    public ResultBase<String> updateActivityData(RaffleActivityBO raffleActivityBO);

}
