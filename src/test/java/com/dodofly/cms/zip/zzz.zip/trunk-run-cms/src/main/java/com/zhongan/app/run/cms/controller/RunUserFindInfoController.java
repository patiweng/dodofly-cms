package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserFindInfoDTO;
import com.zhongan.app.run.cms.service.RunUserFindInfoService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/user")
@Slf4j
public class RunUserFindInfoController {

    @Resource
    private RunUserFindInfoService runUserFindInfoServiceImpl;

    /**
     * cms初始化页面
     * 
     * @return
     */

    @RequestMapping(value = "/find/info", method = RequestMethod.POST)
    public ResultBase<List<RunUserFindInfoDTO>> sysInit(RunUserFindInfoDTO runUserFindInfoDTO) {
        log.info("{}-/find/info,param={" + runUserFindInfoDTO.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunUserFindInfoDTO>> result = new ResultBase<List<RunUserFindInfoDTO>>();
        result = runUserFindInfoServiceImpl.findInfoSource(runUserFindInfoDTO);
        log.info("{}-/find/info  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据id查询用户source信息
     * 
     * @param runUserFindInfoDTO
     * @return
     */
    @RequestMapping(value = "/find/sourceInfoByCdt", method = RequestMethod.POST)
    public ResultBase<List<RunUserFindInfoDTO>> findSourceInfoByCdt(@RequestBody RunUserFindInfoDTO runUserFindInfoDTO) {
        log.info("{}-/find/info,param={" + runUserFindInfoDTO.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunUserFindInfoDTO>> result = new ResultBase<List<RunUserFindInfoDTO>>();
        result = runUserFindInfoServiceImpl.findSourceInfoByCdt(runUserFindInfoDTO);
        log.info("{}-/find/info  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }
}
