package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserActivityInfoDTO;
import com.zhongan.app.run.cms.service.UserActivityInfoService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 瓜分奖励
 * 
 * @author yangzhen001
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class UserActivityInfoController {

    @Resource
    private UserActivityInfoService userActivityInfoServiceImpl;

    /**
     * /查询用户是否有正在开赛的比赛
     * 
     * @param userActParam
     * @return
     */
    @RequestMapping(value = "/selectUserActivityIsOpen", method = RequestMethod.POST)
    public ResultBase<UserActivityInfoDTO> selectUserActivityIsOpen(@RequestBody UserActivityInfoDTO userActParam) {
        log.info("{}-into /selectUserActivityIsOpen, param={}", JSONObject.toJSONString(userActParam));
        ResultBase<UserActivityInfoDTO> resultBase = userActivityInfoServiceImpl.selectUserActivityIsOpen(userActParam);
        log.info("{}-/selectUserActivityIsOpen return, data={}");
        return resultBase;
    }

    /**
     * /根据条件查询用户参赛信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserActivityInfoByCdt", method = RequestMethod.POST)
    public ResultBase<List<UserActivityInfoDTO>> selectUserActivityInfoByCdt(@RequestBody UserActivityInfoDTO info) {
        log.info("{}-into /queryActivityInfoByCdt, param={UserActivityDTO= " + JSONObject.toJSONString(info) + " }",
                ThreadLocalUtil.getRequestNo());
        ResultBase<List<UserActivityInfoDTO>> resultBase = userActivityInfoServiceImpl
                .selectUserActivityInfoByCdt(info);
        log.info("{}-/queryActivityInfoByCdt return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }



    /**
     * /根据条件查询用户第一场参赛信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserFirstActivityInfoByCdt", method = RequestMethod.POST)
    public ResultBase<List<UserActivityInfoDTO>> selectUserFirstActivityInfoByCdt(@RequestBody UserActivityInfoDTO info) {
        log.info(
                "{}-into /selectUserFirstActivityInfoByCdt, param={UserActivityInfoDTO= "
                        + JSONObject.toJSONString(info) + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<List<UserActivityInfoDTO>> resultBase = userActivityInfoServiceImpl
                .selectUserFirstActivityInfoByCdt(info);
        log.info("{}-/selectUserFirstActivityInfoByCdt return, data={" + resultBase + "}",
                ThreadLocalUtil.getRequestNo());
        return resultBase;
    }
    /**
     * /更新或插入用户参赛信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/inOrUpUserActivityInfor", method = RequestMethod.POST)
    public ResultBase<String> inOrUpUserActivityInfor(@RequestBody UserActivityInfoDTO info) {
        log.info("{}-into /inOrUpUserActivityInfor, param={UserActivityInfoDTO= " + JSONObject.toJSONString(info)
                + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = userActivityInfoServiceImpl.inOrUpUserActivityInfor(info);
        log.info("{}-/inOrUpUserActivityInfor return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * /根据条件获取用户参赛数量
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserActivityCountByCdt", method = RequestMethod.POST)
    public ResultBase<Integer> selectUserActivityCountByCdt(@RequestBody UserActivityInfoDTO info) {
        log.info("{}-into /selectUserActivityCountByCdt, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<Integer> resultBase = userActivityInfoServiceImpl.selectUserActivityCountByCdt(info);
        log.info("{}-/selectUserActivityCountByCdt return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * /分页获得用户获取的积分总数
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserGainPointTotal", method = RequestMethod.POST)
    public ResultBase<String> selectUserGainPointTotal(@RequestBody UserActivityInfoDTO info) {
        log.info("{}-into /selectUserGainPointTotal, param={UserActivityInfoDTO= " + JSONObject.toJSONString(info)
                + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = userActivityInfoServiceImpl.selectUserGainPointTotal(info);
        log.info("{}-/selectUserGainPointTotal return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 获取参加活动用户总数
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserActivityCountByCdtDistinct", method = RequestMethod.POST)
    public ResultBase<Integer> selectUserActivityCountByCdtDistinct(@RequestBody UserActivityInfoDTO info) {
        log.info("{}-into /selectUserActivityCountByCdtDistinct, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<Integer> resultBase = userActivityInfoServiceImpl.selectUserActivityCountByCdtDistinct(info);
        log.info("{}-/selectUserActivityCountByCdtDistinct return, data={" + resultBase + "}",
                ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 获取参加活动用户分页
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUnionidByCdtDistinctPage", method = RequestMethod.POST)
    public ResultBase<List<String>> selectUnionidByCdtDistinctPage(@RequestBody UserActivityInfoDTO info) {
        log.info("{}-into /selectUnionidByCdtDistinctPage, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<List<String>> resultBase = userActivityInfoServiceImpl.selectUnionidByCdtDistinctPage(info);
        log.info("{}-/selectUnionidByCdtDistinctPage return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }
}
