package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.BeansException;
import org.springframework.stereotype.Service;

import com.alibaba.common.lang.StringUtil;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.SpecialAwardRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.SpecialAwardDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.RafflePresentRepository;
import com.zhongan.app.run.cms.repository.SpecialAwardRepository;
import com.zhongan.app.run.cms.service.SpecialAwardService;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Service("specialAwardServiceImpl")
public class SpecialAwardServiceImpl implements SpecialAwardService {

    @Resource
    private SpecialAwardRepository  specialAwardRepository;
    @Resource
    private RafflePresentRepository rafflePresentRepository;
    @Resource
    private RedisUtil               redisUtil;

    @Override
    public Page<SpecialAwardDTO> selectSpecialAwardListPage(Page<SpecialAwardDTO> page) {
        log.info("{}-SpecialAwardRepository.selectSpecialAwardListPage,param={" + page.toString() + "}");
        try {
            Page<SpecialAwardRepo> pageRepo = new Page<SpecialAwardRepo>();
            BeanUtils.copyProperties(page, pageRepo);
            pageRepo = specialAwardRepository.selectSpecialAwardListPage(pageRepo);
            List<SpecialAwardRepo> resultList = pageRepo.getResultList();
            List<SpecialAwardDTO> SpecialAwardDTOList = Lists.newArrayList();
            if (resultList != null && resultList.size() > 0) {
                SpecialAwardDTO SpecialAwardDTO = new SpecialAwardDTO();
                for (SpecialAwardRepo SpecialAwardRepo : resultList) {
                    SpecialAwardDTO clone = (SpecialAwardDTO) SpecialAwardDTO.clone();
                    BeanUtils.copyProperties(SpecialAwardRepo, clone);
                    SpecialAwardDTOList.add(clone);
                }
            }
            page.setResultList(SpecialAwardDTOList);
            page.setTotalItem(pageRepo.getTotalItem());
            return page;
        } catch (Exception e) {
            log.error("异常SpecialAwardServiceImpl.selectSpecialAwardListPage  fail……" + e);
        }
        return null;
    }

    @Override
    public ResultBase<String> insertSpecialAward(SpecialAwardDTO specialAwardDTO) {
        log.info("{}-SpecialAwardRepository.insertSpecialAward Start……", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            SpecialAwardRepo specialAwardRepo = new SpecialAwardRepo();
            BeanUtils.copyProperties(specialAwardDTO, specialAwardRepo);
            specialAwardRepository.insertSpecialAward(specialAwardRepo);

            /******* 存入redis *******/
            String key = String.format("bububao_special_award:%s", specialAwardRepo.getRequireid());
            redisUtil.put(key, JSONObject.toJSONString(specialAwardRepo));

            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            resultBase.setSuccess(true);
            resultBase.setValue("新增成功");
            return resultBase;
        } catch (BeansException e) {
            log.error("新增异常SpecialAwardServiceImpl.insertSpecialAward  fail……" + e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setSuccess(false);
            resultBase.setValue("新增异常");
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> deleteById(Long id) {
        log.info("{}-SpecialAwardRepository.deleteById start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            if (null != id) {
                SpecialAwardRepo specialAwardRepo = specialAwardRepository.selectSpecialAwardOne(String.valueOf(id));
                specialAwardRepository.deleteById(id);//删除

                /******* 更新redis *******/
                String key = String.format("bububao_special_award:%s", specialAwardRepo.getRequireid());
                String jsonStr = redisUtil.getString(key);
                if (StringUtil.isNotBlank(jsonStr)) {
                    redisUtil.delete(key);
                }

                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
                resultBase.setSuccess(true);
                resultBase.setValue("删除成功");
            } else {
                resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
                resultBase.setSuccess(false);
                resultBase.setValue("id不能为空");
            }
            return resultBase;
        } catch (Exception e) {
            log.error("删除异常SpecialAwardServiceImpl.deleteById  fail……" + e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> updateById(SpecialAwardDTO specialAwardDTO) {
        log.info("{}-SpecialAwardRepository.updateById start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            if (null != specialAwardDTO && null != specialAwardDTO.getId()) {
                SpecialAwardRepo specialAwardRepo = new SpecialAwardRepo();
                BeanUtils.copyProperties(specialAwardDTO, specialAwardRepo);
                specialAwardRepository.updateById(specialAwardRepo);

                /******* 更新redis *******/
                String key = String.format("bububao_special_award:%s", specialAwardRepo.getRequireid());
                redisUtil.put(key, JSONObject.toJSONString(specialAwardRepo));

                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
                resultBase.setSuccess(true);
            } else {
                resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
                resultBase.setSuccess(false);
                resultBase.setValue("id不能为空");
            }
        } catch (Exception e) {
            log.error("更新异常SpecialAwardServiceImpl.updateById  fail……" + e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<SpecialAwardDTO> selectSpecialAwardOne(String id) {
        log.info("{}-SpecialAwardRepository.selectSpecialAwardOne start...", ThreadLocalUtil.getRequestNo());
        ResultBase<SpecialAwardDTO> resultBase = new ResultBase<SpecialAwardDTO>();
        try {
            SpecialAwardRepo SpecialAwardRepo = specialAwardRepository.selectSpecialAwardOne(id);
            if (null != SpecialAwardRepo) {
                SpecialAwardDTO SpecialAwardDTO = new SpecialAwardDTO();
                BeanUtils.copyProperties(SpecialAwardRepo, SpecialAwardDTO);
                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
                resultBase.setSuccess(true);
                resultBase.setValue(SpecialAwardDTO);
                return resultBase;
            }
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
        } catch (Exception e) {
            log.info("异常===SpecialAwardRepository.selectSpecialAwardOne fail", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }
}
