package com.zhongan.app.run.cms.repository;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.icu.text.DecimalFormat;
import com.zhongan.app.run.cms.bean.dataobject.AnalysisBusinessDO;
import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.AnalysisBusinessRepo;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessDTO;
import com.zhongan.app.run.cms.dao.AnalysisBusinessDAO;
import com.zhongan.app.run.cms.dao.TransLogDAO;

@Repository
public class AnalysisBusinessRepository {

    @Resource
    private AnalysisBusinessDAO analysisBusinessDAO;
    @Resource
    private TransLogDAO         transLogDAO;

    public Page<AnalysisBusinessRepo> selectAnalysisBusinessPage(Page<AnalysisBusinessDTO> analysisBusinessDTOPage) {
        Map<String, Object> map = Maps.newHashMap();
        getParamMap(analysisBusinessDTOPage, map);

        List<AnalysisBusinessDO> analysisBusinessDOList = analysisBusinessDAO.selectAnalysisBusinessList(map);
        List<AnalysisBusinessRepo> analysisBusinessRepoList = Lists.newArrayList();
        if (null != analysisBusinessDOList && analysisBusinessDOList.size() > 0) {
            AnalysisBusinessRepo analysisBusinessRepo = new AnalysisBusinessRepo();
            for (AnalysisBusinessDO analysisBusinessDo : analysisBusinessDOList) {
                AnalysisBusinessRepo clone = (AnalysisBusinessRepo) analysisBusinessRepo.clone();
                BeanUtils.copyProperties(analysisBusinessDo, clone);

                clone.setInsureRate(countRate(analysisBusinessDo.getAddInsure(), analysisBusinessDo.getAddGrant()));//某段时间投保转化率
                Integer activeCount = 0;//活动人数
                if (!"1".equals(analysisBusinessDo.getBopsFlag())) {
                    activeCount = getActivePerCount(analysisBusinessDo.getSourceCode(), analysisBusinessDTOPage
                            .getParam().getSdate(), analysisBusinessDTOPage.getParam().getEdate());
                }

                clone.setActiveCount(activeCount.toString());//设置活跃人数

                clone.setActivePercent(countRate(activeCount.longValue(), clone.getInsureAll()));//设置活跃度

                clone.setInsureAllRate(countRate(clone.getInsureAll(), clone.getGrantAll()));//累计投保转化率
                clone.setSourceName((analysisBusinessDo.getSourceName() == null ? "" : analysisBusinessDo
                        .getSourceName()) + analysisBusinessDo.getSourceCode());

                //clone.setInsureRate(analysisBusinessDo.getInsureRate());
                //clone.setInsureAllRate(analysisBusinessDo.getInsureAllRate());
                analysisBusinessRepoList.add(clone);
            }

        }
        Page<AnalysisBusinessRepo> analysisBusinessRepoPage = new Page<AnalysisBusinessRepo>();
        analysisBusinessRepoPage.setResultList(analysisBusinessRepoList);
        Integer counts = analysisBusinessDAO.selectCounts(map);
        analysisBusinessRepoPage.setTotalItem(counts);
        return analysisBusinessRepoPage;
    }

    private Integer getActivePerCount(String sourceCode, String sdate, String edate) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sourceCode", sourceCode);
        sdate = sdate + " 00:00:00";
        edate = edate + " 23:59:59";
        map.put("sdate", sdate);
        map.put("edate", edate);
        List<TransLogDO> list = transLogDAO.selectTransLogByDate(map);

        if (null != list && list.size() > 0) {
            return list.size();
        } else {
            return 0;
        }
    }

    private void getParamMap(Page<AnalysisBusinessDTO> analysisBusinessDTOPage, Map<String, Object> map) {
        AnalysisBusinessDTO analysisMonitorDTO = analysisBusinessDTOPage.getParam();
        String bopsFlag = analysisMonitorDTO.getBopsFlag();
        map.put("startRow", analysisBusinessDTOPage.getStartRow());
        map.put("pageSize", analysisBusinessDTOPage.getPageSize());
        //从左侧菜单点过来的,列表不显示数据
        if ("1".equals(bopsFlag)) {
            map.put("sdate", "null");
            map.put("edate", "null");
        } else {
            map.put("sdate", analysisMonitorDTO.getSdate());
            map.put("edate", analysisMonitorDTO.getEdate());
        }
    }

    public List<AnalysisBusinessDO> queryListForExcel(String sdate, String edate) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sdate", sdate);
        map.put("edate", edate);
        return analysisBusinessDAO.queryListForExcel(map);
    }

    public List<AnalysisBusinessDO> queryAnalisysBusinessAll() {
        return analysisBusinessDAO.queryAnalisysBusinessAll();
    }

    /**
     * 字符串转百分比
     * 
     * @param rate
     * @return
     */
    private String formatPercentum(String rate) {
        NumberFormat nf = NumberFormat.getPercentInstance();
        String format = nf.format(Double.valueOf(rate));
        return format;
    }

    private String countRate(Long index, Long count) {
        if (index == 0 || count == 0) {
            return "0%";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return formatPercentum(s);
    }

}
