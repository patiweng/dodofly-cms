package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.HealthProductChannelRelationDO;

@Component
public interface HealthProductChannelRelationDAO {

    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<HealthProductChannelRelationDO> selectDataByCdt(HealthProductChannelRelationDO healthProductChannelRelationDO);

    /**
     * 根据id查询数据
     * 
     * @param id
     * @return
     */
    HealthProductChannelRelationDO selectOneDataById(String id);

    /**
     * 插入数据
     * 
     * @param HealthProductChannelRelationDO
     */
    void insert(HealthProductChannelRelationDO healthProductChannelRelationDO);

    /**
     * 更新数据
     * 
     * @param HealthProductChannelRelationDO
     */
    void update(HealthProductChannelRelationDO healthProductChannelRelationDO);

    /**
     * 分页查询HealthCampaign信息
     * 
     * @param map
     * @return
     */
    List<HealthProductChannelRelationDO> selectHealthCampaign(Map map);

    /**
     * 查询BububaoCampaignList条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 删除BububaoCampaignList
     * 
     * @param id
     * @return
     */
    void deleteCampaignListById(String id);

}
