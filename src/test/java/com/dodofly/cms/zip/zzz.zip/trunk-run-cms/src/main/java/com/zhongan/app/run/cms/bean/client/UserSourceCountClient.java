package com.zhongan.app.run.cms.bean.client;

import lombok.Data;

@Data
public class UserSourceCountClient {
    private String source;
    private String sourceCount;
}
