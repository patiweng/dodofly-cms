package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailResDTO;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类ICashierHelpPayDetailService.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年9月13日 上午10:24:33
 */
public interface ICashierHelpPayDetailService {
    public PageDTO<CashierHelpPayDetailResDTO> queryCashierHelpPayDetatilList(CashierHelpPayDetailQueryDTO queryDTO)
            throws Exception;

    public Long saveOrUpdateCashierHelpPayDetail(CashierHelpPayDetailDTO dto) throws Exception;

    public List<CashierHelpPayDetailDTO> queryByCondition(CashierHelpPayDetailDTO dto);

    public Integer deleteById(long id);
}
