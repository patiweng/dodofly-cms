package com.zhongan.app.run.cms.dao.bean;

import java.math.BigDecimal;
import java.util.Date;

public class HistoryBusinessDO {
    /**
     * This field corresponds to the column bububao_history_business.id
     *
     * @mbggenerated
     */
    private Long       id;

    /**
     * 统计时间 This field corresponds to the column
     * bububao_history_business.biz_time
     *
     * @mbggenerated
     */
    private Date       bizTime;

    /**
     * 渠道码 This field corresponds to the column
     * bububao_history_business.source_code
     *
     * @mbggenerated
     */
    private String     sourceCode;

    /**
     * 渠道名 This field corresponds to the column
     * bububao_history_business.source_name
     *
     * @mbggenerated
     */
    private String     sourceName;

    /**
     * 累计授权用户数 This field corresponds to the column
     * bububao_history_business.acc_num
     *
     * @mbggenerated
     */
    private BigDecimal accNum;

    /**
     * 累计投保用户数 This field corresponds to the column
     * bububao_history_business.ins_num
     *
     * @mbggenerated
     */
    private BigDecimal insNum;

    /**
     * 累计续保用户数 This field corresponds to the column
     * bububao_history_business.ren_num
     *
     * @mbggenerated
     */
    private BigDecimal renNum;

    /**
     * 累计付费续保用户数 This field corresponds to the column
     * bububao_history_business.ren_pay_num
     *
     * @mbggenerated
     */
    private BigDecimal renPayNum;

    /**
     * 累计保费收入 This field corresponds to the column
     * bububao_history_business.ren_pay_fee
     *
     * @mbggenerated
     */
    private BigDecimal renPayFee;

    /**
     * 扩展信息,json格式 This field corresponds to the column
     * bububao_history_business.extra_info
     *
     * @mbggenerated
     */
    private String     extraInfo;

    /**
     * 创建人 This field corresponds to the column bububao_history_business.creator
     *
     * @mbggenerated
     */
    private String     creator;

    /**
     * 创建时间 This field corresponds to the column
     * bububao_history_business.gmt_created
     *
     * @mbggenerated
     */
    private Date       gmtCreated;

    /**
     * 修改人 This field corresponds to the column
     * bububao_history_business.modifier
     *
     * @mbggenerated
     */
    private String     modifier;

    /**
     * 修改时间 This field corresponds to the column
     * bububao_history_business.gmt_modified
     *
     * @mbggenerated
     */
    private Date       gmtModified;

    /**
     * This field corresponds to the column bububao_history_business.is_deleted
     *
     * @mbggenerated
     */
    private String     isDeleted;

    /** @mbggenerated
     */
    public HistoryBusinessDO(Long id, Date bizTime, String sourceCode, String sourceName, BigDecimal accNum,
                             BigDecimal insNum, BigDecimal renNum, BigDecimal renPayNum, BigDecimal renPayFee,
                             String extraInfo, String creator, Date gmtCreated, String modifier, Date gmtModified,
                             String isDeleted) {
        this.id = id;
        this.bizTime = bizTime;
        this.sourceCode = sourceCode;
        this.sourceName = sourceName;
        this.accNum = accNum;
        this.insNum = insNum;
        this.renNum = renNum;
        this.renPayNum = renPayNum;
        this.renPayFee = renPayFee;
        this.extraInfo = extraInfo;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /** @mbggenerated
     */
    public HistoryBusinessDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.id
     *
     * @return the value of bububao_history_business.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_history_business.id
     *
     * @param id the value for bububao_history_business.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.biz_time
     *
     * @return the value of bububao_history_business.biz_time
     * @mbggenerated
     */
    public Date getBizTime() {
        return bizTime;
    }

    /**
     * Sets the value of the database column bububao_history_business.biz_time
     *
     * @param bizTime the value for bububao_history_business.biz_time
     * @mbggenerated
     */
    public void setBizTime(Date bizTime) {
        this.bizTime = bizTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.source_code
     *
     * @return the value of bububao_history_business.source_code
     * @mbggenerated
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Sets the value of the database column
     * bububao_history_business.source_code
     *
     * @param sourceCode the value for bububao_history_business.source_code
     * @mbggenerated
     */
    public void setSourceCode(String sourceCode) {
        this.sourceCode = sourceCode;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.source_name
     *
     * @return the value of bububao_history_business.source_name
     * @mbggenerated
     */
    public String getSourceName() {
        return sourceName;
    }

    /**
     * Sets the value of the database column
     * bububao_history_business.source_name
     *
     * @param sourceName the value for bububao_history_business.source_name
     * @mbggenerated
     */
    public void setSourceName(String sourceName) {
        this.sourceName = sourceName;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.acc_num
     *
     * @return the value of bububao_history_business.acc_num
     * @mbggenerated
     */
    public BigDecimal getAccNum() {
        return accNum;
    }

    /**
     * Sets the value of the database column bububao_history_business.acc_num
     *
     * @param accNum the value for bububao_history_business.acc_num
     * @mbggenerated
     */
    public void setAccNum(BigDecimal accNum) {
        this.accNum = accNum;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.ins_num
     *
     * @return the value of bububao_history_business.ins_num
     * @mbggenerated
     */
    public BigDecimal getInsNum() {
        return insNum;
    }

    /**
     * Sets the value of the database column bububao_history_business.ins_num
     *
     * @param insNum the value for bububao_history_business.ins_num
     * @mbggenerated
     */
    public void setInsNum(BigDecimal insNum) {
        this.insNum = insNum;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.ren_num
     *
     * @return the value of bububao_history_business.ren_num
     * @mbggenerated
     */
    public BigDecimal getRenNum() {
        return renNum;
    }

    /**
     * Sets the value of the database column bububao_history_business.ren_num
     *
     * @param renNum the value for bububao_history_business.ren_num
     * @mbggenerated
     */
    public void setRenNum(BigDecimal renNum) {
        this.renNum = renNum;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.ren_pay_num
     *
     * @return the value of bububao_history_business.ren_pay_num
     * @mbggenerated
     */
    public BigDecimal getRenPayNum() {
        return renPayNum;
    }

    /**
     * Sets the value of the database column
     * bububao_history_business.ren_pay_num
     *
     * @param renPayNum the value for bububao_history_business.ren_pay_num
     * @mbggenerated
     */
    public void setRenPayNum(BigDecimal renPayNum) {
        this.renPayNum = renPayNum;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.ren_pay_fee
     *
     * @return the value of bububao_history_business.ren_pay_fee
     * @mbggenerated
     */
    public BigDecimal getRenPayFee() {
        return renPayFee;
    }

    /**
     * Sets the value of the database column
     * bububao_history_business.ren_pay_fee
     *
     * @param renPayFee the value for bububao_history_business.ren_pay_fee
     * @mbggenerated
     */
    public void setRenPayFee(BigDecimal renPayFee) {
        this.renPayFee = renPayFee;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.extra_info
     *
     * @return the value of bububao_history_business.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column bububao_history_business.extra_info
     *
     * @param extraInfo the value for bububao_history_business.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.creator
     *
     * @return the value of bububao_history_business.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column bububao_history_business.creator
     *
     * @param creator the value for bububao_history_business.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.gmt_created
     *
     * @return the value of bububao_history_business.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column
     * bububao_history_business.gmt_created
     *
     * @param gmtCreated the value for bububao_history_business.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.modifier
     *
     * @return the value of bububao_history_business.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column bububao_history_business.modifier
     *
     * @param modifier the value for bububao_history_business.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.gmt_modified
     *
     * @return the value of bububao_history_business.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column
     * bububao_history_business.gmt_modified
     *
     * @param gmtModified the value for bububao_history_business.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_history_business.is_deleted
     *
     * @return the value of bububao_history_business.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column bububao_history_business.is_deleted
     *
     * @param isDeleted the value for bububao_history_business.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
