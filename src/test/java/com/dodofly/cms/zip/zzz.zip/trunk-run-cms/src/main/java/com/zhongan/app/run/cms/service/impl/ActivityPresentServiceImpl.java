package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.bo.ActivityPresentBO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityPresentDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.ActivityPresentRepo;
import com.zhongan.app.run.cms.bean.repo.RafflePresentRepo;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.ActivityPresentListPageDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.dao.BububaoActivityPresentDAO;
import com.zhongan.app.run.cms.repository.ActivityPresentRepository;
import com.zhongan.app.run.cms.repository.RafflePresentRepository;
import com.zhongan.app.run.cms.service.ActivityPresentService;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class ActivityPresentServiceImpl implements ActivityPresentService {

    @Resource
    private ActivityPresentRepository activityPresentRepository;
    @Resource
    private RafflePresentRepository   rafflePresentRepository;

    @Resource
    private BububaoActivityPresentDAO activityPresentDAO;

    @Resource
    private RedisUtil                 redisUtil;

    @Override
    public ResultBase<List<ActivityPresentDTO>> selectActivityPresentData(ActivityPresentBO activityPresentBO) {
        ResultBase<List<ActivityPresentDTO>> result = new ResultBase<List<ActivityPresentDTO>>();
        log.info("{}-ActivityPresent select begin...");
        try {
            ActivityPresentRepo activityPresentRepo = new ActivityPresentRepo();
            BeanUtils.copyProperties(activityPresentBO, activityPresentRepo);
            result = activityPresentRepository.selectActivityPresentList(activityPresentRepo);
            if (result.getValue().size() > 0) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-ActivityPresent select fail,please find error to..."
                    + "error location polynomial : ActivityPresentServiceImpl--selectActivityPresentData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...");
        }
        return result;
    }

    @Override
    public ResultBase<String> insertActivityPresentData(ActivityPresentBO activityPresentBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            ActivityPresentRepo activityPresentRepo = new ActivityPresentRepo();
            BeanUtils.copyProperties(activityPresentBO, activityPresentRepo);
            result = activityPresentRepository.saveActivityPresent(activityPresentRepo);

            if (result.isSuccess()) {
                //缓存对象key：ActivityId   value：List
                BububaoActivityPresentDO bububaoActivityPresentDOTwo = new BububaoActivityPresentDO();
                bububaoActivityPresentDOTwo.setActivityId(activityPresentBO.getActivityId());
                List<BububaoActivityPresentDO> list = activityPresentDAO.selectDataByCdt(bububaoActivityPresentDOTwo);
                redisUtil.put("bububao_activity_present:" + activityPresentBO.getActivityId(),
                        JSONObject.toJSONString(list));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save-- ActivityPresent...."
                    + "error location polynomial : ActivityPresentServiceImpl--insertActivityPresentData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> updateActivityPresentData(ActivityPresentBO activityPresentBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            ActivityPresentRepo activityPresentRepo = new ActivityPresentRepo();
            BeanUtils.copyProperties(activityPresentBO, activityPresentRepo);
            result = activityPresentRepository.updateActivityPresentList(activityPresentRepo);
            if (result.isSuccess()) {
                //缓存对象key：ActivityId   value：List
                BububaoActivityPresentDO bububaoActivityPresentDOTwo = new BububaoActivityPresentDO();
                bububaoActivityPresentDOTwo.setActivityId(activityPresentBO.getActivityId());
                List<BububaoActivityPresentDO> list = activityPresentDAO.selectDataByCdt(bububaoActivityPresentDOTwo);
                redisUtil.put("bububao_activity_present:" + activityPresentBO.getActivityId(),
                        JSONObject.toJSONString(list));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--ActivityPresent...."
                    + "error location polynomial : ActivityPresentServiceImpl--updateActivityPresentData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    //分页信息查询 
    @Override
    public ActivityPresentListPageDTO selectActivityPresentPage(Page<ActivityPresentDTO> activityPresentListPage) {
        ActivityPresentListPageDTO activityPresentListPageDTO = new ActivityPresentListPageDTO();
        Page<ActivityPresentRepo> activityPresentRepoPage = new Page<ActivityPresentRepo>();
        BeanUtils.copyProperties(activityPresentListPage, activityPresentRepoPage);
        activityPresentRepoPage = activityPresentRepository.selectActivityPresentDataPage(activityPresentRepoPage);
        List<ActivityPresentRepo> activityPresentRepolist = activityPresentRepoPage.getResultList();
        List<ActivityPresentDTO> activityPresentDTOList = Lists.newArrayList();
        if (activityPresentRepolist != null && activityPresentRepolist.size() > 0) {
            ActivityPresentDTO activityPresentDTO = null;
            for (ActivityPresentRepo activityPresentRepos : activityPresentRepolist) {
                activityPresentDTO = new ActivityPresentDTO();
                BeanUtils.copyProperties(activityPresentRepos, activityPresentDTO);
                RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(activityPresentDTO
                        .getPresentId());
                activityPresentDTO.setPresentName(rafflePresentDTO.getName());
                activityPresentDTOList.add(activityPresentDTO);
            }
        }
        activityPresentListPage.setResultList(activityPresentDTOList);
        activityPresentListPage.setTotalItem(activityPresentRepoPage.getTotalItem());
        activityPresentListPageDTO.setActivityPresentDTOPage(activityPresentListPage);
        return activityPresentListPageDTO;
    }

    @Override
    public ResultBase<String> deleteActivityPresent(String id) {
        //删除
        log.info("{}-delete activitypresent info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            BububaoActivityPresentDO bububaoActivityPresentDO = activityPresentDAO.selectOneDataById(id);
            String activityid = bububaoActivityPresentDO.getActivityId();
            result = activityPresentRepository.deleteByid(id);
            if (result.isSuccess()) {
                BububaoActivityPresentDO bububaoActivityPresentDOTwo = new BububaoActivityPresentDO();
                bububaoActivityPresentDOTwo.setActivityId(activityid);
                List<BububaoActivityPresentDO> list = activityPresentDAO.selectDataByCdt(bububaoActivityPresentDOTwo);
                List<BububaoActivityPresentDO> listss = Lists.newArrayList();
                if (list.size() > 0) {
                    for (BububaoActivityPresentDO bububaoActivityPresentDOs : list) {
                        if (bububaoActivityPresentDOs.getIsDeleted().equals("0")) {
                            listss.add(bububaoActivityPresentDOs);
                        }
                    }
                    redisUtil.put("bububao_activity_present:" + activityid, JSONObject.toJSONString(listss));
                } else {
                    redisUtil.delete("bububao_activity_present:" + activityid);
                }
            }
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-ChannelList delete fail,please find error to...。"
                    + "error location polynomial:ActivityPresentServiceImpl--deleteActivityPresent()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    //活动id
    @Override
    public ResultBase<String> updateActivityPresentLists(String id) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            BububaoActivityPresentDO bububaoActivityPresentDOTwo = new BububaoActivityPresentDO();
            bububaoActivityPresentDOTwo.setActivityId(id);
            List<BububaoActivityPresentDO> list = activityPresentDAO.selectDataByCdtNew(bububaoActivityPresentDOTwo);
            List<BububaoActivityPresentDO> listss = Lists.newArrayList();
            if (list.size() > 0) {
                for (BububaoActivityPresentDO bububaoActivityPresentDOs : list) {
                    if (bububaoActivityPresentDOs.getIsDeleted().equals("0")) {
                        listss.add(bububaoActivityPresentDOs);
                    }
                }
                redisUtil.put("bububao_activity_present:" + id, JSONObject.toJSONString(listss));
            } else {
                redisUtil.delete("bububao_activity_present:" + id);
            }
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-ChannelList delete fail,please find error to...。"
                    + "error location polynomial:ActivityPresentServiceImpl--updateActivityPresentLists()"
                    + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    //根据主键查询单条记录 后台
    @Override
    public ActivityPresentDTO selectDataByid(String id) {
        log.info("{}-ActivityPresentDTO selectone begin...");
        ActivityPresentDTO activityPresentDTO = activityPresentRepository.selectActivityPresentByid(id);
        if (activityPresentDTO != null) {
            RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(activityPresentDTO
                    .getPresentId());
            RafflePresentRepo rafflePresentRepo = new RafflePresentRepo();
            rafflePresentRepo.setType(rafflePresentDTO.getType());
            ResultBase<List<RafflePresentDTO>> resultend = rafflePresentRepository.selectPresentList(rafflePresentRepo);
            if (resultend.getValue().size() > 0) {
                activityPresentDTO.setRafflePresentDTOList(resultend.getValue());
            }
            activityPresentDTO.setPresentType(rafflePresentDTO.getType());
            activityPresentDTO.setPresentName(rafflePresentDTO.getName());
        }
        return activityPresentDTO;
    }

}
