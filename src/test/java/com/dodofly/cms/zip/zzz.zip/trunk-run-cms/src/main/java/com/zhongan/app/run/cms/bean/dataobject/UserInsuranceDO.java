package com.zhongan.app.run.cms.bean.dataobject;

import java.util.Date;

import lombok.Data;

@Data
public class UserInsuranceDO {

    private Long    id;

    private Long    unionid;

    /** 在哪个渠道投的保 */
    private String  channelFrom;

    /** 渠道交易号 */
    private String  insuredId;

    /** 营销活动id */
    private String  campaignDefId;

    /** 产品组合id */
    private String  packageDefId;

    /** 投保人姓名 */
    private String  holderName;

    /** 投保人身份证， 身份证：I；护照号：P */
    private String  holderIdentity;

    /** 投保人手机号 */
    private String  holderPhone;

    /** 证件类型 */
    private String  holderCertiType;

    /** 投保人性别，男：1，女：0，未知：10 */
    private String  holderSex;

    /** 投保人出生日期 */
    private Date    holderBirthday;

    /** 渠道端计算保额 */
    private Integer channelSum;

    /** 渠道端计算保费,支付时选择优惠券可能会减少 */
    private Integer channelPremium;

    /** 实际保额 */
    private Integer originSum;

    /** 实际保费 */
    private Integer originPremium;

    /** 保单开始时间 */
    private Date    policyStartTime;

    /** 保单结束时间 */
    private Date    policyEndTime;

    /** 保单号 */
    private String  policyNo;

    /** 保单Id */
    private String  policyId;

    /** 是否免费保单，0：否，1：是 */
    private String  isFree;

    /** 免费的天数 */
    private Integer freeDays;

    /** 使用优惠券的id */
    private Long    couponId;

    /** 优惠券 */
    private String  coupon;

    /** 是否已支付 */
    private String  paid;

    /** 支付时间 */
    private String  paidTime;

    /** 最后投保缴费截止时间 */
    private String  duePayTime;

    /** 创建时间 */
    private String  createtime;

    /** 修改时间 */
    private String  modifytime;

    /** 状态， 0，成功 1，失败 */
    private String  status;

    /** 查询时间 */
    private Date    date;

}
