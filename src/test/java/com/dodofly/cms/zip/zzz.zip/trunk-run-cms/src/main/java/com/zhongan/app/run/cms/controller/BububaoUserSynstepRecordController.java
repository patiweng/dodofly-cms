package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.BububaoUserSynstepRecordDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserCarveUpLoginRecordDTO;
import com.zhongan.app.run.cms.bean.web.UserCarveUpLoginRecordParamDTO;
import com.zhongan.app.run.cms.service.UserSynstepRecordService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 记录用户登陆步数情况
 * 
 * @author yangzhen001
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/userSynstepRecord")
public class BububaoUserSynstepRecordController {

    @Resource
    private UserSynstepRecordService userSynstepRecordServiceImpl;

    /**
     * 插入用户登陆记录
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/insertUserSynstepRecord", method = RequestMethod.POST)
    public ResultBase<Integer> insertUserSynstepRecord(@RequestBody BububaoUserSynstepRecordDTO info) {
        log.info("{}-into /insertUserSynstepRecord, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<Integer> resultBase = userSynstepRecordServiceImpl.insertUserSynstepRecord(info);
        log.info("{}-/insertUserSynstepRecord return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 根据条件查询用户同步步数情况
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserSynstepRecord", method = RequestMethod.POST)
    public ResultBase<List<BububaoUserSynstepRecordDTO>> selectUserSynstepRecord(@RequestBody BububaoUserSynstepRecordDTO info) {
        log.info("{}-into /selectUserSynstepRecord, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<List<BububaoUserSynstepRecordDTO>> resultBase = userSynstepRecordServiceImpl
                .selectUserSynstepRecord(info);
        log.info("{}-/selectUserSynstepRecord return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * cms用户参加瓜分活动用户参赛数据信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectUserCarveUpRewardDetilInfoPage")
    public ModelAndView selectUserCarveUpRewardDetilInfoPage(UserCarveUpLoginRecordParamDTO param) {
        log.info("{}-into /selectUserCarveUpRewardDetilInfoPage, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(param));
        PageDTO<UserCarveUpLoginRecordDTO> page = userSynstepRecordServiceImpl.selectUserCarveUpRewardDetilInfo(param);
        ModelAndView modelAndView = new ModelAndView("cms/carveUpRewardUserSynstepRecord");
        modelAndView.addObject("userCarveUpRewardDetilInfoList", page.getResultList());
        modelAndView.addObject("userCarveUpRewardDetilInfoParam", param);
        modelAndView.addObject("page", page);
        modelAndView.addObject("totalPage", page.getTotalPage());
        log.info("{}-/selectUserCarveUpRewardDetilInfoPage return, data={" + page + "}", ThreadLocalUtil.getRequestNo());
        return modelAndView;
    }

    /**
     * 删除用户dateList之间的日期/当天时间推后days后的days内的数据
     * 
     * @param dateList
     * @param days
     * @return
     */
    @RequestMapping(value = "/deleteSynStepRecordByDays")
    public ResultBase<String> deleteSynStepRecordByDays(@RequestParam(value = "dateList", required = false) List<String> dateList,
                                                        @RequestParam("days") int days) {
        log.info("{}-into /deleteSynStepRecordByDays,days:{}", ThreadLocalUtil.getRequestNo(), days);
        ResultBase<String> result = userSynstepRecordServiceImpl.deleteSynStepRecordByDays(dateList, days);
        log.info("{}-/deleteSynStepRecordInfoOverDayInThread return:{}", ThreadLocalUtil.getRequestNo(),
                JSON.toJSONString(result));
        return result;

    }
}
