package com.zhongan.app.run.cms.bean.bo;

import java.util.Date;
import java.util.List;

import lombok.Data;

@Data
public class AwardRuleCdtBO {

    private List<Long> activityPresentIds;

    private Date       registerTime;

    private Integer    renewalTimes;

    private Double     payMoney;

    private Integer    newAliveDays;

}
