package com.zhongan.app.run.cms.conver;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailResDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDetailDO;
import com.zhongan.health.common.share.enm.YesOrNo;
import com.zhongan.health.common.utils.DateUtils;

public class CashierHelpPayDetailConvert {

    public static List<CashierHelpPayDetailResDTO> convertResDTO(List<CashierHelpPayDetailDO> list,
                                                                 List<RunChannelListDTO> channelListDTOs) {
        Map<String, String> channelMap = Maps.newConcurrentMap();
        for (RunChannelListDTO runChannelListDTO : channelListDTOs) {
            channelMap.put(runChannelListDTO.getNo(), runChannelListDTO.getName());
        }

        List<CashierHelpPayDetailResDTO> CashierHelpPayDetailResDTOs = Lists.newArrayList();
        CashierHelpPayDetailResDTO CashierHelpPayDetailResDTO = null;
        for (CashierHelpPayDetailDO CashierHelpPayDetailDO : list) {
            CashierHelpPayDetailResDTO = new CashierHelpPayDetailResDTO();
            BeanUtils.copyProperties(CashierHelpPayDetailDO, CashierHelpPayDetailResDTO, "bizTime", "bizChannel");
            CashierHelpPayDetailResDTO.setBizTime(DateUtils.formatDateYYYY_MM_DD_HH_MM_SS(CashierHelpPayDetailDO
                    .getBizTime()));
            CashierHelpPayDetailResDTO.setBizChannel(channelMap.get(CashierHelpPayDetailDO.getBizChannel()));
            CashierHelpPayDetailResDTOs.add(CashierHelpPayDetailResDTO);
        }
        return CashierHelpPayDetailResDTOs;
    }

    public static CashierHelpPayDetailDO convertDO(CashierHelpPayDetailDTO CashierHelpPayDetailDTO) {
        CashierHelpPayDetailDO CashierHelpPayDetailDO = new CashierHelpPayDetailDO();
        BeanUtils.copyProperties(CashierHelpPayDetailDTO, CashierHelpPayDetailDO);
        if (null == CashierHelpPayDetailDTO.getId()) {
            CashierHelpPayDetailDO.setCreator("system");
            CashierHelpPayDetailDO.setGmtCreated(new Date());
            CashierHelpPayDetailDO.setModifier("system");
            CashierHelpPayDetailDO.setGmtModified(new Date());
            CashierHelpPayDetailDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            CashierHelpPayDetailDO.setModifier("system");
            CashierHelpPayDetailDO.setGmtModified(new Date());
        }
        return CashierHelpPayDetailDO;
    }

    public static List<CashierHelpPayDetailDTO> convertDTO(List<CashierHelpPayDetailDO> list) {
        List<CashierHelpPayDetailDTO> CashierHelpPayDetailResDTOs = Lists.newArrayList();
        CashierHelpPayDetailDTO CashierHelpPayDetailResDTO = null;
        for (CashierHelpPayDetailDO CashierHelpPayDetailDO : list) {
            CashierHelpPayDetailResDTO = new CashierHelpPayDetailDTO();
            BeanUtils.copyProperties(CashierHelpPayDetailDO, CashierHelpPayDetailResDTO);
            CashierHelpPayDetailResDTOs.add(CashierHelpPayDetailResDTO);
        }
        return CashierHelpPayDetailResDTOs;
    }

    public static CashierHelpPayDetailDTO convertDTO(CashierHelpPayDetailQueryDTO queryDTO) {
        CashierHelpPayDetailDTO detailDTO = new CashierHelpPayDetailDTO();
        BeanUtils.copyProperties(queryDTO, detailDTO);
        return detailDTO;
    }
}
