package com.zhongan.app.run.cms.service.qrcode;

import com.zhongan.health.common.share.bean.BaseResult;

import javax.servlet.http.HttpServletRequest;

/**
 * oss操作接口
 * @author lichao002
 * @date 2018-07-02
 */
public interface OssService {

    /**
     * 上传文件到oss
     * @param request
     * @param fileName 文件名称
     * @param fileFormat 文件格式
     * @return
     */
    public BaseResult<String> uploadFile(HttpServletRequest request, String fileName, String fileFormat);
}
