package com.zhongan.app.run.cms.common.csvutil.annotion;

import lombok.Data;

@Data
public abstract class ValueFormat {

    protected String formatParam;

    public abstract Object readFormat(Object value, Class<?> propertyClass, String propertyName);

    public abstract String writeFormat(Object value, Class<?> propertyClass, String propertyName);
}
