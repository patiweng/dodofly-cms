package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoFromScancodeDO {
	
	private String id;
	private String openId;
	private String eventKey;
	private String createTime;
    private String ticket;
    private String modifyTime;
    private String unionId;
    private String groupId;
    private String extId;
    private String citicId;
    private String codeSource;
}
