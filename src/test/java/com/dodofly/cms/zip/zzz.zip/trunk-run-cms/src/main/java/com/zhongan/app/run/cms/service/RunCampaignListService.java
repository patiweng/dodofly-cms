package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.bo.RunCampaignListBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCampaignListDTO;
import com.zhongan.app.run.cms.bean.web.RunCampaignListPageDTO;

public interface RunCampaignListService {
	
	public RunCampaignListPageDTO selectCampaigninfoPage(Page<RunCampaignListDTO> runCampaignListPage);
	
	public ResultBase<List<RunCampaignListDTO>> selectCampaignInfo(RunCampaignListBO runCampaignListBO);
	
	
	public ResultBase<List<RunCampaignListDTO>> selectCampaignData(RunCampaignListBO runCampaignListBO);
	
	public ResultBase<String> insertCampaignList(RunCampaignListDTO runCampaignListDTO);
	 
	public ResultBase<String> updateCampaignList(RunCampaignListDTO runCampaignListDTO);
	
	public ResultBase<String> deleteCampaignList(String id);
	
	public RunCampaignListDTO selectOneCampaignList(String id);
}
