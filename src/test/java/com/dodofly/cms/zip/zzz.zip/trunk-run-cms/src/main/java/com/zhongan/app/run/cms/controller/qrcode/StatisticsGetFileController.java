package com.zhongan.app.run.cms.controller.qrcode;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/qrcode")
@Slf4j
public class StatisticsGetFileController {
    @Resource
    private OssTool ossTool;

    /**
     * 从oss上获取文件
     * 
     * @return
     */

    @RequestMapping(value = "/getFile/{fileName}", method = RequestMethod.GET)
    public void getImg(@PathVariable String fileName, HttpServletResponse response) {
        InputStream ins = null;
        OutputStream outs = null;
        try {
            StringBuffer title = new StringBuffer();
            String nowTime = DateTimeUtils.formatCurrentTime(DateTimeUtils.DATE_FORMAT_YYYYMMDD);
            if(fileName.indexOf("二维码") < 0){
                String firstName = fileName.substring(0, 1);
                if (firstName.equals("I")) {
                    title.append("扫码投保统计");
                } else {
                    title.append("扫码投保明细");
                }
                title.append("-").append(nowTime).append(".csv");
            }else{
                title.append(fileName).append(".zip");
                fileName = title.toString();
            }

            response.setDateHeader("Expires", 0);
            response.addHeader("Cache-Control", "post-check=0, pre-check=0");
            response.setHeader("Pragma", "no-cache");
            response.setHeader("Connection", "close");
            response.setContentType("application/octet-stream");
            response.setCharacterEncoding("UTF-8");
            response.setHeader("Content-disposition", "attachment;filename="
                    + URLEncoder.encode(title.toString(), "UTF-8"));
            ins = ossTool.downloadFile(fileName);
            outs = response.getOutputStream();
            int iread = 0;
            byte[] buf = new byte[1024];
            while ((iread = ins.read(buf, 0, 1024)) != -1) {
                outs.write(buf, 0, iread);
            }
            outs.flush();
        } catch (Exception exp) {
            log.error("{}-", exp.getMessage(), exp, ThreadLocalUtil.getRequestNo());
        } finally {
            if (ins != null) {
                try {
                    ins.close();
                } catch (Exception ex) {
                    log.error("{}-", ex.getMessage(), ex, ThreadLocalUtil.getRequestNo());
                }
            }
            if (outs != null) {
                try {
                    outs.close();
                } catch (Exception ex) {
                    log.error("{}-", ex.getMessage(), ex, ThreadLocalUtil.getRequestNo());
                }
            }
        }
        log.info("{}-/getFile/ return", ThreadLocalUtil.getRequestNo());
    }

}
