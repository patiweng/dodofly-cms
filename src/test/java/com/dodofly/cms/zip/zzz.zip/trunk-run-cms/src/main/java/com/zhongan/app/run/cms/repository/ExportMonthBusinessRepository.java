package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.icu.util.Calendar;
import com.zhongan.app.run.cms.bean.dataobject.MonthBusinessDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.MonthBusinessRepo;
import com.zhongan.app.run.cms.bean.web.MonthBusinessDTO;
import com.zhongan.app.run.cms.dao.ExportMonthBusinessDAO;

@Repository
public class ExportMonthBusinessRepository {
    @Resource
    private ExportMonthBusinessDAO exportMonthBusinessDAO;

    public Page<MonthBusinessRepo> selectMonthBusinessPage(Page<MonthBusinessDTO> monthBusinessPage) {

        Map<String, Object> map = Maps.newHashMap();
        getParamMap(monthBusinessPage, map);
        List<MonthBusinessDO> monthBusinessDOList = exportMonthBusinessDAO.selectMonthBusinessList(map);
        List<MonthBusinessRepo> monthBusinessRepoList = Lists.newArrayList();
        if (null != monthBusinessDOList && monthBusinessDOList.size() > 0) {
            MonthBusinessRepo monthBusinessRepo = new MonthBusinessRepo();
            for (MonthBusinessDO monthBusinessDO : monthBusinessDOList) {
                MonthBusinessRepo clone = (MonthBusinessRepo) monthBusinessRepo.clone();
                BeanUtils.copyProperties(monthBusinessDO, clone);
                monthBusinessRepoList.add(clone);
            }
        }
        Page<MonthBusinessRepo> monthBusinessRepoPage = new Page<MonthBusinessRepo>();
        monthBusinessRepoPage.setResultList(monthBusinessRepoList);
        Integer counts = exportMonthBusinessDAO.selectCounts(map);
        monthBusinessRepoPage.setTotalItem(counts);
        return monthBusinessRepoPage;
    }

    public List<MonthBusinessDO> queryMonthListForExcel(Map<String, String> map) {

        List<MonthBusinessDO> monthList = exportMonthBusinessDAO.queryMonthListForExcel(map);
        return monthList;
    }

    private void getParamMap(Page<MonthBusinessDTO> monthBusinessDTOPage, Map<String, Object> map) {
        MonthBusinessDTO weekMonitorDTO = monthBusinessDTOPage.getParam();
        String bopsFlag = weekMonitorDTO.getBopsFlag();
        map.put("startRow", monthBusinessDTOPage.getStartRow());
        map.put("pageSize", monthBusinessDTOPage.getPageSize());

        Calendar c = Calendar.getInstance();
        int year = c.get(Calendar.YEAR);//当前日期年份
        //int month = c.get(Calendar.MONTH) + 1;//当前月份

        //从左侧菜单点过来的,列表不显示数据
        if ("1".equals(bopsFlag)) {
            map.put("curr_year", "null");
        } else {
            map.put("curr_year", String.valueOf(year));
        }
    }

}
