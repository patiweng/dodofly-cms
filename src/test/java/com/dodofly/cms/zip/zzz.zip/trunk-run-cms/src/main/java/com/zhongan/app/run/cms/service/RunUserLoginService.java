package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCmsUserDTO;

public interface RunUserLoginService {
	
	
	public ResultBase<RunCmsUserDTO> login(String userName,String password);
	public ResultBase<RunCmsUserDTO> checkLogin(String token);
	public ResultBase<String> editPwd(String userName,String oPwd,String nPwd);
}
