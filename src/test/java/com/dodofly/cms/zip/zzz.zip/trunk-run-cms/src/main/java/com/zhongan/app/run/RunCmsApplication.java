package com.zhongan.app.run;

import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.feign.EnableFeignClients;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.zhongan.app.run.cms.common.interceptors.LoginCheckInterceptor;

import io.prometheus.client.hotspot.DefaultExports;
import io.prometheus.client.spring.boot.EnablePrometheusEndpoint;

@SpringBootApplication
@ImportResource("classpath:beanRefContext.xml")
@EnableAutoConfiguration
@Configuration
@EnableFeignClients
@EnableDiscoveryClient
@MapperScan(basePackages = "com.zhongan.app.run.cms.dao")
@EnablePrometheusEndpoint
public class RunCmsApplication extends WebMvcConfigurerAdapter {
    @Resource
    private LoginCheckInterceptor loginCheckInterceptor;

    @PostConstruct
    public void init() {
        DefaultExports.initialize();
    }

    public static void main(String[] args) {
        //        System.setProperty("DEPLOY_ENV", "test");// TODO  上线前请去掉此句，在本机设置好环境变量也可去掉此句
        /* 修改时区为东8区，否则部分日期转换有问题 */
        TimeZone.setDefault(TimeZone.getTimeZone("GMT+8"));
        SpringApplication.run(RunCmsApplication.class, args);
    }

    /**
     * 配置拦截器
     * 
     * @author lance
     * @param registry
     */
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(loginCheckInterceptor).addPathPatterns("/run/**");
    }
}
