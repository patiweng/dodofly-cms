package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

@Data
public class RunMarketingActivitiesRepo {
    private String        id;
    private String        activitiesType;
    private String        activityCode;
    private String        activitiesName;
    private String        activitiesIcon;
    private String        activitiesUrl;
    private String        isselfFlag;
    private String        disOrder;
    private String        startTime;
    private String        endTime;
    private String        minStep;
    private String        maxStep;
    private String        allChannel;
    private String        creator;
    private String        modifier;
    private String        gmtCreated;
    private String        gmtModified;
    private String        isDeleted;
    private String        userStep;
    private String        activityId;
    private String        activityMark;
    private MultipartFile marketingImgFile; //上传到OSS 的图片
}
