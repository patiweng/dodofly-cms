package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.zhongan.app.run.cms.dao.DataUpdatedDAO;

/**
 * 数据订正专用
 * @author songchengsong
 *
 */
@RestController
@RequestMapping("/run/cms/data")
@Slf4j
public class DataUpdateController {
	
	@Resource
	private DataUpdatedDAO dataUpdatedDAO;
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public void update(){
		dataUpdatedDAO.update();
	}
}
