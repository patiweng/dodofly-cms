package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.AwardRecordDO;
import com.zhongan.app.run.cms.bean.web.AwardRecordDTO;

@Component
public interface AwardRecordDAO {

    /**
     * 根据条件查询奖励记录信息
     * 
     * @param record
     * @return
     */
    public List<AwardRecordDO> selectDataByCdt(AwardRecordDO record);

    /**
     * 向用户奖励记录表中插入一条记录
     * 
     * @param awardRecordDO
     */
    public void insertAwardRecord(AwardRecordDO awardRecordDO);

    /**
     * 更新用户奖励记录
     * 
     * @param awardRecordDTO
     * @return
     */
    public void updateAwardRecord(AwardRecordDTO awardRecordDTO);

    /**
     * 分页查询用户奖励记录
     * 
     * @param map
     * @return
     */
    List<AwardRecordDO> selectAwardRecordListPage(Map<String, Object> map);

    /**
     * 分页查询总条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map<String, Object> map);

    /**
     * 根据id查询用户奖励记录表
     * 
     * @param id
     * @return
     */
    AwardRecordDO selectDataById(Long id);

    /**
     * 更新用户奖励记录表
     * 
     * @param record
     * @return
     */
    int update(AwardRecordDO record);

    /**
     * 导出报表
     * 
     * @param awardRecordDTO
     * @return
     */
    List<AwardRecordDO> selectAwardRecordListOfExcel(AwardRecordDO awardRecordDO);
}
