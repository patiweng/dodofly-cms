package com.zhongan.app.run.cms.common.excelutil;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import com.zhongan.app.run.cms.common.excelutil.cellconver.DefaultCellConvert;
import com.zhongan.app.run.cms.common.excelutil.annotion.CellConvert;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

public class ExcelHelper {

    private static final Logger log = LoggerFactory.getLogger(ExcelHelper.class);

    public static final String EXCEL_SUFFIX_XLSX = ".xlsx";
    public static final String EXCEL_SUFFIX_XLS = ".xls";

    private static final CellConvert ANNOTION_CELLCONVERT = new DefaultCellConvert();

    public static <T> List<T> readList(String path, Class<T> clazz) {
        return readList(new File(path), 0, clazz);
    }

    public static <T> List<T> readList(String path, int sheetIndex, Class<T> clazz) {
        return readList(new File(path), sheetIndex, clazz);
    }

    public static <T> List<T> readList(File exceleFile, int sheetIndex, Class<T> clazz) {
        return readList(exceleFile, sheetIndex, ANNOTION_CELLCONVERT, clazz);
    }

    public static <T> void writeList(String path, List<T> dataList, Class<T> clazz) {
        writeList(path, "sheet_" + UUID.randomUUID(), dataList, clazz);
    }

    public static <T> void writeList(String path, String sheetName, List<T> dataList, Class<T> clazz) {
        writeList(new File(path), sheetName, dataList, clazz);
    }

    public static <T> void writeList(File exceleFile, String sheetName, List<T> dataList, Class<T> clazz) {
        writeList(exceleFile, sheetName, ANNOTION_CELLCONVERT, dataList, clazz);
    }

    public static <T> Workbook writeList(File exceleFile, String sheetName, CellConvert convert, List<T> dataList, Class<T> clazz) {
        try{
            FileOutputStream fileOut = new FileOutputStream(exceleFile);
            Workbook w = writeList(null, exceleFile.getName(), sheetName, convert, dataList, clazz);
            w.write(fileOut);
            fileOut.close();
            return w;
        }catch(Exception e){
            log.error("error",e);
            throw new RuntimeException("未知错误" + e.getMessage());
        }
    }
    public static <T> Workbook writeListEndWith(String excelEnd, String sheetName, List<T> dataList, Class<T> clazz){
        return writeList(null, excelEnd, sheetName, ANNOTION_CELLCONVERT, dataList, clazz);
    }
    public static <T> Workbook writeListEndWith(Workbook workbook,String excelEnd, String sheetName, List<T> dataList, Class<T> clazz){
        return writeList(workbook, excelEnd, sheetName, ANNOTION_CELLCONVERT, dataList, clazz);
    }

    public static <T> Workbook writeList(Workbook workbook, String excelName, String sheetName, List<T> dataList, Class<T> clazz){
        return writeList(workbook, excelName, sheetName, ANNOTION_CELLCONVERT, dataList, clazz);
    }

    public static <T> Workbook writeList(Workbook workbook, String excelName, String sheetName, CellConvert convert, List<T> dataList, Class<T> clazz) {

        try {
            if(workbook == null){
                if (excelName.endsWith(EXCEL_SUFFIX_XLSX)) {
                    workbook = new XSSFWorkbook();
                } else if (excelName.endsWith(EXCEL_SUFFIX_XLS)) {
                    workbook = new HSSFWorkbook();
                } else {
                    throw new RuntimeException("不识别的后缀名 , 目前只识别  【.xlsx， .xls】");
                }
            }
            Sheet sheet = workbook.createSheet(sheetName);

            convert.writeConvertHead(clazz, sheet);
            if (dataList != null) {
                convert.writeConvertContent(dataList, clazz, sheet);
            }

            return workbook;
        } catch (Exception e) {
            log.error("error",e);
            throw new RuntimeException("写入excel数据失败", e);
        }
    }

    /**
     * @Description: 获取excel的数据
     * @author lichao002
     * @param exceleFile 必填
     * @param sheetIndex 必填
     * @param convert 必填
     * @param clazz 必填
     * @param <T>
     * @return
     */
    public static <T> List<T> readList(File exceleFile, int sheetIndex, CellConvert convert, Class<T> clazz) {
        InputStream input = null;
        try {
            input = new FileInputStream(exceleFile);
            return readList(input, sheetIndex, convert, clazz);
        } catch (Exception e) {
            log.error("error",e);
        }finally {
            try {
                if(input != null)
                    input.close();
            } catch (IOException e) {
                log.error("error",e);
            }
        }
        return null;
    }

    public static <T> List<T> readList(InputStream input, int sheetIndex, CellConvert convert, Class<T> clazz) {
        List<T> dataList = new ArrayList<T>();

        try {
            Workbook workbook = WorkbookFactory.create(input);

            Sheet sheet = workbook.getSheetAt(sheetIndex);

            int rowCount = sheet.getLastRowNum();

            if (rowCount == 0) {
                return null;
            }

            Row titleRow = sheet.getRow(0);
            int cellCount = titleRow.getLastCellNum();

            String[] titles = new String[cellCount];
            for (int i = 0; i < cellCount; i++) {
                titles[i] = titleRow.getCell(i).toString();
            }

            for (int i = 1; i < (rowCount + 1); i++) {
                Row contentRow = sheet.getRow(i);
                Map<String, Cell> mapCell = new HashMap<String, Cell>();
                for (int j = 0; j < cellCount; j++) {
                    mapCell.put(titles[j], contentRow.getCell(j, Row.RETURN_BLANK_AS_NULL));
                }
                T t = convert.readConvert(mapCell, clazz);
                if (t != null) {
                    dataList.add(t);
                }
            }

        } catch (Exception e) {
            log.error("error",e);
            throw new RuntimeException("获取Excel数据失败", e);
        }

        return dataList;
    }

    /**
     * @Description: 获取excel的数据 titles顺序与文件列明相同
     * @author lichao002
     * @param exceleFile 必填
     * @param sheetIndex 必填
     * @param convert 必填
     * @param titles 必填
     * @param clazz 必填
     * @param <T>
     * @return
     */
    public static <T> List<T> readList(File exceleFile, int sheetIndex, CellConvert convert, List<String> titles, Class<T> clazz) {
        InputStream input = null;
        try {
            input = new FileInputStream(exceleFile);
            return readList(input, sheetIndex, convert, titles, clazz);
        } catch (Exception e) {
            log.error("error",e);
        }finally {
            try {
                if(input != null)
                    input.close();
            } catch (IOException e) {
                log.error("error",e);
            }
        }
        return null;
    }

    public static <T> List<T> readList(InputStream input, int sheetIndex, CellConvert convert, List<String> titles, Class<T> clazz){
        List<T> dataList = new ArrayList<T>();

        try {
            Workbook workbook = WorkbookFactory.create(input);

            Sheet sheet = workbook.getSheetAt(sheetIndex);

            int rowCount = sheet.getLastRowNum();

            if (rowCount == 0 || CollectionUtils.isEmpty(titles)) {
                return null;
            }

            int cellCount = titles.size();

            for (int i = 1; i < (rowCount + 1); i++) {
                Row contentRow = sheet.getRow(i);
                Map<String, Cell> mapCell = new HashMap<String, Cell>();
                for (int j = 0; j < cellCount; j++) {
                    mapCell.put(titles.get(j), contentRow.getCell(j, Row.RETURN_BLANK_AS_NULL));
                }
                T t = convert.readConvert(mapCell, clazz);
                if (t != null) {
                    dataList.add(t);
                }
            }

        } catch (Exception e) {
            log.error("error",e);
            throw new RuntimeException("获取Excel数据失败", e);
        }

        return dataList;
    }
}
