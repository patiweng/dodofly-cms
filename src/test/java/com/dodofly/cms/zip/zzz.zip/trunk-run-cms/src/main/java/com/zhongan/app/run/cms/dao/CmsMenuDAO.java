package com.zhongan.app.run.cms.dao;

import java.util.List;

import com.zhongan.app.run.cms.bean.dataobject.CmsMenuDO;

public interface CmsMenuDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<CmsMenuDO> selectDataByCdt(CmsMenuDO cmsMenuDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   CmsMenuDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param CmsMenuDO
	    */
	   void insert(CmsMenuDO cmsMenuDO);
	   
	   /**
	    * 更新数据
	    * @param CmsMenuDO
	    */
	   void update(CmsMenuDO cmsMenuDO);
}
