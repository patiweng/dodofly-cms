package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.SpecialAwardDTO;
import com.zhongan.app.run.cms.service.SpecialAwardService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 类SpecialAwardController.java的实现描述：特殊奖励配置表controller
 * 
 * @author panchuanhe 2017年3月16日 上午11:38:20
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class SpecialAwardController {

    @Resource
    private SpecialAwardService specialAwardServiceImpl;

    /**
     * 分页查询特殊奖励配置列表
     * 
     * @param SpecialAwardDTO
     * @param request
     * @return
     */
    @RequestMapping(value = "/select/selectspecialawardlistpage")
    public ModelAndView selectSpecialAwardListPage(SpecialAwardDTO specialAwardDTO, HttpServletRequest request) {
        log.info("{}-info/select/selectSpecialAwardlistpage,param={" + specialAwardDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        Page<SpecialAwardDTO> page = new Page<SpecialAwardDTO>(specialAwardDTO.getPageSize(),
                specialAwardDTO.getCurrentPage());
        page.setParam(specialAwardDTO);
        page = specialAwardServiceImpl.selectSpecialAwardListPage(page);
        Map<String, Object> model = Maps.newHashMap();
        model.put("specialAwardList", page.getResultList());
        model.put("specialAwardDTO", specialAwardDTO);
        model.put("page", page);
        log.info("{}-/select/selectSpecialAwardlistpage return, data={" + page.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/specialaward", model);
    }

    /**
     * 新增特殊奖励配置
     * 
     * @param SpecialAwardDTO
     * @return
     */
    @RequestMapping(value = "/insert/insertspecialaward", method = RequestMethod.POST)
    public ResultBase<String> insertSpecialAward(SpecialAwardDTO specialAwardDTO) {
        log.info("{}-info/insert/insertSpecialAward,param={" + specialAwardDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        if (null != specialAwardDTO.getId()) {
            //更新
            return specialAwardServiceImpl.updateById(specialAwardDTO);
        }
        //新增
        return specialAwardServiceImpl.insertSpecialAward(specialAwardDTO);
    }

    @RequestMapping(value = "/delete/deleteonebyid", method = RequestMethod.POST)
    public ResultBase<String> deleteOneById(SpecialAwardDTO specialAwardDTO) {
        log.info("{}-info/delete/deleteOneById,param={" + specialAwardDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return specialAwardServiceImpl.deleteById(specialAwardDTO.getId());
    }

    /**
     * 根据id查询一条
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/select/selectspecialawardone", method = RequestMethod.GET)
    public SpecialAwardDTO selectSpecialAwardOne(String id) {
        log.info("{}-info/select/selectspecialawardone,param={" + id.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<SpecialAwardDTO> selectSpecialAwardOne = specialAwardServiceImpl.selectSpecialAwardOne(id);
        return selectSpecialAwardOne.getValue();
    }
}
