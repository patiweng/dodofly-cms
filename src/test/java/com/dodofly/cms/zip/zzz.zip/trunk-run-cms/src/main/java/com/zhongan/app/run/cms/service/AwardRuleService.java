package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AwardRuleDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface AwardRuleService {

    /**
     * 分页查询活动奖品规则
     * 
     * @param page
     * @return
     */
    Page<AwardRuleDTO> selectAwardRuleListPage(Page<AwardRuleDTO> page);

    /**
     * 新增
     * 
     * @param awardRuleDTO
     * @return
     */
    ResultBase<String> insertAwardRule(AwardRuleDTO awardRuleDTO);

    /**
     * 根据id删除
     */
    ResultBase<String> deleteById(Long id);

    /**
     * 更新
     * 
     * @param awardRuleDTO
     * @return
     */
    ResultBase<String> updateById(AwardRuleDTO awardRuleDTO);

    /**
     * 根据id查询一条
     * 
     * @param id
     * @return
     */
    ResultBase<AwardRuleDTO> selectAwardRuleOne(String id);

    /**
     * 根据活动id查询该活动下配置的所有礼物
     * 
     * @param activityId
     * @return
     */
    List<RafflePresentDTO> selectPresentNameList(String activityId);
}
