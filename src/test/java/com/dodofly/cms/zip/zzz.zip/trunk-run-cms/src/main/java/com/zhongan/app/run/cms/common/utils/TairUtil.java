package com.zhongan.app.run.cms.common.utils;

import java.io.Serializable;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

import com.taobao.tair.DataEntry;
import com.taobao.tair.Result;
import com.taobao.tair.ResultCode;
import com.taobao.tair.TairManager;
import com.taobao.tair.impl.DefaultTairManager;
@Slf4j
public class TairUtil {
    private TairManager      tm;
    private List<String>     configServerList = null;
    private String           groupName        = null;
    private int              namespace        = 1;
    private int              version          = 1;
    private static final int YEAR             = 365 * 7 * 24 * 3600;
    private static final int WEEK             = 7 * 24 * 3600;

    public void init() {
        DefaultTairManager dtm = new DefaultTairManager();
        dtm.setConfigServerList(configServerList);
        dtm.setGroupName(groupName);
        dtm.init();
        tm = dtm;
    }

    public String getString(Serializable key) {
        Result<DataEntry> result = tm.get(namespace, key);
        if (result != null && result.getValue() != null) {
            return result.getValue().getValue().toString();
        } else {
            return null;
        }
    }

    /**
     * 已固定版本号save k/v
     * 
     * @param key
     * @param value
     * @param expireTime
     * @return
     */
    public boolean putWithFixedVersion(String key, String value, int expireTime) {
        tm.delete(namespace, key);
        ResultCode rc = tm.put(namespace, key, value, version, expireTime);
        return (rc != null && ResultCode.SUCCESS.getCode() == rc.getCode());
    }

    /**
     * 已固定版本号save k/v
     * 
     * @param key
     * @param value
     * @param expireTime
     * @return
     */
    public boolean putWithFixedVersion(String key, String value) {
        tm.delete(namespace, key);
        ResultCode rc = tm.put(namespace, key, value, version);
        return (rc != null && ResultCode.SUCCESS.getCode() == rc.getCode());
    }

    /**
     * 已固定版本号save k/v
     * 
     * @param key
     * @param value
     * @param expireTime
     * @return
     */
    public boolean putWithFixedVersionDefaultTime(String key, Serializable value) {
        tm.delete(namespace, key);
        ResultCode rc = tm.put(namespace, key, value, version, YEAR);
        return (rc != null && ResultCode.SUCCESS.getCode() == rc.getCode());
    }

    /**
     * 已固定版本号save k/v
     * 
     * @param key
     * @param value
     * @param expireTime
     * @return
     */
    public boolean putWithFixedVersionWeekTime(String key, Serializable value) {
        tm.delete(namespace, key);
        ResultCode rc = tm.put(namespace, key, value, version, WEEK);
        return (rc != null && ResultCode.SUCCESS.getCode() == rc.getCode());
    }
    /**
     * 已固定版本号save k/v
     * 
     * @param key
     * @param value
     * @param expireTime
     * @return
     */
    public boolean putWithFixedVersion(String key, Serializable value,int expirTime) {
    	log.info("namespace {} key {} value{} expirTime{}",namespace,key,value,expirTime);
        tm.delete(namespace, key);
        ResultCode rc = tm.put(namespace, key, value, version, expirTime);
        return (rc != null && ResultCode.SUCCESS.getCode() == rc.getCode());
    }
    public void delete(Serializable key) {
        tm.delete(namespace, key);
    }


    /**
     * @param key
     * @param value
     * @param version
     * @return
     */
    public ResultCode put(Serializable key, Serializable value, int version) {
        return tm.put(namespace, key, value, version);
    }

    /**
     * @param key
     * @param value
     * @param version
     * @return
     */
    public ResultCode put(Serializable key, Serializable value, int version, int expireTime) {
        return tm.put(namespace, key, value, version, expireTime);
    }

    /**
     * @param key
     * @param value
     * @return
     */
    public ResultCode put(Serializable key, Serializable value) {
        return tm.put(namespace, key, value, version, YEAR);
    }

    /**
     * @param key
     * @return
     */
    public DataEntry get(Serializable key) {
        Result<DataEntry> result = tm.get(namespace, key);
        if (result.getRc().getCode() == ResultCode.SUCCESS.getCode()) {
            return result.getValue();
        }
        return null;
    }

    public TairManager getTm() {
        return tm;
    }

    public void setTm(TairManager tm) {
        this.tm = tm;
    }

    public List<String> getConfigServerList() {
        return configServerList;
    }

    public void setConfigServerList(List<String> configServerList) {
        this.configServerList = configServerList;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public int getNamespace() {
        return namespace;
    }

    public void setNamespace(int namespace) {
        this.namespace = namespace;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public static int getYear() {
        return YEAR;
    }

    /* ======================================================= */
}
