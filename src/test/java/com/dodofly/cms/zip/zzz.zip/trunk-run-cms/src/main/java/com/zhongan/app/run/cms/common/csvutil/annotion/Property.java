package com.zhongan.app.run.cms.common.csvutil.annotion;

import com.zhongan.app.run.cms.common.csvutil.format.DefaultValueFormat;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target( { ElementType.ANNOTATION_TYPE, ElementType.FIELD })
public @interface Property {

    /**
     * 标题
     * @return
     */
    String title();

    /**
     * 排序
     * @return
     */
    int order() default 0;

    /**
     * 格式化
     * @return
     */
    Class<? extends ValueFormat> format() default DefaultValueFormat.class;

    /**
     * 配合format的参数  如果formatParam有值 但是format 为默认值得花 那么采取BooleanValueFormat 来处理
     * @return
     */
    String formatParam() default "";
}
