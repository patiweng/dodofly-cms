package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoMarketingActivitiesDO;

@Component
public interface BububaoMarketingActivitiesDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoMarketingActivitiesDO> selectDataByCdt(BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO);
	   
	   /**
	    * 查询某个渠道有效期内满足条件的营销活动
	    * @param bububaoMarketingActivitiesDO
	    * @return
	    */
	   List<BububaoMarketingActivitiesDO>  selectChannelValMarkets(BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO);
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoMarketingActivitiesDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoMarketingActivitiesDO
	    */
	   void insert(BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoMarketingActivitiesDO
	    */
	   void update(BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO);
	   
	   /**
	     * 分页查询MarketingActivities信息
	     * 
	     * @param map
	     * @return
	     */
	    List<BububaoMarketingActivitiesDO> selectBububaoMarketing(Map map);
	    
	    /**
	     * 查询MarketingActivities条数
	     * 
	     * @param map
	     * @return
	     */
	    Integer selectCounts(Map map);
	    /**
	     * 删除MarketingActivities
	     * 
	     * @param  id
	     * @return
	     */
	    void deleteMarketingActivitiesById(String id);
	    
	    /**
	     * 更新数据为无效数据
	     * @param id
	     */
	    void updateByid(String id);
}
