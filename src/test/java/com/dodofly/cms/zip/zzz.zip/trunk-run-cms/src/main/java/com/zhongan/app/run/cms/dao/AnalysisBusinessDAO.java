package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.AnalysisBusinessDO;

@Component
public interface AnalysisBusinessDAO {

    /**
     * 分页查询列表
     * 
     * @return
     */
    List<AnalysisBusinessDO> selectAnalysisBusinessList(Map map);

    /**
     * 查询总条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 查询到处excel表记录
     * 
     * @param sdate
     * @param edate
     * @return
     */
    List<AnalysisBusinessDO> queryListForExcel(Map map);

    List<AnalysisBusinessDO> queryAnalisysBusinessAll();

}
