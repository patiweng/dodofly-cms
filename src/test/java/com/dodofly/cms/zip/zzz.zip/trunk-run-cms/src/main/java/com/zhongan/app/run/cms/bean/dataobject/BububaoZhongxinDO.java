package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoZhongxinDO {

	private String id;
	private String name;
	private String identity;
	private String phone;
	private String company;
	private String department;
	private String isInsure;
	private String isCode;
}
