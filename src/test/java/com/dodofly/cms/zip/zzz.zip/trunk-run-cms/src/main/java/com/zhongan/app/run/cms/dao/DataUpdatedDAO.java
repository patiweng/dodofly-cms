package com.zhongan.app.run.cms.dao;

public interface DataUpdatedDAO {

	void update();
}
