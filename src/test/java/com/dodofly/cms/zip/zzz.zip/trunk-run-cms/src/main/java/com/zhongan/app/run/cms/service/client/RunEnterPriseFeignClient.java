package com.zhongan.app.run.cms.service.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhongan.app.run.cms.bean.client.EnterpriseEmployeeClient;
import com.zhongan.app.run.cms.bean.web.ResultBase;

@FeignClient(name = "za-run-enterprise", url = "${za.run.enterprise.feignclient.url}")
public interface RunEnterPriseFeignClient {
    @RequestMapping(value = "/run/enterprise/enterpriseunionidexist/{unionid}", method = RequestMethod.GET)
    public ResultBase<List<EnterpriseEmployeeClient>> enterpriseUnionidExist(@PathVariable("unionid") String unionid);
}
