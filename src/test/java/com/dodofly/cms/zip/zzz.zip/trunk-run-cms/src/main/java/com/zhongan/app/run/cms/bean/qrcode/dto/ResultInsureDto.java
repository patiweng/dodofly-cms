package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

import org.springframework.beans.BeanUtils;

import com.zhongan.app.run.cms.common.csvutil.annotion.Property;

/**
 * 投保统计返回数据
 * 
 * @author zhangjin
 * @date 2018-06-06
 */

@Data
public class ResultInsureDto implements Cloneable {

    /**
     * 一级组织名称
     */
    @Property(title = "oneOrgName")
    private String  oneOrgName;
    /**
     * 二级组织名称
     */
    @Property(title = "twoOrgName")
    private String  twoOrgName;
    /**
     * 三级组织名称
     */
    @Property(title = "threeOrgName")
    private String  threeOrgName;
    /**
     * 四级组织名称
     */
    @Property(title = "fourOrgName")
    private String  fourOrgName;
    /**
     * 五级组织名称
     */
    @Property(title = "fiveOrgName")
    private String  fiveOrgName;
    /**
     * 业务员code
     */
    @Property(title = "salesCode")
    private String  salesCode;
    /**
     * 业务员名称
     */
    private String  salesName;
    /**
     * 是否为团队长
     */
    @Property(title = "isLeader")
    private String  isLeader;

    /**
     * 扫描次数
     */
    @Property(title = "scanNum")
    private Integer scanNum;

    /**
     * 投保次数
     */
    @Property(title = "insureNum")
    private Integer insureNum;

    /**
     * 投保用户数
     */
    @Property(title = "holderNum")
    private Integer holderNum;
    /**
     * 是否可为代理人
     */
    private String  isOrgAgent;
    /**
     * 保单号
     */
    @Property(title = "scanPolicyNo")
    private String  scanPolicyNo;
    /**
     * 投保人姓名
     */
    @Property(title = "holderName")
    private String  holderName;

    /**
     * 投保人身份证
     */
    @Property(title = "holderIdentity")
    private String  holderIdentity;

    /**
     * 投保人手机号
     */
    @Property(title = "holderPhone")
    private String  holderPhone;
    /**
     * 实际保额
     */
    @Property(title = "originSum")
    private Integer originSum;

    /**
     * 实际保费
     */
    @Property(title = "originPremium")
    private Double  originPremium;

    /**
     * 保单开始时间
     */
    @Property(title = "policyStartTime")
    private String  policyStartTime;

    /**
     * 保单结束时间
     */
    @Property(title = "policyEndTime")
    private String  policyEndTime;
    
    /**
     * 步步保统一id
     */
    private Long   scanUnionId;

    /**
     * 深克隆
     * 
     * @return
     */
    public ResultInsureDto clone() {
        ResultInsureDto resultOrgDto = null;
        try {
            resultOrgDto = (ResultInsureDto) super.clone();
        } catch (Exception e) {
            resultOrgDto = new ResultInsureDto();
            BeanUtils.copyProperties(this, resultOrgDto);
        }
        return resultOrgDto;
    }

}
