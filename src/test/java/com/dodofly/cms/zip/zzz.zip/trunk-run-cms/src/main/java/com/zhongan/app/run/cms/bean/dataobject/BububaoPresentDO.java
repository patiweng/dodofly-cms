package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoPresentDO {
    private String id;
    private String name;
    private String identify;
    private String description;
    private String price;
    private String url;
    /**
     * 活力值
     */
    private String integral;
    private String type;
    private String creator;
    private String modifier;
    private String createTime;
    private String modifyTime;
    private String isDeleted;
}
