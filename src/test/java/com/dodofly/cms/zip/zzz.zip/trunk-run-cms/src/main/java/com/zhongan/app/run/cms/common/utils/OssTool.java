package com.zhongan.app.run.cms.common.utils;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.security.SecureRandom;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Random;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONArray;
import com.aliyun.openservices.ClientConfiguration;
import com.aliyun.openservices.oss.OSSClient;
import com.aliyun.openservices.oss.model.CannedAccessControlList;
import com.aliyun.openservices.oss.model.GetObjectRequest;
import com.aliyun.openservices.oss.model.OSSObject;
import com.aliyun.openservices.oss.model.OSSObjectSummary;
import com.aliyun.openservices.oss.model.ObjectListing;
import com.aliyun.openservices.oss.model.ObjectMetadata;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;

@Slf4j
public class OssTool {

    private String              accessId;

    private String              accessKey;

    private String              endpoint;

    private String              bucketName;
    
    private String              testField;

    private final static String JONI      = "_";

    public static final String  FILE_SPIT = "/";

    private OSSClient           client;

    @Resource
    private ClientConfiguration ossClientConfig;

    private Logger              logger    = LoggerFactory.getLogger(OssTool.class);

    /**
     * 上传文件至OSS
     * 
     * @param in
     * @param size
     * @param objectKey
     * @return
     * @throws FileNotFoundException
     */
    public String uploadFile(InputStream in, long size, String objectKey) {
        logger.info("OSS uploadFile params:in[" + in + "]size[" + size + "]objectkey[" + objectKey + "]");
        ObjectMetadata objectMeta = new ObjectMetadata();
        objectMeta.setContentLength(size);
        // 因为本机不能上传到OSS 的文件，默认上传成功
        getClient().putObject(bucketName, objectKey, in, objectMeta);
        return objectKey;
    }

    // 将图片上传到oss
    public ResultBase<String> handleImg(String dataId, MultipartFile marketingImgFile) {
        ResultBase<String> result = new ResultBase<String>();
        String fileName = RunConstants.CMS_UPLOAD_PRE + dataId;
        result.setValue(fileName);
        if (marketingImgFile == null) {
            result.setSuccess(true);
            return result;
        }
        try {
            uploadFile(marketingImgFile.getInputStream(), fileName);
        } catch (IOException e) {
            log.error("文件上传失败{}", e);
            result.setSuccess(false);
            return result;
        }
        result.setValue(fileName);
        result.setSuccess(true);
        return result;
    }

    // 将图片上传到oss 礼物
    public ResultBase<String> handleImgPresent(String code,String dataId, MultipartFile marketingImgFile) {
        ResultBase<String> result = new ResultBase<String>();
        String fileNames = RunConstants.CMS_UPLOAD_PRE_PRESENT + code;
        String fileName = RunConstants.CMS_UPLOAD_PRE_PRESENT + code + dataId;
        result.setValue(fileName);
        if (marketingImgFile == null) {
            result.setSuccess(true);
            return result;
        }
        try {
            uploadFile(marketingImgFile.getInputStream(), fileName);
        } catch (IOException e) {
            log.error("文件上传失败{}", e);
            result.setSuccess(false);
            return result;
        }
        result.setValue(fileNames);
        result.setSuccess(true);
        return result;
    }
    /**
     * 上传文件至OSS
     * 
     * @param path
     * @param folder 目录名
     * @return
     * @throws FileNotFoundException
     */
    public String uploadFile(String path, String folder) {
        File file = new File(FilenameUtils.getName(path));
        FileInputStream fis = null;
        //fileName 格式为 xxxx/xxx.xx
        String fileName = RunConstants.PROJECT + folder + getNewFileName(file.getName());
        logger.info("------------objectKey----------" + fileName);
        try {
            fis = new FileInputStream(file);
            ObjectMetadata objectMeta = new ObjectMetadata();
            objectMeta.setContentLength(fis.available());
            getClient().putObject(bucketName, fileName, fis, objectMeta);
        } catch (IOException e) {
            throw new RuntimeException("File upload to OSS failed, path is " + path, e);
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (Exception exp) {
                logger.error(exp.getMessage(), exp);
            }
        }
        return fileName;
    }

    /**
     * 上传文件至OSS
     * 
     * @param path
     * @param folder 目录名
     * @return
     * @throws FileNotFoundException
     */
    public String uploadFileNew(String path, String folder) {
        File file = new File(FilenameUtils.getName(path));
        FileInputStream fis = null;
        //fileName 格式为 xxxx/xxx.xx
        String fileName = RunConstants.PROJECT + folder + getNewFileNameUP(file.getName());
        logger.info("------------objectKey----------" + fileName);
        try {
            fis = new FileInputStream(file);
            ObjectMetadata objectMeta = new ObjectMetadata();
            objectMeta.setContentLength(fis.available());
            getClient().putObject(bucketName, fileName, fis, objectMeta);
        } catch (IOException e) {
            throw new RuntimeException("File upload to OSS failed, path is " + path, e);
        } finally {
            try {
                if (fis != null) {
                    fis.close();
                }
            } catch (Exception exp) {
                logger.error(exp.getMessage(), exp);
            }
        }
        return fileName;
    }

    public String uploadFile(InputStream in, String fileName) {
        ObjectMetadata objectMeta = new ObjectMetadata();
        try {
            objectMeta.setContentLength(in.available());
            logger.info("===========================================================");
            getClient().putObject(bucketName, fileName, in, objectMeta);
            logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        } catch (IOException e) {
            logger.error("上传文件至OSS出错，文件路径：" + fileName + ";message:" + e.getMessage(), e);
            throw new RuntimeException("File upload to OSS failed, path is " + fileName, e);
        } finally {
            if (null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                    logger.error("关闭文件流出错。。。" + e.getMessage(), e);
                }
            }
        }
        return fileName;
    }

    /**
     * 将文件上传到OSS上
     * 
     * @param in 文件流
     * @param folder 文件path
     * @param name
     * @return
     */
    public String uploadFile(InputStream in, String folder, String name) {
        String filename = RunConstants.PROJECT + folder + getNewFileName(name);
        ObjectMetadata objectMeta = new ObjectMetadata();
        try {
            objectMeta.setContentLength(in.available());
            logger.info("===========================================================");
            getClient().putObject(bucketName, filename, in, objectMeta);
            logger.info("+++++++++++++++++++++++++++++++++++++++++++++++++++");
        } catch (IOException e) {
            logger.error("上传文件至OSS出错，文件路径：" + filename + ";message:" + e.getMessage(), e);
            throw new RuntimeException("File upload to OSS failed, path is " + filename, e);
        } finally {
            if (null != in) {
                try {
                    in.close();
                } catch (IOException e) {
                    logger.error("关闭文件流出错。。。" + e.getMessage(), e);
                }
            }
        }
        return filename;
    }

    /**
     * 从OSS下载文件
     * 
     * @param objectkey
     * @return InputStream
     */
    public InputStream downloadFile(String objectkey) {
        OSSObject obj = getClient().getObject(new GetObjectRequest(bucketName, objectkey));
        return obj.getObjectContent();
    }

    public void downloadFile(String objectkey, String newFile) {
        BufferedInputStream bis = null;
        BufferedOutputStream bos = null;
        try {
            OSSObject obj = getClient().getObject(new GetObjectRequest(bucketName, objectkey));
            InputStream is = obj.getObjectContent();
            File file = new File(FilenameUtils.getName(newFile));
            if (!file.getParentFile().isDirectory()) {
                file.getParentFile().mkdirs();
            }
            int buffer = 1024; // 定义缓冲区的大小
            int length = 0;
            byte[] b = new byte[buffer];
            bis = new BufferedInputStream(is);
            bos = new BufferedOutputStream(new FileOutputStream(file));
            while ((length = bis.read(b)) != -1) {
                bos.write(b, 0, length);
            }
            bos.flush();
            bis.close();
            // 下载后删除oss的临时文件
            getClient().deleteObject(bucketName, objectkey);
        } catch (IOException e) {
            throw new RuntimeException("File download from OSS failed, path is " + newFile, e);
        } finally {
            if (bis != null) {
                try {
                    bis.close();
                } catch (IOException e) {
                    logger.error("downloadFile() " + e.getMessage(), e);
                }
            }
            if (bos != null) {
                try {
                    bos.close();
                } catch (IOException e) {
                    logger.error("downloadFile() " + e.getMessage(), e);
                }
            }
        }
    }

    /**
     * 从OSS删除文件
     * 
     * @param objectkey
     */
    public void deleteFile(String objectkey) {
        getClient().deleteObject(bucketName, objectkey);
    }

    /**
     * 从OSS上Copy一个文件，指定文件名称
     * 
     * @param objectkey
     * @param newkey
     * @return
     */
    public String copyFile(String objectkey, String newkey) {
        getClient().copyObject(bucketName, objectkey, bucketName, newkey);
        return newkey;
    }

    /**
     * 上传本地文件到oss
     * 
     * @param path 本地文件
     * @param folder 远端路径
     * @return
     */
    public String uploadOriginFile(String path, String folder) {
        File file = new File(FilenameUtils.getName(path));
        FileInputStream fis = null;
        String fileName = RunConstants.PROJECT + folder + file.getName();
        logger.info("uploadOriginFile(): to upload local-file:" + path + " absolutePath-file:" + file.getAbsolutePath()
                + " remote-file:" + fileName);
        try {
            fis = new FileInputStream(file);
            ObjectMetadata objectMeta = new ObjectMetadata();
            objectMeta.setContentLength(fis.available());
            getClient().putObject(bucketName, fileName, fis, objectMeta);
            return fileName;
        } catch (IOException e) {
            throw new RuntimeException("File upload to OSS failed, path is " + path, e);
        } finally { //关闭链接并删除本地dummy删除。
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    //e.printStackTrace();
                    logger.error("uploadOriginFile() " + e.getMessage(), e);
                }
            }
        }

    }

    /**
     * 读取流
     * 
     * @param inputStream
     * @return
     */
    public JSONArray getJsonObject(InputStream inputStream) {
        StringBuffer sb = new StringBuffer();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String temp;
        try {
            while ((temp = reader.readLine()) != null) {
                sb.append(temp);
            }
        } catch (IOException e) {
            logger.error("读取文件失败，文件为：", e, e.getMessage());
        }
        if ("".equals(sb.toString())) {
            logger.error("用户信息不存在!");
            return null;
        }
        return JSONArray.parseArray(sb.toString());

    }

    /**
     * 创建空文件到oss上
     * 
     * @param name
     * @param folder
     * @return
     */
    public String createDummyFile(String name, String folder) {
        File dummy = null;
        try {
            dummy = File.createTempFile("osstool_forrecord", "dummy");
        } catch (IOException e1) {
            //e1.printStackTrace();
            logger.error("createDummyFile() " + e1.getMessage(), e1);
        }
        if (dummy == null) {
            throw new RuntimeException(
                    "create dummy File.createTempFile(\"osstool_forrecord\",\"dummy\") is failed! dummy==null;");
        }
        FileInputStream fis = null;
        String fileName = RunConstants.PROJECT + folder + name;
        logger.info("createDummyFile(): to upload local-name:" + name + " remote-filename:" + fileName);
        try {
            fis = new FileInputStream(dummy);
            ObjectMetadata objectMeta = new ObjectMetadata();
            objectMeta.setContentLength(fis.available());
            getClient().putObject(bucketName, fileName, fis, objectMeta);
            return fileName;
        } catch (IOException e) {
            throw new RuntimeException("File upload to OSS failed, target file-name is " + fileName, e);
        } finally { //更比链接并删除本地dummy删除。
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    //e.printStackTrace();
                    logger.error("createDummyFile() " + e.getMessage(), e);
                }
            }
            logger.info("to delete dummy-file:" + dummy.getAbsolutePath());
            if (dummy.exists())
                dummy.delete();
        }

    }

    //
    //查询出对应folder下的文件，截取folder部分。
    //
    //    public String[] listFileShortName(String folder) {
    //        logger.info("listFile():  bucketName:" + bucketName + " folder:" + B2gConstants.PROJECT + folder);
    //        ObjectListing objectListing = this.getClient().listObjects(this.bucketName, B2gConstants.PROJECT + folder);
    //        List<OSSObjectSummary> listSumm = objectListing.getObjectSummaries();
    //        if (listSumm == null) {
    //            throw new RuntimeException("getObjectSummaries() is failed!");
    //        }
    //        String[] names = new String[listSumm.size()];
    //        for (int i = 0; i < listSumm.size(); i++) {
    //            String objectName = listSumm.get(i).getKey();
    //            logger.debug("listFile(): listed name:" + objectName);
    //            if (objectName != null) {
    //                String shortName = StringUtil.substringAfterLast(objectName, folder);
    //                //              logger.info("listFile(): listed shortName:" + shortName);
    //                names[i] = shortName;
    //            }
    //        }
    //        logger.info("listFile():  size:" + names.length);
    //        return names;
    //    }

    public String getAccessId() {
        return accessId;
    }

    public void setAccessId(String accessId) {
        this.accessId = accessId;
    }

    public String getAccessKey() {
        return accessKey;
    }

    public void setAccessKey(String accessKey) {
        this.accessKey = accessKey;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public String getBucketName() {
        return bucketName;
    }

    public void setBucketName(String bucketName) {
        this.bucketName = bucketName;
    }
    
    public String getTestField() {
		return testField;
	}

	public void setTestField(String testField) {
		this.testField = testField;
	}

	public void createBucket() {
        if (!getClient().doesBucketExist(bucketName)) {
            // 创建bucket
            getClient().createBucket(bucketName);
        }
    }

    public void queryBucket() {
        ObjectListing objectListing = getClient().listObjects(bucketName);
        List<OSSObjectSummary> listDeletes = objectListing.getObjectSummaries();
        for (int i = 0; i < listDeletes.size(); i++) {
            String objectName = listDeletes.get(i).getKey();
            logger.debug("OSS hasObjects:" + objectName);
        }
    }

    // 删除一个Bucket和其中的Objects
    public void deleteBucket() {
        ObjectListing objectListing = getClient().listObjects(bucketName);
        List<OSSObjectSummary> listDeletes = objectListing.getObjectSummaries();
        for (int i = 0; i < listDeletes.size(); i++) {
            String objectName = listDeletes.get(i).getKey();
            // 如果不为空，先删除bucket下的文件
            getClient().deleteObject(bucketName, objectName);
        }
        getClient().deleteBucket(bucketName);
    }

    // 把Bucket设置为所有人可读
    public void setBucketPublicReadable() {
        // 设置bucket的访问权限，public-read-write权限
        getClient().setBucketAcl(bucketName, CannedAccessControlList.PublicRead);
    }

    private OSSClient getClient() {
    	 logger.info("endpoint[" + endpoint + "]accessId[" + accessId + "]accessKey[" + accessKey + "] bucketName["+bucketName+"]testField["+testField+"]");
        if("EFNSNv6Kwn2zcifp".equals(accessId)){
        	accessId="LTAIJSdsqvE5uZE2";
        	accessKey="eoVhTICy0zDXQDiAv0IsRRcGFFVnEB";
        }
    	 if (client == null) {
            if (StringUtils.isNotEmpty(accessId) && StringUtils.isNotEmpty(accessKey)) {
               
                client = new OSSClient(endpoint, accessId, accessKey, ossClientConfig);

            }
        }
        
        logger.info("OSS getClient:" + client);
        return client;
    }

    private String getNewFileNameUP(String file) {
        String name = new File(FilenameUtils.getName(file)).getName();
        int index = name.lastIndexOf(".");
        return name.substring(0, index) + formatLocal.get().format(new Date()) + name.substring(index);
    }
    @Override
    public String toString() {
    	// TODO Auto-generated method stub
    	return accessId+"|"+accessKey+"|"+endpoint+"|"+bucketName;
    }
    private String getNewFileName(String file) {
        //        String name = new File(file).getName();
        int random = new SecureRandom().nextInt(10000);
        int index = file.lastIndexOf(".");
        return file.substring(0, index) + JONI + formatLocal.get().format(new Date()) + JONI + random
                + file.substring(index);
    }

    private final ThreadLocal<SimpleDateFormat> formatLocal = new ThreadLocal<SimpleDateFormat>() {
                                                                @Override
                                                                public SimpleDateFormat initialValue() {
                                                                    return new SimpleDateFormat("yyyyMMddHHmmss");
                                                                }
                                                            };
}
