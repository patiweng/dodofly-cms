package com.zhongan.app.run.cms.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import com.zhongan.app.run.cms.bean.dataobject.StaticsCollectionDO;
import com.zhongan.app.run.cms.bean.dataobject.UserInsuranceDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.ChannelCodeTmpEnum;
import com.zhongan.app.run.cms.repository.StaticsRepository;
import com.zhongan.app.run.cms.service.StaticsService;
import com.zhongan.app.run.common.utils.AppUtil;

@Service
@Slf4j
public class StaticsServiceImpl implements StaticsService{
	@Resource
	private StaticsRepository staticsRepository;
	
	public ResultBase<String> staticsUvPv(String from,String sdate,String edate){
		ResultBase<String> result= new ResultBase<String>();
		String str = staticsRepository.staticsUvPv(from, sdate, edate);
		result.setValue(str);
		return result;
	}
	public ResultBase<String> staticsAll(HttpServletResponse response,String sDate,String eDate){
		ResultBase<String> result = new ResultBase<String>();
		sDate = sDate + " 00:00:00";
		eDate = eDate + " 23:59:59";
		Map<String,List> map = staticsRepository.staticsAll(sDate, eDate);

		log.info("访问统计数据");
		List<StaticsCollectionDO> fromVisitList = map.get("staticsFromVisit");
		List<StaticsCollectionDO> pageVisitList = map.get("staticsPageVisit");
		List<StaticsCollectionDO> allVisitList = map.get("staticsallVist");
		List<StaticsCollectionDO> oldVisitList = map.get("staticsOldVist");
		List<StaticsCollectionDO> newVisitList = map.get("staticsNewVist");
		List<StaticsCollectionDO> fromAddList = map.get("staticsfromAdd");
		List<StaticsCollectionDO> userAllList = map.get("staticsUserAll");
		List<StaticsCollectionDO> sourceBugList = map.get("staticsSourceBug");
		
        String path = "/alidata1/admin/run-cms/logs/biz-all.xlsx";
        log.info("excel模版的路径为=================" + path);
		//log.info("执行结果数据========{}",JSONObject.toJSONString(map));
        try{
        	File file=new File(path);
            if(!file.exists()){
            	file.createNewFile();
            }
        	OutputStream ouputStream = new FileOutputStream(path);
        	Workbook workbook = new XSSFWorkbook();
        	Sheet sheet1 =  workbook.createSheet("周渠道活跃");
        	Sheet sheet2 =  workbook.createSheet("周页面活跃");
        	Sheet sheet3 =  workbook.createSheet("周总登录");
        	Sheet sheet4 =  workbook.createSheet("周老用户活跃");
        	Sheet sheet5 =  workbook.createSheet("周新用户活跃");
        	Sheet sheet6 =  workbook.createSheet("周渠道新增用户");
        	Sheet sheet7 =  workbook.createSheet("渠道总用户");
        	Sheet sheet9 =  workbook.createSheet("问题单");
        	/****************周渠道活跃数据***************/
        	if(fromVisitList != null && fromVisitList.size()>0){
        		Row row0 = sheet1.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("渠道");
        		Cell cell_03 = row0.createCell(3, Cell.CELL_TYPE_STRING);
        		cell_03.setCellValue("页面");
        		Cell cell_04 = row0.createCell(4, Cell.CELL_TYPE_STRING);
        		cell_04.setCellValue("数量");
        		for(int i=0;i<fromVisitList.size();i++){
        			Row rowx = sheet1.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			cell_2.setCellValue(fromVisitList.get(i).getFromName());
        			Cell cell_3 = rowx.createCell(3, Cell.CELL_TYPE_STRING);
        			cell_3.setCellValue(fromVisitList.get(i).getPage());
        			Cell cell_4 = rowx.createCell(4, Cell.CELL_TYPE_STRING);
        			cell_4.setCellValue(fromVisitList.get(i).getPageCount());
        		}
        	}
        	log.info("周渠道活跃完成");
        	/****************周页面活跃数据***************/
        	if(pageVisitList != null && pageVisitList.size() >0){
        		Row row0 = sheet2.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("页面");
        		Cell cell_03 = row0.createCell(3, Cell.CELL_TYPE_STRING);
        		cell_03.setCellValue("数量");
        		for(int i=0;i<pageVisitList.size();i++){
        			Row rowx = sheet2.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			cell_2.setCellValue(pageVisitList.get(i).getPage());
        			Cell cell_3 = rowx.createCell(3, Cell.CELL_TYPE_STRING);
        			cell_3.setCellValue(pageVisitList.get(i).getAllCount());
        		}
        	}
        	log.info("周页面活跃完成");
        	/****************周总新增数据***************/
        	if(allVisitList != null && allVisitList.size() >0){
        		Row row0 = sheet3.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("数量");
        		for(int i=0;i<allVisitList.size();i++){
        			Row rowx = sheet3.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			cell_2.setCellValue(allVisitList.get(i).getAllActiveCount());
        		}
        	}
        	/****************周老用户活跃***************/
        	if(oldVisitList != null && oldVisitList.size() >0){
        		Row row0 = sheet4.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("数量");
        		for(int i=0;i<oldVisitList.size();i++){
        			Row rowx = sheet4.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			cell_2.setCellValue(oldVisitList.get(i).getOldActiveCount());
        		}
        	}
        	
        	/****************周新用户活跃***************/
        	if(newVisitList != null && newVisitList.size() >0){
        		Row row0 = sheet5.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("数量");
        		for(int i=0;i<newVisitList.size();i++){
        			Row rowx = sheet5.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			cell_2.setCellValue(newVisitList.get(i).getNewActiveCount());
        		}
        	}
        	log.info("周新用户活跃完成");
        	/****************周渠道新增***************/
        	if(fromAddList != null && fromAddList.size() >0){
        		Row row0 = sheet6.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("渠道");
        		Cell cell_03 = row0.createCell(3, Cell.CELL_TYPE_STRING);
        		cell_03.setCellValue("数量");
        		for(int i=0;i<fromAddList.size();i++){
        			Row rowx = sheet6.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			String from = fromAddList.get(i).getFrom();
        			String fromName = ChannelCodeTmpEnum.getEnumByCode(from).getValue();
        			cell_2.setCellValue(fromName);
        			Cell cell_3 = rowx.createCell(3, Cell.CELL_TYPE_STRING);
        			cell_3.setCellValue(fromAddList.get(i).getFromActiveCount());
        		}
        	}
        	log.info("周渠道新增完成");
        	/****************渠道总用户数***************/
        	if(userAllList != null && userAllList.size() >0){
        		Row row0 = sheet7.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("渠道");
        		Cell cell_03 = row0.createCell(3, Cell.CELL_TYPE_STRING);
        		cell_03.setCellValue("数量");
        		for(int i=0;i<userAllList.size();i++){
        			Row rowx = sheet7.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			String from = userAllList.get(i).getFrom();
        			String fromName = ChannelCodeTmpEnum.getEnumByCode(from).getValue();
        			cell_2.setCellValue(fromName);
        			Cell cell_3 = rowx.createCell(3, Cell.CELL_TYPE_STRING);
        			cell_3.setCellValue(userAllList.get(i).getAllCount());
        		}
        	}
        	/****************问题单***************/
        	if(sourceBugList != null && sourceBugList.size() >0){
        		Row row0 = sheet9.createRow(0);
        		Cell cell_01 = row0.createCell(1, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		Cell cell_02 = row0.createCell(2, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("渠道");
        		Cell cell_05 = row0.createCell(3, Cell.CELL_TYPE_STRING);
        		cell_05.setCellValue("授权数");
        		Cell cell_03 = row0.createCell(3, Cell.CELL_TYPE_STRING);
        		cell_03.setCellValue("新增投保");
        		Cell cell_04 = row0.createCell(4, Cell.CELL_TYPE_STRING);
        		cell_04.setCellValue("问题保单数");
        		for(int i=0;i<sourceBugList.size();i++){
        			Row rowx = sheet9.createRow(i+1);
        			Cell cell_1 = rowx.createCell(1, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(i + 1);
        			Cell cell_2 = rowx.createCell(2, Cell.CELL_TYPE_STRING);
        			String from = sourceBugList.get(i).getSource();
        			String fromName = ChannelCodeTmpEnum.getEnumByCode(from).getValue();
        			if("其他".equals(fromName)){
        				fromName = from;
        			}
        			cell_2.setCellValue(fromName);
        			
        			Cell cell_3 = rowx.createCell(3, Cell.CELL_TYPE_STRING);
        			cell_3.setCellValue(sourceBugList.get(i).getAuthCount());
        			
        			Cell cell_4 = rowx.createCell(4, Cell.CELL_TYPE_STRING);
        			cell_4.setCellValue(sourceBugList.get(i).getAddInsureCount());
        			
        			Cell cell_5 = rowx.createCell(5, Cell.CELL_TYPE_STRING);
        			cell_5.setCellValue(sourceBugList.get(i).getBugInsureCount());
        		}
        	}
        	log.info("问题单完成");
        	//String title = "业务数据统计.xlsx";
        	//response.setHeader("Content-disposition","attachment;filename=" + title);
        	 //ouputStream = response.getOutputStream();
             workbook.write(ouputStream);
             ouputStream.flush();
             ouputStream.close();
        }catch(Exception e){
        	log.info("导出EXCEL出错",e);
        }
        result.setErrorMessage("生成成功");
        result.setValue("请到日志目录下载");
        result.setSuccess(true);
        return result;
	}
	public ResultBase<String> staticsXuBao(HttpServletResponse response,String sDate,String eDate){
		ResultBase<String> result = new ResultBase<String>();
		sDate = sDate + " 00:00:00";
		eDate = eDate + " 23:59:59";
		Map<String,List> map = staticsRepository.staticsAll(sDate, eDate);

		log.info("访问统计数据");
		List<UserInsuranceDO> userInsureList = map.get("staticsUserInsure");
		
        String path = "/alidata1/admin/run-cms/logs/biz-xb.xlsx";
        log.info("excel模版的路径为=================" + path);
		//log.info("执行结果数据========{}",JSONObject.toJSONString(map));
        try{
        	File file=new File(path);
            if(!file.exists()){
            	file.createNewFile();
            }
        	OutputStream ouputStream = new FileOutputStream(path);
        	Workbook workbook = new XSSFWorkbook();
        	Sheet sheet8 =  workbook.createSheet("渠道续保用户");
        	/****************渠道续保用户***************/
        	log.info("续保记录条数{}",userInsureList.size());
        	if(userInsureList != null && userInsureList.size() >0 ){
        		int x = 1;
        		Row row0 = sheet8.createRow(0);
        		Cell cell_01 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_01.setCellValue("序号");
        		x++;
        		Cell cell_02 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_02.setCellValue("订单号");
        		x++;
        		Cell cell_03 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_03.setCellValue("渠道");
        		x++;
        		Cell cell_04 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_04.setCellValue("投保人姓名");
        		x++;
        		Cell cell_05 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_05.setCellValue("投保人身份证");
        		x++;
        		Cell cell_06 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_06.setCellValue("投保人电话");
        		x++;
        		Cell cell_08 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_08.setCellValue("保单号");
        		x++;
        		Cell cell_09 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_09.setCellValue("是否免费");
        		x++;
        		Cell cell_010 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_010.setCellValue("渠道保额");
        		x++;
        		Cell cell_011 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_011.setCellValue("渠道保费");
        		x++;
        		Cell cell_012 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_012.setCellValue("实际保额");
        		x++;
        		Cell cell_013 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_013.setCellValue("实际保费");
        		x++;
        		Cell cell_014 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_014.setCellValue("保单起期");
        		x++;
        		Cell cell_015 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_015.setCellValue("保单止期");
        		x++;
        		Cell cell_016 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_016.setCellValue("免费天数");
        		x++;
        		Cell cell_017 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_017.setCellValue("优惠券ID");
        		x++;
        		Cell cell_018 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_018.setCellValue("优惠券");
        		x++;
        		Cell cell_019 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_019.setCellValue("是否支付");
        		x++;
        		Cell cell_020 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_020.setCellValue("营销活动ID");
        		x++;
        		Cell cell_021 = row0.createCell(x, Cell.CELL_TYPE_STRING);
        		cell_021.setCellValue("产品版型ID");
        		x++;
        		for(int i=0;i<userInsureList.size();i++){
        			
        			Row rowx = sheet8.createRow(i+1);
        			int m = 1;
        			Cell cell_0 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_0.setCellValue(m);
        			m ++;
        			Cell cell_1 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_1.setCellValue(nvlObj(userInsureList.get(i).getInsuredId()));
        			m ++;
        			Cell cell_10 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			String from = userInsureList.get(i).getChannelFrom();
        			String fromName = ChannelCodeTmpEnum.getEnumByCode(from).getValue();
        			cell_10.setCellValue(fromName);
        			m ++;
        			Cell cell_2 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_2.setCellValue(nvlObj(userInsureList.get(i).getHolderName()));
        			m ++;
        			Cell cell_3 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_3.setCellValue(nvlObj(userInsureList.get(i).getHolderIdentity()));
        			m ++;
        			Cell cell_4 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_4.setCellValue(nvlObj(userInsureList.get(i).getHolderPhone()));
        			m ++;
        			Cell cell_7 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_7.setCellValue(nvlObj(userInsureList.get(i).getPolicyNo()));
        			m ++;
        			Cell cell_8 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_8.setCellValue(nvlObj(userInsureList.get(i).getIsFree()));
        			m ++;
        			Cell cell_9 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_9.setCellValue(nvlObj(userInsureList.get(i).getChannelSum()));
        			m ++;
        			Cell cell_11 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_11.setCellValue(nvlObj(userInsureList.get(i).getChannelPremium()));
        			m ++;
        			Cell cell_12 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_12.setCellValue(nvlObj(userInsureList.get(i).getOriginSum()));
        			m ++;
        			Cell cell_13 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_13.setCellValue(nvlObj(userInsureList.get(i).getOriginPremium()));
        			m ++;
        			Cell cell_14 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_14.setCellValue(nvlObj(AppUtil.covertDateToString(userInsureList.get(i).getPolicyStartTime())));
        			m ++;
        			Cell cell_15 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_15.setCellValue(nvlObj(AppUtil.covertDateToString(userInsureList.get(i).getPolicyEndTime())));
        			m ++;
        			Cell cell_16 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_16.setCellValue(nvlObj(userInsureList.get(i).getFreeDays()));
        			m ++;
        			Cell cell_17 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_17.setCellValue(nvlObj(userInsureList.get(i).getCouponId()));
        			m ++;
        			Cell cell_18 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_18.setCellValue(nvlObj(userInsureList.get(i).getCoupon()));
        			m ++;
        			Cell cell_19 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_19.setCellValue(nvlObj(userInsureList.get(i).getPaid()));
        			m ++;
        			Cell cell_20 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_20.setCellValue(nvlObj(userInsureList.get(i).getCampaignDefId()));
        			m ++;
        			Cell cell_21 = rowx.createCell(m, Cell.CELL_TYPE_STRING);
        			cell_21.setCellValue(nvlObj(userInsureList.get(i).getPackageDefId()));
        		}
        	}
        	log.info("渠道续保用户完成");
        	//String title = "业务数据统计.xlsx";
        	//response.setHeader("Content-disposition","attachment;filename=" + title);
        	 //ouputStream = response.getOutputStream();
             workbook.write(ouputStream);
             ouputStream.flush();
             ouputStream.close();
        }catch(Exception e){
        	log.info("导出EXCEL出错",e);
        }
        result.setErrorMessage("生成成功");
        result.setValue("请到日志目录下载");
        result.setSuccess(true);
        return result;
	}	
	private String nvlObj(Object obj){
		if(obj == null){
			return "无";
		}else{
			return String.valueOf(obj);
		}
	}
}
