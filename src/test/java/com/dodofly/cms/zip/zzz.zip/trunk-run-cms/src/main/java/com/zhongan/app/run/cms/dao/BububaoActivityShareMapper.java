package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.zhongan.app.run.cms.dao.bean.BububaoActivityShareDO;
import com.zhongan.app.run.cms.dao.bean.BububaoActivityShareExample;

public interface BububaoActivityShareMapper {
    long countByExample(BububaoActivityShareExample example);

    int deleteByExample(BububaoActivityShareExample example);

    int deleteByPrimaryKey(Long id);

    int insert(BububaoActivityShareDO record);

    int insertSelective(BububaoActivityShareDO record);

    List<BububaoActivityShareDO> selectByExample(BububaoActivityShareExample example);

    BububaoActivityShareDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") BububaoActivityShareDO record,
                                 @Param("example") BububaoActivityShareExample example);

    int updateByExample(@Param("record") BububaoActivityShareDO record,
                        @Param("example") BububaoActivityShareExample example);

    int updateByPrimaryKeySelective(BububaoActivityShareDO record);

    int updateByPrimaryKey(BububaoActivityShareDO record);
}
