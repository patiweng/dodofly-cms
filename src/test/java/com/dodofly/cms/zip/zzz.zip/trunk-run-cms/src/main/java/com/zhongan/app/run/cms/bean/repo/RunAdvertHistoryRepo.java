package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;

@Data
public class RunAdvertHistoryRepo {

    private String id;
    private String unionId;
    private String activitiesId;
    private String activitiesName;
    private String displayTime;
    private String clickTime;
    private String gmtCreated;
    private String gmtModified;
    private String isDeleted;
    private String startTime;
    private String endTime;
}
