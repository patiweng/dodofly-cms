package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.BububaoActivityRuleDTO;
import com.zhongan.app.run.cms.bean.web.BububaoActivityRulePageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface ActivityRuleService {

    public ResultBase<List<BububaoActivityRuleDTO>> queryActivityRuleByCdt(BububaoActivityRuleDTO info);

    public ResultBase<String> insertActivityRuleInfo(BububaoActivityRuleDTO info);

    public ResultBase<String> updateActivityRuleInfo(BububaoActivityRuleDTO info);

    public ResultBase<String> deleteActivityRuleById(Long id);

    public BububaoActivityRulePageDTO selectActivityRuleByCdtPage(BububaoActivityRuleDTO param);

    public ResultBase<String> insertorupdateActivityRule(BububaoActivityRuleDTO info);

    public BububaoActivityRuleDTO selectActivityRuleOne(Long id);

    public ResultBase<String> copyActivityRuleById(Long id);

}
