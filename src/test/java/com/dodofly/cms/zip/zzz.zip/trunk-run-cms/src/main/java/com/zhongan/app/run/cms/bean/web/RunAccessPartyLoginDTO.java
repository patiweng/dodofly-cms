package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class RunAccessPartyLoginDTO {

    //id
    private String id;
    //接入方ID
    private String accessPartyId;
    //用户名
    private String loginName;
    //用户密码
    private String loginPassword;
    //创建者
    private String creator;

}
