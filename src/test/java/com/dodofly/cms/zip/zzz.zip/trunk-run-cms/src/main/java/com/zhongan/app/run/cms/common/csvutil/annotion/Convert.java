package com.zhongan.app.run.cms.common.csvutil.annotion;

import java.util.List;

public interface Convert {

    public <T> T readConvert(String[] values, char separator, List<String> titles, Class<T> clazz);

    public <T> List<String[]> writeConvertContent(List<T> datas, Class<T> clazz, List<String> titles);
}
