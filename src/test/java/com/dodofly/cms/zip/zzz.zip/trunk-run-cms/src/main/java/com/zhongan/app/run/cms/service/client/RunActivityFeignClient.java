package com.zhongan.app.run.cms.service.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhongan.app.run.cms.bean.client.BububaoActivityRuleClient;
import com.zhongan.app.run.cms.bean.web.BububaoActivityRuleDTO;
import com.zhongan.app.run.cms.bean.web.CardCouponsDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

@FeignClient(name = "za-run-activity", url = "${za.run.activity.feignclient.url}")
public interface RunActivityFeignClient {

    @RequestMapping(value = "/run/activity/find/count", method = RequestMethod.GET)
    public ResultBase<String> count();

    @RequestMapping(value = "/run/activity/selectcardcoupons", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<List<CardCouponsDTO>> selectcardcoupons(CardCouponsDTO cardCouponsDTO);

    @RequestMapping(value = "/run/activity/rule/queryActivityRuleByCdt", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<List<BububaoActivityRuleDTO>> queryActivityRuleByCdt(BububaoActivityRuleClient client);

    @RequestMapping(value = "/run/activity/rule/insertActivityRuleInfo", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<String> insertActivityRuleInfo(BububaoActivityRuleDTO info);

    @RequestMapping(value = "/run/activity/rule/updateActivityRuleInfoById", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<String> updateActivityRuleInfoById(BububaoActivityRuleDTO info);

    @RequestMapping(value = "/run/activity/rule/countActivityRuleInfo", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<Long> countActivityRuleInfo(BububaoActivityRuleDTO param);

}
