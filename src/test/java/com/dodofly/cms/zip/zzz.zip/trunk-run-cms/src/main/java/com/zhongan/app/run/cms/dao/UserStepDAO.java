package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.UserAllStepDO;
import com.zhongan.app.run.cms.bean.dataobject.UserStepCountDO;
import com.zhongan.app.run.cms.bean.dataobject.UserStepDO;

@Component
public interface UserStepDAO {

    List<UserStepDO> selectUserStepByDate(Map map);

    List<UserAllStepDO> selectUserAllStepByDate(Map map);

    List<UserStepCountDO> selectUserStepCountByDateAndUnionid(Map map);

}
