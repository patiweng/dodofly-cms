package com.zhongan.app.run.cms.common.utils;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.zhongan.app.run.cms.bean.qrcode.dto.UserInfoView;
import com.zhongan.sso.client.SsoSession;
import com.zhongan.sso.client.SsoUser;
public class UserUtil {
    public static UserInfoView getUserInfo() {
        UserInfoView userInfoView = new UserInfoView();
        // 从session中获取人员信息
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();;
        SsoUser ssoUser = SsoSession.getCurrentUser(request);
        if (ssoUser != null) {
            //用用户名作为工作流的筛选条件
            userInfoView.setOperatorId(ssoUser.getUsername());
            userInfoView.setOperatorName(ssoUser.getName());
        }
        // 设置默认值
        if (StringUtils.isEmpty(userInfoView.getOperatorId())) {
            userInfoView.setOperatorId("system");
            userInfoView.setOperatorName("system");
        }
        return userInfoView;
    }
}
