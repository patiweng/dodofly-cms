package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoZhongxinDO;
import com.zhongan.app.run.cms.bean.dataobject.WechatAccessTokenDO;

@Component
public interface WechatAccessTokenDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<WechatAccessTokenDO> selectDataByCdt(WechatAccessTokenDO wechatAccessTokenDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   WechatAccessTokenDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param WechatAccessTokenDO
	    */
	   void insert(WechatAccessTokenDO wechatAccessTokenDO);
	   
	   /**
	    * 更新数据
	    * @param WechatAccessTokenDO
	    */
	   void update(WechatAccessTokenDO wechatAccessTokenDO);
}
