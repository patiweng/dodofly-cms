package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoUserSourceDO;
import com.zhongan.app.run.cms.bean.dataobject.SourceUserDO;
import com.zhongan.app.run.cms.bean.repo.RunUserFindInfoRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserFindInfoDTO;
import com.zhongan.app.run.cms.dao.BububaoUserSourceDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Component
public class RunUserFindInfoRepository {

    @Resource
    private BububaoUserSourceDAO bububaoUserSourceDAO;

    //用户来源表信息查询
    public ResultBase<List<RunUserFindInfoDTO>> selectUserSourceInfo(RunUserFindInfoRepo runUserFindInfoRepo)
            throws Exception {
        log.info("{}-insert find userSourceinfo。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunUserFindInfoDTO>> result = new ResultBase<List<RunUserFindInfoDTO>>();
        List<RunUserFindInfoDTO> listresult = new ArrayList<RunUserFindInfoDTO>();
        RunUserFindInfoDTO runUserFindInfoDTO = new RunUserFindInfoDTO();
        BububaoUserSourceDO bububaoUserSourceDO = new BububaoUserSourceDO();
        BeanUtils.copyProperties(runUserFindInfoRepo, bububaoUserSourceDO);
        List<BububaoUserSourceDO> resultlist = bububaoUserSourceDAO.selectDataByCdt(bububaoUserSourceDO);
        if (resultlist.size() > 0) {
            BeanUtils.copyProperties(resultlist.get(0), runUserFindInfoDTO);
            listresult.add(runUserFindInfoDTO);
        }
        result.setSuccess(true);
        result.setValue(listresult);
        return result;
    }

    //查询用户表
    public List<SourceUserDO> queryUserSourceAll() {
        List<SourceUserDO> result = bububaoUserSourceDAO.selectUserSourceAll();
        return result;
    }

}
