package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayResDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.ICashierHelpPayService;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类CashierHelpPayController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年1月29日 下午2:31:59
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/cashierHelpPay")
public class CashierHelpPayController {

    @Resource
    private ICashierHelpPayService   cashierHelpPayService;

    @Resource
    private RunChannelListRepository runChannelListRepository;

    @RequestMapping(value = "/queryCashierHelpPayList")
    public ModelAndView selectActivityPresentListPage(CashierHelpPayQueryDTO queryDTO) {
        log.info("CashierHelpPayController selectActivityPresentListPage param{}", JSON.toJSONString(queryDTO));
        ModelAndView modelAndView = new ModelAndView("cms/cashierHelpPay");
        try {
            PageDTO<CashierHelpPayResDTO> pageDTO = cashierHelpPayService.queryCashierHelpPayList(queryDTO);
            modelAndView.addObject("page", pageDTO);
            modelAndView.addObject("totalPage", pageDTO.getTotalPage());
            modelAndView.addObject("cashierHelpPayList", pageDTO.getResultList());
            modelAndView.addObject("CashierHelpPayQueryDTO", queryDTO);
            //渠道信息
            RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
            ResultBase<List<RunChannelListDTO>> resultchannel = runChannelListRepository
                    .selectRunChannelListDataList(runChannelListRepo);
            modelAndView.addObject("channelList", resultchannel.getValue());
        } catch (Exception e) {
            log.info("CashierHelpPayController selectActivityPresentListPage param{} exception{}",
                    JSON.toJSONString(queryDTO), e);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/saveOrUpdateCashierHelpPay", method = RequestMethod.POST)
    public ResultBase<Long> saveOrUpdateCashierHelpPay(@RequestBody CashierHelpPayDTO cashierHelpPayDTO) {
        log.info("CashierHelpPayController saveOrUpdateCashierHelpPay param{}", JSON.toJSONString(cashierHelpPayDTO));
        ResultBase<Long> resultBase = new ResultBase<Long>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierHelpPayService.saveOrUpdateCashierHelpPay(cashierHelpPayDTO));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierHelpPayController saveOrUpdateCashierHelpPay param{} exception{}",
                    JSON.toJSONString(cashierHelpPayDTO), e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            return resultBase;
        }
    }

    @RequestMapping(value = "/queryByCondition", method = RequestMethod.POST)
    public ResultBase<List<CashierHelpPayDTO>> queryByCondition(@RequestBody CashierHelpPayDTO cashierHelpPayDTO) {
        log.info("CashierHelpPayController queryByCondition param{}", JSON.toJSONString(cashierHelpPayDTO));
        ResultBase<List<CashierHelpPayDTO>> resultBase = new ResultBase<List<CashierHelpPayDTO>>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierHelpPayService.queryByCondition(cashierHelpPayDTO));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierHelpPayController saveOrUpdateCashierHelpPay param{} exception{}",
                    JSON.toJSONString(cashierHelpPayDTO), e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            return resultBase;
        }
    }

    @RequestMapping(value = "/deleteById", method = RequestMethod.POST)
    public ResultBase<Integer> deleteById(@RequestParam(value = "id") long id) {
        log.info("CashierHelpPayController deleteById id{}", id);
        ResultBase<Integer> resultBase = new ResultBase<Integer>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierHelpPayService.deleteById(id));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierHelpPayController deleteById id{} exception{}", id, e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            return resultBase;
        }
    }

    /**
     * 分页查询用户签约信息
     * 
     * @param queryDTO
     * @return
     */
    @RequestMapping(value = "/queryUserCashierHelpPayList", method = RequestMethod.POST)
    public ResultBase<List<CashierHelpPayResDTO>> queryUserCashierHelpPayList(@RequestBody CashierHelpPayQueryDTO queryDTO) {
        log.info("CashierHelpPayController queryUserCashierHelpPay param==={}", JSON.toJSONString(queryDTO));
        ResultBase<List<CashierHelpPayResDTO>> resultBase = new ResultBase<List<CashierHelpPayResDTO>>();
        try {
            PageDTO<CashierHelpPayResDTO> pageDTO = cashierHelpPayService.queryCashierHelpPayList(queryDTO);
            if (pageDTO.getTotalItem() < 0) {
                resultBase.setSuccess(Boolean.FALSE);
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                log.error("--分页查询用户签约信息 ERROR--CashierHelpPayController queryUserCashierHelpPayList result==={}",
                        JSONObject.toJSONString(resultBase));
                return resultBase;
            }
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(pageDTO.getResultList());
            log.info("---分页查询用户签约信息SUCCESS--CashierHelpPayController queryUserCashierHelpPayList resultBase=={}",
                    JSON.toJSONString(resultBase));
        } catch (Exception e) {
            log.error("--分页查询用户签约信息 ERROR CashierHelpPayController queryUserCashierHelpPay exception{}", e);
            resultBase.setSuccess(Boolean.FALSE);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    /**
     * 查询用户签约总数
     * 
     * @param queryDTO
     * @return
     */
    @RequestMapping(value = "/getUserCashierHelpPayCount", method = RequestMethod.POST)
    public ResultBase<Integer> getUserCashierHelpPayCount(@RequestBody CashierHelpPayQueryDTO queryDTO) {
        log.info("CashierHelpPayController queryUserCashierHelpPay param=={}", JSON.toJSONString(queryDTO));
        ResultBase<Integer> resultBase = new ResultBase<Integer>();
        try {
            Integer count = cashierHelpPayService.getUserCashierHelpPayCount(queryDTO);
            if (count == 0) {
                resultBase.setSuccess(Boolean.FALSE);
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                resultBase.setValue(0);
            } else {
                resultBase.setSuccess(Boolean.TRUE);
                resultBase.setValue(count);
            }
            log.info("---查询用户签约总数SUCCESS--CashierHelpPayController queryUserCashierHelpPay resultBase=={}",
                    JSON.toJSONString(resultBase));
        } catch (Exception e) {
            log.error("--查询用户签约总数 ERROR CashierHelpPayController queryUserCashierHelpPay exception{}", e);
            resultBase.setSuccess(Boolean.FALSE);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }
}
