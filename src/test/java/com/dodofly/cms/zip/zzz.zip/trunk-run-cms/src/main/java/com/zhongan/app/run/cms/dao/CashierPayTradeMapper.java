package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.CashierPayTradeCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierPayTradeDO;

public interface CashierPayTradeMapper {
    /** @mbggenerated
     */
    int countByCriteria(CashierPayTradeCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(CashierPayTradeCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from bububao_cashier_pay_trade", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into bububao_cashier_pay_trade (id, cashier_id, ", "policy_no, insured_id, ",
            "deductions_pay, deductions_num, ", "deductions_date, deductions_status, ",
            "creator, gmt_created, modifier, ", "gmt_modified, is_deleted)",
            "values (#{id,jdbcType=BIGINT}, #{cashierId,jdbcType=BIGINT}, ",
            "#{policyNo,jdbcType=VARCHAR}, #{insuredId,jdbcType=VARCHAR}, ",
            "#{deductionsPay,jdbcType=DECIMAL}, #{deductionsNum,jdbcType=BIGINT}, ",
            "#{deductionsDate,jdbcType=TIMESTAMP}, #{deductionsStatus,jdbcType=BIGINT}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), #{isDeleted,jdbcType=CHAR})" })
    int insert(CashierPayTradeDO record);

    /** @mbggenerated
     */
    int insertSelective(CashierPayTradeDO record);

    /** @mbggenerated
     */
    List<CashierPayTradeDO> selectByCriteriaWithPage(@Param("criteria") CashierPayTradeCriteria criteria,
                                                     @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<CashierPayTradeDO> selectByCriteria(CashierPayTradeCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select", "id, cashier_id, policy_no, insured_id, deductions_pay, deductions_num, deductions_date, ",
            "deductions_status, creator, gmt_created, modifier, gmt_modified, is_deleted",
            "from bububao_cashier_pay_trade", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    CashierPayTradeDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") CashierPayTradeDO record,
                                  @Param("criteria") CashierPayTradeCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") CashierPayTradeDO record, @Param("criteria") CashierPayTradeCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(CashierPayTradeDO record);

    /** @mbggenerated
     */
    @Update({ "update bububao_cashier_pay_trade", "set cashier_id = #{cashierId,jdbcType=BIGINT},",
            "policy_no = #{policyNo,jdbcType=VARCHAR},", "insured_id = #{insuredId,jdbcType=VARCHAR},",
            "deductions_pay = #{deductionsPay,jdbcType=DECIMAL},",
            "deductions_num = #{deductionsNum,jdbcType=BIGINT},",
            "deductions_date = #{deductionsDate,jdbcType=TIMESTAMP},",
            "deductions_status = #{deductionsStatus,jdbcType=BIGINT},", "creator = #{creator,jdbcType=VARCHAR},",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(CashierPayTradeDO record);

    @SuppressWarnings("rawtypes")
    List<Map> queryCashierPayTradeList(PageInfo pageInfo);

    Long queryCashierPayTradeCount(PageInfo pageInfo);
}
