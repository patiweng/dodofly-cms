package com.zhongan.app.run.cms.service.qrcode.impl;

import com.google.common.collect.Lists;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoChannelListDO;
import com.zhongan.app.run.cms.bean.qrcode.dto.*;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoScanQrcodeLogDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdOrgDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdSalesDO;
import com.zhongan.app.run.cms.common.csvutil.CSVUtil;
import com.zhongan.app.run.cms.common.csvutil.conver.MapConvert;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.thread.export.SalesExportThread;
import com.zhongan.app.run.cms.common.utils.*;
import com.zhongan.app.run.cms.dao.BububaoChannelListDAO;
import com.zhongan.app.run.cms.dao.qrcode.*;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdQrcodeService;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdSalesService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BububaoThirdSalesServiceImpl implements BububaoThirdSalesService {

    @Value("${qrcode.downLoadFile}")
    private String                  downLoadFile;

    @Value("${za.run.img.domain.url}")
    private String                bububao_domain;

    @Resource
    private OssTool                   ossTool;

    @Resource
    private Sequence                  seqChannelList;

    @Resource
    private ThreadPoolTaskExecutor    threadPoolSales;

    @Resource
    private BububaoThirdOrgDao        bububaoThirdOrgDao;

    @Resource
    private BububaoExportLogDao       bububaoExportLogDao;

    @Resource
    private BububaoThirdQrcodeDao     bububaoThirdQrcodeDao;

    @Resource
    private BububaoThirdSalesDao      bububaoThirdSalesDao;

    @Resource
    private BububaoScanQrcodeLogDao bububaoScanQrcodeLogDao;

    @Resource
    private BububaoChannelListDAO     bububaoChannelListDAO;

    @Resource
    private BububaoThirdQrcodeService bububaoThirdQrcodeServiceImpl;

    @Override
    public BaseResult<String> insertBatchSaless(HttpServletRequest request, String fileName, String fileFormat) {
        String creatName = UserUtil.getUserInfo().getOperatorName();
        log.info("{}---------------BububaoThirdSalesServiceImpl.insertBatchSaless-------------start,fileName:{},fileFormat,creatName:{}",
                ThreadLocalUtil.getRequestNo(), fileName, fileFormat, creatName);
        BaseResult<String> result = new BaseResult<String>();
        // 转型为MultipartHttpRequest：
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        // 获得文件：
        MultipartFile multipartFile = multipartRequest.getFile(fileName);
        // 获得文件名：
        String filename = multipartFile.getOriginalFilename();
        String format = filename.substring(filename.lastIndexOf(".") + 1);
        if (!fileFormat.equals(format.toLowerCase())) {
            log.error("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------文件格式错误：", ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.FILE_FORMAT_ERROR.getCode());
            result.setMessage(AppErrEnum.FILE_FORMAT_ERROR.getValue());
            return result;
        }
        InputStream inputStream = null;
        List<HashMap> excelDataDtos = null;
        try {
            inputStream = multipartFile.getInputStream();
            //读取csv文件
            excelDataDtos = CSVUtil.readCSVToMap(inputStream, ',', "gbk", new MapConvert(), HashMap.class);
            StringBuffer buffer = new StringBuffer();
            buffer.append(System.currentTimeMillis()).append("_").append(filename);
            String url = ossTool.uploadFile(inputStream, buffer.toString());
            log.info("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------文件上传oss：{},name:{}", ThreadLocalUtil.getRequestNo(), url, creatName);
        }catch (Exception e){
            log.error("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------exception：", ThreadLocalUtil.getRequestNo(), e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
            return result;
        }finally {
            try {
                if(inputStream != null){
                    inputStream.close();
                }
            }catch (Exception e){
                log.error("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------exception：", ThreadLocalUtil.getRequestNo(), e);
            }
        }
        log.info("{}---------------BububaoThirdSalesServiceImpl.insertBatchSaless------------获取csv文件数据，count:{}", ThreadLocalUtil.getRequestNo(), (excelDataDtos == null ? 0 : excelDataDtos.size()));
        //循环保存业务员信息
        loopBatchSaveSaless(excelDataDtos, creatName);
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        log.info("{}---------------BububaoThirdSalesServiceImpl.insertBatchSaless-------------end",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    @Override
    public BaseResult<PageDTO<ResultSalesDto>> findSalessPage(ParamDto param) {
        log.info("{}----------------BububaoThirdSalesServiceImpl.findSalessPage-----------start,param:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<PageDTO<ResultSalesDto>> baseResult = new BaseResult<PageDTO<ResultSalesDto>>();
        //计算分页索引数
        Integer currentPage = param.getCurrentPage();
        Integer pageSize = param.getPageSize();
        if (currentPage == null || currentPage == 0) {
            currentPage = 1;
        }
        if (pageSize == null || pageSize == 0) {
            pageSize = 50;
        }
        Integer start = (currentPage - 1) * pageSize;
        Integer end = currentPage * pageSize;
        param.setStart(start);
        param.setEnd(end);
        param.setUrl(bububao_domain);
        //计算分页
        Integer totleSize = bububaoThirdSalesDao.selectSalessCount(param);
        log.info("{}----------------BububaoThirdSalesServiceImpl.findSalessPage-----------符合条件数据量：{}", ThreadLocalUtil.getRequestNo(), totleSize);
        List<ResultSalesDto> resultSalesDtos = bububaoThirdSalesDao.selectSalessPage(param);
        //组织返回值
        baseResult.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        baseResult.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        //组织分页数据
        PageDTO<ResultSalesDto> page = new PageDTO<ResultSalesDto>();
        page.setCurrentPage(currentPage);
        page.setPageSize(pageSize);
        page.setTotalItem(totleSize);
        page.setResultList(resultSalesDtos);
        baseResult.setResult(page);
        log.info("{}----------------BububaoThirdSalesServiceImpl.findSalessPage-----------end,result:{}",
                ThreadLocalUtil.getRequestNo(), baseResult);
        return baseResult;
    }

    @Override
    public BaseResult<String> deleteBatchSaless(List<ParamDto> params) {
        log.info("{}----------------BububaoThirdSalesServiceImpl.deleteBatchSaless-----------start,params:{}", ThreadLocalUtil.getRequestNo(), params);
        BaseResult<String> result = new BaseResult<String>();
        //判断删除数据是否为空
        if (CollectionUtils.isEmpty(params)) {
            log.info("{}----------------BububaoThirdSalesServiceImpl.deleteBatchSaless------删除数据为空-----end", ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.DELETE_INFO_NULL.getCode());
            result.setMessage(AppErrEnum.DELETE_INFO_NULL.getValue());
            return result;
        }
        //获取当前操作用户
        String modifiedName = UserUtil.getUserInfo().getOperatorName();
        if (StringUtils.isBlank(modifiedName)) {
            modifiedName = "SYSTEM";
        }
        int index = 1;
        //遍历删除数据,判断是否存在投保数据
        for(ParamDto param : params){
            if(isExistInsure(param.getSalesId())){
                log.info("{}----------------BububaoThirdSalesServiceImpl.deleteBatchSaless------删除数据存在投保数据-----end，salesId:{}", ThreadLocalUtil.getRequestNo(), param.getSalesId());
                result.setCode(AppErrEnum.DELETE_INFO_EXIST_INSURE.getCode());
                result.setMessage(String.format(AppErrEnum.DELETE_INFO_EXIST_INSURE.getValue(), index));
                return result;
            }
            index++;
        }
        //遍历删除数据
        for (ParamDto param : params) {
            Long qrcodeId = param.getQrcodeId();
            bububaoThirdQrcodeDao.deleteByQrcodeId(qrcodeId, modifiedName);
            bububaoThirdSalesDao.deleteBySalesId(param.getSalesId(), modifiedName);
            bububaoScanQrcodeLogDao.deleteScanLogByDataIdAndType(param.getSalesId(), 2, modifiedName);
            Long oneOrgId = param.getOneOrgId();
            Long twoOrgId = param.getTwoOrgId();
            Long threeOrgId = param.getThreeOrgId();
            Long fourOrgId = param.getFourOrgId();
            Long fiveOrgId = param.getFiveOrgId();
            List<Long> orgIds = Lists.newArrayList(fiveOrgId, fourOrgId, threeOrgId, twoOrgId, oneOrgId);
            //逐级删除机构信息
            iterationDelete(orgIds, modifiedName);
        }
        //组织返回数据，无异常则成功
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        log.info("{}----------------BububaoThirdSalesServiceImpl.deleteBatchSaless-----------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

    @Override
    public BaseResult<String> exportSaless(ParamDto param) {
        log.info("{}----------------BububaoThirdSalesServiceImpl.exportSaless-----------start,param:{}", ThreadLocalUtil.getRequestNo(), param);
        BaseResult<String> result = new BaseResult<String>();
        List<ParamDto> datas = param.getDatas();
        List<ResultSalesDto> allSaless = null;
        //如果为选择导出数据，则全部导出
        if (CollectionUtils.isEmpty(datas)) {
            log.info("{}----------------BububaoThirdSalesServiceImpl.exportSaless-----------导出全部符合条件的数据", ThreadLocalUtil.getRequestNo());
            allSaless = bububaoThirdSalesDao.selectSalessPage(param);
        } else {
            log.info("{}----------------BububaoThirdSalesServiceImpl.exportSaless-----------导出所选数据", ThreadLocalUtil.getRequestNo());
            allSaless = Lists.newArrayList();
            //遍历组织导出数据
            for (ParamDto paramDto : datas) {
                ResultSalesDto resultSalesDto = new ResultSalesDto();
                Long oneOrgId = paramDto.getOneOrgId();
                Long twoOrgId = paramDto.getTwoOrgId();
                Long threeOrgId = paramDto.getThreeOrgId();
                Long fourOrgId = paramDto.getFourOrgId();
                Long fiveOrgId = paramDto.getFiveOrgId();
                Long salesId = paramDto.getSalesId();
                Long qrcodeId = paramDto.getQrcodeId();
                if (qrcodeId == null) {
                    continue;
                }
                //组织导出数据信息-二维码链接
                resultSalesDto.setQrcodeUrl(bububaoThirdQrcodeDao.selectUrlByQrcodeId(qrcodeId));
                if (salesId == null) {
                    continue;
                }
                //组织导出数据信息-业务员编码
                resultSalesDto.setSalesCode(bububaoThirdSalesDao.selectSalesCodeById(salesId));
                if (oneOrgId == null) {
                    continue;
                }
                //组织导出数据信息-一级机构名称
                resultSalesDto.setOneOrgName(bububaoThirdOrgDao.selectNameById(oneOrgId));
                if (twoOrgId != null) {
                    //组织导出数据信息-二级机构名称
                    resultSalesDto.setTwoOrgName(bububaoThirdOrgDao.selectNameById(twoOrgId));
                    if (threeOrgId != null) {
                        //组织导出数据信息-三级机构名称
                        resultSalesDto.setThreeOrgName(bububaoThirdOrgDao.selectNameById(threeOrgId));
                        if (fourOrgId != null) {
                            //组织导出数据信息-四级机构名称
                            resultSalesDto.setFourOrgName(bububaoThirdOrgDao.selectNameById(fourOrgId));
                            if (fiveOrgId != null) {
                                //组织导出数据信息-五级机构名称
                                resultSalesDto.setFiveOrgName(bububaoThirdOrgDao.selectNameById(fiveOrgId));
                            }
                        }
                    }
                }
                allSaless.add(resultSalesDto);
            }
        }
        //获取当前操作用户
        String exportName = UserUtil.getUserInfo().getOperatorName();
        if (StringUtils.isBlank(exportName)) {
            exportName = "SYSTEM";
        }
        Date date = new Date();
        //组织导出条件信息
        StringBuffer buffer = new StringBuffer();
        if (param.getOneOrgId() != null) {
            //组织导出条件信息-一级机构名称
            buffer.append(bububaoThirdOrgDao.selectNameById(param.getOneOrgId()));
            if (param.getTwoOrgId() != null) {
                //组织导出条件信息-二级机构名称
                buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getTwoOrgId()));
                if (param.getThreeOrgId() != null) {
                    //组织导出条件信息-三级机构名称
                    buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getThreeOrgId()));
                    if (param.getFourOrgId() != null) {
                        //组织导出条件信息-四级机构名称
                        buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getFourOrgId()));
                        if (param.getFiveOrgId() != null) {
                            //组织导出条件信息-五级机构名称
                            buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getFiveOrgId()));
                        }
                    }
                }
            }
        }
        if (StringUtils.isNotBlank(param.getSalesCode())) {
            //组织导出条件信息-业务员编码
            buffer.append("_").append(param.getSalesCode());
        }
        //组织导出历史信息
        BububaoExportLogDO exportLog = new BububaoExportLogDO();
        exportLog.setModuleCode(2);
        exportLog.setCondition(buffer.toString());
        exportLog.setStatus(1);
        exportLog.setUseTime(date);
        exportLog.setIsDeleted("N");
        exportLog.setCreator(exportName);
        exportLog.setGmtCreated(date);
        exportLog.setModifier(exportName);
        exportLog.setGmtModified(date);
        bububaoExportLogDao.insertSelective(exportLog);
        //线程池开启线程，导出数据
        threadPoolSales.execute(new SalesExportThread(bububaoExportLogDao, allSaless, ossTool, exportLog, downLoadFile));
        //组织返回值
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        log.info("{}----------------BububaoThirdSalesServiceImpl.exportSaless-----------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 查询是否子机构
     * 如果有子机构则修改机构属性
     * 如果没有子机构则删除当前机构
     * 如果删除当前机构则判断父机构是否存在子机构
     * @param orgIds
     * @param modifier
     */
    private void iterationDelete(List<Long> orgIds, String modifier) {
        log.info("{}----------------BububaoThirdSalesServiceImpl.iterationDelete-----------start", ThreadLocalUtil.getRequestNo());
        //删除机构集合为空，则结束
        if (CollectionUtils.isEmpty(orgIds)) {
            return;
        }
        int size = 0;
        //遍历机构层级信息
        for (Long orgId : orgIds) {
            size++;
            if (orgId == null || orgId <= 0) {
                continue;
            }
            //查询机构下业务员，如存在，则结束
            List<BububaoThirdSalesDO> salesModels = bububaoThirdSalesDao.selectByCodeAndOrgId(null, orgId, 0L);
            if (CollectionUtils.isNotEmpty(salesModels)) {
                break;
            }
            BububaoThirdOrgDO orgDO = new BububaoThirdOrgDO();
            orgDO.setParentOrgId(orgId);
            //查询机构下机构，如存在，则结束
            List<BububaoThirdOrgDO> childOrgs = bububaoThirdOrgDao.selectByParentIdAndId(orgDO);
            if (CollectionUtils.isEmpty(childOrgs)) {
                //如果不存在，则判断是否是代理，如是代理则结束，否则删除
                BububaoThirdOrgDO orgModel = bububaoThirdOrgDao.selectByPrimaryKey(orgId);
                if (orgModel == null || "N".equals(orgModel.getIsOrgAgent())) {
                    bububaoThirdOrgDao.deleteByOrgId(orgId, modifier);
                    //迭代逐级删除机构信息
                    iterationParentDelete(orgIds.subList(size, orgIds.size()), modifier);
                }
            }
            break;
        }
        log.info("{}----------------BububaoThirdSalesServiceImpl.iterationDelete-----------end", ThreadLocalUtil.getRequestNo());
    }

    /**
     * 如果删除当前机构则判断父机构是否存在子机构
     * 如果存在机构则结束
     * 如果不存在则判断是否是代理
     * 如果是代理则结束
     * 如果不是则删除
     * ....
     * @param orgIds
     * @param modifier
     */
    private void iterationParentDelete(List<Long> orgIds, String modifier) {
        log.info("{}----------------BububaoThirdSalesServiceImpl.iterationParentDelete-----------start", ThreadLocalUtil.getRequestNo());
        //删除机构集合为空，则结束
        if (CollectionUtils.isEmpty(orgIds)) {
            return;
        }
        int size = 0;
        for (Long orgId : orgIds) {
            size++;
            //查询机构下业务员，如存在，则结束
            List<BububaoThirdSalesDO> salesModels = bububaoThirdSalesDao.selectByCodeAndOrgId(null, orgId, 0L);
            if (CollectionUtils.isNotEmpty(salesModels)) {
                break;
            }

            BububaoThirdOrgDO orgDO = new BububaoThirdOrgDO();
            orgDO.setParentOrgId(orgId);
            //查询机构下机构，如存在，则结束
            List<BububaoThirdOrgDO> childOrgs = bububaoThirdOrgDao.selectByParentIdAndId(orgDO);
            if (CollectionUtils.isEmpty(childOrgs)) {
                //如果不存在，则判断是否是代理，如是代理则结束，否则删除
                BububaoThirdOrgDO orgModel = bububaoThirdOrgDao.selectByPrimaryKey(orgId);
                if (orgModel == null || "N".equals(orgModel.getIsOrgAgent())) {
                    bububaoThirdOrgDao.deleteByOrgId(orgId, modifier);
                    if (size > orgIds.size()) {
                        break;
                    }
                    //迭代逐级删除机构信息
                    iterationParentDelete(orgIds.subList(size, orgIds.size()), modifier);
                }
            }
            break;
        }
        log.info("{}----------------BububaoThirdSalesServiceImpl.iterationParentDelete-----------end", ThreadLocalUtil.getRequestNo());
    }

    /**
     * 遍历存储机构信息
     * 
     * @param excelDataDtos
     */
    private void loopBatchSaveSaless(List<HashMap> excelDataDtos, String creatName) {
        log.info("{}--------------BububaoThirdSalesServiceImpl.loopBatchSaveSaless----------start",
                ThreadLocalUtil.getRequestNo());
        //存入数据为空，则结束
        if (CollectionUtils.isEmpty(excelDataDtos)) {
            log.info("{}--------------BububaoThirdSalesServiceImpl.loopBatchSaveSaless----------end,excelDataDtos:{}",
                    ThreadLocalUtil.getRequestNo(), excelDataDtos);
            return;
        }
        if (StringUtils.isBlank(creatName)) {
            creatName = "SYSTEM";
        }
        Date date = new Date();
        List<BububaoThirdOrgDO> list = Lists.newArrayList();
        BububaoThirdSalesDO sales = new BububaoThirdSalesDO();
        //遍历数据，存入数据库
        for (Map<String, String> data : excelDataDtos) {
            //获取是否关注步步保
            String isFollowBububao = data.get("isFollowBububao");
            if (StringUtils.isBlank(isFollowBububao)) {
                isFollowBububao = "N";
            }
            //获取是否组长
            String isLeader = data.get("isLeader");
            if (StringUtils.isBlank(isLeader)) {
                isLeader = "N";
            }
            //获取一级机构名称
            String parentOrgName = data.get("org_1");
            if (StringUtils.isBlank(parentOrgName)) {
                continue;
            }
            //获取二级机构名称
            String childOrgName = data.get("org_2");
            if (CollectionUtils.isEmpty(list)) {
                list.add(new BububaoThirdOrgDO());
            }
            //组织业务员信息
            sales.setId(null);
            sales.setSalesCode(data.get("salseCode"));
            sales.setIsLeader(isLeader);
            sales.setParentSalesId(0L);
            sales.setIsSalesAgent("Y");
            sales.setIsFollowBububao(isFollowBububao);
            sales.setIsDeleted("N");
            sales.setCreator(creatName);
            sales.setGmtCreated(date);
            sales.setModifier(creatName);
            sales.setGmtModified(date);
            //保存一级机构信息
            BububaoThirdOrgDO org1 = saveOrFindSales(list.get(0), creatName, parentOrgName, childOrgName,
                    sales, 0L, 1, null, "Wechat_" + PinyinUtil.getInitials(parentOrgName), date);
            list.remove(0);
            list.add(0, org1);
            int i = 2;
            //逐级保存机构信息
            while (true) {
                if (list.size() < i) {
                    list.add(new BububaoThirdOrgDO());
                }
                //获取父级机构名称
                parentOrgName = data.get("org_" + i);
                if (StringUtils.isBlank(parentOrgName)) {
                    break;
                }
                //获取子集机构名称
                childOrgName = data.get("org_" + (i + 1));
                //保存父级机构信息
                BububaoThirdOrgDO org = saveOrFindSales(list.get(i - 1), creatName, parentOrgName,
                        childOrgName, sales, list.get(i - 2).getId(), i, list.get(i - 2).getChannelId(),
                        list.get(i - 2).getOrgCode(), date);
                list.remove(i - 1);
                list.add(i - 1, org);
                i++;
            }
        }
        log.info("{}--------------BububaoThirdSalesServiceImpl.loopBatchSaveSaless----------end",
                ThreadLocalUtil.getRequestNo());
    }

    /**
     * 保存或则查询业务员信息
     * @param org
     * @param creatName
     * @param parentOrgName
     * @param childOrgName
     * @param sales
     * @param parentId
     * @param orgLevel
     * @param channelId
     * @param orgCode
     * @param date
     * @return
     */
    private BububaoThirdOrgDO saveOrFindSales(BububaoThirdOrgDO org, String creatName, String parentOrgName,
                                                 String childOrgName, BububaoThirdSalesDO sales, Long parentId,
                                                 Integer orgLevel, Long channelId, String orgCode, Date date) {
        log.info("{}--------------BububaoThirdSalesServiceImpl.saveOrFindSales----------start",
                ThreadLocalUtil.getRequestNo());
        //机构名称如相同，则判断业务员信息
        if (!parentOrgName.equals(org.getOrgName())) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("orgName", parentOrgName);
            map.put("orgLevel", orgLevel);
            map.put("parentOrgId", parentId);
            //查询该机构信息是否存在
            List<BububaoThirdOrgDO> orgModels = bububaoThirdOrgDao.selectByInfo(map);
            if (CollectionUtils.isEmpty(orgModels)) {
                //获取该机构code数
                int count = bububaoThirdOrgDao.selectByCode(orgCode, parentId) + 1;
                org.setOrgCode(orgCode + "_" + count);
                if (channelId == null) {
                    //获取渠道id
                    channelId = getChannelId(parentOrgName, org.getOrgCode(), creatName, date);
                }
                //组织机构信息
                org.setChannelId(channelId);
                org.setCreator(creatName);
                org.setGmtCreated(date);
                org.setGmtModified(date);
                org.setIsDeleted("N");
                org.setModifier(creatName);
                org.setOrgLevel(orgLevel);
                org.setParentOrgId(parentId);
                org.setOrgName(parentOrgName);
                org.setId(null);
                bububaoThirdOrgDao.insertSelective(org);
            } else {
                //获取机构信息
                org = orgModels.get(0);
            }

        }
        //判断子集机构名称
        if (StringUtils.isBlank(childOrgName)) {
            //查询业务员信息
            List<BububaoThirdSalesDO> salesModels = bububaoThirdSalesDao.selectByCodeAndOrgId(sales.getSalesCode(),
                    org.getId(), 0L);
            //如果为空，则保存
            if (CollectionUtils.isEmpty(salesModels)) {
                sales.setOrgId(org.getId());
                bububaoThirdSalesDao.insertSelective(sales);
                //生成二维码
                bububaoThirdQrcodeServiceImpl.makeAndInsertQrcode(org.getOrgCode(), sales.getId(),
                        sales.getIsFollowBububao(), 2, creatName);
            }
        }
        log.info("{}--------------BububaoThirdSalesServiceImpl.saveOrFindSales----------end",
                ThreadLocalUtil.getRequestNo());
        return org;
    }

    /**
     * 保存或获取渠道信息并返回渠道id
     * 
     * @param name
     * @param code
     * @param creatName
     * @param date
     * @return
     */
    private Long getChannelId(String name, String code, String creatName, Date date) {
        log.info("{}--------------BububaoThirdSalesServiceImpl.getChannelId----------start",
                ThreadLocalUtil.getRequestNo());
        //渠道名称或者渠道code为空则返回
        if (StringUtils.isBlank(name) || StringUtils.isBlank(code))
            return null;
        String nullStr = "待完善";
        BububaoChannelListDO channel = new BububaoChannelListDO();
        channel.setNo(code);
        channel.setType("1");
        //获取渠道信息
        List<BububaoChannelListDO> resultlist = bububaoChannelListDAO.selectDataByCdt(channel);
        if (CollectionUtils.isNotEmpty(resultlist)) {
            return new Long(resultlist.get(0).getId());
        }
        //组织渠道信息
        Long channelId = null;
        channel.setName(name);
        channel.setCreater(creatName);
        channel.setCreateTime(DateTimeUtils.convertDate2String(date, DateTimeUtils.ZH_CN_DATETIME_PATTERN));
        channel.setTitle("步步保");
        channel.setOwnPlatForm("0");
        channel.setStatus("0");
        channel.setDeleteTime(DateTimeUtils.convertDate2String(date, DateTimeUtils.ZH_CN_DATETIME_PATTERN));
        channel.setPay("wxpay^alipay");
        channel.setUrl(nullStr);
        channel.setMomentsTitle(nullStr);
        channel.setMomentsUrl(nullStr);
        channel.setFriendTitle(nullStr);
        channel.setFriendUrl(nullStr);
        channel.setFriendDescribe(nullStr);
        while (channelId == null) {
            try {
                channelId = seqChannelList.nextValue();
            } catch (Exception e) {
                log.error("exception:{}", e);
            }
        }
        channel.setId(channelId.toString());
        bububaoChannelListDAO.insert(channel);
        log.info("{}--------------BububaoThirdSalesServiceImpl.getChannelId----------end",
                ThreadLocalUtil.getRequestNo());
        return channelId;
    }

    /**
     * 判断是否存在投保信息
     * @param salesId
     * @return
     */
    private boolean isExistInsure(Long salesId){
        log.info("{}--------------BububaoThirdSalesServiceImpl.isExistInsure----------start,salesId:{}", ThreadLocalUtil.getRequestNo(), salesId);
        if(salesId == null || salesId == 0){
            log.info("{}--------------BububaoThirdSalesServiceImpl.isExistInsure-----业务员id为空-----end", ThreadLocalUtil.getRequestNo());
            return false;
        }
        BububaoScanQrcodeLogDO scanQrcodeLogDO = new BububaoScanQrcodeLogDO();
        scanQrcodeLogDO.setScanDataId(salesId);
        scanQrcodeLogDO.setScanDataType((short)2);
        scanQrcodeLogDO.setScanLogType((short)2);
        List<BububaoScanQrcodeLogDO> scanQrcodeLogDOS = bububaoScanQrcodeLogDao
                .selectDataByCdt(scanQrcodeLogDO);
        if(CollectionUtils.isEmpty(scanQrcodeLogDOS)){
            log.info("{}--------------BububaoThirdSalesServiceImpl.isExistInsure-----业务员不存在投保-----end", ThreadLocalUtil.getRequestNo());
            return false;
        }else{
            log.info("{}--------------BububaoThirdSalesServiceImpl.isExistInsure-----业务员存在投保-----end", ThreadLocalUtil.getRequestNo());
            return true;
        }

    }
}
