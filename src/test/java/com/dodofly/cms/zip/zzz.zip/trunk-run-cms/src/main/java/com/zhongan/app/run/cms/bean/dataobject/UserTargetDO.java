package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class UserTargetDO {
    /**ID**/
    private String id;
    /**对应渠道的sourceid**/
    private String userId;
    /**真正的用户ID**/
    private String unionId;
    /**每日目标步数**/
    private String targetSteps;
    /**保额**/
    private String targetCoverage;
    /**开始日期**/
    private String startDate;
    /**结束日期**/
    private String endDate;
    /**创建时间**/
    private String createTime;
    /**修改时间**/
    private String modifyTime;
    /**是否已经使用过降级, 0:否,1:是**/
    private String demote;
    /**免费天数**/
    private String freeDay;
}
