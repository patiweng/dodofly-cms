package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.bo.RafflePresentBO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoPresentDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.ActivityPresentRepo;
import com.zhongan.app.run.cms.bean.repo.RafflePresentRepo;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.PresentListPageDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.dao.BububaoPresentDAO;
import com.zhongan.app.run.cms.repository.ActivityPresentRepository;
import com.zhongan.app.run.cms.repository.RafflePresentRepository;
import com.zhongan.app.run.cms.service.RafflePresentService;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RafflePresentServiceImpl implements RafflePresentService {

    @Resource
    private RafflePresentRepository   rafflePresentRepository;
    @Resource
    private ActivityPresentRepository activityPresentRepository;
    @Resource
    private BububaoPresentDAO         bububaoPresentDAO;
    @Resource
    private RedisUtil                 redisUtil;

    @Override
    public ResultBase<List<RafflePresentDTO>> selectPresentData(RafflePresentBO rafflePresentBO) {
        ResultBase<List<RafflePresentDTO>> result = new ResultBase<List<RafflePresentDTO>>();
        log.info("{}-rafflepresent select begin...");
        try {
            RafflePresentRepo rafflePresentRepo = new RafflePresentRepo();
            BeanUtils.copyProperties(rafflePresentBO, rafflePresentRepo);
            result = rafflePresentRepository.selectPresentList(rafflePresentRepo);
            if (result.getValue().size() > 0) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-raffleActivity select fail,please find error to..."
                    + "error location polynomial : RafflePresentServiceImpl--selectPresentData()" + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...");
        }
        return result;
    }

    //根据主键添加一条记录
    @Override
    public ResultBase<String> insertPresentData(RafflePresentBO rafflePresentBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RafflePresentRepo rafflePresentRepo = new RafflePresentRepo();
            BeanUtils.copyProperties(rafflePresentBO, rafflePresentRepo);
            result = rafflePresentRepository.savePresent(rafflePresentRepo);
            if (result.isSuccess()) {
                //缓存对象key：Id   value：dto
                BububaoPresentDO bububaoPresentDO = bububaoPresentDAO.selectOneDataById(result.getValue());
                redisUtil.put("bububao_present:" + result.getValue(), JSONObject.toJSONString(bububaoPresentDO));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save--Present...."
                    + "error location polynomial : RafflePresentServiceImpl--insertPresentData()" + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    // 根据主键修改一条记录
    @Override
    public ResultBase<String> updatePresentData(RafflePresentBO rafflePresentBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RafflePresentRepo rafflePresentRepo = new RafflePresentRepo();
            BeanUtils.copyProperties(rafflePresentBO, rafflePresentRepo);
            result = rafflePresentRepository.updatePresent(rafflePresentRepo);
            if (result.isSuccess()) {
                //缓存对象key：Id   value：dto
                BububaoPresentDO bububaoPresentDO = bububaoPresentDAO.selectOneDataById(rafflePresentRepo.getId());
                redisUtil
                        .put("bububao_present:" + rafflePresentRepo.getId(), JSONObject.toJSONString(bububaoPresentDO));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save--Present...."
                    + "error location polynomial : RafflePresentServiceImpl--updatePresentData()" + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    //根据主键查询信息  前端接口
    @Override
    public ResultBase<RafflePresentDTO> selectPresentDataByid(String id) {
        ResultBase<RafflePresentDTO> result = new ResultBase<RafflePresentDTO>();
        log.info("{}-rafflePresent selectone begin...");
        try {
            RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(id);
            if (rafflePresentDTO != null) {
                result.setSuccess(true);
                result.setValue(rafflePresentDTO);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-rafflePresent selectone fail,please find error to..."
                    + "error location polynomial : RafflePresentServiceImpl--selectPresentDataByid()" + "exception："
                    + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...");
        }
        return result;
    }

    //分页查询信息
    @Override
    public PresentListPageDTO selectPresentListPage(Page<RafflePresentDTO> rafflePresentListPage) {
        PresentListPageDTO presentListPageDTO = new PresentListPageDTO();
        Page<RafflePresentRepo> rafflePresentRepoPage = new Page<RafflePresentRepo>();
        BeanUtils.copyProperties(rafflePresentListPage, rafflePresentRepoPage);
        rafflePresentRepoPage = rafflePresentRepository.selectPresentListPage(rafflePresentRepoPage);
        List<RafflePresentRepo> rafflePresentRepolist = rafflePresentRepoPage.getResultList();
        List<RafflePresentDTO> rafflePresentDTOList = Lists.newArrayList();
        if (rafflePresentRepolist != null && rafflePresentRepolist.size() > 0) {
            RafflePresentDTO rafflePresentDTO = null;
            for (RafflePresentRepo rafflePresentRepos : rafflePresentRepolist) {
                rafflePresentDTO = new RafflePresentDTO();
                BeanUtils.copyProperties(rafflePresentRepos, rafflePresentDTO);
                if (StringUtils.equals(rafflePresentDTO.getPrice(), "0")) {
                    rafflePresentDTO.setPrice("");
                }
                rafflePresentDTOList.add(rafflePresentDTO);
            }
        }
        rafflePresentListPage.setResultList(rafflePresentDTOList);
        rafflePresentListPage.setTotalItem(rafflePresentRepoPage.getTotalItem());
        presentListPageDTO.setRafflePresentDTODTOPage(rafflePresentListPage);
        return presentListPageDTO;
    }

    //根据主键查询单条记录 后台
    @Override
    public RafflePresentDTO selectDataByid(String id) {
        log.info("{}-rafflePresent selectone begin...");
        RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(id);
        return rafflePresentDTO;
    }

    //删除
    @Override
    public ResultBase<String> deletePresent(String id) {
        log.info("{}-delete present info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            result = rafflePresentRepository.deleteByid(id);
            //删除缓存
            if (result.isSuccess()) {
                redisUtil.delete("bububao_present:" + id);
            }
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-ChannelList delete fail,please find error to...。"
                    + "error location polynomial:RafflePresentServiceImpl--deletePresent()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<List<RafflePresentDTO>> selectPresentByActivityId(ActivityPresentDTO activityPresentDTO) {
        log.info("{}--RafflePresentServiceImpl.selectPresentByActivityId……start,param==={}",
                ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(activityPresentDTO));
        ResultBase<List<RafflePresentDTO>> resultBase = new ResultBase<List<RafflePresentDTO>>();
        List<RafflePresentDTO> dtoList = Lists.newArrayList();
        try {
            //1.根据活动id（activityId）查询bububao_activity_present（优惠活动礼物表）
            ActivityPresentRepo activityPresentRepo = new ActivityPresentRepo();
            BeanUtils.copyProperties(activityPresentDTO, activityPresentRepo);
            List<ActivityPresentRepo> activityPresentRepoList = activityPresentRepository
                    .selectDataByCdt(activityPresentRepo);
            log.info("活动id==={},查询优惠活动礼物表结果==={}", activityPresentDTO.getActivityId(),
                    JSONObject.toJSONString(activityPresentRepoList));
            //2.根据1的查询结果得到礼物表的id，用这些id查询礼物表。得到所有礼物
            if (null != activityPresentRepoList && activityPresentRepoList.size() > 0) {
                for (ActivityPresentRepo activityPresentRepo2 : activityPresentRepoList) {
                    RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(activityPresentRepo2
                            .getPresentId());
                    dtoList.add(rafflePresentDTO);
                }
            }
            resultBase.setSuccess(true);
            resultBase.setValue(dtoList);
        } catch (Exception e) {
            log.error("{}--RafflePresentServiceImpl.selectPresentByActivityId……fail==={}",
                    ThreadLocalUtil.getRequestNo(), e);
            resultBase.setErrorCode(AppErrEnum.ERROR_SYS_0001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_SYS_0001.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

}
