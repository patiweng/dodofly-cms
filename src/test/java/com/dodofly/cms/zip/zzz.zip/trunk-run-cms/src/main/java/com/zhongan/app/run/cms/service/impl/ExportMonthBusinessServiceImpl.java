package com.zhongan.app.run.cms.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.ibm.icu.util.Calendar;
import com.zhongan.app.run.cms.bean.dataobject.MonthBusinessDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.MonthBusinessRepo;
import com.zhongan.app.run.cms.bean.web.MonthBusinessDTO;
import com.zhongan.app.run.cms.bean.web.MonthBusinessPageDTO;
import com.zhongan.app.run.cms.common.utils.ReadExcel;
import com.zhongan.app.run.cms.repository.ExportMonthBusinessRepository;
import com.zhongan.app.run.cms.service.ExportMonthBusinessService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class ExportMonthBusinessServiceImpl implements ExportMonthBusinessService {

    @Resource
    private ExportMonthBusinessRepository exportMonthBusinessRepository;

    @Override
    public MonthBusinessPageDTO selectMonthBusinessList(Page<MonthBusinessDTO> monthBusinessPage) {
        // TODO Auto-generated method stub
        MonthBusinessPageDTO monthBusinessPageDTO = new MonthBusinessPageDTO();
        Page<MonthBusinessRepo> monthBusinessRepoPage = new Page<MonthBusinessRepo>();
        BeanUtils.copyProperties(monthBusinessPage, monthBusinessRepoPage);

        monthBusinessRepoPage = exportMonthBusinessRepository.selectMonthBusinessPage(monthBusinessPage);
        List<MonthBusinessRepo> monthBusinessRepoList = monthBusinessRepoPage.getResultList();
        List<MonthBusinessDTO> monthBusinessDTOList = Lists.newArrayList();

        if (null != monthBusinessRepoList && monthBusinessRepoList.size() > 0) {
            MonthBusinessDTO monthBusinessDTO = new MonthBusinessDTO();
            for (MonthBusinessRepo monthBusinessRepo : monthBusinessRepoList) {
                MonthBusinessDTO clone = (MonthBusinessDTO) monthBusinessDTO.clone();
                BeanUtils.copyProperties(monthBusinessRepo, clone);
                monthBusinessDTOList.add(clone);
            }

        }
        monthBusinessPage.setResultList(monthBusinessDTOList);
        monthBusinessPage.setTotalItem(monthBusinessRepoPage.getTotalItem());
        monthBusinessPageDTO.setMonthBusinessPageDTO(monthBusinessPage);
        return monthBusinessPageDTO;
    }

    @Override
    public void doExportExcelMonthBusiness(HttpServletResponse response) {
        log.info("{}-doExportExcelMonthBusiness start……", ThreadLocalUtil.getRequestNo());
        try {
            Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);//当前日期年份
            Map<String, String> map = new HashMap<String, String>();
            map.put("curr_year", String.valueOf(year));
            List<MonthBusinessDO> resultlist = exportMonthBusinessRepository.queryMonthListForExcel(map);
            if (resultlist == null || resultlist.size() == 0) {
                log.info("没有需要导出的数据！");
                return;
            }
            String path = this.getClass().getResource("/static/excel/monthBusinessReg.xlsx").getPath();
            InputStream is = this.getClass().getResourceAsStream("/static/excel/monthBusinessReg.xlsx");
            log.info("excel模版的路径为=================" + path);
            Workbook workbook = new XSSFWorkbook(is);
            if (workbook == null) {
                log.info("workbook对象为null");
            }
            Sheet sheet = workbook.getSheetAt(0);//获取页签
            if (null != resultlist && resultlist.size() > 0) {
                Long new_add_user = 0L;
                Long xubao_add_user = 0L;
                Long user_premium = 0L;
                for (int i = 0; i < resultlist.size(); i++) {
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    MonthBusinessDO monthBusiness = resultlist.get(i);
                    Row rowx = sheet.getRow(3 + i);
                    rowx.getCell(0).setCellValue(monthBusiness.getUser_month());
                    rowx.getCell(1).setCellValue(monthBusiness.getNew_add_user());
                    rowx.getCell(2).setCellValue(monthBusiness.getXubao_add_user());
                    rowx.getCell(3).setCellValue(monthBusiness.getUser_premium());
                    new_add_user = new_add_user + monthBusiness.getNew_add_user();
                    xubao_add_user = xubao_add_user + monthBusiness.getXubao_add_user();
                    user_premium = user_premium + Long.parseLong(monthBusiness.getUser_premium());
                }

                ReadExcel.copyRows(sheet, 4, 4, 3 + resultlist.size());
                Row rowlast = sheet.getRow(3 + resultlist.size());
                rowlast.getCell(0).setCellValue(year + "年");
                rowlast.getCell(1).setCellValue(new_add_user);
                rowlast.getCell(2).setCellValue(xubao_add_user);
                rowlast.getCell(3).setCellValue(user_premium);
            }
            String title = "月汇总";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {
            log.error("{}-doExportExcelMonthBusiness fail……", e, ThreadLocalUtil.getRequestNo());
        }

    }

}
