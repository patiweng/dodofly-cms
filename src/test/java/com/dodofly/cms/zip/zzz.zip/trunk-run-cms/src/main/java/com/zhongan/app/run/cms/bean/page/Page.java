package com.zhongan.app.run.cms.bean.page;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 类BaseQuery.java的实现描述：TODO 类实现描述
 * 
 * @author yuhao 2016年2月23日 下午4:47:58
 */
public class Page<T> implements Serializable {
    private static final long    serialVersionUID   = -8097236917728235854L;
    private static final Integer DEFAULT_PAGE_SIZE  = new Integer(20);
    private static final Integer DEFAULT_FIRST_SIZE = new Integer(1);
    private static final Integer DEFAULT_TOTAL_SIZE = new Integer(0);
    private T                    param;
    private Integer              totalItem;
    private Integer              pageSize;
    private Integer              currentPage;
    private Integer              startRow;
    private Integer              totalPage;
    private List<T>              resultList         = new ArrayList<T>();

    /**
     * return数据时不要使用本方法
     */
    public Page() {
        //无参构造
    }

    /**
     * pageSize和currentPage初始化
     * 
     * @param pageSize
     * @param currentPage
     */
    public Page(Integer pageSize, Integer currentPage) {
        this.setPageSize(pageSize);
        this.setCurrentPage(currentPage);
    }

    public T getParam() {
        return param;
    }

    public void setParam(T param) {
        this.param = param;
    }

    public List<T> getResultList() {
        return resultList;
    }

    public void setResultList(List<T> resultList) {
        this.resultList = resultList;
    }

    public Integer getTotalItem() {
        if (totalItem == null) {
            return DEFAULT_TOTAL_SIZE;
        }
        return totalItem;
    }

    public void setTotalItem(Integer totalItem) {
        this.totalItem = totalItem;
    }

    public Integer getPageSize() {
        if (pageSize == null) {
            return DEFAULT_PAGE_SIZE;
        }
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getCurrentPage() {
        if (currentPage == null) {
            return DEFAULT_FIRST_SIZE;
        }
        return currentPage;
    }

    public void setCurrentPage(Integer currentPage) {
        if ((currentPage == null) || (currentPage.intValue() <= 0)) {
            this.currentPage = null;
        } else {
            this.currentPage = currentPage;
        }
        setStartRow();
    }

    private void setStartRow() {
        this.startRow = this.getPageSize().intValue() * (this.getCurrentPage().intValue() - 1);
    }

    public int getStartRow() {
        return startRow;
    }

    public void setStartRow(int startRow) {
        this.startRow = startRow;
    }

    public static Integer getDefaultpagesize() {
        return DEFAULT_PAGE_SIZE;
    }

    public static Integer getDefaultfristpage() {
        return DEFAULT_FIRST_SIZE;
    }

    public static Integer getDefaulttotleitem() {
        return DEFAULT_TOTAL_SIZE;
    }

    public void setTotalPage(Integer totalPage) {
        this.totalPage = totalPage;
    }

    public int getTotalPage() {
        int pgSize = this.getPageSize().intValue();
        int total = this.getTotalItem().intValue();
        int result = total / pgSize;

        if ((total == 0) || ((total % pgSize) != 0)) {
            result++;
        }

        return result;
    }

    @Override
    public String toString() {
        return "PageDTO [param=" + param + ", totalItem=" + totalItem + ", pageSize=" + pageSize + ", currentPage="
                + currentPage + ", startRow=" + startRow + ", totalPage=" + totalPage + ", resultList=" + resultList
                + "]";
    }

}
