package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;

import lombok.Data;

@Data
public class RunSysMenuDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//主键
	private String id;
	//菜单名称
	private String menuName;
	//是否为根菜单
	private String isRoot;
	//父菜单
	private String parentId;
	//菜单URL
	private String menuUrl;
	//菜单样式
	private String menuClass;
	//创建者
	private String creator;
	//修改者
	private String modifier;
	//创建时间
	private String gmtCreated;
	//更新时间
	private String gmtModified;
	//是否删除
	private String isDeleted;
}
