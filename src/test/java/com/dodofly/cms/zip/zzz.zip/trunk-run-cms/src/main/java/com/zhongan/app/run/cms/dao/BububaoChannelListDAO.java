package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoChannelListDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoMarketingActivitiesDO;

@Component
public interface BububaoChannelListDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoChannelListDO> selectDataByCdt(BububaoChannelListDO bububaoChannelListDO);
	   /**
	    * 无条件查询所有
	    * @return
	    */
	   List<BububaoChannelListDO> selectDataAll();
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoChannelListDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoChannelListDO
	    */
	   void insert(BububaoChannelListDO bububaoChannelListDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoChannelListDO
	    */
	   void update(BububaoChannelListDO bububaoChannelListDO);
	   
	   /**
	     * 分页查询BububaoChannelListDO信息
	     * 
	     * @param map
	     * @return
	     */
	    List<BububaoChannelListDO> selectBububaoChannelList(Map map);
	    
	    /**
	     * 查询BububaoChannelListDO条数
	     * 
	     * @param map
	     * @return
	     */
	    Integer selectCounts(Map map);
	    /**
	     * 删除BububaoChannelListDO
	     * 
	     * @param  id
	     * @return
	     */
	    void deleteChannelListById(String id);
	    /**
	     * 更新数据为无效数据
	     * @param id
	     */
	    void updateByid(String id);
}
