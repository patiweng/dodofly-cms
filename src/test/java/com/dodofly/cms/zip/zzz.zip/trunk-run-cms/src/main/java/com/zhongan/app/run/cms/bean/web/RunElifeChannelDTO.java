package com.zhongan.app.run.cms.bean.web;

public class RunElifeChannelDTO {

    private Long   id;

    /**
     * 渠道大类：ZJ、HZ、ZY
     */
    private String channelType;

    /**
     * 渠道大类名称：中介业务、合作平台、直营
     */
    private String channelTypeName;

    /**
     * 渠道ID
     */
    private Long   channelId;

    /**
     * 渠道code
     */
    private String channelCode;

    /**
     * 渠道名称
     */
    private String channelName;

    /**
     * 联系人名称
     */
    private String channelContactName;

    /**
     * 联系人电话
     */
    private String channelContactPhone;

    /**
     * 状态
     */
    private String status;

    /**
     * 业务规则
     */
    private String bizRule;

    /**
     * 业务值
     */
    private String bizValue;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getChannelType() {
        return channelType;
    }

    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    public String getChannelTypeName() {
        return channelTypeName;
    }

    public void setChannelTypeName(String channelTypeName) {
        this.channelTypeName = channelTypeName;
    }

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    public String getChannelCode() {
        return channelCode;
    }

    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getChannelContactName() {
        return channelContactName;
    }

    public void setChannelContactName(String channelContactName) {
        this.channelContactName = channelContactName;
    }

    public String getChannelContactPhone() {
        return channelContactPhone;
    }

    public void setChannelContactPhone(String channelContactPhone) {
        this.channelContactPhone = channelContactPhone;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getBizRule() {
        return bizRule;
    }

    public void setBizRule(String bizRule) {
        this.bizRule = bizRule;
    }

    public String getBizValue() {
        return bizValue;
    }

    public void setBizValue(String bizValue) {
        this.bizValue = bizValue;
    }
}
