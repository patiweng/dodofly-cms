package com.zhongan.app.run.cms.bean.client;
public class ChannelListClient {

}
