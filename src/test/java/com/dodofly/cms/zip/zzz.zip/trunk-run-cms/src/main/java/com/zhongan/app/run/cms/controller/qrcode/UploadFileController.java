package com.zhongan.app.run.cms.controller.qrcode;

import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.service.qrcode.OssService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.InputStream;

@RestController
@RequestMapping("/run/cms/qrcode/file/upload")
@Slf4j
public class UploadFileController {

    @Resource
    private OssService ossServiceImpl;

    @RequestMapping(value = "/csv")
    public BaseResult<String> uploadCSV(HttpServletRequest request, HttpServletResponse response) {
        BaseResult<String> result = null;
        log.info("{}-------------UploadFileController.uploadCSV----------------start", ThreadLocalUtil.getRequestNo());
        try {
            result = ossServiceImpl.uploadFile(request, "files", "csv");
        } catch (Exception e) {
            log.error("{}-------------UploadFileController.uploadCSV----------------exception：",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}-------------UploadFileController.uploadCSV----------------end", ThreadLocalUtil.getRequestNo());
        return result;
    }
}
