package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class RunElifeChannelDO {
    /**
     * This field corresponds to the column run_elife_channel.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 渠道大类：ZJ、HZ、ZY This field corresponds to the column
     * run_elife_channel.channel_type
     *
     * @mbggenerated
     */
    private String channelType;

    /**
     * 渠道大类名称：中介业务、合作平台、直营 This field corresponds to the column
     * run_elife_channel.channel_type_name
     *
     * @mbggenerated
     */
    private String channelTypeName;

    /**
     * 渠道ID This field corresponds to the column run_elife_channel.channel_id
     *
     * @mbggenerated
     */
    private Long   channelId;

    /**
     * 渠道code This field corresponds to the column
     * run_elife_channel.channel_code
     *
     * @mbggenerated
     */
    private String channelCode;

    /**
     * 渠道名称 This field corresponds to the column run_elife_channel.channel_name
     *
     * @mbggenerated
     */
    private String channelName;

    /**
     * 联系人名称 This field corresponds to the column
     * run_elife_channel.channel_contact_name
     *
     * @mbggenerated
     */
    private String channelContactName;

    /**
     * 联系人电话 This field corresponds to the column
     * run_elife_channel.channel_contact__phone
     *
     * @mbggenerated
     */
    private String channelContactPhone;

    /**
     * 状态 This field corresponds to the column run_elife_channel.status
     *
     * @mbggenerated
     */
    private String status;

    /**
     * 扩展信息,json格式 This field corresponds to the column
     * run_elife_channel.extra_info
     *
     * @mbggenerated
     */
    private String extraInfo;

    /**
     * 创建人 This field corresponds to the column run_elife_channel.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 创建时间 This field corresponds to the column run_elife_channel.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改人 This field corresponds to the column run_elife_channel.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 修改时间 This field corresponds to the column run_elife_channel.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * This field corresponds to the column run_elife_channel.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /**
     * @mbggenerated
     */
    public RunElifeChannelDO(Long id, String channelType, String channelTypeName, Long channelId, String channelCode,
                             String channelName, String channelContactName, String channelContactPhone, String status,
                             String extraInfo, String creator, Date gmtCreated, String modifier, Date gmtModified,
                             String isDeleted) {
        this.id = id;
        this.channelType = channelType;
        this.channelTypeName = channelTypeName;
        this.channelId = channelId;
        this.channelCode = channelCode;
        this.channelName = channelName;
        this.channelContactName = channelContactName;
        this.channelContactPhone = channelContactPhone;
        this.status = status;
        this.extraInfo = extraInfo;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /**
     * @mbggenerated
     */
    public RunElifeChannelDO() {
        super();
    }

    /**
     * This method returns the value of the database column run_elife_channel.id
     *
     * @return the value of run_elife_channel.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column run_elife_channel.id
     *
     * @param id the value for run_elife_channel.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_type
     *
     * @return the value of run_elife_channel.channel_type
     * @mbggenerated
     */
    public String getChannelType() {
        return channelType;
    }

    /**
     * Sets the value of the database column run_elife_channel.channel_type
     *
     * @param channelType the value for run_elife_channel.channel_type
     * @mbggenerated
     */
    public void setChannelType(String channelType) {
        this.channelType = channelType;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_type_name
     *
     * @return the value of run_elife_channel.channel_type_name
     * @mbggenerated
     */
    public String getChannelTypeName() {
        return channelTypeName;
    }

    /**
     * Sets the value of the database column run_elife_channel.channel_type_name
     *
     * @param channelTypeName the value for run_elife_channel.channel_type_name
     * @mbggenerated
     */
    public void setChannelTypeName(String channelTypeName) {
        this.channelTypeName = channelTypeName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_id
     *
     * @return the value of run_elife_channel.channel_id
     * @mbggenerated
     */
    public Long getChannelId() {
        return channelId;
    }

    /**
     * Sets the value of the database column run_elife_channel.channel_id
     *
     * @param channelId the value for run_elife_channel.channel_id
     * @mbggenerated
     */
    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_code
     *
     * @return the value of run_elife_channel.channel_code
     * @mbggenerated
     */
    public String getChannelCode() {
        return channelCode;
    }

    /**
     * Sets the value of the database column run_elife_channel.channel_code
     *
     * @param channelCode the value for run_elife_channel.channel_code
     * @mbggenerated
     */
    public void setChannelCode(String channelCode) {
        this.channelCode = channelCode;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_name
     *
     * @return the value of run_elife_channel.channel_name
     * @mbggenerated
     */
    public String getChannelName() {
        return channelName;
    }

    /**
     * Sets the value of the database column run_elife_channel.channel_name
     *
     * @param channelName the value for run_elife_channel.channel_name
     * @mbggenerated
     */
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_contact_name
     *
     * @return the value of run_elife_channel.channel_contact_name
     * @mbggenerated
     */
    public String getChannelContactName() {
        return channelContactName;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel.channel_contact_name
     *
     * @param channelContactName the value for
     *            run_elife_channel.channel_contact_name
     * @mbggenerated
     */
    public void setChannelContactName(String channelContactName) {
        this.channelContactName = channelContactName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.channel_contact__phone
     *
     * @return the value of run_elife_channel.channel_contact__phone
     * @mbggenerated
     */
    public String getChannelContactPhone() {
        return channelContactPhone;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel.channel_contact__phone
     *
     * @param channelContactPhone the value for
     *            run_elife_channel.channel_contact__phone
     * @mbggenerated
     */
    public void setChannelContactPhone(String channelContactPhone) {
        this.channelContactPhone = channelContactPhone;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.status
     *
     * @return the value of run_elife_channel.status
     * @mbggenerated
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the database column run_elife_channel.status
     *
     * @param status the value for run_elife_channel.status
     * @mbggenerated
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.extra_info
     *
     * @return the value of run_elife_channel.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column run_elife_channel.extra_info
     *
     * @param extraInfo the value for run_elife_channel.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.creator
     *
     * @return the value of run_elife_channel.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column run_elife_channel.creator
     *
     * @param creator the value for run_elife_channel.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.gmt_created
     *
     * @return the value of run_elife_channel.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column run_elife_channel.gmt_created
     *
     * @param gmtCreated the value for run_elife_channel.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.modifier
     *
     * @return the value of run_elife_channel.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column run_elife_channel.modifier
     *
     * @param modifier the value for run_elife_channel.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.gmt_modified
     *
     * @return the value of run_elife_channel.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column run_elife_channel.gmt_modified
     *
     * @param gmtModified the value for run_elife_channel.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel.is_deleted
     *
     * @return the value of run_elife_channel.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column run_elife_channel.is_deleted
     *
     * @param isDeleted the value for run_elife_channel.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
