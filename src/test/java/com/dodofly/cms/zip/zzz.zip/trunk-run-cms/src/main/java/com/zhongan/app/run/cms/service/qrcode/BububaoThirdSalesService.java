package com.zhongan.app.run.cms.service.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultSalesDto;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 业务员管理接口 service
 * 
 * @author lichao002
 * @date 2018-06-04
 */
public interface BububaoThirdSalesService {

    public BaseResult<String> insertBatchSaless(HttpServletRequest request, String fileName, String fileFormat);

    public BaseResult<PageDTO<ResultSalesDto>> findSalessPage(ParamDto param);

    /**
     * 批量删除业务员
     * 
     * @param params
     * @return
     */
    public BaseResult<String> deleteBatchSaless(List<ParamDto> params);

    /**
     * 导出业务员信息
     * 
     * @param param
     * @return
     */
    public BaseResult<String> exportSaless(ParamDto param);
}
