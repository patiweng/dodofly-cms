package com.zhongan.app.run.cms.common.utils;

import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;

@Slf4j
public class StreamUtil {

    /**
     * 通过网络连接获取输入流
     * @param networkUrl
     * @return
     */
    public static InputStream getInputStreamByNetworkUrl(String networkUrl){
        log.info("{}-------------------StreamUtil.getInputStreamByNetworkUrl---------------start,url:{}", ThreadLocalUtil
                .getRequestNo(), networkUrl);
        if(StringUtils.isBlank(networkUrl)){
            log.info("{}-------------------StreamUtil.getInputStreamByNetworkUrl---------------end", ThreadLocalUtil.getRequestNo());
            return null;
        }
        URL url = null;
        InputStream inputStream = null;
        int loopNum = 0;
        while (inputStream == null && loopNum < 5){
            try {
                url = new URL(networkUrl);
                URLConnection urlConnection = url.openConnection();
                urlConnection.connect();
                HttpURLConnection httpconn =(HttpURLConnection)urlConnection;
                int responseCode = httpconn.getResponseCode();
                if(responseCode != HttpURLConnection.HTTP_OK){
                    log.info("{}-------------------StreamUtil.getInputStreamByNetworkUrl---------------连接异常，responseCode:{}", ThreadLocalUtil.getRequestNo(), responseCode);
                    throw new Exception("链接异常" + responseCode);
                }
                inputStream  = urlConnection.getInputStream();
                if(inputStream == null){
                    log.info("{}-------------------StreamUtil.getInputStreamByNetworkUrl---------------打开数据流异常", ThreadLocalUtil.getRequestNo());
                    throw new Exception("打开数据流异常");
                }
            }catch (Exception e){
                loopNum++;
                log.error("{}-------------------StreamUtil.getInputStreamByNetworkUrl---------------第{}次连接异常exception:{}", ThreadLocalUtil.getRequestNo(), loopNum, e);
            }
        }

        return inputStream;
    }

    /**
     * inputStream转outputStream
     * @param in
     * @return
     * @throws Exception
     */
    public static ByteArrayOutputStream parse(InputStream in) throws Exception
    {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        int ch;
        while ((ch = in.read()) != -1) {
            swapStream.write(ch);
        }
        return swapStream;
    }

    /**
     * outputStream转inputStream
     * @param out
     * @return
     * @throws Exception
     */
    public static ByteArrayInputStream parse(ByteArrayOutputStream out) throws Exception
    {
        ByteArrayInputStream swapStream = new ByteArrayInputStream(out.toByteArray());
        return swapStream;
    }


    /**
     * inputStream转String
     * @param in
     * @return
     * @throws Exception
     */
    public static String parseString(InputStream in) throws Exception
    {
        ByteArrayOutputStream swapStream = new ByteArrayOutputStream();
        int ch;
        while ((ch = in.read()) != -1) {
            swapStream.write(ch);
        }
        return swapStream.toString();
    }

    /**
     * OutputStream 转String
     * @param out
     * @return
     * @throws Exception
     */
    public static String parseString(OutputStream out)throws Exception
    {
        ByteArrayOutputStream   baos=new   ByteArrayOutputStream();
        baos=(ByteArrayOutputStream) out;
        ByteArrayInputStream swapStream = new ByteArrayInputStream(baos.toByteArray());
        return swapStream.toString();
    }

    /**
     * String转inputStream
     * @param in
     * @return
     * @throws Exception
     */
    public static ByteArrayInputStream parseInputStream(String in)throws Exception
    {
        ByteArrayInputStream input=new ByteArrayInputStream(in.getBytes());
        return input;
    }

    /**
     * String 转outputStream
     * @param in
     * @return
     * @throws Exception
     */
    public static ByteArrayOutputStream parseOutputStream(String in)throws Exception
    {
        return parse(parseInputStream(in));
    }
}
