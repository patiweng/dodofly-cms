package com.zhongan.app.run.cms.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.ibm.icu.text.DecimalFormat;
import com.zhongan.app.run.cms.bean.dataobject.WeekBusinessDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.WeekBusinessRepo;
import com.zhongan.app.run.cms.bean.web.WeekBusinessDTO;
import com.zhongan.app.run.cms.bean.web.WeekBusinessPageDTO;
import com.zhongan.app.run.cms.common.utils.ReadExcel;
import com.zhongan.app.run.cms.repository.ExportWeekBusinessRepository;
import com.zhongan.app.run.cms.service.ExportWeekBusinessService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class ExportWeekBusinessServiceImpl implements ExportWeekBusinessService {

    @Resource
    private ExportWeekBusinessRepository exportWeekBusinessRepository;

    @Override
    public WeekBusinessPageDTO selectWeekBusinessList(Page<WeekBusinessDTO> weekBusinessPage) {
        WeekBusinessPageDTO weekBusinessPageDTO = new WeekBusinessPageDTO();
        Page<WeekBusinessRepo> weekBusinessRepoPage = new Page<WeekBusinessRepo>();
        BeanUtils.copyProperties(weekBusinessPage, weekBusinessRepoPage);

        weekBusinessRepoPage = exportWeekBusinessRepository.selectWeekBusinessPage(weekBusinessPage);
        List<WeekBusinessRepo> weekBusinessRepoList = weekBusinessRepoPage.getResultList();
        List<WeekBusinessDTO> weekBusinessDTOList = Lists.newArrayList();

        if (null != weekBusinessRepoList && weekBusinessRepoList.size() > 0) {
            WeekBusinessDTO weekBusinessDTO = new WeekBusinessDTO();
            for (WeekBusinessRepo weekBusinessRepo : weekBusinessRepoList) {
                WeekBusinessDTO clone = (WeekBusinessDTO) weekBusinessDTO.clone();
                BeanUtils.copyProperties(weekBusinessRepo, clone);
                weekBusinessDTOList.add(clone);
            }
        }
        weekBusinessPage.setResultList(weekBusinessDTOList);
        weekBusinessPage.setTotalItem(weekBusinessRepoPage.getTotalItem());
        weekBusinessPageDTO.setWeekBusinessPageDTO(weekBusinessPage);
        return weekBusinessPageDTO;
    }

    @Override
    public void doExportExcelWeekBusiness(HttpServletResponse response) {
        // TODO Auto-generated method stub
        log.info("{}-doExportExcelWeekBusiness start……", ThreadLocalUtil.getRequestNo());
        try {
            List<WeekBusinessDO> resultlist = exportWeekBusinessRepository.queryWeekListForExcel();
            if (resultlist == null || resultlist.size() == 0) {
                log.info("没有需要导出的数据！");
                return;
            }

            String path = this.getClass().getResource("/static/excel/weekBusinessReg.xlsx").getPath();
            InputStream is = this.getClass().getResourceAsStream("/static/excel/weekBusinessReg.xlsx");
            log.info("excel模版的路径为=================" + path);
            Workbook workbook = new XSSFWorkbook(is);
            if (workbook == null) {
                log.info("workbook对象为null");
            }
            Sheet sheet = workbook.getSheetAt(0);//获取页签
            if (null != resultlist && resultlist.size() > 0) {
                Long cell_1 = 0L;
                Long cell_2 = 0L;
                Long cell_3 = 0L;
                Long cell_4 = 0L;
                Long cell_5 = 0L;

                Long cell_7 = 0L;
                Long cell_8 = 0L;
                Long cell_9 = 0L;
                Long cell_10 = 0L;

                for (int i = 0; i < resultlist.size(); i++) {
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    WeekBusinessDO weekBusiness = resultlist.get(i);
                    Row rowx = sheet.getRow(3 + i);
                    rowx.getCell(0).setCellValue(weekBusiness.getSource_name());
                    rowx.getCell(1).setCellValue(weekBusiness.getNew_shouquan_user());
                    cell_1 = cell_1 + weekBusiness.getNew_shouquan_user();
                    rowx.getCell(2).setCellValue(weekBusiness.getNew_insure_user());
                    cell_2 = cell_2 + weekBusiness.getNew_insure_user();
                    rowx.getCell(3).setCellValue(weekBusiness.getActive_all_user());
                    cell_3 = cell_3 + weekBusiness.getActive_all_user();
                    rowx.getCell(4).setCellValue(weekBusiness.getActive_old_user());
                    cell_4 = cell_4 + weekBusiness.getActive_old_user();
                    rowx.getCell(5).setCellValue(weekBusiness.getActive_new_user());
                    cell_5 = cell_5 + weekBusiness.getActive_new_user();
                    rowx.getCell(6).setCellValue(weekBusiness.getActive_persent());
                    rowx.getCell(7).setCellValue(weekBusiness.getPremium_xubao_user());
                    cell_7 = cell_7 + weekBusiness.getPremium_xubao_user();
                    rowx.getCell(8).setCellValue(weekBusiness.getPremium_mianfei_user());
                    cell_8 = cell_8 + weekBusiness.getPremium_mianfei_user();
                    rowx.getCell(9).setCellValue(weekBusiness.getPremium_fufei_user());
                    cell_9 = cell_9 + weekBusiness.getPremium_fufei_user();
                    rowx.getCell(10).setCellValue(weekBusiness.getPremium_shouru());
                    cell_10 = cell_10 + Long.parseLong(weekBusiness.getPremium_shouru());
                    rowx.getCell(11).setCellValue(weekBusiness.getPremium_ARPU());
                }
                ReadExcel.copyRows(sheet, 4, 4, 3 + resultlist.size());
                Row rowlast = sheet.getRow(3 + resultlist.size());
                rowlast.getCell(0).setCellValue("总计");
                rowlast.getCell(1).setCellValue(cell_1);
                rowlast.getCell(2).setCellValue(cell_2);
                rowlast.getCell(3).setCellValue(cell_3);
                rowlast.getCell(4).setCellValue(cell_4);
                rowlast.getCell(5).setCellValue(cell_5);
                rowlast.getCell(7).setCellValue(cell_7);
                rowlast.getCell(8).setCellValue(cell_8);
                rowlast.getCell(9).setCellValue(cell_9);
                rowlast.getCell(10).setCellValue(cell_10);
                rowlast.getCell(11).setCellValue(countNum(cell_10, cell_9));
            }
            String title = "周汇总";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception e) {
            log.error("{}-doExportExcelWeekBusiness fail……", e, ThreadLocalUtil.getRequestNo());
        }

    }

    /**
     * 字符串转百分比
     * 
     * @param rate
     * @return
     */
    private String formatPercentum(String rate) {
        NumberFormat nf = NumberFormat.getPercentInstance();
        String format = nf.format(Double.valueOf(rate));
        return format;
    }

    private String countRate(Long index, Long count) {
        if (index == 0 || count == 0) {
            return "0%";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return formatPercentum(s);
    }

    private String countNum(Long index, Long count) {
        if (index == 0 || count == 0) {
            return "0";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return s;
    }
}
