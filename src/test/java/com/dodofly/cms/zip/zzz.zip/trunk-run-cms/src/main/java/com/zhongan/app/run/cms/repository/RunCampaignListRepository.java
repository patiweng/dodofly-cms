package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoCampaignListDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunCampaignListRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCampaignListDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.dao.BububaoCampaignListDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Component
public class RunCampaignListRepository {
	
	
	@Resource
	private BububaoCampaignListDAO bububaoCampaignListDAO;	 
	
	@Resource
	private Sequence         seqCampaignList;
	
	public ResultBase<List<RunCampaignListDTO>> selectRunCampaignDataRepo(RunCampaignListRepo runCampaignListRepo){
		    log.info("{}-select  CampaignList。。。Repository。。。",ThreadLocalUtil.getRequestNo());
	        ResultBase<List<RunCampaignListDTO>> result = new ResultBase<List<RunCampaignListDTO>>();
	        List<RunCampaignListDTO> listresult = new ArrayList<RunCampaignListDTO>();

	        BububaoCampaignListDO bububaoCampaignListDO = new BububaoCampaignListDO();
	        BeanUtils.copyProperties(runCampaignListRepo, bububaoCampaignListDO);
	        //设置默认值 默认查询步步保营销活动信息
	        if (StringUtils.isBlank(bububaoCampaignListDO.getCampaignType())){
                bububaoCampaignListDO.setCampaignType("0");
            }
	        List<BububaoCampaignListDO> resultlist = bububaoCampaignListDAO.selectDataByCdt(bububaoCampaignListDO); 
	        if(resultlist.size()>0){
	        	for(BububaoCampaignListDO BububaoCampaignListDO:resultlist){
	    	        RunCampaignListDTO runCampaignListDTO = new RunCampaignListDTO();
	    	        BeanUtils.copyProperties(BububaoCampaignListDO, runCampaignListDTO);
	    	        listresult.add(runCampaignListDTO);
	        	}	        		        	
	        }
	        result.setSuccess(true);   
	        result.setValue(listresult);	
	        return result;	
	}
	
	
	//分页查询 
		
	public Page<RunCampaignListRepo> selectCampaignListPage(Page<RunCampaignListRepo> runCampaignListRepoPage){
		
		BububaoCampaignListDO bububaoCampaignListDO = new BububaoCampaignListDO();
        if (null != runCampaignListRepoPage.getParam()) {
            BeanUtils.copyProperties(runCampaignListRepoPage.getParam(), bububaoCampaignListDO);
        }
        //只查询正常的数据，无效的数据不做查询
        bububaoCampaignListDO.setStatus(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", runCampaignListRepoPage.getStartRow());
        map.put("pageSize", runCampaignListRepoPage.getPageSize());
        map.put("bububaoCampaignListDO", bububaoCampaignListDO);
        List<BububaoCampaignListDO> bububaoCampaignListDOList = bububaoCampaignListDAO.selectBububaoCampaign(map);
        List<RunCampaignListRepo> bububaoCampaignListRepoList = Lists.newArrayList();

        if (null != bububaoCampaignListDOList && 0 != bububaoCampaignListDOList.size()) {
        	RunCampaignListRepo runCampaignListRepodo = null;
            for (BububaoCampaignListDO bububaoCampaignListDOs : bububaoCampaignListDOList) {
            	runCampaignListRepodo = new RunCampaignListRepo();
                BeanUtils.copyProperties(bububaoCampaignListDOs, runCampaignListRepodo);
                bububaoCampaignListRepoList.add(runCampaignListRepodo);
            }
        }
        runCampaignListRepoPage.setResultList(bububaoCampaignListRepoList);
        Integer counts = bububaoCampaignListDAO.selectCounts(map);
        runCampaignListRepoPage.setTotalItem(counts);
        return runCampaignListRepoPage;
	}

	
	  //插入一条新的记录（营销活动表）
    public ResultBase<String> saveCampaignList(RunCampaignListRepo runCampaignListRepo) throws Exception {
        log.info("{}-insert bububaoCampaignList。。。Repository。。。",ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        BububaoCampaignListDO bububaoCampaignListDO = new BububaoCampaignListDO();
        BeanUtils.copyProperties(runCampaignListRepo, bububaoCampaignListDO);
        Long id = seqCampaignList.nextValue();
        bububaoCampaignListDO.setId(id.toString());
        bububaoCampaignListDAO.insert(bububaoCampaignListDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }      
    
    
    //根据主键修改营销活动信息
    
    public ResultBase<String> updateCampaignList(RunCampaignListRepo runCampaignListRepo) throws Exception {
    	ResultBase<String> result = new ResultBase<String>();   	
    	log.info("{}-update bububaoCampaignList。。。Repository。。。",ThreadLocalUtil.getRequestNo());
    	BububaoCampaignListDO bububaoCampaignListDO = new BububaoCampaignListDO();
        BeanUtils.copyProperties(runCampaignListRepo, bububaoCampaignListDO);
        bububaoCampaignListDAO.update(bububaoCampaignListDO);
        result.setSuccess(true);
        result.setValue(RunConstants.UPDATE_TRUE);
    	return result;
    }
    
    //删除信息(更新为无效数据)
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        bububaoCampaignListDAO.updateByid(id);
        result.setSuccess(true);
        return result;
    }
    
    //根据id 查询一个对象信息
    
    public RunCampaignListRepo selectOneData(String id){
    	RunCampaignListRepo runCampaignListRepo = new RunCampaignListRepo();
    	BububaoCampaignListDO bububaoCampaignListDO = bububaoCampaignListDAO.selectOneDataById(id);
    	if(bububaoCampaignListDO!=null){
    		BeanUtils.copyProperties(bububaoCampaignListDO, runCampaignListRepo);  	
    	}   	
    	return  runCampaignListRepo;
    }
}
