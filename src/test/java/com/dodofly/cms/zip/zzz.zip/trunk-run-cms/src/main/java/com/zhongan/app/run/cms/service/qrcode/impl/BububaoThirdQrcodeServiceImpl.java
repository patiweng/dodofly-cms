package com.zhongan.app.run.cms.service.qrcode.impl;

import com.alibaba.common.lang.StringUtil;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoThirdQrcodeDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdQrcodeDO;
import com.zhongan.app.run.cms.common.constants.QrCodeConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.QrCodeUtil;
import com.zhongan.app.run.cms.dao.qrcode.BububaoThirdQrcodeDao;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdQrcodeService;
import com.zhongan.health.common.share.bean.BaseResult;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

import java.util.Date;
import java.util.List;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class BububaoThirdQrcodeServiceImpl implements BububaoThirdQrcodeService {

    @Value("${za.run.img.domain.url}")
    private String                bububao_domain;

    private static final String   BUBUBAO_PATH = "/run/proxy/init/appinit";

    private static final int      WIDTH        = 100;

    private static final int      HEIGHT       = 100;

    private static final String   FORMAT       = "png";

    @Resource
    private OssTool               ossTool;

    @Resource
    private BububaoThirdQrcodeDao bububaoThirdQrcodeDao;

    @Override
    public void batchSaveQrcode() {

    }

    @Override
    public void makeAndInsertQrcode(String orgCode, Long id, String isFollowBububao, Integer type, String creatName) {
        StringBuffer buffer = new StringBuffer();
        Date date = new Date();
        buffer.append(bububao_domain).append(BUBUBAO_PATH).append("?from=zaWechatBububao&version=2&isFollow=")
                .append(isFollowBububao).append("&dataType=").append(type)
                .append("&dataId=").append(id);
        String qrcodeUrl = QrCodeUtil.generateQRCode(buffer.toString(), WIDTH, HEIGHT, FORMAT, ossTool, QrCodeConstants.getQrcodeName(type, id, FORMAT));

        BububaoThirdQrcodeDO bububaoThirdQrcode = new BububaoThirdQrcodeDO();
        bububaoThirdQrcode.setDataId(id);
        bububaoThirdQrcode.setDataType(type);
        bububaoThirdQrcode.setQrcodeUrl(qrcodeUrl);
        bububaoThirdQrcode.setScanNum(0);
        bububaoThirdQrcode.setHolderNum(0);
        bububaoThirdQrcode.setInsureNum(0);
        bububaoThirdQrcode.setIsDeleted("N");
        bububaoThirdQrcode.setCreator(creatName);
        bububaoThirdQrcode.setGmtCreated(date);
        bububaoThirdQrcode.setModifier(creatName);
        bububaoThirdQrcode.setGmtModified(date);
        bububaoThirdQrcodeDao.insertSelective(bububaoThirdQrcode);
    }

    @Override
    public List findQrcodesPage() {
        return null;
    }

    /**
     * 修改二维码管理
     */
    @Override
    public BaseResult<Integer> updateThirdQrcode(BububaoThirdQrcodeDto thirdQrcodeDTO) {
        BaseResult<Integer> result = new BaseResult<Integer>();
        BububaoThirdQrcodeDO qrcodeLogDO = new BububaoThirdQrcodeDO();
        try {
            if (StringUtil.isBlank(thirdQrcodeDTO.getModifier())) {
                thirdQrcodeDTO.setModifier("system");
            }
            thirdQrcodeDTO.setGmtModified(new Date());
            BeanUtils.copyProperties(thirdQrcodeDTO, qrcodeLogDO);
            int count = bububaoThirdQrcodeDao.updateCountsByDataIdAndType(qrcodeLogDO);
            result.setResult(count);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.info("异常===BububaoThirdQrcodeServiceImpl.updateThirdQrcode fail", e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }
}
