package com.zhongan.app.run.cms.service.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserStepDTO;

@FeignClient(name = "za-run-step", url = "${za.run.step.feignclient.url}")
public interface RunStepFeignClient {

    @RequestMapping(value = "/run/step/target/getusertargetstep/{unionId}/{tDate}", method = RequestMethod.GET)
    public ResultBase<String> getUserTargetStep(@PathVariable("unionId") String unionId,
                                                @PathVariable("tDate") String tDate);

    @RequestMapping(value = "/run/step/select/selectuserstepsbyunionidanddate", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<List<UserStepDTO>> selectUserStepsByUnionIdAndDate(UserStepDTO userStepDTO);
}
