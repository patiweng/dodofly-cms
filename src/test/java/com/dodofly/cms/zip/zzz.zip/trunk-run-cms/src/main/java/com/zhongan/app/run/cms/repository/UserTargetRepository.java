package com.zhongan.app.run.cms.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.UserTargetDO;
import com.zhongan.app.run.cms.dao.UserTargetDAO;

/**
 * 获取用户目标组件
 * 
 * @author songchengsong 2016年11月21日 下午2:34:27
 */
@Component
public class UserTargetRepository {
    @Autowired
    private UserTargetDAO userTargetDAO;

    /**
     * 根据条件查询目标步数表
     * 
     * @param userTargetDO
     * @return
     */
    public List<UserTargetDO> selectDataByCdt(UserTargetDO userTargetDO) {
        return userTargetDAO.selectDataByCdt(userTargetDO);
    }

}
