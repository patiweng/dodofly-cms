package com.zhongan.app.run.cms.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.ActivityPresentRepo;
import com.zhongan.app.run.cms.bean.repo.AwardRecordRepo;
import com.zhongan.app.run.cms.bean.repo.BububaoPresentRepo;
import com.zhongan.app.run.cms.bean.repo.RaffleActivityRepo;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.AwardRecordDTO;
import com.zhongan.app.run.cms.bean.web.AwardRecordPageDTO;
import com.zhongan.app.run.cms.bean.web.CardCouponsDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.ReadExcel;
import com.zhongan.app.run.cms.repository.ActivityPresentRepository;
import com.zhongan.app.run.cms.repository.AwardRecordRepository;
import com.zhongan.app.run.cms.repository.RaffleActivityRepository;
import com.zhongan.app.run.cms.repository.RafflePresentRepository;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.AwardRecordService;
import com.zhongan.app.run.cms.service.client.RunActivityFeignClient;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Service("awardRecordServiceImpl")
public class AwardRecordServiceImpl implements AwardRecordService {

    @Resource
    private AwardRecordRepository     awardRecordRepository;
    @Resource
    private RafflePresentRepository   rafflePresentRepository;
    @Resource
    private RaffleActivityRepository  raffleActivityRepository;
    @Resource
    private ActivityPresentRepository activityPresentRepository;
    @Resource
    private RunChannelListRepository         runChannelListRepository;

    @Resource
    private RunActivityFeignClient    runActivityFeignClient;

    @Override
    public AwardRecordPageDTO selectAwardRecordListPage(Page<AwardRecordDTO> page) {
        log.info("{}-AwardRecordServiceImpl.selectAwardRecordListPage,param={" + page.toString() + "}");
        AwardRecordPageDTO awardRecordPageDTO = new AwardRecordPageDTO();
        try {
          //如果活动标识不为空，根据活动标识查询活动id
            String  identify= page.getParam().getIdentify();
            if(StringUtils.isNotBlank(identify)){
                RaffleActivityRepo raffleActivityRepo = new RaffleActivityRepo();
                raffleActivityRepo.setIdentify(identify);
                List<RaffleActivityRepo> activityList = raffleActivityRepository.selectActivitiesByCdt(raffleActivityRepo);
                AwardRecordDTO awardRecordDTO= new AwardRecordDTO();
                if (CollectionUtils.isNotEmpty(activityList)) {
                    raffleActivityRepo = activityList.get(0);
                    BeanUtils.copyProperties(page.getParam(), awardRecordDTO);
                    awardRecordDTO.setActivityId(Long.valueOf(raffleActivityRepo.getId()));
                    log.info("{}-activityId={" + raffleActivityRepo.getId() + "}", ThreadLocalUtil.getRequestNo());
                    page.setParam(awardRecordDTO);
                    }
            }
            Page<AwardRecordRepo> pageRepo = new Page<AwardRecordRepo>();
            BeanUtils.copyProperties(page, pageRepo);
            pageRepo = awardRecordRepository.selectAwardRecordListPage(pageRepo);
            List<AwardRecordRepo> resultList = pageRepo.getResultList();
            List<AwardRecordDTO> AwardRecordDTOList = Lists.newArrayList();
            if (resultList != null && resultList.size() > 0) {
                AwardRecordDTO AwardRecordDTO = new AwardRecordDTO();
                for (AwardRecordRepo AwardRecordRepo : resultList) {
                    AwardRecordDTO clone = (AwardRecordDTO) AwardRecordDTO.clone();
                    BeanUtils.copyProperties(AwardRecordRepo, clone);
                    RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(String.valueOf(clone
                            .getPresentId()));
                    if (null != rafflePresentDTO) {
                        clone.setPresentName(rafflePresentDTO.getName());//礼物名称
                        clone.setIntegral(rafflePresentDTO.getIntegral());
                        String type = rafflePresentDTO.getType();
                        if ("3".equals(type)) {
                            CardCouponsDTO cardCoupons = new CardCouponsDTO();
                            cardCoupons.setUnionid(clone.getUnionid());
                            cardCoupons.setActivityId(clone.getActivityId());
                            cardCoupons.setPresentId(clone.getPresentId());
                            ResultBase<List<CardCouponsDTO>> selectcardcoupons = runActivityFeignClient
                                    .selectcardcoupons(cardCoupons);
                            if (selectcardcoupons.isSuccess()
                                    && CollectionUtils.isNotEmpty(selectcardcoupons.getValue())) {
                                List<CardCouponsDTO> value = selectcardcoupons.getValue();
                                clone.setCardPassword(value.get(0).getCardPassword());
                                clone.setCardNum(value.get(0).getCardNum());
                            }
                        }
                    }
                    AwardRecordDTOList.add(clone);
                }
            }
            //查询渠道列表
            ResultBase<List<RunChannelListDTO>> resultchannel = new ResultBase<List<RunChannelListDTO>>();
            RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
            resultchannel = runChannelListRepository.selectRunChannelListDataList(runChannelListRepo);
            page.setResultList(AwardRecordDTOList);
            page.setTotalItem(pageRepo.getTotalItem());
            awardRecordPageDTO.setAwardRecordPage(page);
            awardRecordPageDTO.setRunChannelListDTOList(resultchannel.getValue());
            return awardRecordPageDTO;
        } catch (Exception e) {
            log.error("异常AwardRecordServiceImpl.selectAwardRecordListPage  fail……" + e);
        }
        return null;
    }

    @Override
    public ResultBase<AwardRecordDTO> selectAwardRecordOne(String id) {
        log.info("{}-AwardRecordServiceImpl.selectAwardRecordOne start...", ThreadLocalUtil.getRequestNo());
        ResultBase<AwardRecordDTO> resultBase = new ResultBase<AwardRecordDTO>();
        try {
            AwardRecordRepo AwardRecordRepo = awardRecordRepository.selectAwardRecordOne(id);
            if (null != AwardRecordRepo) {
                AwardRecordDTO AwardRecordDTO = new AwardRecordDTO();
                BeanUtils.copyProperties(AwardRecordRepo, AwardRecordDTO);
                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
                resultBase.setSuccess(true);
                resultBase.setValue(AwardRecordDTO);
                return resultBase;
            }
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
        } catch (Exception e) {
            log.info("异常===AwardRecordServiceImpl.selectAwardRecordOne fail", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> updateById(AwardRecordDTO awardRecordDTO) {
        log.info("{}-AwardRecordServiceImpl.updateById start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            if (null != awardRecordDTO && null != awardRecordDTO.getId()) {
                AwardRecordRepo awardRecordRepo = new AwardRecordRepo();
                BeanUtils.copyProperties(awardRecordDTO, awardRecordRepo);
                awardRecordRepository.updateById(awardRecordRepo);
                resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
                resultBase.setSuccess(true);
            } else {
                resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
                resultBase.setSuccess(false);
                resultBase.setValue("id不能为空");
            }
        } catch (Exception e) {
            log.error("更新异常AwardRecordServiceImpl.updateById  fail……" + e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> getPresentNameArrList(String identify) {
        log.info("{}-AwardRecordServiceImpl.getPresentNameArrList start...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        RaffleActivityRepo raffleActivityRepo = new RaffleActivityRepo();
        ActivityPresentRepo activityPresentRepo = new ActivityPresentRepo();
        List<RafflePresentDTO> rafflePresentList = Lists.newArrayList();
        try {
            raffleActivityRepo.setIdentify(identify);
            List<RaffleActivityRepo> activityList = raffleActivityRepository.selectActivitiesByCdt(raffleActivityRepo);
            if (null != activityList && activityList.size() > 0) {
                raffleActivityRepo = activityList.get(0);
                activityPresentRepo.setActivityId(raffleActivityRepo.getId());
                //优惠活动礼物
                List<ActivityPresentRepo> activityPresentList = activityPresentRepository
                        .selectDataByCdt(activityPresentRepo);
                if (null != activityPresentList && activityPresentList.size() > 0) {
                    RafflePresentDTO rafflePresentDTO = null;
                    for (ActivityPresentRepo activityPresentRepo2 : activityPresentList) {
                        //根据礼物id查询礼物
                        BububaoPresentRepo selectOneDataById = rafflePresentRepository
                                .selectOneDataById(activityPresentRepo2.getPresentId());
                        if (null != selectOneDataById) {
                            rafflePresentDTO = new RafflePresentDTO();
                            BeanUtils.copyProperties(selectOneDataById, rafflePresentDTO);
                            rafflePresentList.add(rafflePresentDTO);
                        }
                    }
                    String jsonString = JSONObject.toJSONString(rafflePresentList);
                    resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                    resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
                    resultBase.setSuccess(true);
                    resultBase.setValue(jsonString);
                } else {
                    resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
                    resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
                    resultBase.setSuccess(false);
                    resultBase.setValue("该活动还未配置礼物");
                }
            } else {
                resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
                resultBase.setSuccess(false);
                resultBase.setValue("活动标识无效");
            }
        } catch (Exception e) {
            log.error("查询异常AwardRecordServiceImpl.getPresentNameArrList  fail……" + e);
        }
        return resultBase;
    }

    @Override
    public void doExportExcel(HttpServletResponse response, AwardRecordDTO awardRecordDTO) {
        log.info("{}-AwardRecordServiceImpl.doExportExcel start...,param={" + awardRecordDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        AwardRecordRepo awardRecordRepo = new AwardRecordRepo();
        try {
          //如果活动标识不为空，根据活动标识查询活动id
            String  identify= awardRecordDTO.getIdentify();
            if(StringUtils.isNotBlank(identify)){
                RaffleActivityRepo raffleActivityRepo = new RaffleActivityRepo();
                raffleActivityRepo.setIdentify(identify);
                List<RaffleActivityRepo> activityList = raffleActivityRepository.selectActivitiesByCdt(raffleActivityRepo);
                if (CollectionUtils.isNotEmpty(activityList)) {
                    raffleActivityRepo = activityList.get(0);
                    awardRecordDTO.setActivityId(Long.valueOf(raffleActivityRepo.getId()));
                    log.info("{}-activityId={" + raffleActivityRepo.getId() + "}", ThreadLocalUtil.getRequestNo());
                    }
            }
            BeanUtils.copyProperties(awardRecordDTO, awardRecordRepo);
            List<AwardRecordRepo> repoList = awardRecordRepository.selectAwardRecordListOfExcel(awardRecordRepo);
            InputStream is = this.getClass().getResourceAsStream("/static/excel/awardRecord.xlsx");
            Workbook workbook = ReadExcel.createworkbook(is);
            if (null == workbook) {
                log.info("workbook为空!");
                return;
            }
            if (null != repoList && repoList.size() > 0) {
                Sheet sheet = workbook.getSheetAt(0);//获取页签
                for (int i = 0; i < repoList.size(); i++) {
                    //第一行不用copy
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    AwardRecordRepo repo = repoList.get(i);
                    RafflePresentDTO rafflePresentDTO = rafflePresentRepository.selectPresentByid(String.valueOf(repo
                            .getPresentId()));
                    Row rowx = sheet.getRow(3 + i);
                    rowx.getCell(0).setCellValue(i + 1);
                    rowx.getCell(1).setCellValue(String.valueOf(repo.getUnionid()));
                    rowx.getCell(2).setCellValue(repo.getChannelFrom());
                    rowx.getCell(3).setCellValue(repo.getCustomerName());
                    rowx.getCell(4).setCellValue(repo.getCustomerPhone());
                    rowx.getCell(5).setCellValue(rafflePresentDTO == null ? "" : rafflePresentDTO.getName());
                    rowx.getCell(6).setCellValue(
                            StringUtils.isEmpty(repo.getPresentPolicyNo()) ? "" : repo.getPresentPolicyNo());
                    rowx.getCell(7)
                            .setCellValue(repo.getRequireId() == null ? "" : String.valueOf(repo.getRequireId()));
                    rowx.getCell(8).setCellValue(repo.getCustomerAddress());
                    rowx.getCell(9).setCellValue(repo.getWinTime());
                }
            }
            String title = "用户奖励记录";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception e) {
            log.error("导出报表异常AwardRecordServiceImpl.doExportExcel  fail……{}", e);
        }
    }

    @Override
    public ResultBase<List<AwardRecordDTO>> selectDataByCdt(AwardRecordDTO awardRecordDTO) {
        log.info("{}--AwardRecordServiceImpl.selectDataByCdt……start,param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(awardRecordDTO));
        ResultBase<List<AwardRecordDTO>> resultBase = new ResultBase<List<AwardRecordDTO>>();
        List<AwardRecordDTO> dtoList = Lists.newArrayList();
        try {
            AwardRecordRepo awardRecordRepo = new AwardRecordRepo();
            BeanUtils.copyProperties(awardRecordDTO, awardRecordRepo);
            List<AwardRecordRepo> repoList = awardRecordRepository.selectAwardRecordsByCdt(awardRecordRepo);
            if (null != repoList && repoList.size() > 0) {
                for (AwardRecordRepo awardRecordRepo2 : repoList) {
                    AwardRecordDTO dto = new AwardRecordDTO();
                    BeanUtils.copyProperties(awardRecordRepo2, dto);
                    dtoList.add(dto);
                }
            }
            resultBase.setValue(dtoList);
            resultBase.setSuccess(true);
            resultBase.setErrorCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_SYS_0000.getCode());
        } catch (Exception e) {
            log.error("{}--AwardRecordServiceImpl.selectDataByCdt……fail==={}", ThreadLocalUtil.getRequestNo(), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_SYS_0001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_SYS_0001.getCode());
        }
        return resultBase;
    }
}
