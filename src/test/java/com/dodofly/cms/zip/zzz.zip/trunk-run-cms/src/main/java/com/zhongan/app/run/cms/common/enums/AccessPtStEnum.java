package com.zhongan.app.run.cms.common.enums;

public enum AccessPtStEnum {
	/***公共***/
	ACCESSPTST_SJ("1","上架"),
	ACCESSPTST_XJ("2","下架"),
	;
	private String code;
    private String value;

    private AccessPtStEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
