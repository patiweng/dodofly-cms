package com.zhongan.app.run.cms.conver;

import java.util.List;

import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.UserActivityInfoDTO;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.dao.bean.UserActivityInfoDO;

public class UserActivityInfoConvert {

    public static List<UserActivityInfoDTO> convertResDTO(List<UserActivityInfoDO> userActivityInfo) {
        List<UserActivityInfoDTO> userActivityInfoDTOs = Lists.newArrayList();
        for (UserActivityInfoDO info : userActivityInfo) {
            UserActivityInfoDTO dto = new UserActivityInfoDTO();
            BeanUtils.copyProperties(info, dto);
            fieldConvert(info, dto);
            userActivityInfoDTOs.add(dto);
        }
        return userActivityInfoDTOs;
    }

    public static void fieldConvert(UserActivityInfoDO info, UserActivityInfoDTO dto) {
        dto.setActivityBeginTime(DateTimeUtils.covertTimeToString(info.getActivityBeginTime()));
        dto.setActivityEndTime(DateTimeUtils.covertTimeToString(info.getActivityEndTime()));
    }
}
