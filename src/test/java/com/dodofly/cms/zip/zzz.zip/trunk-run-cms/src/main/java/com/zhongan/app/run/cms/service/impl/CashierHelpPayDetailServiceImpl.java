package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailResDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.conver.CashierHelpPayDetailConvert;
import com.zhongan.app.run.cms.dao.CashierHelpPayDetailMapper;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDetailCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDetailCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDetailDO;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.ICashierHelpPayDetailService;
import com.zhongan.health.common.share.bean.PageDTO;
import com.zhongan.pipeline.utils.CollectionUtils;

@Service("cashierHelpPayDetailService")
public class CashierHelpPayDetailServiceImpl implements ICashierHelpPayDetailService {

    @Resource
    private CashierHelpPayDetailMapper cashierHelpPayDetailMapper;

    @Resource
    private Sequence                   seqCashierHelpPayDetail;

    @Resource
    private RunChannelListRepository   runChannelListRepository;

    @Override
    public PageDTO<CashierHelpPayDetailResDTO> queryCashierHelpPayDetatilList(CashierHelpPayDetailQueryDTO queryDTO)
            throws Exception {
        PageDTO<CashierHelpPayDetailResDTO> pageDTO = new PageDTO<CashierHelpPayDetailResDTO>();
        int size = queryDTO.getPageSize();
        int currentPage = queryDTO.getCurrentPage() < 1 ? 1 : queryDTO.getCurrentPage();
        pageDTO.setCurrentPage(currentPage);
        pageDTO.setPageSize(size);
        CashierHelpPayDetailCriteria criteria = buildCriteria(CashierHelpPayDetailConvert.convertDTO(queryDTO));
        int count = cashierHelpPayDetailMapper.countByCriteria(criteria);
        if (count > 0) {
            int start = (currentPage - 1) * size;
            PageInfo pageInfo = new PageInfo();
            pageInfo.setOffset(start);
            pageInfo.setSize(size);
            List<CashierHelpPayDetailDO> list = cashierHelpPayDetailMapper.selectByCriteriaWithPage(criteria, pageInfo);
            pageDTO.setResultList(CashierHelpPayDetailConvert.convertResDTO(list, selectRunChannelListDataList()));
            pageDTO.setTotalItem(count);

        }
        return pageDTO;
    }

    @Override
    public Long saveOrUpdateCashierHelpPayDetail(CashierHelpPayDetailDTO dto) throws Exception {
        List<CashierHelpPayDetailDO> list = cashierHelpPayDetailMapper.selectByCriteria(buildCriteria(dto));
        CashierHelpPayDetailDO cashierHelpPayDO = CashierHelpPayDetailConvert.convertDO(dto);
        if (CollectionUtils.isEmpty(list)) {
            cashierHelpPayDO.setId(seqCashierHelpPayDetail.nextValue());
            cashierHelpPayDetailMapper.insert(cashierHelpPayDO);
        } else {
            cashierHelpPayDO.setId(list.get(0).getId());
            cashierHelpPayDetailMapper.updateByPrimaryKeySelective(cashierHelpPayDO);
        }
        return cashierHelpPayDO.getId();
    }

    public List<RunChannelListDTO> selectRunChannelListDataList() {
        RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
        ResultBase<List<RunChannelListDTO>> resultchannel = runChannelListRepository
                .selectRunChannelListDataList(runChannelListRepo);
        return resultchannel.getValue();
    }

    private CashierHelpPayDetailCriteria buildCriteria(CashierHelpPayDetailDTO queryDTO) {
        CashierHelpPayDetailCriteria cashierHelpPayDetailCriteria = new CashierHelpPayDetailCriteria();
        Criteria criteria = cashierHelpPayDetailCriteria.createCriteria();
        if (null != queryDTO.getCashierId()) {
            criteria.andCashierIdEqualTo(queryDTO.getCashierId());
        }
        if (null != queryDTO.getBizStatus()) {
            criteria.andBizStatusEqualTo(queryDTO.getBizStatus());
        }
        if (StringUtils.isNotEmpty(queryDTO.getUserContractNo())) {
            criteria.andUserContractNoEqualTo(queryDTO.getUserContractNo());
        }
        if (null != queryDTO.getBizStatus()) {
            criteria.andBizStatusEqualTo(queryDTO.getBizStatus());
        }
        return cashierHelpPayDetailCriteria;
    }

    @Override
    public List<CashierHelpPayDetailDTO> queryByCondition(CashierHelpPayDetailDTO dto) {
        CashierHelpPayDetailCriteria criteria = buildCriteria(dto);
        return CashierHelpPayDetailConvert.convertDTO(cashierHelpPayDetailMapper.selectByCriteria(criteria));
    }

    @Override
    public Integer deleteById(long id) {
        return cashierHelpPayDetailMapper.deleteByPrimaryKey(id);
    }
}
