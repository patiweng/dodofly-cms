package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

import com.zhongan.app.run.cms.bean.page.Page;

@Data
public class QuestionItemValuePageDTO {
    private String                     role;
    private Page<QuestionItemValueDTO> questionItemValueDTO;
}
