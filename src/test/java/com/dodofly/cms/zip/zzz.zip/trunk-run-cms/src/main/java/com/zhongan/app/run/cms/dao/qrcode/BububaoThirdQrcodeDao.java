package com.zhongan.app.run.cms.dao.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdQrcodeDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * 二维码管理 Dao层
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Component
public interface BububaoThirdQrcodeDao {

    /**
     * 根据二维码id删除二维码信息
     * 
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Long id);

    /**
     * 保存二维码信息
     * 
     * @param record
     * @return
     */
    int insert(BububaoThirdQrcodeDO record);

    /**
     * 保存二维码信息
     * 
     * @param record
     * @return
     */
    int insertSelective(BububaoThirdQrcodeDO record);

    /**
     * 根据二维码id查询二维码信息
     * 
     * @param id
     * @return
     */
    BububaoThirdQrcodeDO selectByPrimaryKey(Long id);

    /**
     * 更新二维码信息
     * 
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(BububaoThirdQrcodeDO record);

    /**
     * 根据二维码id更新二维码信息
     * 
     * @param record
     * @return
     */
    int updateByPrimaryKey(BububaoThirdQrcodeDO record);

    /**
     * 根据数据id和数据类型获取二维码链接
     * 
     * @param dataId
     * @param dataType
     * @return
     */
    String selectQrcodeUrlByDataIdAndType(@Param("dataId") Long dataId, @Param("dataType") Integer dataType);

    /**
     * 逻辑删除二维码信息
     * 
     * @param id
     * @param modifier
     * @return
     */
    int deleteByQrcodeId(@Param("id") Long id, @Param("modifier") String modifier);

    /**
     * 根据dataId和dataType查询二维码信息
     * 
     * @param record
     * @return
     */

    BububaoThirdQrcodeDO selectDataByDataIdAndType(BububaoThirdQrcodeDO record);

    /**
     * 根据二维码id查询二维码链接
     * 
     * @param id
     * @return
     */
    String selectUrlByQrcodeId(Long id);

    /**
     * 根据dataId和dataType修改数量
     * 
     * @param thirdQrcodeDO
     * @return
     */
    int updateCountsByDataIdAndType(BububaoThirdQrcodeDO thirdQrcodeDO);

}
