package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.zhongan.app.run.cms.bean.web.CashierNotifyDetailDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.service.ICashierNotifyDetailService;

/**
 * 类CashierNotifyDetailController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年9月19日 下午2:45:12
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/cashierNotifyDetail")
public class CashierNotifyDetailController {

    @Resource
    private ICashierNotifyDetailService cashierNotifyDetailService;

    @RequestMapping(value = "/saveOrUpdate", method = RequestMethod.POST)
    public ResultBase<Long> saveOrUpdate(@RequestBody CashierNotifyDetailDTO cashierNotifyDetailDTO) {
        log.info("CashierNotifyDetailController saveOrUpdate param{}", JSON.toJSONString(cashierNotifyDetailDTO));
        ResultBase<Long> resultBase = new ResultBase<Long>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierNotifyDetailService.saveOrUpdate(cashierNotifyDetailDTO));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierNotifyDetailController saveOrUpdateCashierNotifyDetail param{} exception{}",
                    JSON.toJSONString(cashierNotifyDetailDTO), e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            return resultBase;
        }
    }

    /**
     * 分页查询用户签约信息
     * 
     * @param queryDTO
     * @return
     */
    @RequestMapping(value = "/queryByCondition", method = RequestMethod.POST)
    public ResultBase<List<CashierNotifyDetailDTO>> queryByCondition(@RequestBody CashierNotifyDetailDTO dto) {
        log.info("cashierNotifyDetail queryCashierNotifyDetailList param==={}", JSON.toJSONString(dto));
        ResultBase<List<CashierNotifyDetailDTO>> resultBase = new ResultBase<List<CashierNotifyDetailDTO>>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierNotifyDetailService.queryByCondition(dto));
        } catch (Exception e) {
            resultBase.setSuccess(Boolean.FALSE);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }
}
