package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.bo.HealthProductChannelRelationBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationDTO;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface HealthProductChannelRelationService {

    public HealthProductChannelRelationPageDTO selectCampaigninfoPage(Page<HealthProductChannelRelationDTO> healthCampaignListPage);

    public ResultBase<List<HealthProductChannelRelationDTO>> selectCampaignInfo(HealthProductChannelRelationBO healthCampaignListBO);

    public ResultBase<String> insertCampaignList(HealthProductChannelRelationDTO healthCampaignListDTO);

    public ResultBase<String> updateCampaignList(HealthProductChannelRelationDTO healthCampaignListDTO);

    public ResultBase<String> deleteCampaignList(String id);

    public HealthProductChannelRelationDTO selectOneCampaignList(String id);
}
