package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

@Data
public class QuestionItemDTO {
    private Long              id;
    private Long              queryId;
    private String            itemTitle;
    private String            queryIcon;
    private String            tagCode;
    private Integer           sort;
    private String            type;
    private String            unit;
    private String            creator;
    private String            modifier;
    private String            createtime;
    private String            modifytime;
    private String            isDeleted;
    private Integer           pageSize;
    private Integer           currentPage;
    private String            inputCheck;
    private QuestionItemCheck check;
    private MultipartFile     marketingImgFile; //上传到OSS 的图片
}
