package com.zhongan.app.run.cms.service.qrcode.impl;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.taobao.tddl.client.sequence.exception.SequenceException;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoExportLogDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.StatisticsParamDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import com.zhongan.app.run.cms.common.constants.QrCodeConstants;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.csvutil.CSVUtil;
import com.zhongan.app.run.cms.common.csvutil.conver.DefaultConvert;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.thread.export.InsureStatisticsThread;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.StreamUtil;
import com.zhongan.app.run.cms.common.utils.UserUtil;
import com.zhongan.app.run.cms.dao.qrcode.BububaoExportLogDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoScanQrcodeLogDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoThirdOrgDao;
import com.zhongan.app.run.cms.service.qrcode.ScanInsureStatisticsService;
import com.zhongan.app.run.common.enums.YesOrNoEnum;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

@Slf4j
@Service("scanInsureStatisticsServiceImpl")
public class ScanInsureStatisticsServiceImpl implements ScanInsureStatisticsService {

    @Resource
    private BububaoThirdOrgDao      bububaoThirdOrgDao;
    @Resource
    private BububaoExportLogDao     bububaoExportLogDao;
    @Resource
    private BububaoScanQrcodeLogDao bububaoScanQrcodeLogDao;

    @Resource
    private OssTool                 ossTool;

    @Resource
    private ThreadPoolTaskExecutor  threadPoolStatistics;
    @Value("${qrcode.downLoadNums}")
    private String                  downLoadNums;
    @Value("${qrcode.downLoadFile}")
    private String                  downLoadFile;

    /**
     * 异步查询历史
     */
    @Override
    public BaseResult<PageDTO<BububaoExportLogDto>> asyncQueryHistory(BububaoExportLogDto bububaoExportLogDto) {
        log.info("{}-asyncQueryHistory,param={" + bububaoExportLogDto.toString() + "}");
        BaseResult<PageDTO<BububaoExportLogDto>> result = new BaseResult<PageDTO<BububaoExportLogDto>>();
        PageDTO<BububaoExportLogDto> page=new PageDTO<BububaoExportLogDto>();
        try {
            BububaoExportLogDO bububaoExportLogModel = new BububaoExportLogDO();
            BeanUtils.copyProperties(bububaoExportLogDto, bububaoExportLogModel);
            Integer currentPage = bububaoExportLogDto.getCurrentPage();
            Integer pageSize = bububaoExportLogDto.getPageSize();
            if (currentPage == null || currentPage == 0) {
                currentPage = 1;
            }
            if (pageSize == null || pageSize == 0) {
                pageSize = 50;
            }
            Integer start = (currentPage - 1) * pageSize;
            Integer end = currentPage * pageSize;
            Map<String, Object> map = Maps.newHashMap();
            map.put("startRow", start);
            map.put("pageSize", pageSize);
            map.put("bububaoExportLogModel", bububaoExportLogModel);
            List<BububaoExportLogDO> logDOList = bububaoExportLogDao.selectExportLogListPage(map);
            List<BububaoExportLogDto> logDtoList = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(logDOList)) {
                BububaoExportLogDto exportLogDto = null;
                for (BububaoExportLogDO out : logDOList) {
                    exportLogDto = new BububaoExportLogDto();
                    BeanUtils.copyProperties(out, exportLogDto);
                    exportLogDto.setGmtCreated(DateTimeUtils.convertDate2String(out.getGmtCreated(),
                            DateTimeUtils.ZH_CN_DATETIME_PATTERN));
                    String condition = out.getCondition();
                    returnCondition(condition, out, exportLogDto);
                    logDtoList.add(exportLogDto);
                }
            }
            Integer count = bububaoExportLogDao.selectCounts(map);
            page.setTotalItem(count);
            page.setResultList(logDtoList);
            page.setCurrentPage(currentPage);
            page.setPageSize(pageSize);
            result.setResult(page);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
            return result;
        } catch (Exception e) {
            log.error("异常ScanInsureStatisticsServiceImpl.asyncQueryHistory  fail……" + e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return null;
    }
  /*
   * 异步下载页条件分类返回
   */
    private void returnCondition(String condition, BububaoExportLogDO out, BububaoExportLogDto exportLogDto) {
        if (condition.contains("_")) {
            String[] conditionList = condition.split("_");
            if (out.getModuleCode() == 2) {
                exportLogDto.setOrgCondition(conditionList[0]);
                exportLogDto.setSalesCodeCondition(conditionList[1]);
            } else {
                exportLogDto.setOrgCondition(conditionList[0]);
                exportLogDto.setTimeCondition(conditionList[1]);
                if (conditionList.length == 3) {
                    exportLogDto.setSalesCodeCondition(conditionList[2]);
                }
            }
        } else {
            exportLogDto.setOrgCondition(condition);
        }

    }

    /**
     * 根据主键删除导出管理表
     */
    @Override
    public BaseResult<String> deleteExportLog(Long id) {
        log.info("{}-delete ExportLog info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        BaseResult<String> result = new BaseResult<String>();
        try {
            BububaoExportLogDO exportLogModel = bububaoExportLogDao.selectByPrimaryKey(id);
            String downloadUrl = exportLogModel.getDownloadUrl();
            BububaoExportLogDO bububaoExportLogModel = new BububaoExportLogDO();
            bububaoExportLogModel.setId(id);
            bububaoExportLogModel.setIsDeleted(YesOrNoEnum.YES.getCode());
            bububaoExportLogModel.setModifier(UserUtil.getUserInfo().getOperatorName());
            bububaoExportLogModel.setGmtModified(new Date());
            int count = bububaoExportLogDao.updateByPrimaryKeySelective(bububaoExportLogModel);
            int idx = downloadUrl.lastIndexOf("/");
            //获取文件名
            downloadUrl = downloadUrl.substring(idx + 1, downloadUrl.length());
            //从OSS删除文件
            ossTool.deleteFile(downloadUrl);
            result.setResult(String.valueOf(count));
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.error(
                    "{}-ExportLog delete fail,please find error to...。"
                            + "error ScanInsureStatisticsServiceImpl--deleteExportLog()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 导出excel
     */
    @Override
    public BaseResult<String> downLoadReports(StatisticsParamDto param) {
        BaseResult<String> result = new BaseResult<String>();
        try {
            //1.根据条件查询数据的条数
            List<ResultInsureDto>  allOrgs=bububaoScanQrcodeLogDao.selectStatisticsPage(param);
            //2.如果大于2万条异步下载
            if (allOrgs.size() > Integer.valueOf(downLoadNums)) {
                //插入导出管理记录
                Long id = insert(param);
                threadPoolStatistics
                        .execute(new InsureStatisticsThread(bububaoExportLogDao, allOrgs, ossTool, id, downLoadFile));
                result.setCode(AppErrEnum.SUCCESS_QRCODE_20000.getCode());
                result.setMessage(AppErrEnum.SUCCESS_QRCODE_20000.getValue());
                return result;
            }
            String url = doExportExcel(allOrgs);
            result.setResult(url);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.error(
                    "{}-ExportLog delete fail,please find error to...。"
                            + "error ScanInsureStatisticsServiceImpl--downLoadReports()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return result;
    }

    /**
     * 插入导出管理表数据
     * 
     * @throws SequenceException
     */
    public long insert(StatisticsParamDto param) throws SequenceException {
        BububaoExportLogDO exportLogDO = new BububaoExportLogDO();
        Date date = new Date();
        exportLogDO.setModuleCode(3);
        exportLogDO.setCondition(selectByPrimaryKey(param));
        exportLogDO.setStatus(1);
        exportLogDO.setUseTime(date);
        exportLogDO.setCreator(UserUtil.getUserInfo().getOperatorName());
        exportLogDO.setModifier(UserUtil.getUserInfo().getOperatorName());
        exportLogDO.setGmtCreated(date);
        exportLogDO.setGmtModified(date);
        exportLogDO.setIsDeleted("N");
        bububaoExportLogDao.insertSelective(exportLogDO);
        return exportLogDO.getId();
    }

    /**
     * 组装查询条件
     * 
     * @param param
     * @return
     */
    public String selectByPrimaryKey(StatisticsParamDto param) {
        StringBuffer conditionBuf = new StringBuffer();
        conditionBuf.append(bububaoThirdOrgDao.selectByPrimaryKey(param.getOneOrgId()).getOrgName());
        if (param.getTwoOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getTwoOrgId()).getOrgName());
        }
        if (param.getThreeOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getThreeOrgId()).getOrgName());
        }
        if (param.getFourOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getFourOrgId()).getOrgName());
        }
        if (param.getFiveOrgId() != null) {
            conditionBuf.append("-" + bububaoThirdOrgDao.selectByPrimaryKey(param.getFiveOrgId()).getOrgName());
        }

        conditionBuf.append("_" + param.getSdate().replaceAll("\\-", "/") + "-");
        conditionBuf.append(param.getEdate().replaceAll("\\-", "/"));
        if (StringUtil.isNotBlank(param.getSalesCode())) {
            conditionBuf.append("_" + param.getSalesCode());
        }
        return conditionBuf.toString();

    }

    /**
     * 下载Excel文件
     * 
     * @param response
     * @param allOrgs
     * @throws Exception
     */
    public String doExportExcel(List<ResultInsureDto> allOrgs) {
        log.info("{}-ScanInsureStatisticsServiceImpl.doExportExcel start...", ThreadLocalUtil.getRequestNo());
        ByteArrayOutputStream outputStream = null;
        String qrCodeUrl = null;
        try {
            outputStream = new ByteArrayOutputStream();
            CSVUtil.writeCSV(outputStream, ',', "utf-8", new DefaultConvert(),
                    QrCodeConstants.getStatisticsExportTitle(), allOrgs, QrCodeConstants.getStatisticsExportEnTitle(),
                    ResultInsureDto.class);
            String nowTime = DateTimeUtils.formatCurrentTime(DateTimeUtils.NOMARK_DATETIME_PATTERN);
            String fileName = RunConstants.UPLOAD_FILE_STATISTICS + nowTime;
            ossTool.uploadFile(StreamUtil.parse(outputStream), fileName);
            //组织下载url
            qrCodeUrl = downLoadFile +RunConstants.DOWNLOAD_URL + fileName;
        } catch (Exception e) {
            log.error("Exception:", e);
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (Exception e) {
                log.error("Exception:", e);
            }
        }
        return qrCodeUrl;
    }



    @Override
    public  BaseResult<PageDTO<ResultInsureDto>> selectStatisticsPage(StatisticsParamDto param) {
        BaseResult<PageDTO<ResultInsureDto>> baseResult = new  BaseResult<PageDTO<ResultInsureDto>>();
        PageDTO<ResultInsureDto> resultPage = new PageDTO<ResultInsureDto>();
        List<ResultInsureDto> resultOrgDtos = Lists.newArrayList();
        try {
            //计算分页开始索引
            Integer currentPage = param.getCurrentPage();
            Integer pageSize = param.getPageSize();
            if (currentPage == null || currentPage == 0) {
                currentPage = 1;
            }
            if (pageSize == null || pageSize == 0) {
                pageSize = 50;
            }
            Integer start = (currentPage - 1) * pageSize;
            Integer end = currentPage * pageSize;
            param.setStart(start);
            param.setEnd(end);
            //获取符合条件的统计数据
            int totleSize= bububaoScanQrcodeLogDao.selectStatisticsCounts(param);
            resultOrgDtos=bububaoScanQrcodeLogDao.selectStatisticsPage(param);
            //组织返回数据
            resultPage.setCurrentPage(currentPage);
            resultPage.setPageSize(pageSize);
            resultPage.setStartRow(start);
            resultPage.setTotalItem(totleSize);
            resultPage.setResultList(resultOrgDtos);
            baseResult.setResult(resultPage);
            baseResult.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            baseResult.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.info("异常===ScanInsureStatisticsServiceImpl.selectStatisticsPage fail", e);
            baseResult.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            baseResult.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        return baseResult;
    }
}
