package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoEmployeePinyinDO {
	
	private String id;//主键
	private String enterpriseCode;//企业号
	private String pinyinList;//拼音
	private String createTime;//创建时间
	private String modifyTime;//修改时间

}
