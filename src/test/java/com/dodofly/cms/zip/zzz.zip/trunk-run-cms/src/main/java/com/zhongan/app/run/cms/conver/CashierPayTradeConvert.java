package com.zhongan.app.run.cms.conver;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.math.NumberUtils;
import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeResDTO;
import com.zhongan.app.run.cms.common.enums.ChannelCodeTmpEnum;
import com.zhongan.app.run.cms.dao.bean.CashierPayTradeDO;
import com.zhongan.health.common.share.enm.YesOrNo;
import com.zhongan.health.common.utils.DateUtils;

public class CashierPayTradeConvert {

    @SuppressWarnings("rawtypes")
    public static List<CashierPayTradeResDTO> convertToDTOs(List<Map> results) {
        List<CashierPayTradeResDTO> cashierPayTradeResDTOs = Lists.newArrayList();
        if (CollectionUtils.isEmpty(results)) {
            return cashierPayTradeResDTOs;
        }
        CashierPayTradeResDTO cashierPayTradeResDTO = null;
        for (Map map : results) {
            cashierPayTradeResDTO = new CashierPayTradeResDTO();
            cashierPayTradeResDTO.setId((Long) map.get("id"));
            cashierPayTradeResDTO.setUserName((String) map.get("user_name"));
            cashierPayTradeResDTO.setPhone((String) map.get("phone"));
            cashierPayTradeResDTO.setCertNo((String) map.get("cert_no"));
            cashierPayTradeResDTO.setPolicyNo((String) map.get("policy_no"));
            cashierPayTradeResDTO.setDeductionsPay(new BigDecimal(String.valueOf(map.get("deductions_pay"))).setScale(
                    2, BigDecimal.ROUND_HALF_UP));
            cashierPayTradeResDTO.setDeductionsDate(DateUtils.formatDateYYYY_MM_DD_HH_MM_SS(DateUtils
                    .parseDateYYYY_MM_DD_HH_MM_SS(String.valueOf(map.get("deductions_date")))));
            cashierPayTradeResDTO.setDeductionsStatus(NumberUtils.createLong(String.valueOf(map
                    .get("deductions_status"))));
            cashierPayTradeResDTO.setOpenChannel(ChannelCodeTmpEnum.getEnumByCode((String) map.get("open_channel"))
                    .getValue());
            cashierPayTradeResDTO.setOpenStatus(NumberUtils.createLong(String.valueOf(map.get("open_stauts"))));
            cashierPayTradeResDTOs.add(cashierPayTradeResDTO);
        }
        return cashierPayTradeResDTOs;
    }

    public static CashierPayTradeDO convertToDO(CashierPayTradeDTO payTradeDTO) {
        CashierPayTradeDO cashierPayTradeDO = new CashierPayTradeDO();
        BeanUtils.copyProperties(payTradeDTO, cashierPayTradeDO, "deductionsDate");
        cashierPayTradeDO.setDeductionsDate(DateUtils.parseDateYYYY_MM_DD_HH_MM_SS(payTradeDTO.getDeductionsDate()));
        if (null == payTradeDTO.getId()) {
            cashierPayTradeDO.setCreator("system");
            cashierPayTradeDO.setGmtCreated(new Date());
            cashierPayTradeDO.setModifier("system");
            cashierPayTradeDO.setGmtModified(new Date());
            cashierPayTradeDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            cashierPayTradeDO.setModifier("system");
            cashierPayTradeDO.setGmtModified(new Date());
        }
        return cashierPayTradeDO;
    }

    public static CashierPayTradeResDTO convertTradeResDTO(List<CashierPayTradeDO> payTradeDOs) {
        CashierPayTradeResDTO cashierPayTradeResDTO = new CashierPayTradeResDTO();
        BeanUtils.copyProperties(payTradeDOs.get(0), cashierPayTradeResDTO, "deductionsDate");
        cashierPayTradeResDTO.setDeductionsDate(DateUtils.formatDateYYYY_MM_DD_HH_MM_SS(payTradeDOs.get(0)
                .getDeductionsDate()));
        return cashierPayTradeResDTO;
    }
}
