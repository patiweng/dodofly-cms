package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

/**
 * excel数据导入
 * 
 * @author lichao002
 * @date 2018-05-30
 */
@Data
public class ExcelDataDto {
    /**
     * 公司（渠道）id
     */
    private Long   oneOrgId;
    /**
     * 公司（渠道）名称
     */
    private String oneOrgName;
    /**
     * 二级组织id
     */
    private Long   twoOrgId;
    /**
     * 二级组织名称
     */
    private String twoOrgName;
    /**
     * 三级组织id
     */
    private Long   threeOrgId;
    /**
     * 三级组织名称
     */
    private String threeOrgName;
    /**
     * 四级组织id
     */
    private Long   fourOrgId;
    /**
     * 四级组织名称
     */
    private String fourOrgName;
    /**
     * 公司（机构）连接
     */
    private String qrcodeUrl;
    /**
     * 业务员id
     */
    private String salesId;

    /**
     * 业务员code
     */
    private String salesCode;
    /**
     * 是否是团队长
     */
    private String isLeader;

    /**
     * 是否关注步步保
     */
    private String isFollowBububao;
    /**
     * 开始时间
     */
    private String sdate;
    /**
     * 结束时间
     */
    private String edate;
}
