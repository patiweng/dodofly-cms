package com.zhongan.app.run.cms.service.impl;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.service.MarathonApplyService;
import com.zhongan.app.run.cms.service.client.RunActivityFeignClient;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class MarathonApplyServiceImpl implements MarathonApplyService {

    @Resource
    private RunActivityFeignClient runActivityFeignClient;

    @Resource
    private RedisUtil              redisUtil;

    @Override
    public String drawBigPrizes(String chromosphere, String flag) {
        String result = null;
        try {//flag 1:查询/保存 2：删除;  chromosphere 1：查询给的死值
            String chromosphereOld = redisUtil.getString(RunConstants.CHROMOSPHERE);
            //查询
            if (chromosphere.equals("1") && flag.equals("1")) {
                if (chromosphereOld != null) {
                    result = chromosphereOld;
                }
                return result;
            } else if (flag.equals("2")) {//删除
                redisUtil.delete(RunConstants.CHROMOSPHERE);
                redisUtil.delete(RunConstants.BIGPRIZE);
                log.info("redisUtil log chromosphere" + redisUtil.getString(RunConstants.CHROMOSPHERE));
                log.info("redisUtil log bigPrize" + redisUtil.getString(RunConstants.BIGPRIZE));
                return result;
            }
            //基数
            Long baseNum = 1000000L;
            // 马拉松总人数
            Long count = Long.valueOf(generateAllJoinInfo());
            Long winningNum = 0L;
            if (count > 0) {
                //计算马拉松大奖号码：双色球大奖号%马拉松总人数+基数
                winningNum = Long.valueOf(chromosphere) % count + baseNum;
            }
            //将计算出的大奖放入缓存
            redisUtil.put(RunConstants.BIGPRIZE, winningNum.toString());
            redisUtil.put(RunConstants.CHROMOSPHERE, chromosphere);
            result = chromosphere;
        } catch (Exception e) {
            log.error("{}-drawBigPrizes  fail,please find error to...。"
                    + "error location polynomial:MarathonApplyServiceImpl--drawBigPrizes()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    /**
     * 查询参加马拉松总人数
     * 
     * @return
     */
    private String generateAllJoinInfo() {
        ResultBase<String> resultBase = runActivityFeignClient.count();
        if (null != resultBase && resultBase.isSuccess()) {
            return resultBase.getValue();
        }
        return null;
    }

}
