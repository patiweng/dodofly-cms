package com.zhongan.app.run.cms.bean.web;

import java.math.BigDecimal;
import java.util.Date;

public class CashierNotifyDetailDTO {
    /**
     * 主键
     */
    private Long       id;

    /**
     * 代收代付ID
     */
    private Long       cashierId;

    /**
     * 订单号
     */
    private String     orderNo;

    /**
     * 订单号
     */
    private String     thirdOrderNo;

    /**
     * 渠道用户号
     */
    private String     payChannelUserNo;

    /**
     * 订单金额
     */
    private BigDecimal amt;

    /**
     * 订单时间
     */
    private Date       orderTime;

    /**
     * 回调信息,json格式
     */
    private String     notifyInfo;

    /**
     * 扩展信息,json格式
     */
    private String     extraInfo;

    /**
     * 创建人
     */
    private String     creator;

    /**
     * 创建时间
     */
    private Date       gmtCreated;

    /**
     * 修改人
     */
    private String     modifier;

    /**
     * 修改时间
     */
    private Date       gmtModified;

    /**
     * 是否删除
     */
    private String     isDeleted;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCashierId() {
        return cashierId;
    }

    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getThirdOrderNo() {
        return thirdOrderNo;
    }

    public void setThirdOrderNo(String thirdOrderNo) {
        this.thirdOrderNo = thirdOrderNo;
    }

    public String getPayChannelUserNo() {
        return payChannelUserNo;
    }

    public void setPayChannelUserNo(String payChannelUserNo) {
        this.payChannelUserNo = payChannelUserNo;
    }

    public BigDecimal getAmt() {
        return amt;
    }

    public void setAmt(BigDecimal amt) {
        this.amt = amt;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public String getNotifyInfo() {
        return notifyInfo;
    }

    public void setNotifyInfo(String notifyInfo) {
        this.notifyInfo = notifyInfo;
    }

    public String getExtraInfo() {
        return extraInfo;
    }

    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }

    public Date getGmtCreated() {
        return gmtCreated;
    }

    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    public String getModifier() {
        return modifier;
    }

    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    public Date getGmtModified() {
        return gmtModified;
    }

    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

}
