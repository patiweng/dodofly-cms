package com.zhongan.app.run.cms.conver;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductResDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelResDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductResDTO;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelDO;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelProductDO;
import com.zhongan.app.run.cms.dao.bean.RunElifeProductDO;
import com.zhongan.health.common.share.enm.YesOrNo;

public class RunElifeConvert {

    public static RunElifeChannelProductDTO convertChannelProductDTO(RunElifeChannelProductQueryDTO dto) {
        RunElifeChannelProductDTO channelProductDTO = new RunElifeChannelProductDTO();
        BeanUtils.copyProperties(dto, channelProductDTO);
        return channelProductDTO;
    }

    public static List<RunElifeChannelProductResDTO> convertChannelProductResDTOs(List<RunElifeChannelProductDO> channelProductDOs) {
        List<RunElifeChannelProductResDTO> dtos = Lists.newArrayList();
        channelProductDOs.forEach(channelProductDO -> {
            dtos.add(convertChannelProductResDTO(channelProductDO));
        });
        return dtos;
    }

    public static RunElifeChannelProductResDTO convertChannelProductResDTO(RunElifeChannelProductDO channelProductDO) {
        RunElifeChannelProductResDTO dto = new RunElifeChannelProductResDTO();
        BeanUtils.copyProperties(channelProductDO, dto);
        return dto;
    }

    public static RunElifeChannelProductDO converChannelProductDo(RunElifeChannelProductDTO dto) {
        RunElifeChannelProductDO channelProductDO = new RunElifeChannelProductDO();
        BeanUtils.copyProperties(dto, channelProductDO);
        if (null == dto.getId()) {
            channelProductDO.setCreator("system");
            channelProductDO.setGmtCreated(new Date());
            channelProductDO.setModifier("system");
            channelProductDO.setGmtModified(new Date());
            channelProductDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            channelProductDO.setModifier("system");
            channelProductDO.setGmtModified(new Date());
        }
        return channelProductDO;
    }

    public static List<RunElifeChannelProductResDTO> convertChannelProductDTO(List<RunElifeChannelProductDO> channelProductDOs) {
        if (CollectionUtils.isEmpty(channelProductDOs)) {
            return null;
        }
        List<RunElifeChannelProductResDTO> channelProductResDTOs = Lists.newArrayList();
        channelProductDOs.forEach(dto -> {
            channelProductResDTOs.add(convertChannelProductResDTO(dto));
        });
        return channelProductResDTOs;
    }

    public static RunElifeChannelDTO convertChannelDTO(RunElifeChannelQueryDTO dto) {
        RunElifeChannelDTO channelDTO = new RunElifeChannelDTO();
        BeanUtils.copyProperties(dto, channelDTO);
        return channelDTO;
    }

    public static List<RunElifeChannelResDTO> convertChannelResDTOs(List<RunElifeChannelDO> channelDOs) {
        List<RunElifeChannelResDTO> dtos = Lists.newArrayList();
        channelDOs.forEach(channelDO -> {
            dtos.add(convertChannelResDTO(channelDO));
        });
        return dtos;
    }

    public static RunElifeChannelResDTO convertChannelResDTO(RunElifeChannelDO channelDO) {
        RunElifeChannelResDTO dto = new RunElifeChannelResDTO();
        BeanUtils.copyProperties(channelDO, dto);
        return dto;
    }

    public static RunElifeChannelDO converChannelDo(RunElifeChannelDTO dto) {
        RunElifeChannelDO channelDO = new RunElifeChannelDO();
        BeanUtils.copyProperties(dto, channelDO);
        if (null == dto.getId()) {
            channelDO.setCreator("system");
            channelDO.setGmtCreated(new Date());
            channelDO.setModifier("system");
            channelDO.setGmtModified(new Date());
            channelDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            channelDO.setModifier("system");
            channelDO.setGmtModified(new Date());
        }
        return channelDO;
    }

    public static RunElifeChannelResDTO converChannelResDTO(List<RunElifeChannelDO> channelDOs) {
        if (CollectionUtils.isEmpty(channelDOs)) {
            return null;
        }
        return convertChannelResDTO(channelDOs.get(0));
    }

    public static RunElifeProductDTO convertProductDTO(RunElifeProductQueryDTO dto) {
        RunElifeProductDTO productDTO = new RunElifeProductDTO();
        BeanUtils.copyProperties(dto, productDTO);
        return productDTO;
    }

    public static List<RunElifeProductResDTO> convertProductResDTOs(List<RunElifeProductDO> productDOs) {
        List<RunElifeProductResDTO> dtos = Lists.newArrayList();
        productDOs.forEach(productDO -> {
            dtos.add(convertProductResDTO(productDO));
        });
        return dtos;
    }

    public static RunElifeProductResDTO convertProductResDTO(RunElifeProductDO productDO) {
        RunElifeProductResDTO dto = new RunElifeProductResDTO();
        BeanUtils.copyProperties(productDO, dto);
        return dto;
    }

    public static RunElifeProductResDTO convertProductResDTO(List<RunElifeProductDO> productDOs) {
        if (CollectionUtils.isEmpty(productDOs)) {
            return null;
        }
        return convertProductResDTO(productDOs.get(0));
    }

    public static RunElifeProductDO converProductDo(RunElifeProductDTO dto) {
        RunElifeProductDO proudctDO = new RunElifeProductDO();
        BeanUtils.copyProperties(dto, proudctDO);
        if (null == dto.getId()) {
            proudctDO.setCreator("system");
            proudctDO.setGmtCreated(new Date());
            proudctDO.setModifier("system");
            proudctDO.setGmtModified(new Date());
            proudctDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            proudctDO.setModifier("system");
            proudctDO.setGmtModified(new Date());
        }
        return proudctDO;
    }

}
