package com.zhongan.app.run.cms.repository;

import java.text.NumberFormat;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.ibm.icu.text.DecimalFormat;
import com.zhongan.app.run.cms.bean.dataobject.AnalysisMonitorDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.AnalysisMonitorRepo;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorDTO;
import com.zhongan.app.run.cms.dao.AnalysisMonitorDAO;

@Repository
public class AnalysisMonitorRepository {
    @Resource
    private AnalysisMonitorDAO analysisMonitorDAO;

    public Page<AnalysisMonitorRepo> selectAnalysisMonitorPage(Page<AnalysisMonitorDTO> analysisMonitorDTOPage) {
        Map<String, Object> map = Maps.newHashMap();
        getParamMap(analysisMonitorDTOPage, map);
        List<AnalysisMonitorDO> analysisMonitorDOList = analysisMonitorDAO.selectAnalysisMonitorlList(map);
        List<AnalysisMonitorRepo> analysisMonitorRepoList = Lists.newArrayList();
        if (analysisMonitorDOList != null && analysisMonitorDOList.size() > 0) {
            AnalysisMonitorRepo analysisMonitorRepo = new AnalysisMonitorRepo();
            for (AnalysisMonitorDO analysisMonitorDO1 : analysisMonitorDOList) {
                generateAnalysisMonitorDO(analysisMonitorDO1);
                AnalysisMonitorRepo clone = (AnalysisMonitorRepo) analysisMonitorRepo.clone();
                BeanUtils.copyProperties(analysisMonitorDO1, clone);
                clone.setInsureconverRate(formatPercentum(analysisMonitorDO1.getInsureconverRate()));
                clone.setInsuresucRate(formatPercentum(analysisMonitorDO1.getInsuresucRate()));
                clone.setInsureerrRate(formatPercentum(analysisMonitorDO1.getInsureerrRate()));
                analysisMonitorRepoList.add(clone);
            }
        }
        Page<AnalysisMonitorRepo> analysisMonitorRepoPage = new Page<AnalysisMonitorRepo>();
        analysisMonitorRepoPage.setResultList(analysisMonitorRepoList);
        Integer counts = analysisMonitorDAO.selectCounts(map);
        analysisMonitorRepoPage.setTotalItem(counts);
        return analysisMonitorRepoPage;
    }

    private void getParamMap(Page<AnalysisMonitorDTO> analysisMonitorDTOPage, Map<String, Object> map) {
        AnalysisMonitorDTO analysisMonitorDTO = analysisMonitorDTOPage.getParam();
        String bopsFlag = analysisMonitorDTO.getBopsFlag();
        map.put("startRow", analysisMonitorDTOPage.getStartRow());
        map.put("pageSize", analysisMonitorDTOPage.getPageSize());
        //从左侧菜单点过来的,列表不显示数据
        if ("1".equals(bopsFlag)) {
            map.put("sdate", "null");
            map.put("edate", "null");
        } else {
            map.put("sdate", analysisMonitorDTO.getSdate());
            map.put("edate", analysisMonitorDTO.getEdate());
        }
    }

    /**
     * 字符串转百分比
     * 
     * @param rate
     * @return
     */
    private String formatPercentum(String rate) {
        NumberFormat nf = NumberFormat.getPercentInstance();
        String format = nf.format(Double.valueOf(rate));
        return format;
    }

    private void generateAnalysisMonitorDO(AnalysisMonitorDO analysisMonitorDO) {
        String count001 = analysisMonitorDO.getHelloindexCount();
        analysisMonitorDO.setStallconverRate(countRate(analysisMonitorDO.getStallindexCount(), count001)); //档位跳转率
        analysisMonitorDO.setInsureconverRate(countRate(analysisMonitorDO.getInsureindexCount(), count001));//投保跳转率
        analysisMonitorDO.setInsuresucRate(countRate(analysisMonitorDO.getInsuresucCount(), count001));//投保成功率
        analysisMonitorDO.setInsureerrRate(countRate(analysisMonitorDO.getInsureerrCount(), count001));//投保失败率
    }

    private String countRate(String index, String count) {
        if (StringUtil.isBlank(index) || StringUtil.isBlank(count) || "0".equals(index) || "0".equals(count)) {
            return "0";
        }
        int index_ = Integer.valueOf(index);
        int count_ = Integer.valueOf(count);
        float num = (float) index_ / count_;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return s;
    }
}
