package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class RunElifeChannelProductDO {
    /**
     * This field corresponds to the column run_elife_channel_product.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 渠道id This field corresponds to the column
     * run_elife_channel_product.channel_id
     *
     * @mbggenerated
     */
    private Long   channelId;

    /**
     * 渠道名称 This field corresponds to the column
     * run_elife_channel_product.channel_name
     *
     * @mbggenerated
     */
    private String channelName;

    /**
     * 产品ID This field corresponds to the column
     * run_elife_channel_product.product_id
     *
     * @mbggenerated
     */
    private Long   productId;

    /**
     * 产品名称 This field corresponds to the column
     * run_elife_channel_product.product_name
     *
     * @mbggenerated
     */
    private String productName;

    /**
     * 营销活动ID This field corresponds to the column
     * run_elife_channel_product.campaign_def_id
     *
     * @mbggenerated
     */
    private Long   campaignDefId;

    /**
     * 营销活动名称 This field corresponds to the column
     * run_elife_channel_product.campaign_def_name
     *
     * @mbggenerated
     */
    private String campaignDefName;

    /**
     * 扩展信息,json格式 This field corresponds to the column
     * run_elife_channel_product.extra_info
     *
     * @mbggenerated
     */
    private String extraInfo;

    /**
     * 创建人 This field corresponds to the column
     * run_elife_channel_product.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 创建时间 This field corresponds to the column
     * run_elife_channel_product.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改人 This field corresponds to the column
     * run_elife_channel_product.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 修改时间 This field corresponds to the column
     * run_elife_channel_product.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * This field corresponds to the column run_elife_channel_product.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /** @mbggenerated
     */
    public RunElifeChannelProductDO(Long id, Long channelId, String channelName, Long productId, String productName,
                                    Long campaignDefId, String campaignDefName, String extraInfo, String creator,
                                    Date gmtCreated, String modifier, Date gmtModified, String isDeleted) {
        this.id = id;
        this.channelId = channelId;
        this.channelName = channelName;
        this.productId = productId;
        this.productName = productName;
        this.campaignDefId = campaignDefId;
        this.campaignDefName = campaignDefName;
        this.extraInfo = extraInfo;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /** @mbggenerated
     */
    public RunElifeChannelProductDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.id
     *
     * @return the value of run_elife_channel_product.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column run_elife_channel_product.id
     *
     * @param id the value for run_elife_channel_product.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.channel_id
     *
     * @return the value of run_elife_channel_product.channel_id
     * @mbggenerated
     */
    public Long getChannelId() {
        return channelId;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.channel_id
     *
     * @param channelId the value for run_elife_channel_product.channel_id
     * @mbggenerated
     */
    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.channel_name
     *
     * @return the value of run_elife_channel_product.channel_name
     * @mbggenerated
     */
    public String getChannelName() {
        return channelName;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.channel_name
     *
     * @param channelName the value for run_elife_channel_product.channel_name
     * @mbggenerated
     */
    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.product_id
     *
     * @return the value of run_elife_channel_product.product_id
     * @mbggenerated
     */
    public Long getProductId() {
        return productId;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.product_id
     *
     * @param productId the value for run_elife_channel_product.product_id
     * @mbggenerated
     */
    public void setProductId(Long productId) {
        this.productId = productId;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.product_name
     *
     * @return the value of run_elife_channel_product.product_name
     * @mbggenerated
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.product_name
     *
     * @param productName the value for run_elife_channel_product.product_name
     * @mbggenerated
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.campaign_def_id
     *
     * @return the value of run_elife_channel_product.campaign_def_id
     * @mbggenerated
     */
    public Long getCampaignDefId() {
        return campaignDefId;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.campaign_def_id
     *
     * @param campaignDefId the value for
     *            run_elife_channel_product.campaign_def_id
     * @mbggenerated
     */
    public void setCampaignDefId(Long campaignDefId) {
        this.campaignDefId = campaignDefId;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.campaign_def_name
     *
     * @return the value of run_elife_channel_product.campaign_def_name
     * @mbggenerated
     */
    public String getCampaignDefName() {
        return campaignDefName;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.campaign_def_name
     *
     * @param campaignDefName the value for
     *            run_elife_channel_product.campaign_def_name
     * @mbggenerated
     */
    public void setCampaignDefName(String campaignDefName) {
        this.campaignDefName = campaignDefName;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.extra_info
     *
     * @return the value of run_elife_channel_product.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.extra_info
     *
     * @param extraInfo the value for run_elife_channel_product.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.creator
     *
     * @return the value of run_elife_channel_product.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column run_elife_channel_product.creator
     *
     * @param creator the value for run_elife_channel_product.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.gmt_created
     *
     * @return the value of run_elife_channel_product.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.gmt_created
     *
     * @param gmtCreated the value for run_elife_channel_product.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.modifier
     *
     * @return the value of run_elife_channel_product.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column run_elife_channel_product.modifier
     *
     * @param modifier the value for run_elife_channel_product.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.gmt_modified
     *
     * @return the value of run_elife_channel_product.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.gmt_modified
     *
     * @param gmtModified the value for run_elife_channel_product.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * run_elife_channel_product.is_deleted
     *
     * @return the value of run_elife_channel_product.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column
     * run_elife_channel_product.is_deleted
     *
     * @param isDeleted the value for run_elife_channel_product.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
