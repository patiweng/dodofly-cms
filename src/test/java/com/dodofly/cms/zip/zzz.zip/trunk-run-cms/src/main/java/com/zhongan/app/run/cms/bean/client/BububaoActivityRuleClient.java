package com.zhongan.app.run.cms.bean.client;

import java.util.Date;

import lombok.Data;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.ActivityRuleInfoDTO;

/**
 * @author yangzhen001
 */
@Data
public class BububaoActivityRuleClient extends PageInfo {

    private static final long   serialVersionUID = 1L;
    /**
     * 主键
     */
    private Long                id;

    /**
     * 活动id
     */
    private Long                activityId;

    /**
     * 规则名称
     */
    private String              ruleName;

    /**
     * 渠道
     */
    private String              source;

    /**
     * 规则
     */
    private String              activityRule;

    /**
     * 创建者
     */
    private String              creator;

    /**
     * 修改者
     */
    private String              modifier;

    /**
     * 创建时间
     */
    private Date                gmtCreated;

    /**
     * 修改时间
     */
    private Date                gmtModified;

    /**
     * 是否删除(Y/N，默认为:N)
     */
    private String              isDeleted;

    /**
     * 扩展信息
     */
    private String              extraInfo;
    /**
     * 规则详细信息
     */
    private ActivityRuleInfoDTO ruleInfo;

}
