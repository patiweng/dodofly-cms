package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.bo.ActivityPresentBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.ActivityPresentListPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface ActivityPresentService {

    public ResultBase<List<ActivityPresentDTO>> selectActivityPresentData(ActivityPresentBO activityPresentBO);
    
    public ActivityPresentListPageDTO selectActivityPresentPage(Page<ActivityPresentDTO> activityPresentListPage);

    public ResultBase<String> deleteActivityPresent(String id);
    
    public ActivityPresentDTO selectDataByid(String id);
    
    public ResultBase<String> updateActivityPresentLists(String id);
    
    public ResultBase<String> insertActivityPresentData(ActivityPresentBO activityPresentBO);

    public ResultBase<String> updateActivityPresentData(ActivityPresentBO activityPresentBO);

}
