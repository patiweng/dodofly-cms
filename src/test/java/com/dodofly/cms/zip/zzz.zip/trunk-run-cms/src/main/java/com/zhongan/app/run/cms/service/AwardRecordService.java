package com.zhongan.app.run.cms.service;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AwardRecordDTO;
import com.zhongan.app.run.cms.bean.web.AwardRecordPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface AwardRecordService {

    /**
     * 分页查询用户奖励记录表
     * 
     * @param page
     * @return
     */
    AwardRecordPageDTO selectAwardRecordListPage(Page<AwardRecordDTO> page);

    /**
     * 根据id查询一条
     * 
     * @param id
     * @return
     */
    ResultBase<AwardRecordDTO> selectAwardRecordOne(String id);

    /**
     * 更新
     * 
     * @param AwardRecordDTO
     * @return
     */
    ResultBase<String> updateById(AwardRecordDTO awardRecordDTO);

    /**
     * 获取数据渲染礼物名称下拉框
     * 
     * @param identify
     * @return
     */
    ResultBase<String> getPresentNameArrList(String identify);

    /**
     * 导出excel
     * 
     * @param awardRecordDTO
     */
    void doExportExcel(HttpServletResponse response, AwardRecordDTO awardRecordDTO);

    /**
     * 根据
     * 
     * @param awardRecordDTO
     * @return
     */
    ResultBase<List<AwardRecordDTO>> selectDataByCdt(AwardRecordDTO awardRecordDTO);
}
