package com.zhongan.app.run.cms.bean.qrcode.dto;

import com.zhongan.app.run.cms.common.csvutil.annotion.Property;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;

@Slf4j
@Data
public class ResultSalesDto extends ResultOrgDto implements Cloneable {

    /**
     * 一级组织名称
     */
    @Property(title = "oneOrgName")
    private String oneOrgName;
    /**
     * 二级组织名称
     */
    @Property(title = "twoOrgName")
    private String twoOrgName;
    /**
     * 三级组织名称
     */
    @Property(title = "threeOrgName")
    private String threeOrgName;
    /**
     * 四级组织名称
     */
    @Property(title = "fourOrgName")
    private String fourOrgName;
    /**
     * 五级组织名称
     */
    @Property(title = "fiveOrgName")
    private String fiveOrgName;
    /**
     * 业务员id
     */
    private Long   salesId;

    /**
     * 业务员code
     */
    @Property(title = "salesCode")
    private String salesCode;

    /**
     * 是否是团长
     */
    private String isLeader;

    /**
     * 深克隆
     * 
     * @return
     */
    public ResultSalesDto clone() {
        ResultSalesDto resultSalesDto = null;
        try {
            resultSalesDto = (ResultSalesDto) super.clone();
        } catch (Exception e) {
            resultSalesDto = new ResultSalesDto();
            BeanUtils.copyProperties(this, resultSalesDto);
        }
        return resultSalesDto;
    }
}
