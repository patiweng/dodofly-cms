package com.zhongan.app.run.cms.service.qrcode.impl;

import com.google.common.collect.Lists;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoChannelListDO;
import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultOrgDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoScanQrcodeLogDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdOrgDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdSalesDO;
import com.zhongan.app.run.cms.common.csvutil.CSVUtil;
import com.zhongan.app.run.cms.common.csvutil.conver.MapConvert;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.thread.export.OrgExportThread;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.PinyinUtil;
import com.zhongan.app.run.cms.common.utils.UserUtil;
import com.zhongan.app.run.cms.dao.BububaoChannelListDAO;
import com.zhongan.app.run.cms.dao.qrcode.BububaoExportLogDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoScanQrcodeLogDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoThirdOrgDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoThirdQrcodeDao;
import com.zhongan.app.run.cms.dao.qrcode.BububaoThirdSalesDao;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdOrgService;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdQrcodeService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
@Service
public class BububaoThirdOrgServiceImpl implements BububaoThirdOrgService {

    @Value("${qrcode.downLoadFile}")
    private String                    downLoadFile;

    @Value("${za.run.img.domain.url}")
    private String                    bububao_domain;

    @Resource
    private OssTool                   ossTool;

    @Resource
    private Sequence                  seqChannelList;

    @Resource
    private ThreadPoolTaskExecutor    threadPoolOrg;

    @Resource
    private BububaoThirdOrgDao        bububaoThirdOrgDao;

    @Resource
    private BububaoThirdSalesDao      bububaoThirdSalesDao;

    @Resource
    private BububaoThirdQrcodeDao     bububaoThirdQrcodeDao;

    @Resource
    private BububaoChannelListDAO     bububaoChannelListDAO;

    @Resource
    private BububaoExportLogDao       bububaoExportLogDao;

    @Resource
    private BububaoScanQrcodeLogDao   bububaoScanQrcodeLogDao;

    @Resource
    private BububaoThirdQrcodeService bububaoThirdQrcodeServiceImpl;

    @Override
    public BaseResult<String> insertBatchOrgs(HttpServletRequest request, String fileName, String fileFormat) {
        //获取当前操作用户
        String creatName = UserUtil.getUserInfo().getOperatorName();
        log.info(
                "{}---------------BububaoThirdOrgServiceImpl.batchSaveOrg-------------start,fileName:{},fileFormat:{},creatName:{}",
                ThreadLocalUtil.getRequestNo(), fileName, fileFormat, creatName);
        BaseResult<String> result = new BaseResult<String>();
        // 转型为MultipartHttpRequest：
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        // 获得文件：
        MultipartFile multipartFile = multipartRequest.getFile(fileName);
        // 获得文件名：
        String filename = multipartFile.getOriginalFilename();
        String format = filename.substring(filename.lastIndexOf(".") + 1);
        if (!fileFormat.equals(format.toLowerCase())) {
            log.error("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------文件格式错误：",
                    ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.FILE_FORMAT_ERROR.getCode());
            result.setMessage(AppErrEnum.FILE_FORMAT_ERROR.getValue());
            return result;
        }
        InputStream inputStream = null;
        List<HashMap> excelDataDtos = null;
        try {
            inputStream = multipartFile.getInputStream();
            //读取csv文件
            excelDataDtos = CSVUtil.readCSVToMap(inputStream, ',', "gbk", new MapConvert(), HashMap.class);
            StringBuffer buffer = new StringBuffer();
            buffer.append(System.currentTimeMillis()).append("_").append(filename);
            String url = ossTool.uploadFile(inputStream, buffer.toString());
            log.info("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------文件上传oss：{},name:{}",
                    ThreadLocalUtil.getRequestNo(), url, creatName);
        } catch (Exception e) {
            log.error("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------exception：",
                    ThreadLocalUtil.getRequestNo(), e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
            return result;
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Exception e) {
                log.error("{}-------------BububaoThirdOrgServiceImpl.batchSaveOrg----------------exception：",
                        ThreadLocalUtil.getRequestNo(), e);
            }
        }
        log.info("{}---------------BububaoThirdOrgServiceImpl.batchSaveOrg------------获取csv文件数据，count:{}",
                ThreadLocalUtil.getRequestNo(), (excelDataDtos == null ? 0 : excelDataDtos.size()));
        //循环保存机构信息
        loopBatchSaveOrgs(excelDataDtos, creatName);
        //组织返回值信息
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        log.info("{}---------------BububaoThirdOrgServiceImpl.batchSaveOrg-------------end",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    @Override
    public BaseResult<PageDTO<ResultOrgDto>> findOrgsPage(ParamDto param) {
        log.info("{}----------------BububaoThirdOrgServiceImpl.findOrgsPage-----------start,param:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<PageDTO<ResultOrgDto>> baseResult = new BaseResult<PageDTO<ResultOrgDto>>();
        //计算分页开始索引
        Integer currentPage = param.getCurrentPage();
        Integer pageSize = param.getPageSize();
        if (currentPage == null || currentPage == 0) {
            currentPage = 1;
        }
        if (pageSize == null || pageSize == 0) {
            pageSize = 50;
        }
        Integer start = (currentPage - 1) * pageSize;
        Integer end = currentPage * pageSize;
        param.setStart(start);
        param.setEnd(end);
        param.setUrl(bububao_domain);
        //获取符合条件的机构数
        Integer totleSize = bububaoThirdOrgDao.selectOrgsCount(param);
        log.info("{}----------------BububaoThirdOrgServiceImpl.findOrgsPage-----------查询总数：{}",
                ThreadLocalUtil.getRequestNo(), totleSize);
        List<ResultOrgDto> resultOrgDtos = bububaoThirdOrgDao.selectOrgsPage(param);
        //组织返回值
        baseResult.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        baseResult.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        //组织分页数据
        PageDTO<ResultOrgDto> page = new PageDTO<ResultOrgDto>();
        page.setCurrentPage(currentPage);
        page.setPageSize(pageSize);
        page.setTotalItem(totleSize);
        page.setResultList(resultOrgDtos);
        baseResult.setResult(page);
        log.info("{}----------------BububaoThirdOrgServiceImpl.findOrgsPage-----------end,result:{}",
                ThreadLocalUtil.getRequestNo(), baseResult);
        return baseResult;
    }

    @Override
    public BaseResult<String> deleteBatchOrgs(List<ParamDto> params) {
        log.info("{}----------------BububaoThirdOrgServiceImpl.deleteBatchOrgs-----------start,params:{}",
                ThreadLocalUtil.getRequestNo(), params);
        BaseResult<String> result = new BaseResult<String>();
        //判断删除数据是否为空
        if (CollectionUtils.isEmpty(params)) {
            log.info("{}----------------BububaoThirdOrgServiceImpl.deleteBatchOrgs-----删除数据为空------end",
                    ThreadLocalUtil.getRequestNo());
            result.setCode(AppErrEnum.DELETE_INFO_NULL.getCode());
            result.setMessage(AppErrEnum.DELETE_INFO_NULL.getValue());
            return result;
        }
        //获取当前操作用户
        String modifiedName = UserUtil.getUserInfo().getOperatorName();
        if (StringUtils.isBlank(modifiedName)) {
            modifiedName = "SYSTEM";
        }
        int index = 1;
        //遍历删除数据,判断是否存在投保数据
        for (ParamDto param : params) {
            Long oneOrgId = param.getOneOrgId();
            Long twoOrgId = param.getTwoOrgId();
            Long threeOrgId = param.getThreeOrgId();
            Long fourOrgId = param.getFourOrgId();
            Long fiveOrgId = param.getFiveOrgId();
            List<Long> orgIds = Lists.newArrayList(fiveOrgId, fourOrgId, threeOrgId, twoOrgId, oneOrgId);
            //判断是否存在投保
            if (isExistInsure(orgIds)) {
                log.info(
                        "{}----------------BububaoThirdOrgServiceImpl.deleteBatchOrgs------删除数据存在投保数据-----end，orgId:{}",
                        ThreadLocalUtil.getRequestNo(), orgIds);
                result.setCode(AppErrEnum.DELETE_INFO_EXIST_INSURE.getCode());
                result.setMessage(String.format(AppErrEnum.DELETE_INFO_EXIST_INSURE.getValue(), index));
                return result;
            }
            index++;
        }
        //遍历删除机构信息
        for (ParamDto param : params) {
            Long oneOrgId = param.getOneOrgId();
            Long twoOrgId = param.getTwoOrgId();
            Long threeOrgId = param.getThreeOrgId();
            Long fourOrgId = param.getFourOrgId();
            Long fiveOrgId = param.getFiveOrgId();
            List<Long> orgIds = Lists.newArrayList(fiveOrgId, fourOrgId, threeOrgId, twoOrgId, oneOrgId);
            Long qrcodeId = param.getQrcodeId();
            bububaoThirdQrcodeDao.deleteByQrcodeId(qrcodeId, modifiedName);
            deleteScanLog(orgIds, modifiedName);
            //逐级删除机构信息
            iterationDelete(orgIds, modifiedName);
        }
        //组织返回值信息
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        log.info("{}----------------BububaoThirdOrgServiceImpl.deleteBatchOrgs-----------end",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    @Override
    public BaseResult<String> exportOrgs(ParamDto param) {
        log.info("{}----------------BububaoThirdOrgServiceImpl.exportOrgs-----------start,param:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<String> result = new BaseResult<String>();
        List<ParamDto> datas = param.getDatas();
        List<ResultOrgDto> allOrgs = null;
        //判断是否全部导出
        if (CollectionUtils.isEmpty(datas)) {
            log.info("{}----------------BububaoThirdOrgServiceImpl.exportOrgs-----------导出符合条件的所有数据",
                    ThreadLocalUtil.getRequestNo());
            allOrgs = bububaoThirdOrgDao.selectOrgsPage(param);
        } else {
            log.info("{}----------------BububaoThirdOrgServiceImpl.exportOrgs-----------导出部分数据",
                    ThreadLocalUtil.getRequestNo());
            allOrgs = Lists.newArrayList();
            //遍历组织导出数据
            for (ParamDto paramDto : datas) {
                ResultOrgDto resultOrgDto = new ResultOrgDto();
                Long oneOrgId = paramDto.getOneOrgId();
                Long twoOrgId = paramDto.getTwoOrgId();
                Long threeOrgId = paramDto.getThreeOrgId();
                Long fourOrgId = paramDto.getFourOrgId();
                Long fiveOrgId = paramDto.getFiveOrgId();
                Long qrcodeId = paramDto.getQrcodeId();
                if (qrcodeId == null) {
                    continue;
                }
                //组织导出信息-二维码信息
                resultOrgDto.setQrcodeUrl(bububaoThirdQrcodeDao.selectUrlByQrcodeId(qrcodeId));
                if (oneOrgId == null) {
                    continue;
                }
                //组织导出信息-一级机构信息
                resultOrgDto.setOneOrgName(bububaoThirdOrgDao.selectNameById(oneOrgId));
                if (twoOrgId != null) {
                    //组织导出信息-二级机构信息
                    resultOrgDto.setTwoOrgName(bububaoThirdOrgDao.selectNameById(twoOrgId));
                    if (threeOrgId != null) {
                        //组织导出信息-三级机构信息
                        resultOrgDto.setThreeOrgName(bububaoThirdOrgDao.selectNameById(threeOrgId));
                        if (fourOrgId != null) {
                            //组织导出信息-四级机构信息
                            resultOrgDto.setFourOrgName(bububaoThirdOrgDao.selectNameById(fourOrgId));
                            if (fiveOrgId != null) {
                                //组织导出信息-五级机构信息
                                resultOrgDto.setFiveOrgName(bububaoThirdOrgDao.selectNameById(fiveOrgId));
                            }
                        }
                    }
                }
                allOrgs.add(resultOrgDto);
            }
        }
        //获取当前操作用户
        String exportName = UserUtil.getUserInfo().getOperatorName();
        if (StringUtils.isBlank(exportName)) {
            exportName = "SYSTEM";
        }
        Date date = new Date();
        //组织导出历史条件信息
        StringBuffer buffer = new StringBuffer();
        if (param.getOneOrgId() != null) {
            //组织导出条件-一级机构信息
            buffer.append(bububaoThirdOrgDao.selectNameById(param.getOneOrgId()));
            if (param.getTwoOrgId() != null) {
                //组织导出条件-二级机构信息
                buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getTwoOrgId()));
                if (param.getThreeOrgId() != null) {
                    //组织导出条件-三级机构信息
                    buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getThreeOrgId()));
                    if (param.getFourOrgId() != null) {
                        //组织导出条件-四级机构信息
                        buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getFourOrgId()));
                        if (param.getFiveOrgId() != null) {
                            //组织导出条件-五级机构信息
                            buffer.append("-").append(bububaoThirdOrgDao.selectNameById(param.getFiveOrgId()));
                        }
                    }
                }
            }
        }
        //组织导出历史信息
        BububaoExportLogDO exportLog = new BububaoExportLogDO();
        exportLog.setModuleCode(1);
        exportLog.setCondition(buffer.toString());
        exportLog.setStatus(1);
        exportLog.setUseTime(date);
        exportLog.setIsDeleted("N");
        exportLog.setCreator(exportName);
        exportLog.setGmtCreated(date);
        exportLog.setModifier(exportName);
        exportLog.setGmtModified(date);
        bububaoExportLogDao.insertSelective(exportLog);
        //线程池启动线程
        threadPoolOrg.execute(new OrgExportThread(bububaoExportLogDao, allOrgs, ossTool, exportLog, downLoadFile));
        //组织返回值信息
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        log.info("{}----------------BububaoThirdOrgServiceImpl.exportOrgs-----------end",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    @Override
    public BaseResult<List<BububaoThirdOrgDO>> selectCondition(Long orgId) {
        log.info("{}----------------BububaoThirdOrgServiceImpl.exportOrgs-----------start,orgId:{}",
                ThreadLocalUtil.getRequestNo(), orgId);
        BaseResult<List<BububaoThirdOrgDO>> result = new BaseResult<List<BububaoThirdOrgDO>>();
        if (orgId == null) {
            orgId = 0L;
        }
        //组织条件信息
        BububaoThirdOrgDO record = new BububaoThirdOrgDO();
        record.setParentOrgId(orgId);
        List<BububaoThirdOrgDO> orgModels = bububaoThirdOrgDao.selectByParentIdAndId(record);
        //组织返回值信息
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        result.setResult(orgModels);
        log.info("{}----------------BububaoThirdOrgServiceImpl.exportOrgs-----------end",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 遍历存储机构信息
     * 
     * @param excelDataDtos
     */
    private void loopBatchSaveOrgs(List<HashMap> excelDataDtos, String creatName) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.loopBatchSaveOrgs----------start",
                ThreadLocalUtil.getRequestNo());
        //判断存入数据为空
        if (CollectionUtils.isEmpty(excelDataDtos)) {
            log.info("{}--------------BububaoThirdOrgServiceImpl.loopBatchSaveOrgs----------end,excelDataDtos:{}",
                    ThreadLocalUtil.getRequestNo(), excelDataDtos);
            return;
        }
        if (StringUtils.isBlank(creatName)) {
            creatName = "SYSTEM";
        }
        Date date = new Date();
        List<BububaoThirdOrgDO> list = Lists.newArrayList();
        //遍历存入数据
        for (Map<String, String> data : excelDataDtos) {
            //获取是否关注步步保
            String isFollowBububao = data.get("isFollowBububao");
            if (StringUtils.isBlank(isFollowBububao)) {
                isFollowBububao = "N";
            }
            //获取一级机构名称
            String parentOrgName = data.get("org_1");
            if (StringUtils.isBlank(parentOrgName)) {
                continue;
            }
            //获取二级机构名称
            String childOrgName = data.get("org_2");
            if (CollectionUtils.isEmpty(list)) {
                list.add(new BububaoThirdOrgDO());
            }
            //保存一级机构信息
            BububaoThirdOrgDO org1 = saveOrFindOrg(list.get(0), creatName, parentOrgName, childOrgName, isFollowBububao,
                    0L, 1, null, "Wechat_" + PinyinUtil.getInitials(parentOrgName), date);
            list.remove(0);
            list.add(0, org1);
            int i = 2;
            //逐级存入机构信息
            while (true) {
                if (list.size() < i) {
                    list.add(new BububaoThirdOrgDO());
                }
                //获取父级机构名称
                parentOrgName = data.get("org_" + i);
                if (StringUtils.isBlank(parentOrgName)) {
                    break;
                }
                //获取子级机构名称
                childOrgName = data.get("org_" + (i + 1));
                //保存父级机构信息
                BububaoThirdOrgDO org = saveOrFindOrg(list.get(i - 1), creatName, parentOrgName, childOrgName,
                        isFollowBububao, list.get(i - 2).getId(), i, list.get(i - 2).getChannelId(),
                        list.get(i - 2).getOrgCode(), date);
                list.remove(i - 1);
                list.add(i - 1, org);
                i++;
            }

        }
        log.info("{}--------------BububaoThirdOrgServiceImpl.loopBatchSaveOrgs----------end",
                ThreadLocalUtil.getRequestNo());
    }

    /**
     * 保存或者查找机构信息
     * 
     * @param org
     * @param creatName
     * @param parentOrgName
     * @param childOrgName
     * @param isFollowBububao
     * @param parentId
     * @param orgLevel
     * @param channelId
     * @param orgCode
     * @param date
     * @return
     */
    private BububaoThirdOrgDO saveOrFindOrg(BububaoThirdOrgDO org, String creatName, String parentOrgName,
                                            String childOrgName, String isFollowBububao, Long parentId,
                                            Integer orgLevel, Long channelId, String orgCode, Date date) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.saveOrFindOrg----------start",
                ThreadLocalUtil.getRequestNo());
        if (!parentOrgName.equals(org.getOrgName())) {
            //组织查询信息
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("orgName", parentOrgName);
            map.put("orgLevel", orgLevel);
            map.put("parentOrgId", parentId);
            List<BububaoThirdOrgDO> orgModels = bububaoThirdOrgDao.selectByInfo(map);
            //判断是否存在机构信息
            if (CollectionUtils.isEmpty(orgModels)) {
                //获取该机构code数
                int count = bububaoThirdOrgDao.selectByCode(orgCode, parentId) + 1;
                //组织机构code
                org.setOrgCode(orgCode + "_" + count);
                if (channelId == null) {
                    //获取渠道id
                    channelId = getChannelId(parentOrgName, org.getOrgCode(), creatName, date);
                }
                //组织机构信息
                org.setChannelId(channelId);
                org.setCreator(creatName);
                org.setGmtCreated(date);
                org.setGmtModified(date);
                org.setIsDeleted("N");
                org.setModifier(creatName);
                org.setOrgLevel(orgLevel);
                org.setParentOrgId(parentId);
                org.setOrgName(parentOrgName);
                org.setId(null);
                if (StringUtils.isBlank(childOrgName)) {
                    org.setIsOrgAgent("Y");

                    org.setIsFollowBububao(isFollowBububao);

                } else {
                    org.setIsOrgAgent("N");
                }
                bububaoThirdOrgDao.insertSelective(org);

                if (StringUtils.isBlank(childOrgName)) {
                    //生成二维码信息
                    bububaoThirdQrcodeServiceImpl.makeAndInsertQrcode(org.getOrgCode(), org.getId(),
                            org.getIsFollowBububao(), 1, creatName);
                }
            } else {
                //获取机构信息
                org = orgModels.get(0);
                updateOrgAndMakeQrcode(org, creatName, childOrgName);
            }

        } else {
            updateOrgAndMakeQrcode(org, creatName, childOrgName);
        }
        log.info("{}--------------BububaoThirdOrgServiceImpl.saveOrFindOrg----------end",
                ThreadLocalUtil.getRequestNo());
        return org;
    }

    private void updateOrgAndMakeQrcode(BububaoThirdOrgDO org, String creatName, String childOrgName) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.updateOrgAndMakeQrcode----------start",
                ThreadLocalUtil.getRequestNo());
        //判断子机构为空，则机构为可销售机构
        if (StringUtils.isBlank(childOrgName)) {
            //如果该机构未设置为可销售，则修改
            if ("N".equals(org.getIsOrgAgent())) {
                org.setIsOrgAgent("Y");
                org.setIsFollowBububao(org.getIsFollowBububao());
                org.setModifier(creatName);
                org.setGmtModified(new Date());
                bububaoThirdOrgDao.updateByPrimaryKeySelective(org);
                if (StringUtils.isBlank(childOrgName)) {
                    bububaoThirdQrcodeServiceImpl.makeAndInsertQrcode(org.getOrgCode(), org.getId(),
                            org.getIsFollowBububao(), 1, creatName);
                }
            }
        }
        log.info("{}--------------BububaoThirdOrgServiceImpl.updateOrgAndMakeQrcode----------end",
                ThreadLocalUtil.getRequestNo());
    }

    /**
     * 保存或获取渠道信息并返回渠道id
     * 
     * @param name
     * @param code
     * @param creatName
     * @param date
     * @return
     */
    private Long getChannelId(String name, String code, String creatName, Date date) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.getChannelId----------start",
                ThreadLocalUtil.getRequestNo());
        if (StringUtils.isBlank(name) || StringUtils.isBlank(code))
            return null;
        String nullStr = "待完善";
        BububaoChannelListDO channel = new BububaoChannelListDO();
        channel.setNo(code);
        channel.setType("1");
        //查询渠道信息
        List<BububaoChannelListDO> resultlist = bububaoChannelListDAO.selectDataByCdt(channel);
        if (CollectionUtils.isNotEmpty(resultlist)) {
            return new Long(resultlist.get(0).getId());
        }
        //组织渠道信息
        Long channelId = null;
        channel.setName(name);
        channel.setCreater(creatName);
        channel.setCreateTime(DateTimeUtils.convertDate2String(date, DateTimeUtils.ZH_CN_DATETIME_PATTERN));
        channel.setTitle("步步保");
        channel.setOwnPlatForm("0");
        channel.setStatus("0");
        channel.setDeleteTime(DateTimeUtils.convertDate2String(date, DateTimeUtils.ZH_CN_DATETIME_PATTERN));
        channel.setPay("wxpay^alipay");
        channel.setUrl(nullStr);
        channel.setMomentsTitle(nullStr);
        channel.setMomentsUrl(nullStr);
        channel.setFriendTitle(nullStr);
        channel.setFriendUrl(nullStr);
        channel.setFriendDescribe(nullStr);
        while (channelId == null) {
            try {
                channelId = seqChannelList.nextValue();
            } catch (Exception e) {
                log.error("exception:{}", e);
            }
        }
        channel.setId(channelId.toString());
        bububaoChannelListDAO.insert(channel);
        log.info("{}--------------BububaoThirdOrgServiceImpl.getChannelId----------end",
                ThreadLocalUtil.getRequestNo());
        return channelId;
    }

    /**
     * 查询是否子机构 如果有子机构则修改机构属性 如果没有子机构则删除当前机构 如果删除当前机构则判断父机构是否存在子机构
     * 
     * @param orgIds
     * @param modifier
     */
    private void iterationDelete(List<Long> orgIds, String modifier) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.iterationDelete----------start",
                ThreadLocalUtil.getRequestNo());
        //删除机构集合为空，则结束
        if (CollectionUtils.isEmpty(orgIds)) {
            return;
        }
        int size = 0;
        for (Long orgId : orgIds) {
            size++;
            if (orgId == null || orgId <= 0) {
                continue;
            }
            //查询机构下业务员，如存在，则结束
            List<BububaoThirdSalesDO> salesModels = bububaoThirdSalesDao.selectByCodeAndOrgId(null, orgId, 0L);
            if (salesModels != null && salesModels.size() > 0) {
                deleteOrgAgent(modifier, orgId);
                break;
            }

            BububaoThirdOrgDO orgDO = new BububaoThirdOrgDO();
            orgDO.setParentOrgId(orgId);
            //查询机构下机构，如存在，则修改为不可销售，否则删除
            List<BububaoThirdOrgDO> childOrgs = bububaoThirdOrgDao.selectByParentIdAndId(orgDO);

            if (CollectionUtils.isEmpty(childOrgs)) {
                bububaoThirdOrgDao.deleteByOrgId(orgId, modifier);
                //迭代删除机构信息
                iterationParentDelete(orgIds.subList(size, orgIds.size()), modifier);
            } else {
                deleteOrgAgent(modifier, orgId);
            }
            break;
        }
        log.info("{}--------------BububaoThirdOrgServiceImpl.iterationDelete----------end",
                ThreadLocalUtil.getRequestNo());
    }

    /**
     * 删除机构代理权限
     * 
     * @param modifier
     * @param orgId
     */
    private void deleteOrgAgent(String modifier, Long orgId) {
        BububaoThirdOrgDO orgModel = new BububaoThirdOrgDO();
        orgModel.setId(orgId);
        orgModel.setIsOrgAgent("N");
        orgModel.setModifier(modifier);
        orgModel.setGmtModified(new Date());
        bububaoThirdOrgDao.updateByPrimaryKeySelective(orgModel);
    }

    /**
     * 如果删除当前机构则判断父机构是否存在子机构 如果存在机构则结束 如果不存在则判断是否是代理 如果是代理则结束 如果不是则删除 .....
     * 
     * @param orgIds
     * @param modifier
     */
    private void iterationParentDelete(List<Long> orgIds, String modifier) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.iterationParentDelete----------start",
                ThreadLocalUtil.getRequestNo());
        //删除机构集合为空，则结束
        if (CollectionUtils.isEmpty(orgIds)) {
            return;
        }
        int size = 0;
        for (Long orgId : orgIds) {
            size++;
            //查询机构下业务员，如存在，则结束
            List<BububaoThirdSalesDO> salesModels = bububaoThirdSalesDao.selectByCodeAndOrgId(null, orgId, 0L);
            if (CollectionUtils.isNotEmpty(salesModels)) {
                break;
            }

            BububaoThirdOrgDO orgDO = new BububaoThirdOrgDO();
            orgDO.setParentOrgId(orgId);
            //查询机构下机构，如存在，则结束
            List<BububaoThirdOrgDO> childOrgs = bububaoThirdOrgDao.selectByParentIdAndId(orgDO);

            if (CollectionUtils.isEmpty(childOrgs)) {
                BububaoThirdOrgDO orgModel = bububaoThirdOrgDao.selectByPrimaryKey(orgId);
                //该机构不可销售，则删除
                if (orgModel == null || "N".equals(orgModel.getIsOrgAgent())) {
                    bububaoThirdOrgDao.deleteByOrgId(orgId, modifier);
                    iterationParentDelete(orgIds.subList(size, orgIds.size()), modifier);
                }
            }
            break;
        }
        log.info("{}--------------BububaoThirdOrgServiceImpl.iterationParentDelete----------end",
                ThreadLocalUtil.getRequestNo());
    }

    /**
     * 判断是否存在投保信息
     * 
     * @param orgIds
     * @return
     */
    private boolean isExistInsure(List<Long> orgIds) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.isExistInsure----------start,orgIds:{}",
                ThreadLocalUtil.getRequestNo(), orgIds);
        if (CollectionUtils.isEmpty(orgIds)) {
            log.info("{}--------------BububaoThirdOrgServiceImpl.isExistInsure-----机构id为空-----end",
                    ThreadLocalUtil.getRequestNo());
            return false;
        }
        for (Long orgId : orgIds) {
            if (orgId == null || orgId == 0) {
                continue;
            }
            BububaoScanQrcodeLogDO scanQrcodeLogDO = new BububaoScanQrcodeLogDO();
            scanQrcodeLogDO.setScanDataId(orgId);
            scanQrcodeLogDO.setScanDataType((short) 1);
            scanQrcodeLogDO.setScanLogType((short) 2);
            List<BububaoScanQrcodeLogDO> scanQrcodeLogDOS = bububaoScanQrcodeLogDao.selectDataByCdt(scanQrcodeLogDO);
            if (CollectionUtils.isEmpty(scanQrcodeLogDOS)) {
                log.info("{}--------------BububaoThirdOrgServiceImpl.isExistInsure-----机构不存在投保-----end",
                        ThreadLocalUtil.getRequestNo());
                return false;
            } else {
                log.info("{}--------------BububaoThirdOrgServiceImpl.isExistInsure-----机构存在投保-----end",
                        ThreadLocalUtil.getRequestNo());
                return true;
            }
        }
        log.info("{}--------------BububaoThirdOrgServiceImpl.isExistInsure----------end",
                ThreadLocalUtil.getRequestNo());
        return false;
    }

    /**
     * 删除扫描日志
     * 
     * @param orgIds
     * @param modifier
     */
    private void deleteScanLog(List<Long> orgIds, String modifier) {
        log.info("{}--------------BububaoThirdOrgServiceImpl.deleteScanLog----------start,orgIds:{}",
                ThreadLocalUtil.getRequestNo(), orgIds);
        if (CollectionUtils.isEmpty(orgIds)) {
            log.info("{}--------------BububaoThirdOrgServiceImpl.deleteScanLog-----机构id为空-----end",
                    ThreadLocalUtil.getRequestNo());
            return;
        }
        for (Long orgId : orgIds) {
            if (orgId == null || orgId == 0) {
                continue;
            }
            bububaoScanQrcodeLogDao.deleteScanLogByDataIdAndType(orgId, 1, modifier);
            log.info("{}--------------BububaoThirdOrgServiceImpl.deleteScanLog-----删除扫码记录-----end",
                    ThreadLocalUtil.getRequestNo());
            return;
        }
    }
}
