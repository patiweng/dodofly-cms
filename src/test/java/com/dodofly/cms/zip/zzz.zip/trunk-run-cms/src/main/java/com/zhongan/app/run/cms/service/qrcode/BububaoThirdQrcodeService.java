package com.zhongan.app.run.cms.service.qrcode;

import java.util.List;

import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoThirdQrcodeDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdQrcodeDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.health.common.share.bean.BaseResult;

/**
 * 二维码管理接口 service
 * 
 * @author lichao002
 * @date 2018-06-04
 */
public interface BububaoThirdQrcodeService {

    public void batchSaveQrcode();

    public void makeAndInsertQrcode(String orgCode, Long id, String isFollowBububao, Integer type, String creatName);

    public List findQrcodesPage();

    /**
     * 修改二维码管理表
     * 
     * @param thirdQrcodeDO
     * @return
     */
    public BaseResult<Integer> updateThirdQrcode(BububaoThirdQrcodeDto thirdQrcodeDTO);
}
