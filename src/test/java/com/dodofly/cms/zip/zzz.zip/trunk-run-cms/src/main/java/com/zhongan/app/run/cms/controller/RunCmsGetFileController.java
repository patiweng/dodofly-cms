package com.zhongan.app.run.cms.controller;

import java.io.InputStream;
import java.io.OutputStream;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/")
@Slf4j
public class RunCmsGetFileController {
	 @Resource
	 private OssTool               ossTool;
	 
	    /**
	     * 从oss上获取图片
	     * @return
	     */  
	    
	    @RequestMapping(value = "/getimg/{fileName}", method = RequestMethod.GET)
	    public void getImg(@PathVariable String fileName, HttpServletResponse response) {
	        InputStream ins = null;
	        OutputStream outs = null;
	        try {
	            response.setDateHeader("Expires", 0);
	            response.addHeader("Cache-Control", "post-check=0, pre-check=0");
	            response.setHeader("Pragma", "no-cache");
	            response.setContentType("image/png");
	            response.setCharacterEncoding("text/html;charaset=UTF-8");
	            ins = ossTool.downloadFile(fileName);
	            outs = response.getOutputStream();
	            int iread = 0;
	            byte[] buf = new byte[1024];
	            while ((iread = ins.read(buf, 0, 1024)) != -1) {
	                outs.write(buf, 0, iread);
	            }
	            outs.flush();
	        } catch (Exception exp) {
	            log.error("{}-",exp.getMessage(), exp,ThreadLocalUtil.getRequestNo());
	        } finally {
	            if (ins != null) {
	                try {
	                    ins.close();
	                } catch (Exception ex) {
	                    log.error("{}-",ex.getMessage(), ex,ThreadLocalUtil.getRequestNo());
	                }
	            }
	            if (outs != null) {
	                try {
	                    outs.close();
	                } catch (Exception ex) {
	                    log.error("{}-",ex.getMessage(), ex,ThreadLocalUtil.getRequestNo());
	                }
	            }
	        }
	        log.info("{}-/getimg/marketing/ return",ThreadLocalUtil.getRequestNo());
	    }
}
