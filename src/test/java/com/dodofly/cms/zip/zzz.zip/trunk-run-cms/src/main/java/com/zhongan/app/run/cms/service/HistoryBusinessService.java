package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.HistoryBusinessDTO;
import com.zhongan.app.run.cms.bean.web.HistoryBusinessQueryDTO;

public interface HistoryBusinessService {

    public List<HistoryBusinessDTO> queryByCondition(HistoryBusinessQueryDTO queryDTO);
}
