package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class AwardRecordDO implements Cloneable {

    private Long   id;
    //用户id
    private Long   unionid;
    //活动id
    private Long   activityId;
    //礼物id
    private Long   presentId;

    /**
     * 礼物URL
     */
    private String presentUrl;

    /**
     * 礼物的保单号
     */
    private String presentPolicyNo;

    //特殊奖励id
    private Long   requireId;
    //获取时间
    private String winTime;
    //虚拟礼物号码（备用）
    private String presentNo;
    //实物快递联系人
    private String customerName;
    //快递信息
    private String expressInfo;
    //联系手机号
    private String customerPhone;
    //详细地址
    private String customerAddress;
    //奖品配送时间
    private String deliveryTime;
    //奖品配送人
    private String deliveryName;
    //创建时间
    private String createtime;
    //修改时间
    private String modifytime;
    //是否重复
    private String isRepeated;
    //是否已发放
    private String status;
    /******* 开始时间 *********/
    private String sdate;
    /******* 结束时间 *********/
    private String edate;
    /**
     * 渠道来源
     */
    private String channelFrom;
    /**
     * 保单号
     */
    private String policyNo;

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
