package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class QuestionItemValueDTO {
    private Long    id;
    private Long    itemId;
    private String  optionValue;
    private Integer sort;
    private String  creator;
    private String  modifier;
    private String  createtime;
    private String  modifytime;
    private String  isDeleted;
    private Integer pageSize;
    private Integer currentPage;
}
