package com.zhongan.app.run.cms.service.qrcode;

import java.util.List;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.StatisticsParamDto;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类ScanInsureStatisticsService.java的实现描述：扫码投保统计接口
 * 
 * @author zhangjin 2018年6月5日 下午4:42:04
 */
public interface StatisticsDetailService {

    /**
     * 导出投保统计表明细
     * 
     * @param param
     * @return
     */

    public BaseResult<String> downLoadReports(StatisticsParamDto param);
    /**
     * 投保统计明细分页查询
     * @param param
     * @return
     */

    public BaseResult<PageDTO<ResultInsureDto>> selectStatisticsDetailPage(StatisticsParamDto param);

}
