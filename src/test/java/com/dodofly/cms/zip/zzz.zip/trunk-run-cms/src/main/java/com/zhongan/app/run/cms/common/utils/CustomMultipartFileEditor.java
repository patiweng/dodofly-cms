package com.zhongan.app.run.cms.common.utils;

import java.beans.PropertyEditorSupport;

public class CustomMultipartFileEditor extends PropertyEditorSupport {

    public void setValue(Object value) {
        if (null == value) {
            super.setValue("");
        } else if ("".equals(value)) {
            super.setValue(null);
        } else {
            super.setValue(value);
        }
    }

}
