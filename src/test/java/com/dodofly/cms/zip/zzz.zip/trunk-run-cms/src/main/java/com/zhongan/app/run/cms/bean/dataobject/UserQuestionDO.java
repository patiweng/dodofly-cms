package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class UserQuestionDO {
    private Long   id;
    private Long   userId;
    private Long   queryId;
    private Long   itemId;
    private String itemType;
    private String itemValue;
    private String creator;
    private String modifier;
    private String createtime;
    private String modifytime;
    private String isDeleted;
}
