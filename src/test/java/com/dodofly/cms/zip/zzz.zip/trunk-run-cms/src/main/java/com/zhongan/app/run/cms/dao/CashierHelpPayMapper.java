package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDO;

public interface CashierHelpPayMapper {
    /** @mbggenerated
     */
    int countByCriteria(CashierHelpPayCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(CashierHelpPayCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from bububao_cashier_help_pay", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into bububao_cashier_help_pay (id, unionId, ", "user_name, user_target, ",
            "user_contract_no, pay_channel_code, ", "original_channel_id, pay_channel_user_no, ", "phone, cert_type, ",
            "cert_no, biz_activity, ", "biz_source, dk_source, ", "open_channel, open_stauts, ",
            "open_time, close_time, ", "creator, gmt_created, modifier, ", "gmt_modified, is_deleted)",
            "values (#{id,jdbcType=BIGINT}, #{unionid,jdbcType=BIGINT}, ",
            "#{userName,jdbcType=VARCHAR}, #{userTarget,jdbcType=BIGINT}, ",
            "#{userContractNo,jdbcType=VARCHAR}, #{payChannelCode,jdbcType=VARCHAR}, ",
            "#{originalChannelId,jdbcType=VARCHAR}, #{payChannelUserNo,jdbcType=VARCHAR}, ",
            "#{phone,jdbcType=VARCHAR}, #{certType,jdbcType=VARCHAR}, ",
            "#{certNo,jdbcType=VARCHAR}, #{bizActivity,jdbcType=VARCHAR}, ",
            "#{bizSource,jdbcType=VARCHAR}, #{dkSource,jdbcType=VARCHAR}, ",
            "#{openChannel,jdbcType=VARCHAR}, #{openStauts,jdbcType=BIGINT}, ",
            "#{openTime,jdbcType=TIMESTAMP}, #{closeTime,jdbcType=TIMESTAMP}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), #{isDeleted,jdbcType=CHAR})" })
    int insert(CashierHelpPayDO record);

    /** @mbggenerated
     */
    int insertSelective(CashierHelpPayDO record);

    /** @mbggenerated
     */
    List<CashierHelpPayDO> selectByCriteriaWithPage(@Param("criteria") CashierHelpPayCriteria criteria,
                                                    @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<CashierHelpPayDO> selectByCriteria(CashierHelpPayCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select",
            "id, unionId, user_name, user_target, user_contract_no, pay_channel_code, original_channel_id, ",
            "pay_channel_user_no, phone, cert_type, cert_no, biz_activity, biz_source, dk_source, ",
            "open_channel, open_stauts, open_time, close_time, creator, gmt_created, modifier, ",
            "gmt_modified, is_deleted", "from bububao_cashier_help_pay", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    CashierHelpPayDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") CashierHelpPayDO record,
                                  @Param("criteria") CashierHelpPayCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") CashierHelpPayDO record, @Param("criteria") CashierHelpPayCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(CashierHelpPayDO record);

    /** @mbggenerated
     */
    @Update({ "update bububao_cashier_help_pay", "set unionId = #{unionid,jdbcType=BIGINT},",
            "user_name = #{userName,jdbcType=VARCHAR},", "user_target = #{userTarget,jdbcType=BIGINT},",
            "user_contract_no = #{userContractNo,jdbcType=VARCHAR},",
            "pay_channel_code = #{payChannelCode,jdbcType=VARCHAR},",
            "original_channel_id = #{originalChannelId,jdbcType=VARCHAR},",
            "pay_channel_user_no = #{payChannelUserNo,jdbcType=VARCHAR},", "phone = #{phone,jdbcType=VARCHAR},",
            "cert_type = #{certType,jdbcType=VARCHAR},", "cert_no = #{certNo,jdbcType=VARCHAR},",
            "biz_activity = #{bizActivity,jdbcType=VARCHAR},", "biz_source = #{bizSource,jdbcType=VARCHAR},",
            "dk_source = #{dkSource,jdbcType=VARCHAR},", "open_channel = #{openChannel,jdbcType=VARCHAR},",
            "open_stauts = #{openStauts,jdbcType=BIGINT},", "open_time = #{openTime,jdbcType=TIMESTAMP},",
            "close_time = #{closeTime,jdbcType=TIMESTAMP},", "creator = #{creator,jdbcType=VARCHAR},",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(CashierHelpPayDO record);
}
