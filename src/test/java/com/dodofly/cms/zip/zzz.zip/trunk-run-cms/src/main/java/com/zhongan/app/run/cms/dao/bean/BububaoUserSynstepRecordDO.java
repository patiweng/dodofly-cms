package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

import lombok.Data;

/**
 * 用户登录记录
 * 
 * @author yangzhen001
 */
@Data
public class BububaoUserSynstepRecordDO {

    /**
     * 主键
     */
    private Long   id;

    /**
     * 用户id
     */
    private Long   unionid;

    /**
     * 用户来原表id
     */
    private Long   userid;

    /**
     * 用户活动渠道来源
     */
    private String channelFrom;

    /**
     * 对应步数的时期
     */
    private Date   date;

    /**
     * 用户每一次登陆进来的步数
     */
    private String steps;

    private String creator;

    private String modifier;

    private Date   gmtCreated;

    private Date   gmtModified;

    /**
     * 是否删除
     */
    private String isDeleted;

    /**
     * 扩展信息
     */
    private String extraInfo;
}
