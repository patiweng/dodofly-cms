package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.taobao.tddl.client.sequence.Sequence;
import com.taobao.tddl.client.sequence.exception.SequenceException;
import com.zhongan.app.run.cms.bean.dataobject.BububaoAdvertHistoryDO;
import com.zhongan.app.run.cms.bean.repo.RunAdvertHistoryRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunAdvertHistoryDTO;
import com.zhongan.app.run.cms.dao.BububaoAdvertHistoryDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Component
public class RunAdvertHistoryRepository {

    @Resource
    private BububaoAdvertHistoryDAO bububaoAdvertHistoryDAO;

    @Resource
    private Sequence                seqAdvertHistory;

    /**
     * 开屏广告展示判断 1、如果开屏广告当天已展示、则返回false 2、如果开屏广告当天未展示、则返回true且在开屏广告表插入一条记录
     * 
     * @param runAdvertHistoryRepo
     * @return
     */
    public boolean adverDisplay(RunAdvertHistoryRepo runAdvertHistoryRepo) {
        String unionId = runAdvertHistoryRepo.getUnionId();
        String activId = runAdvertHistoryRepo.getActivitiesId();
        String activitiesName = runAdvertHistoryRepo.getActivitiesName();
        BububaoAdvertHistoryDO qryDO = new BububaoAdvertHistoryDO();
        qryDO.setUnionId(unionId);
        qryDO.setActivitiesId(activId);
        List<BububaoAdvertHistoryDO> hisList = bububaoAdvertHistoryDAO.selectAdvertByUser(qryDO);
        if (hisList != null && hisList.size() > 0) {
            return false;
        } else {
            /* 插入一条记录 */
            BububaoAdvertHistoryDO insertDO = new BububaoAdvertHistoryDO();
            try {
                insertDO.setId(String.valueOf(seqAdvertHistory.nextValue()));
                insertDO.setUnionId(unionId);
                insertDO.setActivitiesId(activId);
                insertDO.setActivitiesName(activitiesName);
            } catch (SequenceException e) {
                log.error("{}-增加开屏记录异常", e, ThreadLocalUtil.getRequestNo());
                return false;
            }
            bububaoAdvertHistoryDAO.insert(insertDO);
            return true;
        }

    }

    public ResultBase<List<RunAdvertHistoryDTO>> selectBububaoAdvertHistoryInfo(RunAdvertHistoryRepo runAdvertHistoryRepo) {

        log.info("{}-select  AdvertHistory。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunAdvertHistoryDTO>> result = new ResultBase<List<RunAdvertHistoryDTO>>();
        List<RunAdvertHistoryDTO> listresult = new ArrayList<RunAdvertHistoryDTO>();
        BububaoAdvertHistoryDO bububaoAdvertHistoryDO = new BububaoAdvertHistoryDO();
        BeanUtils.copyProperties(runAdvertHistoryRepo, bububaoAdvertHistoryDO);
        List<BububaoAdvertHistoryDO> resultlist = bububaoAdvertHistoryDAO.selectDataByCdt(bububaoAdvertHistoryDO);
        if (resultlist != null && resultlist.size() > 0) {
            for (BububaoAdvertHistoryDO bububaoAdvertHistory : resultlist) {
                RunAdvertHistoryDTO runAdvertHistoryDTO = new RunAdvertHistoryDTO();
                runAdvertHistoryDTO.setActivitiesId(bububaoAdvertHistory.getActivitiesId());
                runAdvertHistoryDTO.setActivitiesName(bububaoAdvertHistory.getActivitiesName());
                runAdvertHistoryDTO.setClickTime(bububaoAdvertHistory.getClickTime());
                runAdvertHistoryDTO.setDisplayTime(bububaoAdvertHistory.getDisplayTime());
                runAdvertHistoryDTO.setGmtCreated(bububaoAdvertHistory.getGmtCreated());
                runAdvertHistoryDTO.setGmtModified(bububaoAdvertHistory.getGmtModified());
                runAdvertHistoryDTO.setId(bububaoAdvertHistory.getId());
                runAdvertHistoryDTO.setIsDeleted(bububaoAdvertHistory.getIsDeleted());
                runAdvertHistoryDTO.setUnionId(bububaoAdvertHistory.getUnionId());
                listresult.add(runAdvertHistoryDTO);
            }
            result.setValue(listresult);
        }
        result.setSuccess(true);
        return result;
    }

    //插入一条数据

    public ResultBase<String> saveAdvertHistory(RunAdvertHistoryRepo runAdvertHistoryRepo) throws Exception {
        log.info("{}-insert saveAdvertHistory。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        BububaoAdvertHistoryDO bububaoAdvertHistoryDO = new BububaoAdvertHistoryDO();
        BeanUtils.copyProperties(runAdvertHistoryRepo, bububaoAdvertHistoryDO);
        Long id = seqAdvertHistory.nextValue();
        bububaoAdvertHistoryDO.setId(id.toString());
        bububaoAdvertHistoryDO.setIsDeleted("1");
        bububaoAdvertHistoryDAO.insert(bububaoAdvertHistoryDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    /**
     * 删除数据
     * 
     * @param runAdvertHistoryRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> deleteByExample(RunAdvertHistoryRepo runAdvertHistoryRepo) throws Exception {
        log.info("{}-insert deleteByExample。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        BububaoAdvertHistoryDO bububaoAdvertHistoryDO = new BububaoAdvertHistoryDO();
        BeanUtils.copyProperties(runAdvertHistoryRepo, bububaoAdvertHistoryDO);
        long example = bububaoAdvertHistoryDAO.deleteByExample(bububaoAdvertHistoryDO);
        result.setValue(String.valueOf(example));
        result.setSuccess(true);
        return result;
    }

    public boolean advertHistoryByCdt(RunAdvertHistoryRepo runAdvertHistoryRepo) {
        String activId = runAdvertHistoryRepo.getActivitiesId();
        String activitiesName = runAdvertHistoryRepo.getActivitiesName();
        String unionId = runAdvertHistoryRepo.getUnionId();
        BububaoAdvertHistoryDO qryDO = new BububaoAdvertHistoryDO();
        BeanUtils.copyProperties(runAdvertHistoryRepo, qryDO);
        List<BububaoAdvertHistoryDO> hisList = bububaoAdvertHistoryDAO.advertHistoryByCdt(qryDO);
        if (hisList != null && hisList.size() > 0) {
            return false;
        } else {
            /* 插入一条记录 */
            BububaoAdvertHistoryDO insertDO = new BububaoAdvertHistoryDO();
            try {
                insertDO.setId(String.valueOf(seqAdvertHistory.nextValue()));
                insertDO.setUnionId(unionId);
                insertDO.setActivitiesId(activId);
                insertDO.setActivitiesName(activitiesName);
            } catch (SequenceException e) {
                log.error("{}-advertHistoryByCdt,增加开屏记录异常:{}", ThreadLocalUtil.getRequestNo(), e);
                return false;
            }
            bububaoAdvertHistoryDAO.insert(insertDO);
            return true;
        }
    }

    public boolean isAdvertDisplay(RunAdvertHistoryRepo runAdvertHistoryRepo) {
        BububaoAdvertHistoryDO qryDO = new BububaoAdvertHistoryDO();
        BeanUtils.copyProperties(runAdvertHistoryRepo, qryDO);
        List<BububaoAdvertHistoryDO> hisList = bububaoAdvertHistoryDAO.selectAdvertByUser(qryDO);
        if (hisList != null && hisList.size() > 0) {
            return false;
        } else {
            return true;
        }
    }

}
