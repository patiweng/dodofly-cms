package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.dao.bean.UserInviteCriteria;
import com.zhongan.app.run.cms.dao.bean.UserInviteDO;
import com.zhongan.app.run.cms.bean.page.PageInfo;

public interface UserInviteMapper {
    /**
     * @mbggenerated
     */
    int countByCriteria(UserInviteCriteria criteria);

    /**
     * @mbggenerated
     */
    int deleteByCriteria(UserInviteCriteria criteria);

    /**
     * @mbggenerated
     */
    @Delete({ "delete from bububao_user_invite", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /**
     * @mbggenerated
     */
    @Insert({ "insert into bububao_user_invite (id, unionid, ", "activity_id, channel_from, ",
            "activity_type, join_openid, ", "nick_name, relation, ", "state, headimgurl, ", "creator, modifier, ",
            "gmt_created, gmt_modified, is_deleted, extra_info, ", "join_unionid, openId)",
            "values (#{id,jdbcType=BIGINT}, #{unionid,jdbcType=BIGINT}, ",
            "#{activityId,jdbcType=VARCHAR}, #{channelFrom,jdbcType=VARCHAR}, ",
            "#{activityType,jdbcType=VARCHAR}, #{joinOpenid,jdbcType=VARCHAR}, ",
            "#{nickName,jdbcType=VARCHAR}, #{relation,jdbcType=CHAR}, ",
            "#{state,jdbcType=CHAR}, #{headimgurl,jdbcType=VARCHAR}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), now(), #{isDeleted,jdbcType=CHAR}, #{extraInfo,jdbcType=VARCHAR}, ",
            "#{joinUnionid,jdbcType=BIGINT}, #{openid,jdbcType=VARCHAR})" })
    int insert(UserInviteDO record);

    /**
     * @mbggenerated
     */
    int insertSelective(UserInviteDO record);

    /**
     * @mbggenerated
     */
    List<UserInviteDO> selectByCriteriaWithPage(@Param("criteria") UserInviteCriteria criteria,
                                                @Param("pageInfo") PageInfo pageInfo);

    /**
     * @mbggenerated
     */
    List<UserInviteDO> selectByCriteria(UserInviteCriteria criteria);

    /**
     * @mbggenerated
     */
    @Select({ "select", "id, unionid, activity_id, channel_from, activity_type, join_openid, nick_name, ",
            "relation, state, headimgurl, creator, modifier, gmt_created, gmt_modified, is_deleted, ",
            "extra_info, join_unionid, openId", "from bububao_user_invite", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    UserInviteDO selectByPrimaryKey(@Param("id") Long id);

    /**
     * @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") UserInviteDO record, @Param("criteria") UserInviteCriteria criteria);

    /**
     * @mbggenerated
     */
    int updateByCriteria(@Param("record") UserInviteDO record, @Param("criteria") UserInviteCriteria criteria);

    /**
     * @mbggenerated
     */
    int updateByPrimaryKeySelective(UserInviteDO record);

    /**
     * @mbggenerated
     */
    @Update({ "update bububao_user_invite", "set unionid = #{unionid,jdbcType=BIGINT},",
            "activity_id = #{activityId,jdbcType=VARCHAR},", "channel_from = #{channelFrom,jdbcType=VARCHAR},",
            "activity_type = #{activityType,jdbcType=VARCHAR},", "join_openid = #{joinOpenid,jdbcType=VARCHAR},",
            "nick_name = #{nickName,jdbcType=VARCHAR},", "relation = #{relation,jdbcType=CHAR},",
            "state = #{state,jdbcType=CHAR},", "headimgurl = #{headimgurl,jdbcType=VARCHAR},",
            "creator = #{creator,jdbcType=VARCHAR},", "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR},", "extra_info = #{extraInfo,jdbcType=VARCHAR},",
            "join_unionid = #{joinUnionid,jdbcType=BIGINT},", "openId = #{openid,jdbcType=VARCHAR}",
            "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(UserInviteDO record);
}
