package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.zhongan.app.run.cms.bean.dataobject.StaticsCollectionDO;
import com.zhongan.app.run.cms.bean.dataobject.UserInsuranceDO;
import com.zhongan.app.run.cms.common.enums.ChannelCodeTmpEnum;
import com.zhongan.app.run.cms.dao.StaticsCollectionDAO;

@Repository
public class StaticsRepository {
	
	@Resource
	private StaticsCollectionDAO staticsCollectionDAO;
	
	public String staticsUvPv(String from,String sdate,String edate){
		StaticsCollectionDO uvdo = new StaticsCollectionDO();
		uvdo.setFrom(from);
		uvdo.setSDate(sdate);
		uvdo.setEDate(edate);
		List<StaticsCollectionDO> uvlist = staticsCollectionDAO.selectUv(uvdo);
		StaticsCollectionDO pvdo = new StaticsCollectionDO();
		pvdo.setFrom(from);
		pvdo.setSDate(sdate);
		pvdo.setEDate(edate);
		List<StaticsCollectionDO> pvlist = staticsCollectionDAO.selectPv(pvdo);
		StringBuffer rf = new StringBuffer();
		rf.append("<===========渠道访问UV数统计============>");
		rf.append(uvlist.get(0).getAllCount());
		rf.append("<====================================>");
		rf.append("<===========渠道访问PV数统计============>");
		if(pvlist != null && pvlist.size() >0){
			for(StaticsCollectionDO data:pvlist){
				String cname = data.getPage();
				String ccount = data.getAllCount();
				rf.append(cname + "----" + ccount);
			}
		}
		rf.append("<====================================>");
		return rf.toString();
	}
	
	public Map<String,List> staticsAll(String sDate,String eDate){
		Map<String,List> map = new HashMap<String,List>();
		/****************周渠道活跃*****************/
		List<StaticsCollectionDO> listAll = new ArrayList<StaticsCollectionDO>();
		for(ChannelCodeTmpEnum codeEnum:ChannelCodeTmpEnum.values()){
			StaticsCollectionDO staticsCollectionDO = new StaticsCollectionDO();
			staticsCollectionDO.setFrom(codeEnum.getCode());
			staticsCollectionDO.setSDate(sDate);
			staticsCollectionDO.setEDate(eDate);
			List<StaticsCollectionDO> fromVisitList = staticsCollectionDAO.selectFromVisit(staticsCollectionDO);
			if(fromVisitList != null && fromVisitList.size()>0){
				for(StaticsCollectionDO data:fromVisitList){
					data.setFromName(codeEnum.getValue());
					listAll.add(data);
				}
			}
		}
		/****************周页面活跃*****************/
		StaticsCollectionDO pagetAllDO = new StaticsCollectionDO();
		pagetAllDO.setSDate(sDate);
		pagetAllDO.setEDate(eDate);
		List<StaticsCollectionDO> pageList = staticsCollectionDAO.selectAllVisit(pagetAllDO);
		
		
		/****************周登录活跃*****************/
		StaticsCollectionDO allVisitDO = new StaticsCollectionDO();
		allVisitDO.setSDate(sDate);
		allVisitDO.setEDate(eDate);
		List<StaticsCollectionDO> allVistList = staticsCollectionDAO.selectAllActive(allVisitDO);
		/****************周老用户活跃*****************/
		StaticsCollectionDO oldVisitDO = new StaticsCollectionDO();
		oldVisitDO.setSDate(sDate);
		oldVisitDO.setEDate(eDate);
		List<StaticsCollectionDO> oldVistList = staticsCollectionDAO.selectOldActive(oldVisitDO);
		/****************周新用户活跃*****************/
		StaticsCollectionDO newVisitDO = new StaticsCollectionDO();
		newVisitDO.setSDate(sDate);
		newVisitDO.setEDate(eDate);
		List<StaticsCollectionDO> newVistList = staticsCollectionDAO.selectNewActive(newVisitDO);
		/****************周渠道新增*****************/
		StaticsCollectionDO fromAddDO = new StaticsCollectionDO();
		fromAddDO.setSDate(sDate);
		fromAddDO.setEDate(eDate);
		List<StaticsCollectionDO> fromAddList = staticsCollectionDAO.selectFromActive(fromAddDO);
		/****************渠道总用户*****************/
		StaticsCollectionDO userAllDO = new StaticsCollectionDO();
		List<StaticsCollectionDO> userAllList = staticsCollectionDAO.selectUserCount(userAllDO);
		/****************渠道续保用户*****************/
		StaticsCollectionDO userInsureDO = new StaticsCollectionDO();
		userInsureDO.setSDate(sDate);
		userInsureDO.setEDate(eDate);
		List<UserInsuranceDO> userInsureList = staticsCollectionDAO.selectUserInsure(userInsureDO);
		
		/****************渠道问题单***********************/
		StaticsCollectionDO sourceBugDO = new StaticsCollectionDO();
		sourceBugDO.setSDate(sDate);
		sourceBugDO.setEDate(eDate);
		List<StaticsCollectionDO> sourceBugList = staticsCollectionDAO.selectBugInsure(sourceBugDO);
		
		map.put("staticsFromVisit", listAll);
		map.put("staticsPageVisit", pageList);
		map.put("staticsallVist", allVistList);
		map.put("staticsOldVist", oldVistList);
		map.put("staticsNewVist", newVistList);
		map.put("staticsfromAdd", fromAddList);
		map.put("staticsUserAll", userAllList);
		map.put("staticsUserInsure", userInsureList);
		map.put("staticsSourceBug", sourceBugList);
		return map;
	}

}
