package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayResDTO;
import com.zhongan.app.run.cms.conver.CashierHelpPayConvert;
import com.zhongan.app.run.cms.dao.CashierHelpPayMapper;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDO;
import com.zhongan.app.run.cms.service.ICashierHelpPayService;
import com.zhongan.app.run.common.enums.OpenStautsEnum;
import com.zhongan.health.common.share.bean.PageDTO;
import com.zhongan.health.common.share.enm.YesOrNo;
import com.zhongan.health.common.utils.DateUtils;

@Service("cashierHelpPayService")
public class CashierHelpPayServiceImpl implements ICashierHelpPayService {

    @Resource
    private CashierHelpPayMapper            cashierHelpPayMapper;

    @Resource
    private CashierHelpPayDetailServiceImpl cashierHelpPayDetailServiceImpl;

    @Resource
    private Sequence                        seqCashierHelpPay;

    private final static String             BUBUBAO = "bububao";

    @Override
    public PageDTO<CashierHelpPayResDTO> queryCashierHelpPayList(CashierHelpPayQueryDTO queryDTO) throws Exception {
        PageDTO<CashierHelpPayResDTO> pageDTO = new PageDTO<CashierHelpPayResDTO>();
        int size = queryDTO.getPageSize();
        int currentPage = queryDTO.getCurrentPage() < 1 ? 1 : queryDTO.getCurrentPage();
        pageDTO.setCurrentPage(currentPage);
        pageDTO.setPageSize(size);
        CashierHelpPayCriteria criteria = buildCriteria(queryDTO);
        int count = cashierHelpPayMapper.countByCriteria(criteria);
        if (count > 0) {
            int start = (currentPage - 1) * size;
            PageInfo pageInfo = new PageInfo();
            pageInfo.setOffset(start);
            pageInfo.setSize(size);
            List<CashierHelpPayDO> list = cashierHelpPayMapper.selectByCriteriaWithPage(criteria, pageInfo);
            pageDTO.setResultList(CashierHelpPayConvert.convertResDTO(list));
            pageDTO.setTotalItem(count);
        }
        return pageDTO;
    }

    @Override
    public Integer getUserCashierHelpPayCount(CashierHelpPayQueryDTO queryDTO) throws Exception {
        CashierHelpPayCriteria criteria = buildCriteria(queryDTO);
        return cashierHelpPayMapper.countByCriteria(criteria);
    }

    private CashierHelpPayCriteria buildCriteria(CashierHelpPayQueryDTO queryDTO) {
        CashierHelpPayCriteria cashierHelpPayCriteria = new CashierHelpPayCriteria();
        cashierHelpPayCriteria.setOrderByClause("open_time asc");
        Criteria createCriteria = cashierHelpPayCriteria.createCriteria();
        if (StringUtils.isNotBlank(queryDTO.getPhone())) {
            createCriteria.andPhoneEqualTo(queryDTO.getPhone());
        }
        if (StringUtils.isNotBlank(queryDTO.getCertNo())) {
            createCriteria.andCertNoLike("%" + queryDTO.getCertNo() + "%");
        }
        if (StringUtils.isNotBlank(queryDTO.getStartTime()) && StringUtils.isNotBlank(queryDTO.getEndTime())) {
            createCriteria.andOpenTimeBetween(DateUtils.parseDate(queryDTO.getStartTime()),
                    DateUtils.parseDate(queryDTO.getEndTime()));
        }
        if (null != queryDTO.getOpenStauts()) {
            createCriteria.andOpenStautsEqualTo(queryDTO.getOpenStauts());
        }
        String openChannel = queryDTO.getOpenChannel();
        if (StringUtils.isNotBlank(queryDTO.getOpenChannel()) && !StringUtils.equals("all", openChannel)) {
            createCriteria.andOpenChannelEqualTo(queryDTO.getOpenChannel());
        }

        createCriteria.andOpenStautsNotEqualTo(OpenStautsEnum.APPLY.getCode());
        createCriteria.andBizSourceEqualTo(BUBUBAO);
        return cashierHelpPayCriteria;
    }

    @Override
    public Long saveOrUpdateCashierHelpPay(CashierHelpPayDTO cashierHelpPayDTO) throws Exception {
        CashierHelpPayCriteria cashierHelpPayCriteria = new CashierHelpPayCriteria();
        Criteria criteria = cashierHelpPayCriteria.createCriteria();

        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getCertNo())
                && StringUtils.isNotEmpty(cashierHelpPayDTO.getPhone())) {
            criteria.andCertNoEqualTo(cashierHelpPayDTO.getCertNo());
            criteria.andPhoneEqualTo(cashierHelpPayDTO.getPhone());
        } else {
            criteria.andPayChannelUserNoEqualTo(cashierHelpPayDTO.getPayChannelUserNo());
        }

        if (!BUBUBAO.equals(cashierHelpPayDTO.getBizSource())) {
            criteria.andBizSourceEqualTo(cashierHelpPayDTO.getBizSource());
            criteria.andOpenChannelEqualTo(cashierHelpPayDTO.getOpenChannel());
        }

        List<CashierHelpPayDO> payDOs = cashierHelpPayMapper.selectByCriteria(cashierHelpPayCriteria);
        Long nextValue = 0L;
        CashierHelpPayDO convertDO = null;
        if (CollectionUtils.isEmpty(payDOs)) {
            nextValue = seqCashierHelpPay.nextValue();
            convertDO = CashierHelpPayConvert.convertDO(cashierHelpPayDTO);
            convertDO.setId(nextValue);
            cashierHelpPayMapper.insert(convertDO);
        } else {
            CashierHelpPayDO cashierHelpPayDO = payDOs.get(0);
            cashierHelpPayDTO.setId(cashierHelpPayDO.getId());
            convertDO = CashierHelpPayConvert.convertDO(cashierHelpPayDTO);
            if (cashierHelpPayDO.getOpenTime() != null) {
                convertDO.setOpenTime(null);
            }
            if (cashierHelpPayDO.getCloseTime() != null) {
                convertDO.setCloseTime(null);
            }
            cashierHelpPayMapper.updateByPrimaryKeySelective(convertDO);
            nextValue = cashierHelpPayDO.getId();
        }

        if (OpenStautsEnum.REVOCATION.getCode().equals(cashierHelpPayDTO.getOpenStauts())
                || OpenStautsEnum.OPEN.getCode().equals(cashierHelpPayDTO.getOpenStauts())) {
            CashierHelpPayDetailDTO dto = new CashierHelpPayDetailDTO();
            dto.setCashierId(nextValue);
            dto.setUserContractNo(cashierHelpPayDTO.getUserContractNo());
            dto.setDkSource(cashierHelpPayDTO.getDkSource());
            dto.setBizTime(OpenStautsEnum.OPEN.getCode().equals(cashierHelpPayDTO.getOpenStauts()) ? cashierHelpPayDTO
                    .getOpenTime() : cashierHelpPayDTO.getCloseTime());
            dto.setBizStatus(cashierHelpPayDTO.getOpenStauts());
            dto.setBizChannel(cashierHelpPayDTO.getOpenChannel());
            cashierHelpPayDetailServiceImpl.saveOrUpdateCashierHelpPayDetail(dto);
        }

        return nextValue;
    }

    @Override
    public List<CashierHelpPayDTO> queryByCondition(CashierHelpPayDTO cashierHelpPayDTO) throws Exception {
        CashierHelpPayCriteria cashierHelpPayCriteria = buildCriteria(cashierHelpPayDTO);
        return CashierHelpPayConvert.convertDTO(cashierHelpPayMapper.selectByCriteria(cashierHelpPayCriteria));
    }

    @Override
    public Integer deleteById(Long id) throws Exception {
        return cashierHelpPayMapper.deleteByPrimaryKey(id);
    }

    /**
     * 为了兼容一个用户多个签约记录 且 payChannelUserNo 不一样 根据身份证，和手机号码可以确认同一账户
     * 
     * @param certNo
     * @param phone
     * @throws Exception
     */
    public void compatibilityFinancial(CashierHelpPayDTO cashierHelpPayDTO) throws Exception {
        CashierHelpPayDTO dto = new CashierHelpPayDTO();
        dto.setCertNo(cashierHelpPayDTO.getCertNo());
        dto.setPhone(cashierHelpPayDTO.getPhone());
        List<CashierHelpPayDO> helpPayDOs = cashierHelpPayMapper.selectByCriteria(buildCriteria(dto));
        if (CollectionUtils.isNotEmpty(helpPayDOs)) {
            for (CashierHelpPayDO cashierHelpPayDO : helpPayDOs) {
                if (!cashierHelpPayDTO.getPayChannelUserNo().equals(cashierHelpPayDO.getPayChannelUserNo())) {
                    if (cashierHelpPayDO.getOpenTime() != null) {
                        cashierHelpPayDO.setOpenTime(null);
                    } else {
                        cashierHelpPayDO.setOpenTime(cashierHelpPayDTO.getOpenTime());
                    }
                    if (cashierHelpPayDO.getCloseTime() != null) {
                        cashierHelpPayDO.setCloseTime(null);
                    } else {
                        cashierHelpPayDO.setCloseTime(cashierHelpPayDTO.getCloseTime());
                    }
                    cashierHelpPayDO.setOpenStauts(cashierHelpPayDTO.getOpenStauts());
                    cashierHelpPayMapper.updateByPrimaryKeySelective(cashierHelpPayDO);

                    if (OpenStautsEnum.REVOCATION.getCode().equals(cashierHelpPayDTO.getOpenStauts())
                            || OpenStautsEnum.OPEN.getCode().equals(cashierHelpPayDTO.getOpenStauts())) {
                        CashierHelpPayDetailDTO payDetailDTO = new CashierHelpPayDetailDTO();
                        payDetailDTO.setCashierId(cashierHelpPayDO.getId());
                        payDetailDTO.setUserContractNo(cashierHelpPayDTO.getUserContractNo());
                        payDetailDTO.setDkSource(cashierHelpPayDO.getDkSource());
                        payDetailDTO
                                .setBizTime(OpenStautsEnum.OPEN.getCode().equals(cashierHelpPayDTO.getOpenStauts()) ? cashierHelpPayDTO
                                        .getOpenTime() : cashierHelpPayDTO.getCloseTime());
                        payDetailDTO.setBizStatus(cashierHelpPayDTO.getOpenStauts());
                        payDetailDTO.setBizChannel(cashierHelpPayDO.getOpenChannel());
                        cashierHelpPayDetailServiceImpl.saveOrUpdateCashierHelpPayDetail(payDetailDTO);
                    }
                }
            }
        }
    }

    private CashierHelpPayCriteria buildCriteria(CashierHelpPayDTO cashierHelpPayDTO) {
        CashierHelpPayCriteria cashierHelpPayCriteria = new CashierHelpPayCriteria();
        Criteria createCriteria = cashierHelpPayCriteria.createCriteria();
        if (StringUtils.isNoneBlank(cashierHelpPayDTO.getOpenChannel())) {
            createCriteria.andOpenChannelEqualTo(cashierHelpPayDTO.getOpenChannel());
        }
        if (cashierHelpPayDTO.getOpenStauts() != null) {
            createCriteria.andOpenStautsEqualTo(cashierHelpPayDTO.getOpenStauts());
        }
        if (cashierHelpPayDTO.getUnionid() != null) {
            createCriteria.andUnionidEqualTo(cashierHelpPayDTO.getUnionid());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getUserContractNo())) {
            createCriteria.andUserContractNoEqualTo(cashierHelpPayDTO.getUserContractNo());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getBizSource())) {
            createCriteria.andBizSourceEqualTo(cashierHelpPayDTO.getBizSource());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getPayChannelUserNo())) {
            createCriteria.andPayChannelUserNoEqualTo(cashierHelpPayDTO.getPayChannelUserNo());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getDkSource())) {
            createCriteria.andDkSourceEqualTo(cashierHelpPayDTO.getDkSource());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getCertNo())) {
            createCriteria.andCertNoEqualTo(cashierHelpPayDTO.getCertNo());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getPhone())) {
            createCriteria.andPhoneEqualTo(cashierHelpPayDTO.getPhone());
        }
        if (StringUtils.isNotEmpty(cashierHelpPayDTO.getIsClosed())
                && YesOrNo.YES.getCode().equals(cashierHelpPayDTO.getIsClosed())) {
            createCriteria.andCloseTimeIsNull();
        }
        return cashierHelpPayCriteria;
    }

}
