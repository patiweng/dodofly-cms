package com.zhongan.app.run.cms.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.HealthProductChannelRelationBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.HealthProductChannelRelationRepo;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationDTO;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.AppUtil;
import com.zhongan.app.run.cms.repository.HealthProductChannelRelationRepository;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.HealthProductChannelRelationService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class HealthProductChannelRelationServiceImpl implements HealthProductChannelRelationService {

    @Resource
    private HealthProductChannelRelationRepository healthProductChannelRelationRepository;

    @Resource
    private RunChannelListRepository               runChannelListRepository;

    //后台作为微服务的接口
    @Override
    public ResultBase<List<HealthProductChannelRelationDTO>> selectCampaignInfo(HealthProductChannelRelationBO healthProductChannelRelationBO) {
        ResultBase<List<HealthProductChannelRelationDTO>> result = new ResultBase<List<HealthProductChannelRelationDTO>>();
        log.info("{}-CampaignList select begin...", ThreadLocalUtil.getRequestNo());
        //参数的校验
        ResultBase<String> valResult = CheckBitparam(healthProductChannelRelationBO);
        if (!valResult.isSuccess()) {
            log.info("{}-fail--param:" + valResult.getErrorCode() + "-" + valResult.getErrorMessage(),
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            HealthProductChannelRelationRepo healthProductChannelRelationRepo = new HealthProductChannelRelationRepo();
            BeanUtils.copyProperties(healthProductChannelRelationBO, healthProductChannelRelationRepo);
            result = healthProductChannelRelationRepository.selectRunCampaignDataRepo(healthProductChannelRelationRepo);
            if (result.getValue().size() > 0) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-CampaignList select fail,please find error to..."
                    + "error location polynomial : HealthCampaignListServiceImpl--selectcampaignInfo()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    //入参数的校验
    @SuppressWarnings({ "unchecked" })
    private ResultBase<String> CheckBitparam(HealthProductChannelRelationBO healthProductChannelRelationBO) {
        log.info("{}-param check code...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        //渠道号不能为空
        if (StringUtils.isEmpty(healthProductChannelRelationBO.getChannelNo())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100009, result);
        }
        result.setSuccess(true);
        return result;
    }

    //营销活动分页查询
    @Override
    public HealthProductChannelRelationPageDTO selectCampaigninfoPage(Page<HealthProductChannelRelationDTO> healthProductChannelRelationPage) {
        HealthProductChannelRelationPageDTO healthProductChannelRelationPageDTO = new HealthProductChannelRelationPageDTO();
        Page<HealthProductChannelRelationRepo> healthProductChannelRelationRepoPage = new Page<HealthProductChannelRelationRepo>();
        BeanUtils.copyProperties(healthProductChannelRelationPage, healthProductChannelRelationRepoPage);
        healthProductChannelRelationRepoPage = healthProductChannelRelationRepository
                .selectCampaignListPage(healthProductChannelRelationRepoPage);
        List<HealthProductChannelRelationRepo> healthProductChannelRelationRepoRepolist = healthProductChannelRelationRepoPage
                .getResultList();
        List<HealthProductChannelRelationDTO> healthProductChannelRelationDTOList = Lists.newArrayList();
        ResultBase<List<RunChannelListDTO>> resultchannel = new ResultBase<List<RunChannelListDTO>>();
        RunChannelListRepo runChannelListRepot = new RunChannelListRepo();
        resultchannel = runChannelListRepository.selectRunChannelListDataList(runChannelListRepot);
        Map<String, String> channelList = getChannelList(resultchannel.getValue());
        if (healthProductChannelRelationRepoRepolist != null && healthProductChannelRelationRepoRepolist.size() > 0) {
            HealthProductChannelRelationDTO healthProductChannelRelationDTO = null;
            for (HealthProductChannelRelationRepo healthProductChannelRelationRepoRepo : healthProductChannelRelationRepoRepolist) {
                healthProductChannelRelationDTO = new HealthProductChannelRelationDTO();
                BeanUtils.copyProperties(healthProductChannelRelationRepoRepo, healthProductChannelRelationDTO);
                healthProductChannelRelationDTO.setName(channelList.get(healthProductChannelRelationRepoRepo
                        .getChannelNo()));
                healthProductChannelRelationDTOList.add(healthProductChannelRelationDTO);
            }
        }
        healthProductChannelRelationPage.setResultList(healthProductChannelRelationDTOList);
        healthProductChannelRelationPage.setTotalItem(healthProductChannelRelationRepoPage.getTotalItem());
        healthProductChannelRelationPageDTO.setHealthCampaignListDTOPage(healthProductChannelRelationPage);
        healthProductChannelRelationPageDTO.setRunChannelListDTOList(resultchannel.getValue());
        return healthProductChannelRelationPageDTO;
    }

    private Map<String, String> getChannelList(List<RunChannelListDTO> channelListDTOList) {
        Map<String, String> channelList = Maps.newHashMap();
        for (RunChannelListDTO runChannelListDTO : channelListDTOList) {
            channelList.put(runChannelListDTO.getNo(), runChannelListDTO.getName());
        }
        return channelList;
    }

    //新建营销活动
    @Override
    public ResultBase<String> insertCampaignList(HealthProductChannelRelationDTO healthProductChannelRelationDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            HealthProductChannelRelationRepo healthProductChannelRelationRepo = new HealthProductChannelRelationRepo();
            HealthProductChannelRelationRepo healthProductChannelRelationRepoend = new HealthProductChannelRelationRepo();
            BeanUtils.copyProperties(healthProductChannelRelationDTO, healthProductChannelRelationRepo);
            //查询渠道id
            RunChannelListRepo channelRepo = new RunChannelListRepo();
            channelRepo.setNo(healthProductChannelRelationDTO.getChannelNo());
            RunChannelListDTO channelResult = runChannelListRepository.selectRunChannelListData(channelRepo).getValue();
            if (channelResult == null) {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10005.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10005.getValue());
                return result;
            }
            //判断页面来值 渠道id+营销活动id+产品组合id 是否已在库里存值
            healthProductChannelRelationRepo.setChannelId(channelResult.getId());
            healthProductChannelRelationRepoend.setChannelNo(healthProductChannelRelationRepo.getChannelNo());
            healthProductChannelRelationRepoend.setCampaignId(healthProductChannelRelationRepo.getCampaignId());
            healthProductChannelRelationRepoend.setPackageId(healthProductChannelRelationRepo.getPackageId());
            ResultBase<List<HealthProductChannelRelationDTO>> resultend = healthProductChannelRelationRepository
                    .selectRunCampaignDataRepo(healthProductChannelRelationRepoend);
            if (null != resultend.getValue() && resultend.getValue().size() > 0) {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10002.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10002.getValue());
                return result;
            }

            result = healthProductChannelRelationRepository.saveCampaignList(healthProductChannelRelationRepo);

            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save--CampaignList...."
                    + "error location polynomial : HealthCampaignListServiceImpl--insertCampaignList()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    //根据主键修改营销活动 
    @Override
    public ResultBase<String> updateCampaignList(HealthProductChannelRelationDTO healthProductChannelRelationDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            HealthProductChannelRelationRepo healthProductChannelRelationRepo = new HealthProductChannelRelationRepo();
            BeanUtils.copyProperties(healthProductChannelRelationDTO, healthProductChannelRelationRepo);
            //查询渠道ID
            RunChannelListRepo channelRepo = new RunChannelListRepo();
            channelRepo.setNo(healthProductChannelRelationDTO.getChannelNo());
            RunChannelListDTO channelResult = runChannelListRepository.selectRunChannelListData(channelRepo).getValue();
            if (channelResult == null) {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10005.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10005.getValue());
                return result;
            }
            healthProductChannelRelationRepo.setChannelId(channelResult.getId());
            result = healthProductChannelRelationRepository.updateCampaignList(healthProductChannelRelationRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--CampaignList...."
                    + "error location polynomial : HealthCampaignListServiceImpl--updateCampaignList()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    //根据主键删除营销活动
    @Override
    public ResultBase<String> deleteCampaignList(String id) {
        log.info("{}-delete CampaignList info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            healthProductChannelRelationRepository.deleteDataById(id);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-CampaignList delete fail,please find error to...。"
                    + "error location polynomial:HealthCampaignListServiceImpl--deleteCampaignList()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    //根据ID 查询单个对象的信息
    @Override
    public HealthProductChannelRelationDTO selectOneCampaignList(String id) {
        log.info("{}-select one CampaignList info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        HealthProductChannelRelationDTO healthProductChannelRelationDTO = new HealthProductChannelRelationDTO();
        try {
            HealthProductChannelRelationRepo healthProductChannelRelationRepo = healthProductChannelRelationRepository
                    .selectOneData(id);
            if (healthProductChannelRelationRepo != null) {
                RunChannelListRepo runChannelListRepot = new RunChannelListRepo();
                runChannelListRepot.setNo(healthProductChannelRelationRepo.getChannelNo());
                ResultBase<List<RunChannelListDTO>> result = runChannelListRepository
                        .selectRunChannelListDataList(runChannelListRepot);
                BeanUtils.copyProperties(healthProductChannelRelationRepo, healthProductChannelRelationDTO);
                healthProductChannelRelationDTO.setName(result.getValue().get(0).getName());
            }
        } catch (Exception e) {
            log.error("{}-CampaignList select one  fail,please find error to...。"
                    + "error location polynomial:HealthCampaignListServiceImpl--selectOneCampaignList()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
        }
        return healthProductChannelRelationDTO;
    }

}
