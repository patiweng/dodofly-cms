package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

import com.zhongan.app.run.cms.bean.page.PageInfo;

/**
 * @author yangzhen001
 */
@Data
public class UserActivityInfoDTO extends PageInfo implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long              id;
    /** 用户id */
    private Long              unionid;
    /** 用户渠道来 */
    private String            channelFrom;
    /** 一级活动id */
    private String            activityId;
    /** 二级活动id */
    private String            childrenId;
    /** 该场活动用户投入的积分 */
    private String            inputPoint;
    /** 该场活动结束用户获取的积分 */
    private String            gainPoint;
    /** 是否使用打折卡(Y/N) */
    private String            isDiscount;
    /** 是否使用懒人卡(Y/N) */
    private String            isLazy;
    /** 是否使用复活卡(Y/N) */
    private String            isResurgence;
    /** 活动结束时间 */
    private String            activityEndTime;
    /** 活动开始时间 */
    private String            activityBeginTime;
    /** 创建时间 */
    private Date              gmtCreated;
    /** 修改时间 */
    private Date              gmtModified;
    /** 用户是否达标 1 达标 0 未达标 */
    private String            isStandard;
    /** 在活动结束后的最大步数 */
    private String            steps;

    /** 当前时间 */
    private Date              nowTime;
    /** 大于这个时间的活动 */
    private Date              activityTime;

}
