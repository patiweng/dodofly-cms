package com.zhongan.app.run.cms.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.ibm.icu.text.DecimalFormat;
import com.zhongan.app.run.cms.bean.dataobject.AnalysisBusinessDO;
import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.AnalysisBusinessRepo;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessDTO;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.utils.ReadExcel;
import com.zhongan.app.run.cms.repository.AnalysisBusinessRepository;
import com.zhongan.app.run.cms.repository.RunUserFindInfoRepository;
import com.zhongan.app.run.cms.repository.TransLogRepository;
import com.zhongan.app.run.cms.service.ExportExcelBusinessService;
import com.zhongan.app.run.cms.service.client.RunAnalysisFeignClient;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class ExportExcelBusinessServiceImpl implements ExportExcelBusinessService {

    @Resource
    private AnalysisBusinessRepository analysisBusinessRepository;
    @Resource
    private RunUserFindInfoRepository  runUserFindInfoRepository;
    @Resource
    private TransLogRepository         transLogRepository;
    @Resource
    private RunAnalysisFeignClient     runAnalysisFeignClient;

    @Override
    public AnalysisBusinessPageDTO selectAnalysisBusinessList(Page<AnalysisBusinessDTO> analysisBusinessPage) {
        // TODO Auto-generated method stub

        AnalysisBusinessPageDTO analysisBusinessPageDTO = new AnalysisBusinessPageDTO();
        Page<AnalysisBusinessRepo> analysisBusinessRepoPage = new Page<AnalysisBusinessRepo>();
        BeanUtils.copyProperties(analysisBusinessPage, analysisBusinessRepoPage);

        analysisBusinessRepoPage = analysisBusinessRepository.selectAnalysisBusinessPage(analysisBusinessPage);
        List<AnalysisBusinessRepo> analysisBusinessRepoList = analysisBusinessRepoPage.getResultList();
        List<AnalysisBusinessDTO> analysisBusinessDTOList = Lists.newArrayList();
        if (null != analysisBusinessRepoList && analysisBusinessRepoList.size() > 0) {
            AnalysisBusinessDTO analysisBusinessDTO = new AnalysisBusinessDTO();
            for (AnalysisBusinessRepo analysisBusinessRepo : analysisBusinessRepoList) {
                AnalysisBusinessDTO clone = (AnalysisBusinessDTO) analysisBusinessDTO.clone();
                BeanUtils.copyProperties(analysisBusinessRepo, clone);
                analysisBusinessDTOList.add(clone);
            }

        }
        analysisBusinessPage.setResultList(analysisBusinessDTOList);
        analysisBusinessPage.setTotalItem(analysisBusinessRepoPage.getTotalItem());
        analysisBusinessPageDTO.setAnalysisBusinessDTOPage(analysisBusinessPage);
        return analysisBusinessPageDTO;
    }

    @Override
    public void doExportExcelBusiness(HttpServletResponse response, String sdate, String edate) {
        // TODO Auto-generated method stub
        log.info("{}-doExportExcelBusiness start……", ThreadLocalUtil.getRequestNo());
        try {
            List<AnalysisBusinessDO> resultlist = analysisBusinessRepository.queryListForExcel(sdate, edate);
            if (resultlist == null || resultlist.size() == 0) {
                log.info("没有需要导出的数据！");
                return;
            }

            Map<String, List<AnalysisBusinessDO>> excelMap = new HashMap<String, List<AnalysisBusinessDO>>();
            for (AnalysisBusinessDO analysisBusinessDo : resultlist) {
                if (null == excelMap.get(analysisBusinessDo.getSourceCode())) {
                    List<AnalysisBusinessDO> example = new ArrayList<AnalysisBusinessDO>();
                    example.add(analysisBusinessDo);
                    excelMap.put(analysisBusinessDo.getSourceCode(), example);
                } else {
                    excelMap.get(analysisBusinessDo.getSourceCode()).add(analysisBusinessDo);
                }
            }

            //ResultBase<List<UserSourceCountClient>> runUserClient = runUserFeignClient.queryUserSourceAll();

            List<AnalysisBusinessDO> runUserList = analysisBusinessRepository.queryAnalisysBusinessAll();

            Long addGrant = 0L, addInsure = 0L, addGrantTotal = 0L, addInsureTotal = 0L, activeCountAll = 0L;

            //构建excel

            String path = this.getClass().getResource("/static/excel/businessReg.xlsx").getPath();
            InputStream is = this.getClass().getResourceAsStream("/static/excel/businessReg.xlsx");
            log.info("excel模版的路径为=================" + path);

            Workbook workbook = new XSSFWorkbook(is);
            if (workbook == null) {
                log.info("workbook对象为null");
            }

            Sheet sheet = workbook.getSheetAt(0);//获取页签
            if (null != runUserList && runUserList.size() > 0) {

                for (int i = 0; i < runUserList.size(); i++) {
                    //第一行不用copy
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    AnalysisBusinessDO sourceClient = runUserList.get(i);

                    List<AnalysisBusinessDO> businessList = excelMap.get(sourceClient.getSourceCode());

                    Long addGrantAll = 0L;
                    Long addInsureAll = 0L;
                    for (AnalysisBusinessDO analysisBusinessDo : businessList) {
                        addGrantAll = addGrantAll + analysisBusinessDo.getAddGrant();//新增授权
                        addInsureAll = addInsureAll + analysisBusinessDo.getAddInsure();//新增投保
                    }
                    Row rowx = sheet.getRow(3 + i);
                    rowx.getCell(0).setCellValue(i + 1);//序列号
                    rowx.getCell(1).setCellValue(sourceClient.getSourceName() + sourceClient.getSourceCode());//渠道名字

                    rowx.getCell(2).setCellValue(addGrantAll);//新增授权
                    rowx.getCell(3).setCellValue(addInsureAll);//新增投保
                    rowx.getCell(4).setCellValue(addGrantAll == 0L ? "0%" : countRate(addInsureAll, addGrantAll));//新增投保转化率

                    Integer activeCount = getActivePerCount(sourceClient.getSourceCode(), sdate, edate);

                    rowx.getCell(5).setCellValue(activeCount.toString());//活跃人数
                    rowx.getCell(6)
                            .setCellValue(countRate(activeCount.longValue(), businessList.get(0).getInsureAll()));//活跃度

                    rowx.getCell(7).setCellValue(sourceClient.getGrantAll());//累计授权

                    rowx.getCell(8).setCellValue(sourceClient.getInsureAll());//累计投保

                    rowx.getCell(9)
                            .setCellValue(
                                    businessList.size() > 0 ? countRate(sourceClient.getInsureAll(),
                                            sourceClient.getGrantAll()) : "0%");//累计投保转化率

                    addGrant = addGrant + addGrantAll;//总概的新增授权
                    addInsure = addInsure + addInsureAll;//总概的新增投保
                    activeCountAll = activeCountAll + activeCount;
                    addGrantTotal = addGrantTotal + sourceClient.getGrantAll();
                    addInsureTotal = addInsureTotal + sourceClient.getInsureAll();

                }
                log.info("-----------------------------------合计----------------------------");
                //添加合计行
                ReadExcel.copyRows(sheet, 4, 4, 3 + runUserList.size());
                Row rowlast = sheet.getRow(3 + runUserList.size());
                rowlast.getCell(0).setCellValue("--");
                rowlast.getCell(1).setCellValue("总概");
                rowlast.getCell(2).setCellValue(addGrant);//该段时间内总概新增授权
                rowlast.getCell(3).setCellValue(addInsure);//该段时间内总概新增投保数
                rowlast.getCell(4).setCellValue(countRate(addInsure, addGrant));//该段时间内概总新增投保转化率
                rowlast.getCell(5).setCellValue(activeCountAll);//活跃人数
                rowlast.getCell(6).setCellValue(countRate(activeCountAll, addInsureTotal));//活跃度
                rowlast.getCell(7).setCellValue(addGrantTotal);//概总累计授权
                rowlast.getCell(8).setCellValue(addInsureTotal);//概总累计投保
                rowlast.getCell(9).setCellValue(countRate(addInsureTotal, addGrantTotal));
            }
            String title = "渠道数量分析";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();

        } catch (Exception e) {
            log.error("{}-doExportExcelBusiness fail……", e, ThreadLocalUtil.getRequestNo());
        }

    }

    @Override
    public ResultBase<String> getTodayDataAnalysisBusiness() {

        ResultBase<String> result = new ResultBase<String>();
        try {
            runAnalysisFeignClient.businessStatic();
            result.setSuccess(true);
            result.setValue("今天数据已经同步完毕！");
            result.setErrorCode("0");
            result.setErrorMessage("今天数据已经同步完毕！");
        } catch (Exception e) {
            log.error("{}-getTodayDataAnalysisBusiness fail……", e, ThreadLocalUtil.getRequestNo());

            result.setSuccess(false);
            result.setValue("数据同步失败！");
            result.setErrorCode("1");
            result.setErrorMessage("数据同步失败！");
        }
        return result;
    }

    private Integer getActivePerCount(String sourceCode, String sdate, String edate) {
        Map<String, String> map = new HashMap<String, String>();
        map.put("sourceCode", sourceCode);
        sdate = sdate + " 00:00:00";
        edate = edate + " 23:59:59";
        map.put("sdate", sdate);
        map.put("edate", edate);
        List<TransLogDO> list = transLogRepository.selectTransLogByDate(map);

        if (null != list && list.size() > 0) {
            return list.size();
        } else {
            return 0;
        }
    }

    /**
     * 字符串转百分比
     * 
     * @param rate
     * @return
     */
    private String formatPercentum(String rate) {
        NumberFormat nf = NumberFormat.getPercentInstance();
        String format = nf.format(Double.valueOf(rate));
        return format;
    }

    private String countRate(Long index, Long count) {
        if (index == 0 || count == 0) {
            return "0%";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return formatPercentum(s);
    }

}
