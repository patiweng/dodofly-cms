package com.zhongan.app.run.cms.bean.qrcode.model;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * 组织机构管理
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Data
public class BububaoThirdOrgDO {

    /**
     * 机构id
     */
    private Long                         id;

    /**
     * 机构code
     */
    private String                       orgCode;

    /**
     * 机构名称
     */
    private String                       orgName;

    /**
     * 机构级别 1 一级(总公司) 2 二级 ....
     */
    private Integer                      orgLevel;

    /**
     * 渠道id
     */
    private Long                         channelId;

    /**
     * 父级机构id
     */
    private Long                         parentOrgId;

    /**
     * 是否可为代理人
     */
    private String                       isOrgAgent;

    /**
     * 是否需要关注步步保 N、Y
     */
    private String                       isFollowBububao;

    /**
     * 是否删除 N、Y
     */
    private String                       isDeleted;

    /**
     * 创建人
     */
    private String                       creator;

    /**
     * 创建时间
     */
    private Date                         gmtCreated;

    /**
     * 修改人
     */
    private String                       modifier;

    /**
     * 更新时间
     */
    private Date                         gmtModified;

    /**
     * 子机构
     */
    private List<BububaoThirdOrgDO>   childOrgs;

    /**
     * 业务员
     */
    private List<BububaoThirdSalesDO> saless;
}
