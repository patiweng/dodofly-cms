package com.zhongan.app.run.cms.common.ziputil;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.StreamUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.io.*;
import java.nio.charset.Charset;
import java.util.List;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

@Slf4j
public class ZIPUtil {

    private static final String REGEX_NETWORK_URL = "^([hH][tT]{2}[pP]:/*|[hH][tT]{2}[pP][sS]:/*|[fF][tT][pP]:/*)(([A-Za-z0-9-~]+).)+([A-Za-z0-9-~\\/])+(\\?{0,1}(([A-Za-z0-9-~]+\\={0,1})([A-Za-z0-9-~]*)\\&{0,1})*)$";
    private static final String REGEX_LOCAL_URL = "^([fF][iI][lL][eE]:///)?[A-Za-z]/://[^/:/?/\"/>/</*]*";

    private static Pattern networkPattern;
    private static Pattern localPattern;

    public static Pattern getNetworkPattern(){
        if(networkPattern == null)
            networkPattern = Pattern.compile(REGEX_NETWORK_URL);
        return networkPattern;
    }

    public static Pattern getLocalPattern() {
        if(localPattern == null)
            localPattern = Pattern.compile(REGEX_LOCAL_URL);
        return localPattern;
    }

    public static void zipUrls(List<String> urls, ZipOutputStream outputStream, List<String> fileNames, OssTool ossTool){
        try {
            if(urls == null){
                return ;
            }
            int size = urls.size();
            for (int i = 0 ; i < size ; i++){
                zipUrl(urls.get(i), outputStream, fileNames.get(i), ossTool);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }

    }

    public static void zipUrls(List<String> urls, OutputStream outputStream, List<String> fileNames, OssTool ossTool){
        ZipOutputStream zipOutputStream = null;
        try {
            zipOutputStream = new ZipOutputStream(outputStream, Charset.forName("utf-8"));
            if(urls == null){
                return ;
            }
            int size = urls.size();
            for (int i = 0 ; i < size ; i++){
                zipUrl(urls.get(i), zipOutputStream, fileNames.get(i), ossTool);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }finally {
            try {
                if(zipOutputStream != null){
                    zipOutputStream.closeEntry();
                    zipOutputStream.close();
                }
            }catch (Exception e){
                log.error("Exception:", e);
            }
        }

    }

    public static void zipUrl(String url, ZipOutputStream zipOutputStream, String fileName, OssTool ossTool){
        try {
            if(StringUtils.isBlank(url)){
                return ;
            }
            if(getNetworkPattern().matcher(url).matches()){
                zipInput(StreamUtil.getInputStreamByNetworkUrl(url), zipOutputStream, fileName);
            }else if(getLocalPattern().matcher(url).matches()){
                zipFile(new File(url), zipOutputStream);
            }else{
                zipInput(ossTool.downloadFile(url), zipOutputStream, fileName);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }
    }

    public static void zipFiles(List<File> files, ZipOutputStream outputStream){
        try {
            if(files == null){
                return ;
            }
            for (File file : files){
                zipFile(file, outputStream);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }
    }

    public static void zipFiles(List<File> files, OutputStream outputStream){
        ZipOutputStream zipOutputStream = null;
        try {
            zipOutputStream = new ZipOutputStream(outputStream, Charset.forName("utf-8"));
            if(files == null){
                return ;
            }
            for (File file : files){
                zipFile(file, zipOutputStream);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }finally {
            try {
                if(zipOutputStream != null){
                    zipOutputStream.closeEntry();
                    zipOutputStream.close();
                }
            }catch (Exception e){
                log.error("Exception:", e);
            }
        }
    }

    public static void zipFile(File file, ZipOutputStream outputStream){
        try {
            if(file == null){
                return ;
            }
            if(file.exists()){
                if(file.isFile()){
                    FileInputStream fileInputStream = new FileInputStream(file);
                    zipInput(fileInputStream, outputStream, file.getName());
                }
            }else {
                File[] files = file.listFiles();
                zipFiles(Lists.newArrayList(files), outputStream);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }
    }

    public static void zipInputs(List<InputStream> inputStreams, ZipOutputStream outputStream, List<String> fileNames){
        try {
            if(inputStreams == null){
                return ;
            }
            int size = inputStreams.size();
            for (int i = 0 ; i < size ; i++){
                zipInput(inputStreams.get(i), outputStream, fileNames.get(i));
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }
    }


    public static void zipInputs(List<InputStream> inputStreams, OutputStream outputStream, List<String> fileNames){
        ZipOutputStream zipOutputStream = null;
        try {
            zipOutputStream = new ZipOutputStream(outputStream, Charset.forName("utf-8"));
            if(inputStreams == null){
                return ;
            }
            int size = inputStreams.size();
            for (int i = 0 ; i < size ; i++){
                zipInput(inputStreams.get(i), zipOutputStream, fileNames.get(i));
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }finally {
            try {
                if(zipOutputStream != null){
                    zipOutputStream.closeEntry();
                    zipOutputStream.close();
                }
            }catch (Exception e){
                log.error("Exception:", e);
            }
        }
    }

    public static void zipInput(InputStream inputStream, ZipOutputStream outputStream, String fileName){
        BufferedInputStream bufferedInputStream = null;
        try {
            if(inputStream == null){
                return ;
            }
            bufferedInputStream = new BufferedInputStream(inputStream, 512);
            ZipEntry entry = new ZipEntry(fileName);
            outputStream.putNextEntry(entry);
            int num;
            byte[] bytes = new byte[512];
            while ((num = bufferedInputStream.read(bytes)) != -1){
                outputStream.write(bytes, 0, num);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }finally {
            try {
                if(bufferedInputStream != null){
                    bufferedInputStream.close();
                }
                if(inputStream != null){
                    inputStream.close();
                }
            }catch (Exception e){
                log.error("Exception:", e);
            }
        }

    }

    public static void zipInput(InputStream inputStream, OutputStream outputStream, String fileName){
        BufferedInputStream bufferedInputStream = null;
        ZipOutputStream zipOutputStream = null;
        try {
            if(inputStream == null){
                return ;
            }
            zipOutputStream = new ZipOutputStream(outputStream, Charset.forName("utf-8"));
            bufferedInputStream = new BufferedInputStream(inputStream, 512);
            ZipEntry entry = new ZipEntry(fileName);
            zipOutputStream.putNextEntry(entry);
            int num;
            byte[] bytes = new byte[512];
            while ((num = bufferedInputStream.read(bytes)) != -1){
                zipOutputStream.write(bytes, 0, num);
            }
        }catch (Exception e){
            log.error("Exception:", e);
        }finally {
            try {
                if(bufferedInputStream != null){
                    bufferedInputStream.close();
                }
                if(zipOutputStream != null){
                    zipOutputStream.closeEntry();
                    zipOutputStream.close();
                }
                if(inputStream != null){
                    inputStream.close();
                }
            }catch (Exception e){
                log.error("Exception:", e);
            }
        }

    }

    public static void main(String[] args){
        try {
            File file = new File("D:/test.zip");
            FileOutputStream fileOutputStream = new FileOutputStream(file);
            ZipOutputStream zipOutputStream = new ZipOutputStream(fileOutputStream);

            File f = new File("D:/new.png");
            FileInputStream fileInputStream = new FileInputStream(f);
            BufferedInputStream bins = new BufferedInputStream(fileInputStream, 512);
            ZipEntry entry = new ZipEntry("1.png");
            zipOutputStream.putNextEntry(entry);
            int nNumber;
            byte[] buffer = new byte[512];
            while ((nNumber = bins.read(buffer)) != -1) {
                zipOutputStream.write(buffer, 0, nNumber);
            }

            bins.close();
            fileInputStream.close();

            File d = new File("C:/Users/lichao002/Desktop/健康险对接渠道清单（主要）1.xls");
            FileInputStream fileInputm = new FileInputStream(d);
            BufferedInputStream bin = new BufferedInputStream(fileInputm, 512);
            ZipEntry entr = new ZipEntry("dd/多福多寿.xls");
            zipOutputStream.putNextEntry(entr);
            int nNumbe;
            byte[] buffe = new byte[512];
            while ((nNumbe = bin.read(buffe)) != -1) {
                zipOutputStream.write(buffe, 0, nNumbe);
            }

            zipOutputStream.close();
            fileOutputStream.close();
        }catch (Exception e){
            System.out.println(e);
        }
        Pattern pattern = Pattern.compile(REGEX_NETWORK_URL);

        if (pattern.matcher("HTtp://127.0.0.1:8080/ba").matches()) {
            System.out.println("是正确的网址");
        } else {
            System.out.println("非法网址");
        }

    }
}
