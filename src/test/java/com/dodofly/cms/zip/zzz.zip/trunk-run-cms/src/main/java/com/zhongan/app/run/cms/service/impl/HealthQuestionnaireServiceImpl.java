package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.QuestionItemRepo;
import com.zhongan.app.run.cms.bean.repo.QuestionItemValueRepo;
import com.zhongan.app.run.cms.bean.repo.QuestionListRepo;
import com.zhongan.app.run.cms.bean.repo.UserQuestionRepo;
import com.zhongan.app.run.cms.bean.web.QuestionItemCheck;
import com.zhongan.app.run.cms.bean.web.QuestionItemDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemPageDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemValueDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemValuePageDTO;
import com.zhongan.app.run.cms.bean.web.QuestionListDTO;
import com.zhongan.app.run.cms.bean.web.QuestionListPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserQuestionDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.QuestionItemRepository;
import com.zhongan.app.run.cms.repository.QuestionItemValueRepository;
import com.zhongan.app.run.cms.repository.QuestionListRepository;
import com.zhongan.app.run.cms.repository.UserQuestionRepository;
import com.zhongan.app.run.cms.service.HealthQuestionnaireService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@Service("healthQuestionnaireServiceImpl")
public class HealthQuestionnaireServiceImpl implements HealthQuestionnaireService {
    @Resource
    private QuestionItemRepository      questionItemRepository;
    @Resource
    private QuestionItemValueRepository questionItemValueRepository;
    @Resource
    private QuestionListRepository      questionListRepository;
    @Resource
    private UserQuestionRepository      userQuestionRepository;

    @Override
    public ResultBase<JSONObject> selectQuestionnaireTag(QuestionListDTO questionListDTO) {
        log.info("HealthQuestionnaireServiceImpl.selectQuestionnaireTag……start，param=={}", questionListDTO.toString());
        ResultBase<JSONObject> resultBase = new ResultBase<JSONObject>();
        JSONObject baseData = null;//问卷
        JSONArray itemArray = null;//题目
        JSONArray optionArray = null;//题目子选项
        try {
            //根据id查询问卷表
            QuestionListDTO qDto = new QuestionListDTO();
            QuestionListRepo questionListRepo = questionListRepository.selectDataById(questionListDTO.getId());
            if (null != questionListRepo) {
                BeanUtils.copyProperties(questionListRepo, qDto);
                baseData = (JSONObject) JSONObject.toJSON(qDto);
                //查询改问卷的题目
                QuestionItemRepo questionItemRepo = new QuestionItemRepo();
                questionItemRepo.setQueryId(qDto.getId());
                questionItemRepo.setIsDeleted("0");
                //题目List
                List<QuestionItemRepo> questionItemRepoList = questionItemRepository.selectDataByCdt(questionItemRepo);
                if (null != questionItemRepoList && questionItemRepoList.size() > 0) {
                    itemArray = new JSONArray();
                    for (QuestionItemRepo itemRepo : questionItemRepoList) {
                        JSONObject itemObj = (JSONObject) JSONObject.toJSON(itemRepo);
                        String type = itemRepo.getType();
                        //1=单选 2=多选 5=下拉框 查询子选项
                        if ("1".equals(type) || "2".equals(type) || "5".equals(type)) {
                            QuestionItemValueRepo questionItemValueRepo = new QuestionItemValueRepo();
                            questionItemValueRepo.setItemId(itemRepo.getId());
                            questionItemValueRepo.setIsDeleted("0");
                            //题目子选项List
                            List<QuestionItemValueRepo> questionItemValueList = questionItemValueRepository
                                    .selectDataByCdt(questionItemValueRepo);
                            if (null != questionItemValueList && questionItemValueList.size() > 0) {
                                optionArray = new JSONArray();
                                for (QuestionItemValueRepo itemValueRepo : questionItemValueList) {
                                    JSONObject optionObj = (JSONObject) JSONObject.toJSON(itemValueRepo);
                                    optionArray.add(optionObj);
                                }
                            }
                            itemObj.put("optionArray", optionArray);
                        }
                        itemArray.add(itemObj);
                    }
                }
                baseData.put("itemArray", itemArray);
                resultBase.setValue(baseData);
                log.info("问卷题目json字符串======={}", baseData.toJSONString());
            }
            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            resultBase.setSuccess(true);
        } catch (Exception e) {
            log.error("HealthQuestionnaireServiceImpl.selectQuestionnaireTag……fail==={}", e);
            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> insertUserQuestion(List<UserQuestionDTO> userQuestions) {
        log.info("HealthQuestionnaireServiceImpl.insertUserQuestion  start……param==={}", userQuestions.toString());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            for (UserQuestionDTO userQuestionDTO : userQuestions) {
                UserQuestionRepo userQuestionRepo = new UserQuestionRepo();
                BeanUtils.copyProperties(userQuestionDTO, userQuestionRepo);
                userQuestionRepository.save(userQuestionRepo);
            }
            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            resultBase.setSuccess(true);
            resultBase.setValue("新增成功!");
        } catch (Exception e) {
            log.error("HealthQuestionnaireServiceImpl.insertUserQuestion……fail==={}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            resultBase.setSuccess(false);
            resultBase.setValue("新增失败!");
        }
        return resultBase;
    }

    @Override
    public ResultBase<List<UserQuestionDTO>> selectUserQuestionByCdt(UserQuestionDTO userQuestionDTO) {
        log.info("HealthQuestionnaireServiceImpl.selectUserQuestionByCdt……start……param==={}",
                userQuestionDTO.toString());
        ResultBase<List<UserQuestionDTO>> resultBase = new ResultBase<List<UserQuestionDTO>>();
        List<UserQuestionDTO> dtoList = null;
        try {
            UserQuestionRepo userQuestionRepo = new UserQuestionRepo();
            BeanUtils.copyProperties(userQuestionDTO, userQuestionRepo);
            List<UserQuestionRepo> repoList = userQuestionRepository.selectDataByCdt(userQuestionRepo);
            if (repoList != null && repoList.size() > 0) {
                dtoList = Lists.newArrayList();
                UserQuestionDTO dto = new UserQuestionDTO();
                for (UserQuestionRepo repo : repoList) {
                    BeanUtils.copyProperties(repo, dto);
                    dtoList.add(dto);
                }
            }
            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            resultBase.setSuccess(true);
            resultBase.setValue(dtoList);
        } catch (Exception e) {
            log.error("HealthQuestionnaireServiceImpl.selectUserQuestionByCdt……fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
            resultBase.setValue(null);
        }
        return resultBase;
    }

    @Override
    public ResultBase<String> insertQustionnaireData(QuestionListDTO questionListDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionListRepo questionListRepo = new QuestionListRepo();
            BeanUtils.copyProperties(questionListDTO, questionListRepo);
            result = questionListRepository.saveQuestionList(questionListRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save-- QuestionList...."
                    + "error location polynomial : HealthQuestionnaireServiceImpl--insertQustionnaireData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    @Override
    public QuestionListDTO selectOneQustionnaire(String id) {
        log.info("{}-select one Qustionnaire info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        QuestionListDTO questionListDTO = new QuestionListDTO();
        try {
            QuestionListRepo questionListRepo = questionListRepository.selectDataById(Long.valueOf(id));
            if (questionListRepo != null) {
                BeanUtils.copyProperties(questionListRepo, questionListDTO);
            }
        } catch (Exception e) {
            log.error("{}-Qustionnaire select one  fail,please find error to...。"
                    + "error location polynomial:HealthQuestionnaireServiceImpl--selectOneQustionnaire()"
                    + "exception：" + e, ThreadLocalUtil.getRequestNo());
        }
        return questionListDTO;
    }

    @Override
    public QuestionListPageDTO selectQustionnaireListPage(Page<QuestionListDTO> questionListDTOPage) {
        QuestionListPageDTO questionListPageDTO = new QuestionListPageDTO();
        Page<QuestionListRepo> questionListRepoPage = new Page<QuestionListRepo>();
        BeanUtils.copyProperties(questionListDTOPage, questionListRepoPage);
        questionListRepoPage = questionListRepository.selectQuestionListDataPage(questionListRepoPage);
        List<QuestionListRepo> questionListRepoList = questionListRepoPage.getResultList();
        List<QuestionListDTO> questionListDTOList = Lists.newArrayList();
        if (questionListRepoList != null && questionListRepoList.size() > 0) {
            QuestionListDTO questionListDTO = null;
            for (QuestionListRepo questionListRepos : questionListRepoList) {
                questionListDTO = new QuestionListDTO();
                BeanUtils.copyProperties(questionListRepos, questionListDTO);
                questionListDTOList.add(questionListDTO);
            }
        }
        questionListDTOPage.setResultList(questionListDTOList);
        questionListDTOPage.setTotalItem(questionListRepoPage.getTotalItem());
        questionListPageDTO.setQuestionListDTO(questionListDTOPage);
        return questionListPageDTO;
    }

    @Override
    public ResultBase<String> updateQustionnaireData(QuestionListDTO questionListDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionListRepo questionListRepo = new QuestionListRepo();
            BeanUtils.copyProperties(questionListDTO, questionListRepo);
            result = questionListRepository.updateQuestionList(questionListRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--QuestionList...."
                    + "error location polynomial : RaffleActivityServiceImpl--updateQustionnaireData()" + "exception："
                    + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> deleteQustionnaire(String id) {
        log.info("{}-delete Qustionnaire info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionItemDTO itemDTO = new QuestionItemDTO();
            itemDTO.setQueryId(Long.valueOf(id));
            List<QuestionItemDTO> itemDTOList = selectQuestionItemByCdt(itemDTO).getValue();
            if (null != itemDTOList && !itemDTOList.isEmpty()) {
                QuestionItemValueDTO valueDTO = null;
                for (QuestionItemDTO itemDTOs : itemDTOList) {
                    valueDTO = new QuestionItemValueDTO();
                    valueDTO.setItemId(itemDTOs.getId());
                    List<QuestionItemValueDTO> valueDTOList = selectQuestionItemValueByCdt(valueDTO).getValue();
                    if (null != valueDTOList && !valueDTOList.isEmpty()) {
                        //删除问题下的所有选项
                        for (QuestionItemValueDTO valueDTOS : valueDTOList) {
                            deleteQustionItemValue(valueDTOS.getId().toString());
                        }
                    }
                    //删除问卷下所有问题
                    deleteQustionItem(itemDTOs.getId().toString());
                }
            }
            //删除问卷
            result = questionListRepository.deleteByid(id);
            if (result.isSuccess()) {
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
                result.setSuccess(true);
            } else {
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
                result.setSuccess(false);
            }
        } catch (Exception e) {
            log.error("{}-Qustionnaire delete fail,please find error to...。"
                    + "error location HealthQuestionnaireServiceImpl--deleteQustionnaire()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> insertQustionItemData(QuestionItemDTO questionItemDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionItemRepo questionItemRepo = new QuestionItemRepo();
            BeanUtils.copyProperties(questionItemDTO, questionItemRepo);
            result = questionItemRepository.saveQuestionItem(questionItemRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save-- QuestionItem...."
                    + "error location polynomial : HealthQuestionnaireServiceImpl--insertQustionItemData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    @Override
    public QuestionItemDTO selectOneQustionItem(String id) {
        log.info("{}-select one QuestionItem info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        QuestionItemDTO questionItemDTO = new QuestionItemDTO();
        try {
            QuestionItemRepo questionListRepo = questionItemRepository.selectDataById(Long.valueOf(id));
            if (questionListRepo != null) {
                BeanUtils.copyProperties(questionListRepo, questionItemDTO);
                if (null != questionItemDTO.getInputCheck() && !"".equals(questionItemDTO.getInputCheck())) {
                    questionItemDTO
                            .setCheck(JSON.parseObject(questionItemDTO.getInputCheck(), QuestionItemCheck.class));
                }
            }
        } catch (Exception e) {
            log.error("{}-QuestionItem select one  fail,please find error to...。"
                    + "error location polynomial:HealthQuestionnaireServiceImpl--selectOneQustionItem()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
        }
        return questionItemDTO;
    }

    @Override
    public QuestionItemPageDTO selectQustionItemListPage(Page<QuestionItemDTO> questionItemDTOPage) {
        QuestionItemPageDTO questionItemPageDTO = new QuestionItemPageDTO();
        Page<QuestionItemRepo> questionItemRepoPage = new Page<QuestionItemRepo>();
        BeanUtils.copyProperties(questionItemDTOPage, questionItemRepoPage);
        questionItemRepoPage = questionItemRepository.selectQuestionItemDataPage(questionItemRepoPage);
        List<QuestionItemRepo> questionItemRepoList = questionItemRepoPage.getResultList();
        List<QuestionItemDTO> questionItemDTOList = Lists.newArrayList();
        if (questionItemRepoList != null && questionItemRepoList.size() > 0) {
            QuestionItemDTO questionItemDTO = null;
            for (QuestionItemRepo questionItemRepos : questionItemRepoList) {
                questionItemDTO = new QuestionItemDTO();
                BeanUtils.copyProperties(questionItemRepos, questionItemDTO);
                questionItemDTOList.add(questionItemDTO);
            }
        }
        questionItemDTOPage.setResultList(questionItemDTOList);
        questionItemDTOPage.setTotalItem(questionItemRepoPage.getTotalItem());
        questionItemPageDTO.setQuestionItemDTO(questionItemDTOPage);
        return questionItemPageDTO;
    }

    @Override
    public ResultBase<String> updateQustionItemData(QuestionItemDTO questionItemDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionItemRepo questionItemRepo = new QuestionItemRepo();
            BeanUtils.copyProperties(questionItemDTO, questionItemRepo);
            result = questionItemRepository.updateQuestionItemList(questionItemRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--QustionItem...."
                    + "error location polynomial : RaffleActivityServiceImpl--updateQustionItemData()" + "exception："
                    + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> deleteQustionItem(String id) {
        log.info("{}-delete QustionItem info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            //删除问题下所有选项
            QuestionItemValueDTO valueDTO = new QuestionItemValueDTO();
            valueDTO.setItemId(Long.valueOf(id));
            List<QuestionItemValueDTO> valueDTOList = selectQuestionItemValueByCdt(valueDTO).getValue();
            if (null != valueDTOList && !valueDTOList.isEmpty()) {
                for (QuestionItemValueDTO valueDTOs : valueDTOList) {
                    deleteQustionItemValue(valueDTOs.getId().toString());
                }
            }
            result = questionItemRepository.deleteByid(id);
            if (result.isSuccess()) {
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
                result.setSuccess(true);
            } else {
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
                result.setSuccess(false);
            }
        } catch (Exception e) {
            log.error("{}-QustionItem delete fail,please find error to...。"
                    + "error location HealthQuestionnaireServiceImpl--deleteQustionItem()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<List<QuestionItemDTO>> selectQuestionItemByCdt(QuestionItemDTO questionItemDTO) {
        log.info("HealthQuestionnaireServiceImpl.selectQuestionItemByCdt……start……param==={}",
                questionItemDTO.toString());
        ResultBase<List<QuestionItemDTO>> resultBase = new ResultBase<List<QuestionItemDTO>>();
        List<QuestionItemDTO> dtoList = null;
        try {
            QuestionItemRepo questionItemRepo = new QuestionItemRepo();
            BeanUtils.copyProperties(questionItemDTO, questionItemRepo);
            List<QuestionItemRepo> repoList = questionItemRepository.selectDataByCdt(questionItemRepo);
            if (repoList != null && repoList.size() > 0) {
                dtoList = Lists.newArrayList();
                QuestionItemDTO dto = null;
                for (QuestionItemRepo repo : repoList) {
                    dto = new QuestionItemDTO();
                    BeanUtils.copyProperties(repo, dto);
                    dtoList.add(dto);
                }
            }
            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            resultBase.setSuccess(true);
            resultBase.setValue(dtoList);
        } catch (Exception e) {
            log.error("HealthQuestionnaireServiceImpl.selectQuestionItemByCdt……fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
            resultBase.setValue(null);
        }
        return resultBase;
    }

    @Override
    public QuestionItemValueDTO selectOneQustionItemValue(String id) {
        log.info("{}-select one QuestionItemValue info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        QuestionItemValueDTO questionItemValueDTO = new QuestionItemValueDTO();
        try {
            QuestionItemValueRepo questionItemValueRepo = questionItemValueRepository.selectDataById(Long.valueOf(id));
            if (questionItemValueRepo != null) {
                BeanUtils.copyProperties(questionItemValueRepo, questionItemValueDTO);
            }
        } catch (Exception e) {
            log.error("{}-QuestionItemValue select one  fail,please find error to...。"
                    + "error location polynomial:HealthQuestionnaireServiceImpl--selectOneQustionItemValue()"
                    + "exception：" + e, ThreadLocalUtil.getRequestNo());
        }
        return questionItemValueDTO;
    }

    @Override
    public QuestionItemValuePageDTO selectQustionItemValueListPage(Page<QuestionItemValueDTO> questionItemValueDTOPage) {
        QuestionItemValuePageDTO questionItemValuePageDTO = new QuestionItemValuePageDTO();
        Page<QuestionItemValueRepo> questionItemValueRepoPage = new Page<QuestionItemValueRepo>();
        BeanUtils.copyProperties(questionItemValueDTOPage, questionItemValueRepoPage);
        questionItemValueRepoPage = questionItemValueRepository
                .selectQuestionItemValueDataPage(questionItemValueRepoPage);
        List<QuestionItemValueRepo> questionItemValueRepoList = questionItemValueRepoPage.getResultList();
        List<QuestionItemValueDTO> questionItemValueDTOList = Lists.newArrayList();
        if (questionItemValueRepoList != null && questionItemValueRepoList.size() > 0) {
            QuestionItemValueDTO questionItemValueDTO = null;
            for (QuestionItemValueRepo questionItemValueRepos : questionItemValueRepoList) {
                questionItemValueDTO = new QuestionItemValueDTO();
                BeanUtils.copyProperties(questionItemValueRepos, questionItemValueDTO);
                questionItemValueDTOList.add(questionItemValueDTO);
            }
        }
        questionItemValueDTOPage.setResultList(questionItemValueDTOList);
        questionItemValueDTOPage.setTotalItem(questionItemValueRepoPage.getTotalItem());
        questionItemValuePageDTO.setQuestionItemValueDTO(questionItemValueDTOPage);
        return questionItemValuePageDTO;
    }

    @Override
    public ResultBase<String> insertQustionItemValueData(QuestionItemValueDTO questionItemValueDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionItemValueRepo questionItemValueRepo = new QuestionItemValueRepo();
            BeanUtils.copyProperties(questionItemValueDTO, questionItemValueRepo);
            result = questionItemValueRepository.saveQuestionItemValue(questionItemValueRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save-- QuestionItemValue...."
                    + "error location polynomial : HealthQuestionnaireServiceImpl--insertQustionItemValueData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> updateQustionItemValueData(QuestionItemValueDTO questionItemValueDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            QuestionItemValueRepo questionItemValueRepo = new QuestionItemValueRepo();
            BeanUtils.copyProperties(questionItemValueDTO, questionItemValueRepo);
            result = questionItemValueRepository.updateQuestionItemList(questionItemValueRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--QuestionItemValue...."
                    + "error location polynomial : RaffleActivityServiceImpl--updateQustionItemValueData()"
                    + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> deleteQustionItemValue(String id) {
        log.info("{}-delete QustionItemValue info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            result = questionItemValueRepository.deleteByid(id);
            if (result.isSuccess()) {
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
                result.setSuccess(true);
            } else {
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
                result.setSuccess(false);
            }
        } catch (Exception e) {
            log.error("{}-QuestionItemValue delete fail,please find error to...。"
                    + "error location HealthQuestionnaireServiceImpl--deleteQustionItemValue()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<List<QuestionItemValueDTO>> selectQuestionItemValueByCdt(QuestionItemValueDTO questionItemValueDTO) {
        log.info("HealthQuestionnaireServiceImpl.selectQuestionItemValueByCdt……start……param==={}",
                questionItemValueDTO.toString());
        ResultBase<List<QuestionItemValueDTO>> resultBase = new ResultBase<List<QuestionItemValueDTO>>();
        List<QuestionItemValueDTO> dtoList = null;
        try {
            QuestionItemValueRepo questionItemValueRepo = new QuestionItemValueRepo();
            BeanUtils.copyProperties(questionItemValueDTO, questionItemValueRepo);
            List<QuestionItemValueRepo> repoList = questionItemValueRepository.selectDataByCdt(questionItemValueRepo);
            if (repoList != null && repoList.size() > 0) {
                dtoList = Lists.newArrayList();
                QuestionItemValueDTO dto = null;
                for (QuestionItemValueRepo repo : repoList) {
                    dto = new QuestionItemValueDTO();
                    BeanUtils.copyProperties(repo, dto);
                    dtoList.add(dto);
                }
            }
            resultBase.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            resultBase.setSuccess(true);
            resultBase.setValue(dtoList);
        } catch (Exception e) {
            log.error("HealthQuestionnaireServiceImpl.selectQuestionItemValueByCdt……fail……{}", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            resultBase.setSuccess(false);
            resultBase.setValue(null);
        }
        return resultBase;
    }
}
