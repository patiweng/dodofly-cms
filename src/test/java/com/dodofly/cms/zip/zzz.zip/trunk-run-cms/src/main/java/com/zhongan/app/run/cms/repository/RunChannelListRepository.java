package com.zhongan.app.run.cms.repository;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoChannelListDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.dao.BububaoChannelListDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
@Slf4j
@Component
public class RunChannelListRepository {

	@Resource
	private BububaoChannelListDAO bububaoChannelListDAO;
	
	@Resource
	private Sequence         seqChannelList;
	
	@Resource
	private OssTool ossTool;
	@Value("${za.run.img.domain.url}")
	private String imgDomain;
	public ResultBase<RunChannelListDTO> selectRunChannelListData(RunChannelListRepo runChannelListRepo){
		    log.info("{}-select  RunChannelList。。。Repository。。。",ThreadLocalUtil.getRequestNo());
	        ResultBase<RunChannelListDTO> result = new ResultBase<RunChannelListDTO>();
	        RunChannelListDTO runChannelListDTO = new RunChannelListDTO();
	        BububaoChannelListDO bububaoChannelListDO = new BububaoChannelListDO();
	        BeanUtils.copyProperties(runChannelListRepo, bububaoChannelListDO);
	        List<BububaoChannelListDO> resultlist = bububaoChannelListDAO.selectDataByCdt(bububaoChannelListDO); 
	        if(resultlist.size()>0){
	        	BeanUtils.copyProperties(resultlist.get(0), runChannelListDTO);
	        	result.setValue(runChannelListDTO);	 
	        }else{
	        	 result.setValue(null);	
	        }
	        result.setSuccess(true);   	       
	        return result;					
	}
	
	
	public ResultBase<List<RunChannelListDTO>> selectRunChannelListDataList(RunChannelListRepo runChannelListRepo){
	    log.info("{}-select  RunChannelList。。。Repository。。。",ThreadLocalUtil.getRequestNo());
	    ResultBase<List<RunChannelListDTO>> result = new ResultBase<List<RunChannelListDTO>>();
        BububaoChannelListDO bububaoChannelListDO = new BububaoChannelListDO();
        BeanUtils.copyProperties(runChannelListRepo, bububaoChannelListDO);
        List<RunChannelListDTO> list = new ArrayList<RunChannelListDTO>();
        List<BububaoChannelListDO> resultlist = bububaoChannelListDAO.selectDataByCdt(bububaoChannelListDO);       
        if(resultlist.size()>0){
        	 for(BububaoChannelListDO BububaoChannelListDO :resultlist){
             	RunChannelListDTO runChannelListDTO = new RunChannelListDTO();
             	BeanUtils.copyProperties(BububaoChannelListDO, runChannelListDTO);
             	list.add(runChannelListDTO);
             }       	
        }
        result.setSuccess(true);   
        result.setValue(list);	
        return result;					
     }
	
	//分页
	
	public Page<RunChannelListRepo> selectChannelListPage(Page<RunChannelListRepo> runChannelListRepoPage){
		
		BububaoChannelListDO bububaoChannelListDO = new BububaoChannelListDO();
        if (null != runChannelListRepoPage.getParam()) {
            BeanUtils.copyProperties(runChannelListRepoPage.getParam(), bububaoChannelListDO);
        }
        bububaoChannelListDO.setStatus(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", runChannelListRepoPage.getStartRow());
        map.put("pageSize", runChannelListRepoPage.getPageSize());
        map.put("bububaoChannelListDO", bububaoChannelListDO);
        List<BububaoChannelListDO> bububaoChannelListDOList = bububaoChannelListDAO.selectBububaoChannelList(map);
        List<RunChannelListRepo> runChannelListRepoList = Lists.newArrayList();
        if (null != bububaoChannelListDOList && 0 != bububaoChannelListDOList.size()) {
        	RunChannelListRepo runChannelListRepodo = null;
            for (BububaoChannelListDO BububaoChannelLists : bububaoChannelListDOList) {
            	runChannelListRepodo = new RunChannelListRepo();
                BeanUtils.copyProperties(BububaoChannelLists, runChannelListRepodo);
                runChannelListRepoList.add(runChannelListRepodo);
            }
        }
        runChannelListRepoPage.setResultList(runChannelListRepoList);
        Integer counts = bububaoChannelListDAO.selectCounts(map);
        runChannelListRepoPage.setTotalItem(counts);
        return runChannelListRepoPage;	
	}
	

	  //插入一条新的记录（渠道表）
    public ResultBase<String> saveChannelList(RunChannelListRepo runChannelListRepo) throws Exception {
        log.info("{}-insert bububaoChannelList。。。Repository。。。RunChannelListRepo={}",ThreadLocalUtil.getRequestNo(),runChannelListRepo);
        ResultBase<String> result = new ResultBase<String>();
        BububaoChannelListDO bububaoChannelListDO = new BububaoChannelListDO();
        BeanUtils.copyProperties(runChannelListRepo, bububaoChannelListDO);
        Long id = seqChannelList.nextValue();
        /************文件上传*************/
        ResultBase<String> flagRs = ossTool.handleImg(String.valueOf(id)+"_1",runChannelListRepo.getMarketingImgFile());
        if(!flagRs.isSuccess()){
        	result.setSuccess(false);
        	log.info("{}-insert bububaoChannelList。。。Repository11。。。message={}",ThreadLocalUtil.getRequestNo(),AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
        	result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	return result;
        }
        ResultBase<String> flagRs2 = ossTool.handleImg(String.valueOf(id)+"_2",runChannelListRepo.getMarketingImgFileTwo());
        if(!flagRs2.isSuccess()){
        	result.setSuccess(false);
        	log.info("{}-insert bububaoChannelList。。。Repository22。。。message={}",ThreadLocalUtil.getRequestNo(),AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
        	result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	return result;
        }
        String file1 = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        String file2 = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        
        bububaoChannelListDO.setMomentsUrl(file1);
        bububaoChannelListDO.setFriendUrl(file2);
        bububaoChannelListDO.setId(id.toString());
        bububaoChannelListDO.setCreater(RunConstants.SYSTEM_NAME);
        bububaoChannelListDAO.insert(bububaoChannelListDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }      
    
    
    //根据主键修改渠道信息
    
    public ResultBase<String> updateChannelList(RunChannelListRepo runChannelListRepo) throws Exception {
    	ResultBase<String> result = new ResultBase<String>();   	
    	log.info("{}-update bububaoChannelList。。。Repository。。。",ThreadLocalUtil.getRequestNo());
    	BububaoChannelListDO bububaoChannelListDO = new BububaoChannelListDO();
        BeanUtils.copyProperties(runChannelListRepo, bububaoChannelListDO);
        String id = bububaoChannelListDO.getId();
        /************文件上传*************/
        ResultBase<String> flagRs = ossTool.handleImg(String.valueOf(id)+"_1",runChannelListRepo.getMarketingImgFile());
        if(!flagRs.isSuccess()){
        	result.setSuccess(false);
        	result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
        	result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	return result;
        }
        ResultBase<String> flagRs2 = ossTool.handleImg(String.valueOf(id)+"_2",runChannelListRepo.getMarketingImgFileTwo());
        if(!flagRs2.isSuccess()){
        	result.setSuccess(false);
        	result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
        	result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	return result;
        }
        String file1 = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        String file2 = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs2.getValue();
        bububaoChannelListDO.setMomentsUrl(file1);
        bububaoChannelListDO.setFriendUrl(file2);
        bububaoChannelListDAO.update(bububaoChannelListDO);
        result.setSuccess(true);
        result.setValue(RunConstants.UPDATE_TRUE);
    	return result;
    }
    
    //删除信息
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        bububaoChannelListDAO.updateByid(id);
        result.setSuccess(true);
        return result;
    }
    
 //根据id 查询一个对象信息
    
    public RunChannelListRepo selectOneData(String id){
    	RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
    	BububaoChannelListDO bububaoChannelListDO = bububaoChannelListDAO.selectOneDataById(id);
    	if(bububaoChannelListDO!=null){
    		BeanUtils.copyProperties(bububaoChannelListDO, runChannelListRepo);  	
    	}   	
    	return  runChannelListRepo;
    }
}
