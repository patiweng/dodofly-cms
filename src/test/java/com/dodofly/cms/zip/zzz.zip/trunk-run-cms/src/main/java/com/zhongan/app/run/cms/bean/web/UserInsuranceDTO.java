package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

import lombok.Data;

import com.alibaba.fastjson.JSONObject;

@Data
public class UserInsuranceDTO {

    private Long    id;

    private Long    unionid;

    /** 在哪个渠道投的保 */
    private String  channelFrom;

    /** 渠道交易号 */
    private String  insuredId;

    /** 营销活动id */
    private String  campaignDefId;

    /** 产品组合id */
    private String  packageDefId;

    /** 投保人姓名 */
    private String  holderName;

    /** 投保人身份证， 身份证：I；护照号：P */
    private String  holderIdentity;

    /** 投保人手机号 */
    private String  holderPhone;

    /** 证件类型 */
    private String  holderCertiType;

    /** 投保人性别，男：1，女：0，未知：10 */
    private String  holderSex;

    /** 投保人出生日期 */
    private String  holderBirthday;

    /** 渠道端计算保额 */
    private Integer channelSum;

    /** 渠道端计算保费,支付时选择优惠券可能会减少 */
    private Double  channelPremium;

    /** 实际保额 */
    private Integer originSum;

    /** 实际保费 */
    private Double  originPremium;

    /** 保单开始时间 */
    private String  policyStartTime;

    /** 保单结束时间 */
    private String  policyEndTime;

    /** 保单号 */
    private String  policyNo;

    /** 保单Id */
    private String  policyId;

    /** 是否免费保单，0：否，1：是 */
    private String  isFree;

    /** 免费的天数 */
    private Integer freeDays;

    /** 使用优惠券的id */
    private Long    couponId;

    /** 优惠券 */
    private String  coupon;

    /** 是否已支付 */
    private String  paid;

    /** 支付时间 */
    private String  paidTime;

    /** 最后投保缴费截止时间 */
    private String  duePayTime;

    /** 创建时间 */
    private Date    createtime;

    /** 修改时间 */
    private Date    modifytime;

    /** 状态， 0，成功 1，失败 */
    private String  status;

    /** 用户渠道来源表中的id */
    private String  userId;

    /** 用户目标步数 */
    private String  userTarget;

    /** 总天数 */
    private Integer days;

    /** 昵称 */
    private String  nickName;

    /** 头像url */
    private String  headImgUrl;

    /** 每日保费 */
    private String  premium;

    /** 渠道活动名称 */
    private String  channelTitle;

    /** 短信校验码 */
    private String  verificationCode;

    /** 当前渠道（续保支付时取得当前渠道的渠道码（如果为微信渠道推送微信消息）和支付方式，其他跟着上一张保单的渠道走） */
    private String  currentChannelFrom;

    /** 如果出两张保单，第二个渠道交易号 */
    private String  insuredIdSec;

    /** 如果出两张保单，第二个保单号 */
    private String  policyNoSec;

    /** 小程序唯一标识 */
    private String  openid;
    /** 用户的token */
    private String  newtoken;

    /** 续保标识:Y：是;N：否 */
    private String  isRenewal;

    /** 续保最近一张保单号 */
    private String  renewalpolicyNo;

    /** 续保保单标识1：付费保单;0：免费保单 */
    private String  renewalFlag;

    public String getAccountInfo() {
        JSONObject obj = new JSONObject();
        obj.put("dk_certif_id", this.getHolderIdentity());
        obj.put("dk_phone_no", this.getHolderPhone());
        return obj.toJSONString();
    }
}
