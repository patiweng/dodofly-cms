package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.MonthBusinessDTO;
import com.zhongan.app.run.cms.bean.web.MonthBusinessPageDTO;
import com.zhongan.app.run.cms.service.ExportMonthBusinessService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/excelbusiness")
@Slf4j
public class ExportMonthBusinessController {
    @Resource
    private ExportMonthBusinessService exportMonthBusinessServiceImpl;

    /**
     * 月汇总，分页查询
     * 
     * @param request
     * @param monthBusinessDTO
     * @return
     */
    @RequestMapping(value = "/select/selectmonthbusinesslistpage")
    public ModelAndView selectMonthBusinessListPage(HttpServletRequest request, MonthBusinessDTO monthBusinessDTO) {
        log.info("{}-into /select/selectMonthBusinessListPage,param={ " + monthBusinessDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<MonthBusinessDTO> monthBusinessPage = new Page<MonthBusinessDTO>(monthBusinessDTO.getPageSize(),
                monthBusinessDTO.getCurrentPage());
        monthBusinessPage.setParam(monthBusinessDTO);
        MonthBusinessPageDTO result = exportMonthBusinessServiceImpl.selectMonthBusinessList(monthBusinessPage);
        monthBusinessPage = result.getMonthBusinessPageDTO();
        Map<String, Object> model = Maps.newHashMap();
        if (null != monthBusinessPage) {
            model.put("monthBusinessList", monthBusinessPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("monthBussinessDTO", monthBusinessDTO);
        model.put("page", monthBusinessPage);
        return new ModelAndView("cms/monthBusiness", model);
    }

    @RequestMapping(value = "/select/doexportexcelmonthbusiness", method = RequestMethod.GET)
    public void doExportExcelMonthBusiness(HttpServletResponse response) {
        log.info("{}-/doExportExcelMonthBusiness,doExportExcelMonthBusiness start……", ThreadLocalUtil.getRequestNo());
        exportMonthBusinessServiceImpl.doExportExcelMonthBusiness(response);
    }

}
