package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.dataobject.AwardRuleDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityPresentDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoMarketingActivitiesDO;
import com.zhongan.app.run.cms.dao.AwardRuleDAO;
import com.zhongan.app.run.cms.dao.BububaoActivityPresentDAO;
import com.zhongan.app.run.cms.dao.BububaoMarketingActivitiesDAO;
import com.zhongan.app.run.common.utils.RedisUtil;

@Slf4j
@RestController
@RequestMapping("/run/cms/clearredis")
public class ClearRedisController {

    @Resource
    private RedisUtil                     redisUtil;

    @Resource
    private BububaoMarketingActivitiesDAO marketingActivitiesDAO;

    @Resource
    private BububaoActivityPresentDAO     activityPresentDAO;

    @Resource
    private AwardRuleDAO                  awardRuleDAO;

    @RequestMapping(value = "/clearredis/{id}", method = RequestMethod.GET)
    public void clearRedis(@PathVariable String id) {
        redisUtil.delete("bububao_marketing_activities:" + id);
        log.info("redisUtil log bububao_marketing_activities"
                + redisUtil.getString("bububao_marketing_activities:" + id));
        BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = marketingActivitiesDAO.selectOneDataById(id);
        String activityId = bububaoMarketingActivitiesDO.getActivityId();
        redisUtil.delete("bububao_activity:" + activityId);
        log.info("redisUtil log bububao_activity" + redisUtil.getString("bububao_activity:" + activityId));
        redisUtil.delete("bububao_activity_times:" + activityId);
        log.info("redisUtil log bububao_activity_times" + redisUtil.getString("bububao_activity_times:" + activityId));
        redisUtil.delete("bububao_activity_present:" + activityId);
        log.info("redisUtil log bububao_activity_present"
                + redisUtil.getString("bububao_activity_present:" + activityId));

        BububaoActivityPresentDO bububaoActivityPresentDO = new BububaoActivityPresentDO();
        bububaoActivityPresentDO.setActivityId(activityId);
        List<BububaoActivityPresentDO> activityPresentDOs = activityPresentDAO
                .selectDataByCdt(bububaoActivityPresentDO);
        if (activityPresentDOs.size() > 0) {
            for (BububaoActivityPresentDO aBububaoActivityPresentDO : activityPresentDOs) {
                String presentId = aBububaoActivityPresentDO.getPresentId();
                redisUtil.delete("bububao_present:" + presentId);
                log.info("redisUtil log bububao_present" + redisUtil.getString("bububao_present:" + presentId));
                String activityPresentId = aBububaoActivityPresentDO.getId();
                redisUtil.delete("bububao_activity_present_number:" + activityPresentId);
                log.info("redisUtil log bububao_activity_present_number"
                        + redisUtil.getString("bububao_activity_present_number:" + activityPresentId));
                redisUtil.delete("bububao_award_rule:" + activityPresentId);
                log.info("redisUtil log bububao_award_rule"
                        + redisUtil.getString("bububao_award_rule:" + activityPresentId));

                AwardRuleDO awardRuleDO = new AwardRuleDO();
                awardRuleDO.setActivityPresentId(Long.parseLong(activityPresentId));
                List<AwardRuleDO> awardRuleDOs = awardRuleDAO.selectAllDataByCdt(awardRuleDO);
                if (awardRuleDOs.size() > 0) {
                    for (AwardRuleDO aAwardRuleDO : awardRuleDOs) {
                        Integer requireid = aAwardRuleDO.getRequireid();
                        if (requireid > 0) {
                            redisUtil.delete("bububao_special_award:" + requireid);
                            log.info("redisUtil log bububao_special_award"
                                    + redisUtil.getString("bububao_special_award:" + requireid));
                        }
                    }
                }
            }
        }
    }

    @RequestMapping(value = "/clearpropertyredis/{unionid}", method = RequestMethod.GET)
    public void clearPropertyRedis(@PathVariable String unionid) {
        redisUtil.delete("runstep_" + unionid);
        log.info("redisUtil log bububao_user_property" + unionid + redisUtil.getString("runstep_" + unionid));
    }

}
