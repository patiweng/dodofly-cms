package com.zhongan.app.run.cms.conver;

import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.CashierNotifyDetailDTO;
import com.zhongan.app.run.cms.dao.bean.CashierNotifyDetailDO;
import com.zhongan.health.common.share.enm.YesOrNo;

public class CashierNotifyDetailConvert {

    public static CashierNotifyDetailDO convertToDO(CashierNotifyDetailDTO notifyDetailDTO) {
        CashierNotifyDetailDO cashierNotifyDetailDO = new CashierNotifyDetailDO();
        BeanUtils.copyProperties(notifyDetailDTO, cashierNotifyDetailDO);
        if (null == notifyDetailDTO.getId()) {
            cashierNotifyDetailDO.setCreator("system");
            cashierNotifyDetailDO.setGmtCreated(new Date());
            cashierNotifyDetailDO.setModifier("system");
            cashierNotifyDetailDO.setGmtModified(new Date());
            cashierNotifyDetailDO.setIsDeleted(YesOrNo.NO.getCode());
        } else {
            cashierNotifyDetailDO.setModifier("system");
            cashierNotifyDetailDO.setGmtModified(new Date());
        }
        return cashierNotifyDetailDO;
    }

    public static List<CashierNotifyDetailDTO> convertToDTOs(List<CashierNotifyDetailDO> cashierNotifyDetailDOs) {
        List<CashierNotifyDetailDTO> detailDTOs = Lists.newArrayList();
        if (CollectionUtils.isEmpty(cashierNotifyDetailDOs)) {
            return detailDTOs;
        }
        CashierNotifyDetailDTO notifyDetailDTO = null;
        for (CashierNotifyDetailDO detailDO : cashierNotifyDetailDOs) {
            notifyDetailDTO = new CashierNotifyDetailDTO();
            BeanUtils.copyProperties(detailDO, notifyDetailDTO);
            detailDTOs.add(notifyDetailDTO);
        }
        return detailDTOs;
    }
}
