package com.zhongan.app.run.cms.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.RunCampaignListBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunCampaignListRepo;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCampaignListDTO;
import com.zhongan.app.run.cms.bean.web.RunCampaignListPageDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.AppUtil;
import com.zhongan.app.run.cms.repository.RunCampaignListRepository;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.RunCampaignListService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RunCampaignListServiceImpl implements RunCampaignListService {

    @Resource
    private RunCampaignListRepository runCampaignListRepository;

    @Resource
    private RunChannelListRepository  runChannelListRepository;

    //后台作为微服务的接口
    @Override
    public ResultBase<List<RunCampaignListDTO>> selectCampaignInfo(RunCampaignListBO runCampaignListBO) {
        ResultBase<List<RunCampaignListDTO>> result = new ResultBase<List<RunCampaignListDTO>>();
        log.info("{}-CampaignList select begin...", ThreadLocalUtil.getRequestNo());
        //参数的校验
        ResultBase<String> valResult = CheckBitparam(runCampaignListBO);
        if (!valResult.isSuccess()) {
            log.info("{}-fail--param:" + valResult.getErrorCode() + "-" + valResult.getErrorMessage(),
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            RunCampaignListRepo runCampaignListRepo = new RunCampaignListRepo();
            BeanUtils.copyProperties(runCampaignListBO, runCampaignListRepo);
            //公共接口：付费活动，注册专属字段 默认传0（否）
            runCampaignListRepo.setPayActivity(RunConstants.IS_NO_PAY_ACTIVITY);
            runCampaignListRepo.setIntroName(RunConstants.IS_NO_INTRO_NAME);
            result = runCampaignListRepository.selectRunCampaignDataRepo(runCampaignListRepo);
            if (result.getValue().size() > 0) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error(
                    "{}-CampaignList select fail,please find error to..."
                            + "error location polynomial : RunCampaignListServiceImpl--selectcampaignInfo()"
                            + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    //入参数的校验
    @SuppressWarnings({ "unchecked" })
    private ResultBase<String> CheckBitparam(RunCampaignListBO runCampaignListBO) {
        log.info("{}-param check code...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        //渠道号不能为空
        if (StringUtils.isEmpty(runCampaignListBO.getChannelNo())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100009, result);
        }
        result.setSuccess(true);
        return result;
    }

    //微信端用接口
    @Override
    public ResultBase<List<RunCampaignListDTO>> selectCampaignData(RunCampaignListBO runCampaignListBO) {
        ResultBase<List<RunCampaignListDTO>> result = new ResultBase<List<RunCampaignListDTO>>();
        log.info("{}-CampaignList select begin...P2", ThreadLocalUtil.getRequestNo());
        //参数的校验
        ResultBase<String> valResult = CheckBitparam(runCampaignListBO);
        if (!valResult.isSuccess()) {
            log.info("{}-fail--param:" + valResult.getErrorCode() + "-" + valResult.getErrorMessage(),
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            RunCampaignListRepo runCampaignListRepo = new RunCampaignListRepo();
            BeanUtils.copyProperties(runCampaignListBO, runCampaignListRepo);
            //來自頁面的接口：付费活动，注册专属字段 默认传0 需要以此判斷返回的結果集中的參數值做 一一对应返回
            /*
             * //是否为付费活动
             * runCampaignListRepo.setPayActivity(RunConstants.IS_PAY_ACTIVITY);
             * ResultBase<List<RunCampaignListDTO>> resultpay =
             * runCampaignListRepository
             * .selectRunCampaignDataRepo(runCampaignListRepo);
             * if(resultpay.getValue().size()>0){ resultpay.setSuccess(true);
             * resultpay
             * .setErrorDescription(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
             * resultpay
             * .setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
             * return resultpay; } //是否为注册专属
             * runCampaignListRepo.setPayActivity(RunConstants.IS_INTRO_NAME);
             * ResultBase<List<RunCampaignListDTO>> resultintro =
             * runCampaignListRepository
             * .selectRunCampaignDataRepo(runCampaignListRepo);
             * if(resultintro.getValue().size()>0){
             * resultintro.setSuccess(true);
             * resultintro.setErrorDescription(AppErrEnum
             * .SUCCESS_RUNUSER_00002.getCode());
             * resultintro.setErrorMessage(AppErrEnum
             * .SUCCESS_RUNUSER_00002.getValue()); return resultintro; }
             */
            result = runCampaignListRepository.selectRunCampaignDataRepo(runCampaignListRepo);
            if (result.getValue().size() > 0) {
                List<RunCampaignListDTO> listpay = new ArrayList<RunCampaignListDTO>();
                List<RunCampaignListDTO> listintro = new ArrayList<RunCampaignListDTO>();
                for (RunCampaignListDTO runCampaignListDTO : result.getValue()) {
                    if (runCampaignListDTO.getPayActivity().equals(RunConstants.IS_PAY_ACTIVITY)) {
                        listpay.add(runCampaignListDTO);
                        result.setValue(listpay);
                        log.info("{}-pay_activity....data..." + result, ThreadLocalUtil.getRequestNo());
                    } else if (runCampaignListDTO.getIntroName().equals(RunConstants.IS_INTRO_NAME)) {
                        listintro.add(runCampaignListDTO);
                        result.setValue(listintro);
                        log.info("{}-intro_name....data..." + result, ThreadLocalUtil.getRequestNo());
                    }
                }
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
                result.setSuccess(true);
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error(
                    "{}-CampaignList。。。P2   select fail,please find error to..."
                            + "error location polynomial : RunCampaignListServiceImpl--selectCampaignData()"
                            + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...P2", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    //营销活动分页查询
    @Override
    public RunCampaignListPageDTO selectCampaigninfoPage(Page<RunCampaignListDTO> runCampaignListPage) {
        RunCampaignListPageDTO runCampaignListPageDTO = new RunCampaignListPageDTO();
        Page<RunCampaignListRepo> runCampaignListRepoPage = new Page<RunCampaignListRepo>();
        BeanUtils.copyProperties(runCampaignListPage, runCampaignListRepoPage);
        runCampaignListRepoPage = runCampaignListRepository.selectCampaignListPage(runCampaignListRepoPage);
        List<RunCampaignListRepo> runCampaignListRepoRepolist = runCampaignListRepoPage.getResultList();
        List<RunCampaignListDTO> runCampaignListDTOList = Lists.newArrayList();
        ResultBase<List<RunChannelListDTO>> resultchannel = new ResultBase<List<RunChannelListDTO>>();
        RunChannelListRepo runChannelListRepot = new RunChannelListRepo();
        resultchannel = runChannelListRepository.selectRunChannelListDataList(runChannelListRepot);
        Map<String, String> channelList = getChannelList(resultchannel.getValue());
        if (runCampaignListRepoRepolist != null && runCampaignListRepoRepolist.size() > 0) {
            RunCampaignListDTO runCampaignListDTO = null;
            for (RunCampaignListRepo runCampaignListRepoRepo : runCampaignListRepoRepolist) {
                runCampaignListDTO = new RunCampaignListDTO();
                BeanUtils.copyProperties(runCampaignListRepoRepo, runCampaignListDTO);
                runCampaignListDTO.setName(channelList.get(runCampaignListRepoRepo.getChannelNo()));
                runCampaignListDTOList.add(runCampaignListDTO);
            }
        }
        runCampaignListPage.setResultList(runCampaignListDTOList);
        runCampaignListPage.setTotalItem(runCampaignListRepoPage.getTotalItem());
        runCampaignListPageDTO.setRunCampaignListDTODTOPage(runCampaignListPage);
        runCampaignListPageDTO.setRunChannelListDTOList(resultchannel.getValue());
        return runCampaignListPageDTO;
    }

    private Map<String, String> getChannelList(List<RunChannelListDTO> channelListDTOList) {
        Map<String, String> channelList = Maps.newHashMap();
        for (RunChannelListDTO runChannelListDTO : channelListDTOList) {
            channelList.put(runChannelListDTO.getNo(), runChannelListDTO.getName());
        }
        return channelList;
    }

    //新建营销活动
    @Override
    public ResultBase<String> insertCampaignList(RunCampaignListDTO runCampaignListDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunCampaignListRepo runCampaignListRepo = new RunCampaignListRepo();
            RunCampaignListRepo runCampaignListRepoend = new RunCampaignListRepo();
            BeanUtils.copyProperties(runCampaignListDTO, runCampaignListRepo);

            //判断页面来值 渠道id+营销活动id+产品组合id 是否已在库里存值
            if (runCampaignListRepo.getPayActivity().equals("0") && runCampaignListRepo.getIntroName().equals("0")) {
                runCampaignListRepoend.setChannelNo(runCampaignListRepo.getChannelNo());
                runCampaignListRepoend.setActivityRequire(runCampaignListRepo.getActivityRequire());
                runCampaignListRepoend.setPayActivity(runCampaignListRepo.getPayActivity());
                runCampaignListRepoend.setIntroName(runCampaignListRepo.getIntroName());
                ResultBase<List<RunCampaignListDTO>> resultend = runCampaignListRepository
                        .selectRunCampaignDataRepo(runCampaignListRepoend);
                if (null != resultend.getValue() && resultend.getValue().size() > 0) {
                    result.setSuccess(false);
                    result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10002.getCode());
                    result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10002.getValue());
                    return result;
                }
            }

            result = runCampaignListRepository.saveCampaignList(runCampaignListRepo);

            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error(
                    "{}-fail....save--CampaignList...."
                            + "error location polynomial : RunCampaignListServiceImpl--insertCampaignList()"
                            + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    //根据主键修改营销活动 
    @Override
    public ResultBase<String> updateCampaignList(RunCampaignListDTO runCampaignListDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunCampaignListRepo runCampaignListRepo = new RunCampaignListRepo();
            BeanUtils.copyProperties(runCampaignListDTO, runCampaignListRepo);
            result = runCampaignListRepository.updateCampaignList(runCampaignListRepo);
            if (result.isSuccess()) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error(
                    "{}-fail....update--CampaignList...."
                            + "error location polynomial : RunCampaignListServiceImpl--updateCampaignList()"
                            + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    //根据主键删除营销活动
    @Override
    public ResultBase<String> deleteCampaignList(String id) {
        log.info("{}-delete CampaignList info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            runCampaignListRepository.deleteByid(id);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-CampaignList delete fail,please find error to...。"
                    + "error location polynomial:RunCampaignListServiceImpl--deleteCampaignList()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    //根据ID 查询单个对象的信息
    @Override
    public RunCampaignListDTO selectOneCampaignList(String id) {
        log.info("{}-select one CampaignList info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        RunCampaignListDTO runCampaignListDTO = new RunCampaignListDTO();
        try {
            RunCampaignListRepo runCampaignListRepo = runCampaignListRepository.selectOneData(id);
            if (runCampaignListRepo != null) {
                RunChannelListRepo runChannelListRepot = new RunChannelListRepo();
                runChannelListRepot.setNo(runCampaignListRepo.getChannelNo());
                ResultBase<List<RunChannelListDTO>> result = runChannelListRepository
                        .selectRunChannelListDataList(runChannelListRepot);
                BeanUtils.copyProperties(runCampaignListRepo, runCampaignListDTO);
                runCampaignListDTO.setName(result.getValue().get(0).getName());
            }
        } catch (Exception e) {
            log.error("{}-CampaignList select one  fail,please find error to...。"
                    + "error location polynomial:RunCampaignListServiceImpl--selectOneCampaignList()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
        }
        return runCampaignListDTO;
    }

}
