package com.zhongan.app.run.cms.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserInviteInfoDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.dao.UserInviteMapper;
import com.zhongan.app.run.cms.dao.bean.UserInviteCriteria;
import com.zhongan.app.run.cms.dao.bean.UserInviteCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.UserInviteDO;
import com.zhongan.app.run.cms.service.UserInviteService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.enm.YesOrNo;

@Service
@Slf4j
public class UserInviteServiceImpl implements UserInviteService {

    @Resource
    private UserInviteMapper userInviteMapper;

    //查询用户邀请好友列表
    @Override
    public ResultBase<List<UserInviteInfoDTO>> queryFriendsListByCdt(UserInviteInfoDTO info) {
        ResultBase<List<UserInviteInfoDTO>> result = new ResultBase<List<UserInviteInfoDTO>>();
        try {
            List<UserInviteDO> listByCdt = userInviteMapper.selectByCriteria(buildUserInviteCriteria(info));
            List<UserInviteInfoDTO> list = null;
            if (CollectionUtils.isNotEmpty(listByCdt)) {
                list = Lists.newArrayList();
                UserInviteInfoDTO dto = null;
                for (UserInviteDO userInviteInfo : listByCdt) {
                    dto = new UserInviteInfoDTO();
                    BeanUtils.copyProperties(userInviteInfo, dto);
                    list.add(dto);
                }
            }
            result.setValue(list);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--queryFriendsListByCdt 查询出错 param>>>>>{},Exception:{}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    private ResultBase<List<UserInviteInfoDTO>> chackParam(UserInviteInfoDTO info) {
        ResultBase<List<UserInviteInfoDTO>> result = new ResultBase<List<UserInviteInfoDTO>>();
        if (null == info.getUnionid()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERACTIVITY_20003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERACTIVITY_20003.getValue());
            return result;
        }
        /*
         * if (null == info.getJoinUnionid()) { result.setSuccess(false);
         * result.setErrorCode(AppErrEnum.ERROR_USERACTIVITY_20005.getCode());
         * result
         * .setErrorMessage(AppErrEnum.ERROR_USERACTIVITY_20005.getValue());
         * return result; }
         */
        if (StringUtils.isBlank(info.getJoinOpenid())) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERACTIVITY_20009.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERACTIVITY_20009.getValue());
            return result;
        }
        result.setSuccess(true);
        return result;
    }

    //跟新或插入好友信息
    @Override
    public ResultBase<String> useFriendJoin(UserInviteInfoDTO info) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            ResultBase<List<UserInviteInfoDTO>> chackParam = this.chackParam(info);
            if (!chackParam.isSuccess()) {
                result.setSuccess(false);
                result.setErrorCode(chackParam.getErrorCode());
                result.setErrorMessage(chackParam.getErrorMessage());
                return result;
            }
            List<UserInviteDO> listByCdt = userInviteMapper.selectByCriteria(buildUserInviteForUpOrInsert(info));
            UserInviteDO userInviteDO = new UserInviteDO();
            BeanUtils.copyProperties(info, userInviteDO);
            if (CollectionUtils.isNotEmpty(listByCdt)) {
                userInviteDO.setId(listByCdt.get(0).getId());
                userInviteDO.setGmtModified(new Date());
                userInviteMapper.updateByPrimaryKeySelective(userInviteDO);
            } else {
                userInviteDO.setGmtCreated(new Date());
                userInviteDO.setGmtModified(new Date());
                userInviteMapper.insertSelective(userInviteDO);
            }
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--useFriendJoin 查询出错 param>>>>>{},Exception:{}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    private UserInviteCriteria buildUserInviteCriteria(UserInviteInfoDTO dto) {
        UserInviteCriteria userInviteCriteria = new UserInviteCriteria();
        userInviteCriteria.setOrderByClause("id DESC");
        Criteria criteria = userInviteCriteria.createCriteria();
        if (null != dto.getUnionid() && 0 != dto.getUnionid().intValue()) {
            criteria.andUnionidEqualTo(dto.getUnionid());
        }
        if (null != dto.getJoinUnionid() && 0 != dto.getJoinUnionid().intValue()) {
            criteria.andJoinUnionidEqualTo(dto.getJoinUnionid());
        }
        if (StringUtils.isNoneBlank(dto.getOpenid())) {
            criteria.andOpenidEqualTo(dto.getOpenid());
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (StringUtils.isNoneBlank(dto.getActivityId())) {
            criteria.andActivityIdEqualTo(dto.getActivityId());
        }
        if (StringUtils.isNoneBlank(dto.getActivityType())) {
            criteria.andActivityTypeEqualTo(dto.getActivityType());
        }
        if (StringUtils.isNoneBlank(dto.getJoinOpenid())) {
            criteria.andJoinOpenidEqualTo(dto.getJoinOpenid());
        }
        if (StringUtils.isNoneBlank(dto.getState())) {
            criteria.andStateEqualTo(dto.getState());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userInviteCriteria;
    }

    private UserInviteCriteria buildUserInviteForUpOrInsert(UserInviteInfoDTO dto) {
        UserInviteCriteria userInviteCriteria = new UserInviteCriteria();
        userInviteCriteria.setOrderByClause("id DESC");
        Criteria criteria = userInviteCriteria.createCriteria();
        if (null != dto.getId()) {
            criteria.andIdEqualTo(dto.getId());
        }
        if (StringUtils.isNoneBlank(dto.getOpenid())) {
            criteria.andOpenidEqualTo(dto.getOpenid());
        } else {
            if (null != dto.getUnionid() && 0 != dto.getUnionid().intValue()) {
                criteria.andUnionidEqualTo(dto.getUnionid());
            }
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (StringUtils.isNoneBlank(dto.getActivityId())) {
            criteria.andActivityIdEqualTo(dto.getActivityId());
        }
        if (StringUtils.isNoneBlank(dto.getActivityType())) {
            criteria.andActivityTypeEqualTo(dto.getActivityType());
        }
        if (StringUtils.isNoneBlank(dto.getJoinOpenid())) {
            criteria.andJoinOpenidEqualTo(dto.getJoinOpenid());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userInviteCriteria;
    }

    /**
     * 单纯插入
     */
    @Override
    public ResultBase<String> insertFriendInfo(UserInviteInfoDTO info) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            ResultBase<List<UserInviteInfoDTO>> chackParam = this.chackParam(info);
            if (!chackParam.isSuccess()) {
                result.setSuccess(false);
                result.setErrorCode(chackParam.getErrorCode());
                result.setErrorMessage(chackParam.getErrorMessage());
                return result;
            }
            UserInviteDO userInviteDO = new UserInviteDO();
            BeanUtils.copyProperties(info, userInviteDO);
            userInviteDO.setGmtCreated(new Date());
            userInviteDO.setGmtModified(new Date());
            userInviteMapper.insertSelective(userInviteDO);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--insertFriendInfo插入出错 param>>>>>{},Exception:{}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    /**
     * 判断用户是否加入没有就插入一条数据返回false
     */
    @Override
    public ResultBase<Boolean> inseOrJudgeIsInvite(UserInviteInfoDTO info) {
        ResultBase<Boolean> result = new ResultBase<>();
        try {
            UserInviteInfoDTO dto = new UserInviteInfoDTO();
            dto.setChannelFrom(info.getChannelFrom());
            dto.setActivityId(info.getActivityId());
            dto.setOpenid(info.getOpenid());
            dto.setJoinOpenid(info.getJoinOpenid());
            dto.setActivityType(info.getActivityType());
            List<UserInviteDO> listByCdt = userInviteMapper.selectByCriteria(buildUserInviteCriteria(dto));
            if (CollectionUtils.isNotEmpty(listByCdt)) {
                result.setSuccess(true);
                result.setValue(true);
                return result;
            }
            UserInviteDO userInviteDO = new UserInviteDO();
            BeanUtils.copyProperties(info, userInviteDO);
            userInviteDO.setGmtCreated(new Date());
            userInviteDO.setGmtModified(new Date());
            userInviteMapper.insertSelective(userInviteDO);
            result.setSuccess(true);
            result.setValue(false);
        } catch (Exception e) {
            log.error("{}--insertFriendInfo插入出错 param>>>>>{},Exception:{}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

}
