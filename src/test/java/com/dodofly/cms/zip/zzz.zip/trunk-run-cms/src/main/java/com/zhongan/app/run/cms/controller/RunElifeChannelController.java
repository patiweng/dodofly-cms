package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelResDTO;
import com.zhongan.app.run.cms.service.IRunElifeChannelService;
import com.zhongan.app.run.common.utils.AppRunRuntimeException;
import com.zhongan.app.run.common.utils.BusinessErrorCode;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类RunElifeChannelController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月27日 下午2:11:54
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/elifeChannel")
public class RunElifeChannelController {

    @Resource
    private IRunElifeChannelService runElifeChannelService;

    @RequestMapping(value = "/queryList")
    public BaseResult<PageDTO<RunElifeChannelResDTO>> queryList(@RequestBody RunElifeChannelQueryDTO dto) {
        log.info("RunElifeChannelController queryList param{}", JSON.toJSONString(dto));
        BaseResult<PageDTO<RunElifeChannelResDTO>> baseResult = new BaseResult<PageDTO<RunElifeChannelResDTO>>();
        try {
            baseResult.setSuccess(runElifeChannelService.queryList(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelController queryList param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelController queryList param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/queryByCondition")
    public BaseResult<JSONObject> queryByCondition(@RequestBody RunElifeChannelDTO dto) {
        log.info("RunElifeChannelController queryByCondition param{}", JSON.toJSONString(dto));
        BaseResult<JSONObject> baseResult = new BaseResult<JSONObject>();
        try {
            baseResult.setSuccess(runElifeChannelService.queryByCondition(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelController queryByCondition param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelController queryByCondition param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/saveOrUpdate")
    public BaseResult<Integer> saveOrUpdate(@RequestBody RunElifeChannelDTO dto) {
        log.info("RunElifeChannelController saveOrUpdate param{}", JSON.toJSONString(dto));
        BaseResult<Integer> baseResult = new BaseResult<Integer>();
        try {
            baseResult.setSuccess(runElifeChannelService.saveOrUpdate(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelController saveOrUpdate param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelController saveOrUpdate param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/delete")
    public BaseResult<Integer> delete(@RequestParam(name = "id", required = true) Long id) {
        log.info("RunElifeChannelController delete id:{}", id);
        BaseResult<Integer> baseResult = new BaseResult<Integer>();
        try {
            baseResult.setSuccess(runElifeChannelService.deleteById(id));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeChannelController delete id{} exception{}", id, e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeChannelController delete id{} exception{}", id, e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }
}
