package com.zhongan.app.run.cms.common.utils;

import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.joda.time.DateTime;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
public class AppUtil {
	
    /** 分页参数 */
    public static final Integer PAGESIZE = 100;
	
	 /**
     * date to string
     * 
     * @param date
     * @param format
     * @return
     */
    public static String convertDate2String(Date date, String format) {

        if (date == null) {
            return "";
        }

        if (StringUtils.isEmpty(format)) {
            format = "yyyy-MM-dd";
        }

        DateTime dateTime = new DateTime(date);
        String dateStr = dateTime.toString(format);

        return dateStr;
    }

    /**
     * 过滤特殊字符
     */
    public static String stringFilter(String str) {
        if (str == null || "".equals(str)) {
            return str;
        }
        String returnStr = str;
        String dcReg = "script;eval;document";
        String tcReg = "[\\|&$%@+=\r\n]";
        Pattern p = Pattern.compile(tcReg, Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(returnStr);
        returnStr = m.replaceAll("").trim();
        String ex[] = dcReg.split(";");
        for (int i = 0; i < ex.length; i++) {
            Pattern pt = Pattern.compile(ex[i], Pattern.CASE_INSENSITIVE);
            Matcher mt = pt.matcher(returnStr);
            returnStr = mt.replaceAll("").trim();
        }
        return returnStr;
    }

    public static StringBuffer stringBufFilter(StringBuffer sbf) {
        if (sbf == null || "".equals(sbf)) {
            return sbf;
        }
        StringBuffer sf = new StringBuffer();
        sf.append(stringFilter(sbf.toString()));
        sbf = sf;
        return sbf;
    }

    public static boolean filterCheck(String str) {
        if (str == null || "".equals(str)) {
            return true;
        }
        String returnStr = str;
        String dcReg = "script;eval;document";
        String tcReg = "[\\|&$%@+=\r\n]";
        Pattern p = Pattern.compile(tcReg, Pattern.CASE_INSENSITIVE);
        Matcher m = p.matcher(returnStr);
        System.out.println(m.groupCount());
        while (m.find()) {
            return false;
        }
        returnStr = m.replaceAll("").trim();
        String ex[] = dcReg.split(";");
        for (int i = 0; i < ex.length; i++) {
            Pattern pt = Pattern.compile(ex[i], Pattern.CASE_INSENSITIVE);
            Matcher mt = pt.matcher(returnStr);
            while (mt.find()) {
                return false;
            }
        }
        return true;
    }

    public static ServletInputStream streamFilter(ServletInputStream servletInputStream) throws IOException {
        if (servletInputStream == null) {
            return servletInputStream;
        }
        String input = IOUtils.toString(servletInputStream);
        if (!filterCheck(input)) {
            /** 检测到非法输入，清空输入流 **/
            servletInputStream = null;
        }
        return servletInputStream;
    }

    /**
     * 过滤特殊字符
     */
    public static Cookie cookieFilter(Cookie cookie) {
        String value = cookie.getValue();
        cookie.setValue(stringFilter(value));
        return cookie;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(AppUtil.stringFilter("script+=evalhhhhh321321323213eval213211321321321321"));
        System.out.println(AppUtil.filterCheck("Script"));
        System.out.println(MD5Util.md5("12345678"));
    }
    
	/**
	 * 异常结果组装
	 * @param appErrEnum
	 * @return
	 */
	public static ResultBase<?> createErrResult(AppErrEnum appErrEnum,ResultBase<?> result){
		result.setSuccess(false);
		result.setErrorCode(appErrEnum.getCode());
		result.setErrorMessage(appErrEnum.getValue());
		return result;
	}
	
	/**
	 * 异常结果组装
	 * @param appErrEnum
	 * @return
	 */
	public static ResultBase<?> createErrResult(String  errCode,String errMsg,ResultBase<?> result){
		result.setSuccess(false);
		result.setErrorCode(errCode);
		result.setErrorMessage(errMsg);
		return result;
	}	
	/**
     * 获得当前系统时间,精确到毫秒
     * 
     * @return
     */
    public static String getSysAccurateMSecond() {
    	JodaTimeUtil sdf   = new JodaTimeUtil("yyyy-MM-dd HH:mm:ss:SSS");
        return sdf.format(new Date());
    }
}
