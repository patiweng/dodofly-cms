package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayDetailResDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.service.ICashierHelpPayDetailService;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类CashierHelpPayDetailController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年9月12日 下午5:13:31
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/cashierHelpPayDetail")
public class CashierHelpPayDetailController {

    @Resource
    private ICashierHelpPayDetailService cashierHelpPayDetailService;

    /**
     * 分页查询用户签约信息
     * 
     * @param queryDTO
     * @return
     */
    @RequestMapping(value = "/queryUserCashierHelpPayDetailList")
    public ModelAndView queryUserCashierHelpPayDetailList(CashierHelpPayDetailQueryDTO queryDTO) {
        log.info("cashierHelpPayDetail queryUserCashierHelpPayDetailList param==={}", JSON.toJSONString(queryDTO));
        ModelAndView modelAndView = new ModelAndView("cms/cashierHelpPayDetail");
        try {
            PageDTO<CashierHelpPayDetailResDTO> pageDTO = cashierHelpPayDetailService
                    .queryCashierHelpPayDetatilList(queryDTO);
            modelAndView.addObject("page", pageDTO);
            modelAndView.addObject("totalPage", pageDTO.getTotalPage());
            modelAndView.addObject("cashierHelpPayDetailList", pageDTO.getResultList());
            modelAndView.addObject("cashierHelpPayQueryDetailDTO", queryDTO);
        } catch (Exception e) {
            log.info("CashierHelpPayController selectActivityPresentListPage param{} exception{}",
                    JSON.toJSONString(queryDTO), e);
        }
        return modelAndView;
    }

    /**
     * 分页查询用户签约信息
     * 
     * @param queryDTO
     * @return
     */
    @RequestMapping(value = "/queryByCondition", method = RequestMethod.POST)
    public ResultBase<List<CashierHelpPayDetailDTO>> queryByCondition(@RequestBody CashierHelpPayDetailDTO dto) {
        log.info("cashierHelpPayDetail queryCashierHelpPayDetailList param==={}", JSON.toJSONString(dto));
        ResultBase<List<CashierHelpPayDetailDTO>> resultBase = new ResultBase<List<CashierHelpPayDetailDTO>>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierHelpPayDetailService.queryByCondition(dto));
        } catch (Exception e) {
            resultBase.setSuccess(Boolean.FALSE);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    @RequestMapping(value = "/deleteById", method = RequestMethod.POST)
    public ResultBase<Integer> deleteById(@RequestParam(value = "id") long id) {
        log.info("cashierHelpPayDetail deleteById id{}", id);
        ResultBase<Integer> resultBase = new ResultBase<Integer>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierHelpPayDetailService.deleteById(id));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierHelpPayController deleteById id{} exception{}", id, e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            return resultBase;
        }
    }
}
