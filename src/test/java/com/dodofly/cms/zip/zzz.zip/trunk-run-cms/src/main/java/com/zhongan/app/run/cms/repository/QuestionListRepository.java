package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.QuestionListDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.QuestionListRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.dao.QuestionListDAO;

@Slf4j
@Repository
public class QuestionListRepository {
    @Resource
    private QuestionListDAO questionListDAO;

    @Resource
    private Sequence        seqQuestion;

    @Resource
    private OssTool         ossTool;

    @Value("${za.run.img.domain.url}")
    private String          imgDomain;

    /**
     * 主键查询
     * 
     * @param id
     * @return
     */
    public QuestionListRepo selectDataById(Long id) {
        QuestionListDO questionListDO = new QuestionListDO();
        questionListDO.setIsDeleted("0");
        List<QuestionListDO> doList = questionListDAO.selectDataByCdt(questionListDO);
        QuestionListRepo qRepo = null;
        if (null != doList && doList.size() > 0) {
            questionListDO = doList.get(0);
            qRepo = new QuestionListRepo();
            BeanUtils.copyProperties(questionListDO, qRepo);
        }
        return qRepo;
    }

    /**
     * 分页查询
     * 
     * @param questionListRepo
     * @return
     */
    public Page<QuestionListRepo> selectQuestionListDataPage(Page<QuestionListRepo> questionListRepo) {
        QuestionListDO questionListDO = new QuestionListDO();
        if (null != questionListRepo.getParam()) {
            BeanUtils.copyProperties(questionListRepo.getParam(), questionListDO);
        }
        questionListDO.setIsDeleted(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", questionListRepo.getStartRow());
        map.put("pageSize", questionListRepo.getPageSize());
        map.put("questionListDO", questionListDO);
        List<QuestionListDO> questionListDOList = questionListDAO.selectQuestionList(map);
        List<QuestionListRepo> questionListRepoList = Lists.newArrayList();
        if (null != questionListDOList && 0 != questionListDOList.size()) {
            QuestionListRepo questionList = null;
            for (QuestionListDO questionListDOlists : questionListDOList) {
                questionList = new QuestionListRepo();
                BeanUtils.copyProperties(questionListDOlists, questionList);
                questionListRepoList.add(questionList);
            }
        }
        questionListRepo.setResultList(questionListRepoList);
        Integer counts = questionListDAO.selectCounts(map);
        questionListRepo.setTotalItem(counts);
        return questionListRepo;
    }

    /**
     * 删除
     * 
     * @param id
     * @return
     */
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        questionListDAO.updateDeletedById(id);
        result.setSuccess(true);
        return result;
    }

    /**
     * 插入一条新的记录
     * 
     * @param questionListRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> saveQuestionList(QuestionListRepo questionListRepo) throws Exception {
        log.info("{}-insert questionList。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        QuestionListDO questionListDO = new QuestionListDO();
        BeanUtils.copyProperties(questionListRepo, questionListDO);
        Long id = seqQuestion.nextValue();
        /** 文件上传 **/
        ResultBase<String> flagRs = ossTool.handleImg(String.valueOf(id), questionListRepo.getMarketingImgFile());
        if (!flagRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
            return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        questionListDO.setQueryIcon(fileUrl);
        questionListDO.setId(id);
        questionListDO.setCreator(RunConstants.SYSTEM_NAME);
        questionListDAO.insert(questionListDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    /**
     * 根据主键修改信息
     * 
     * @param questionListRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> updateQuestionList(QuestionListRepo questionListRepo) throws Exception {
        ResultBase<String> result = new ResultBase<String>();
        log.info("{}-update questionList。。。Repository。。。");
        QuestionListDO questionListDO = new QuestionListDO();
        BeanUtils.copyProperties(questionListRepo, questionListDO);
        /** 文件上传 **/
        String id = questionListDO.getId().toString();
        ResultBase<String> flagRs = ossTool.handleImg(id, questionListRepo.getMarketingImgFile());
        if (!flagRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
            return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        questionListDO.setQueryIcon(fileUrl);
        questionListDAO.update(questionListDO);
        result.setSuccess(true);
        return result;
    }
}
