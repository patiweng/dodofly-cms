package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class StaticsCollectionDO {
	
	private String sDate;
	private String eDate;
	private String page;
	private String pageCount;
	private String allCount;
	private String allActiveCount;
	private String oldActiveCount;
	private String newActiveCount;
	private String from;
	private String fromActiveCount;
	private String fromName;
	private String weixin_userCount;
	private String ledongli_userCount;
	private String xiaomiApp_userCount;
	private String ishuashua_userCount;
	private String zhonganApp_userCount;
	private String meizu_userCount;
	private String bong_userCount;
	
	private String source;
	private String authCount;
	private String addInsureCount;
	private String bugInsureCount;
	
}
