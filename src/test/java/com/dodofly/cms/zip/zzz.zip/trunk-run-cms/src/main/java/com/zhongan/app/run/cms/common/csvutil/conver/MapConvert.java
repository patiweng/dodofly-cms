package com.zhongan.app.run.cms.common.csvutil.conver;

import com.zhongan.app.run.cms.common.csvutil.annotion.Convert;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class MapConvert implements Convert {
    @Override
    public <T> T readConvert(String[] values, char separator, List<String> titles, Class<T> clazz) {
        T t = null;
        try {
            t = clazz.newInstance();
            Method method = clazz.getDeclaredMethod("put", new Class[] { Object.class, Object.class });
            int size = titles.size();
            for (int i = 0 ; i <  size ; i++){
                if(StringUtils.isBlank(titles.get(i))){
                    continue;
                }
                method.invoke(t, titles.get(i), values[i]);
            }

        }catch (Exception e){
           log.error("Exception:", e);
        }
        return t;
    }

    @Override
    public <T> List<String[]> writeConvertContent(List<T> datas, Class<T> clazz, List<String> titles) {
        return null;
    }
}
