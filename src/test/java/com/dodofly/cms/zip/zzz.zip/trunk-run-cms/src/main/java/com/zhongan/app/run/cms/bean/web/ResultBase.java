package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;

public class ResultBase<T> implements Serializable {

    private static final long serialVersionUID = -351414120670006950L;

    private boolean           isSuccess        = false;

    private String            errorCode        = "";

    private String            errorMessage     = "";

    private T                 value;

    public ResultBase() {
        //无参构造
    }

    public ResultBase(T value) {
        this.isSuccess = true;
        this.value = value;
    }

    public ResultBase(String errorCode, String errorMessage) {
        super();
        this.isSuccess = false;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public ResultBase(boolean isSuccess, String errorCode, String errorMessage) {
        super();
        this.isSuccess = isSuccess;
        this.errorCode = errorCode;
        this.errorMessage = errorMessage;
    }

    public T getValue() {
        return this.value;
    }

    public void setValue(T value) {
        this.value = value;
    }

    public boolean isSuccess() {
        return isSuccess;
    }

    public void setSuccess(boolean isSuccess) {
        this.isSuccess = isSuccess;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    @Override
    public String toString() {
        return "ResultBase [isSuccess=" + isSuccess + ", errorCode=" + errorCode + ", errorMessage=" + errorMessage
                + (value == null ? "" : (", value=" + value.toString())) + "]";
    }
}
