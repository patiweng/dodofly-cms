package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;

@Data
public class BububaoPresentRepo {
    private String id;
    private String name;
    private String identify;
    private String description;
    private String price;
    private String url;
    private String type;
    private String creator;
    private String modifier;
    private String createTime;
    private String modifyTime;
    private String isDeleted;
}
