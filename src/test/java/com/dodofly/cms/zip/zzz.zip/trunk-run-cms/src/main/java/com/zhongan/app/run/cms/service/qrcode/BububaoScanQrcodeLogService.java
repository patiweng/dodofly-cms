package com.zhongan.app.run.cms.service.qrcode;

import java.util.List;

import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoScanQrcodeLogDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoScanQrcodeLogDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.health.common.share.bean.BaseResult;

/**
 * 扫码记录接口 service
 * 
 * @author lichao002
 * @date 2018-06-04
 */
public interface BububaoScanQrcodeLogService {

    public void batchSaveScanQrcodeLog();

    public List findScanQrcodeLogsPage();

    /**
     * 插入扫码日志记录
     * 
     * @param bububaoScanQrcodeLogDTO
     * @return
     */
    public BaseResult<Integer> insertScanQrcodeLog(BububaoScanQrcodeLogDto bububaoScanQrcodeLogDTO);

    /**
     * 根据条件查询扫码日志记录表
     * 
     * @param bububaoScanQrcodeLogDTO
     * @return
     */
    public BaseResult<List<BububaoScanQrcodeLogDto>> selectScanQrcodeLog(BububaoScanQrcodeLogDto bububaoScanQrcodeLogDTO);
}
