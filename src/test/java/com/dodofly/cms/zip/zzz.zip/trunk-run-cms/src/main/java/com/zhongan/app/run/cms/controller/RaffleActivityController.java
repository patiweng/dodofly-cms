package com.zhongan.app.run.cms.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.RaffleActivityBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ActivityListPageDTO;
import com.zhongan.app.run.cms.bean.web.RaffleActivityDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.RaffleActivityService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class RaffleActivityController {
    @Resource
    private RaffleActivityService raffleActivityServiceImpl;

    @RequestMapping(value = "/selectactivity", method = RequestMethod.POST)
    public ResultBase<List<RaffleActivityDTO>> selectActivity(@RequestBody RaffleActivityDTO raffleActivityDTO) {
        log.info("{}-into /selectactivity, param={ " + raffleActivityDTO.toString() + " }");
        ResultBase<List<RaffleActivityDTO>> result = new ResultBase<List<RaffleActivityDTO>>();
        RaffleActivityBO raffleActivityBO = new RaffleActivityBO();
        BeanUtils.copyProperties(raffleActivityDTO, raffleActivityBO);
        result = raffleActivityServiceImpl.selectActivityData(raffleActivityBO);
        log.info("{}-/selectactivity return, data={" + result + "}");
        return result;
    }

    /**
     * 新增信息  前端接口
     * 
     * @return
     */

    @RequestMapping(value = "/insertactivitydata", method = RequestMethod.POST)
    public ResultBase<String> insertActivity(@RequestBody RaffleActivityDTO raffleActivityDTO) {
        log.info("{}-/insertdata,param={" + raffleActivityDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        RaffleActivityBO raffleActivityBO = new RaffleActivityBO();
        BeanUtils.copyProperties(raffleActivityDTO, raffleActivityBO);
        result = raffleActivityServiceImpl.insertActivityData(raffleActivityBO);
        log.info("{}-/insertdata  return,data={" + result.toString() + "}");
        return result;
    }

    /**
     * 新增   修改信息  后台
     * 
     * @return
     */

    @RequestMapping(value = "/insertorupdatedata", method = RequestMethod.POST)
    public ResultBase<String> insertOrUpdate(RaffleActivityDTO raffleActivityDTO) {
    	 log.info("{}-/insertorupdate,param={" + raffleActivityDTO.toString() + "}");
         ResultBase<String> result = new ResultBase<String>();
         Map<String, Object> model = Maps.newHashMap();
         model.put("raffleActivityDTO", raffleActivityDTO);    
         if("".equals(raffleActivityDTO.getId())){
        	 raffleActivityDTO.setId(null);
 	      }
         RaffleActivityBO raffleActivityBO = new RaffleActivityBO();
         BeanUtils.copyProperties(raffleActivityDTO, raffleActivityBO);
         if(null==raffleActivityBO.getId()){
         	result = raffleActivityServiceImpl.insertActivityData(raffleActivityBO);
         }
         else{
         	result = raffleActivityServiceImpl.updateActivityData(raffleActivityBO);
         }
         log.info("{}-/insertorupdate  return,data={" + result.toString() + "}");
         return result;
    }

    
    /**
     * 根据主键查询单条   后台
     * 
     * @return
     */
    @RequestMapping(value = "/selectactivityone/{id}", method = RequestMethod.GET)
    public RaffleActivityDTO selectOneData(@PathVariable String id) {
        log.info("{}-into /selectactivityone, param={ " + id + " }");
        RaffleActivityDTO result = new RaffleActivityDTO();        
        result = raffleActivityServiceImpl.selectDataByid(id);
        log.info("{}-/selectactivityone return, data={" + result + "}");
        return result;
    }
    
    /**
     * 查询所有信息 分页。。。
     * 
     * @return
     */ 
    @RequestMapping(value = "/select/activitypage")
    public ModelAndView selectactivityListPage(RaffleActivityDTO raffleActivityDTO, HttpServletRequest request) {
    	 log.info("{}-into /select/activitypage, param={ " + raffleActivityDTO.toString() + " }",ThreadLocalUtil.getRequestNo());
    	 validParam(raffleActivityDTO);
         Page<RaffleActivityDTO> activityListPage = new Page<RaffleActivityDTO>(raffleActivityDTO.getPageSize(), raffleActivityDTO.getCurrentPage());
         activityListPage.setParam(raffleActivityDTO);
         ActivityListPageDTO result = raffleActivityServiceImpl.selectActivityListPage(activityListPage);
         activityListPage = result.getRaffleActivityDTOPage();
         Map<String, Object> model = Maps.newHashMap();
         if (null != activityListPage) {
             model.put("activitylistPage", activityListPage.getResultList());
         }
         model.put("role", result.getRole());
         model.put("raffleActivityDTO", raffleActivityDTO);
         model.put("page", activityListPage);
         log.info("{}-/select/activitypage return, data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());
         return new ModelAndView("cms/activity", model);
    }	  
    
    //入参校验
    private RaffleActivityDTO validParam(RaffleActivityDTO raffleActivityDTO) {
        if ("".equals(raffleActivityDTO.getName())) {
        	raffleActivityDTO.setName(null);
        }      
        return raffleActivityDTO;
    }
    /**
     * 修改信息
     * 
     * @return
     */

    @RequestMapping(value = "/updateactivitydata", method = RequestMethod.POST)
    public ResultBase<String> updateActivity(@RequestBody RaffleActivityDTO raffleActivityDTO) {
        log.info("{}-/uodatedata,param={" + raffleActivityDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        RaffleActivityBO raffleActivityBO = new RaffleActivityBO();
        BeanUtils.copyProperties(raffleActivityDTO, raffleActivityBO);
        result = raffleActivityServiceImpl.updateActivityData(raffleActivityBO);
        log.info("{}-/uodatedata  return,data={" + result.toString() + "}");
        return result;
    }
    
    
    /**
     * 根据主键删除
     * 
     * @return
     */  
 
    @RequestMapping(value = "/deleteactivitydata/{id}", method = RequestMethod.GET) 
    public ResultBase<String> deleteActivityData(@PathVariable String id){
    	 log.info("{}-/deleteactivitydata/{id}, param={ " + id.toString() + " }",ThreadLocalUtil.getRequestNo());
    	 ResultBase<String> result= new ResultBase<String>();
    	 if(id!=null){
    	  result= raffleActivityServiceImpl.deleteActivity(id);
    	 }    	 	    	 
    	 log.info("{}-/deleteactivitydata/{id} return, data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());	
    	 return result;
    }	    

}
