package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

import com.zhongan.health.common.share.bean.PageDTO;

/**
 * cms用户参加瓜分活动用户参赛数据信息
 * 
 * @author yangzhen001
 */
@Data
public class UserCarveUpLoginRecordParamDTO extends PageDTO<UserCarveUpLoginRecordParamDTO> {
    private static final long serialVersionUID = 1L;

    /**
     * 用户id
     */
    private Long              unionid;

    /**
     * 用户来原表id
     */
    private Long              userid;

    /**
     * 用户活动渠道来源
     */
    private String            channelFrom;
    /**
     * 用户名字
     */
    private String            identityName;
    /**
     * 身份证
     */
    private String            identity;
    /**
     * 手机
     */
    private String            phone;
    /**
     * 用户投入积分
     */
    private String            inputPoint;
    /**
     * 用户获取积分
     */
    private String            gainPoint;
    /**
     * 用户是否达标
     */
    private String            isStandard;
    /**
     * 用户当天最大步数
     */
    private String            maxSteps;

    /**
     * 对应步数的时期
     */
    private String            date;

    /**
     * 用户每一次登陆进来的步数
     */
    private String            steps;

    /**
     * 创建时间
     */
    private String            gmtCreated;
    /**
     * 更改日期
     */
    private String            gmtModified;

}
