package com.zhongan.app.run.cms.repository;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoMarketingActivitiesDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunMarketingActivitiesRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.dao.BububaoMarketingActivitiesDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
@Component
@Slf4j
public class RunMarketingActivitiesRepository {
	
	@Resource
	private BububaoMarketingActivitiesDAO bububaoMarketingActivitiesDAO;
	@Resource
	private Sequence         seqMarketingActivities;
	@Resource
	private OssTool ossTool;
	@Value("${za.run.img.domain.url}")
	private String imgDomain;
	
	//接口  查询
	public ResultBase<List<RunMarketingActivitiesDTO>> selectMarketingActivitiesRepo(RunMarketingActivitiesRepo runMarketingActivitiesRepo){
		
	    log.info("{}-select  MarketingActivities。。。Repository。。。",ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        List<RunMarketingActivitiesDTO> listresult = new ArrayList<RunMarketingActivitiesDTO>();       
        BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = new BububaoMarketingActivitiesDO();
        BeanUtils.copyProperties(runMarketingActivitiesRepo, bububaoMarketingActivitiesDO);
        List<BububaoMarketingActivitiesDO> resultlist = bububaoMarketingActivitiesDAO.selectDataByCdt(bububaoMarketingActivitiesDO); 
        if(resultlist!=null && resultlist.size()>0){
        	for(BububaoMarketingActivitiesDO bububaoMarketingActivities : resultlist){
        		RunMarketingActivitiesDTO runMarketingActivitiesDTO = new RunMarketingActivitiesDTO();
        		BeanUtils.copyProperties(bububaoMarketingActivities, runMarketingActivitiesDTO);      		
        		listresult.add(runMarketingActivitiesDTO);       		
        	}     	
        	result.setValue(listresult);
        }
        result.setSuccess(true);   	
        return result;	
	}
	
	public ResultBase<List<RunMarketingActivitiesDTO>> selectMarketingValRepo(RunMarketingActivitiesRepo runMarketingActivitiesRepo){
		
	    log.info("{}-select  MarketingActivities。。。Repository。。。",ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        List<RunMarketingActivitiesDTO> listresult = new ArrayList<RunMarketingActivitiesDTO>();       
        BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = new BububaoMarketingActivitiesDO();
        BeanUtils.copyProperties(runMarketingActivitiesRepo, bububaoMarketingActivitiesDO);
        List<BububaoMarketingActivitiesDO> resultlist = bububaoMarketingActivitiesDAO.selectChannelValMarkets(bububaoMarketingActivitiesDO); 
        if(resultlist!=null && resultlist.size()>0){
        	for(BububaoMarketingActivitiesDO bububaoMarketingActivities : resultlist){
        		RunMarketingActivitiesDTO runMarketingActivitiesDTO = new RunMarketingActivitiesDTO();
        		BeanUtils.copyProperties(bububaoMarketingActivities, runMarketingActivitiesDTO);      		
        		listresult.add(runMarketingActivitiesDTO);       		
        	}     	
        	result.setValue(listresult);
        }
        result.setSuccess(true);   	
        return result;	
	}
	
	
    //分页查询运营活动信息
	
    public Page<RunMarketingActivitiesRepo> selectMarketingActivitiesPage(Page<RunMarketingActivitiesRepo> runMarketingActivitiesRepo) {
    	BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = new BububaoMarketingActivitiesDO();
        if (null != runMarketingActivitiesRepo.getParam()) {
            BeanUtils.copyProperties(runMarketingActivitiesRepo.getParam(), bububaoMarketingActivitiesDO);
        }
        bububaoMarketingActivitiesDO.setIsDeleted(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", runMarketingActivitiesRepo.getStartRow());
        map.put("pageSize", runMarketingActivitiesRepo.getPageSize());
        map.put("bububaoMarketingActivitiesDO", bububaoMarketingActivitiesDO);
        List<BububaoMarketingActivitiesDO> bububaoMarketingDOList = bububaoMarketingActivitiesDAO.selectBububaoMarketing(map);
        List<RunMarketingActivitiesRepo> bububaoMarketingRepoList = Lists.newArrayList();

        if (null != bububaoMarketingDOList && 0 != bububaoMarketingDOList.size()) {
        	RunMarketingActivitiesRepo runMarketingActivitiesRepodo = null;
            for (BububaoMarketingActivitiesDO bububaoMarketingActivities : bububaoMarketingDOList) {
            	runMarketingActivitiesRepodo = new RunMarketingActivitiesRepo();
                BeanUtils.copyProperties(bububaoMarketingActivities, runMarketingActivitiesRepodo);
                bububaoMarketingRepoList.add(runMarketingActivitiesRepodo);
            }
        }
        runMarketingActivitiesRepo.setResultList(bububaoMarketingRepoList);
        Integer counts = bububaoMarketingActivitiesDAO.selectCounts(map);
        runMarketingActivitiesRepo.setTotalItem(counts);
        return runMarketingActivitiesRepo;
    }
    
    //插入一条新的记录（运营活动表）
    public ResultBase<String> saveMarketingActivities(RunMarketingActivitiesRepo runMarketingActivitiesRepo) throws Exception {
        log.info("{}-insert bububaoMarketing。。。Repository。。。",ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = new BububaoMarketingActivitiesDO();
        BeanUtils.copyProperties(runMarketingActivitiesRepo, bububaoMarketingActivitiesDO);
        Long id = seqMarketingActivities.nextValue();
        /**文件上传**/
        runMarketingActivitiesRepo.setId(String.valueOf(id));
        ResultBase<String> flagRs = ossTool.handleImg(String.valueOf(id),runMarketingActivitiesRepo.getMarketingImgFile());
        if(!flagRs.isSuccess()){
        	result.setSuccess(false);
        	result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
        	result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        bububaoMarketingActivitiesDO.setActivitiesIcon(fileUrl);
        bububaoMarketingActivitiesDO.setId(id.toString());
        bububaoMarketingActivitiesDO.setCreator(RunConstants.SYSTEM_NAME);
        bububaoMarketingActivitiesDAO.insert(bububaoMarketingActivitiesDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }      
    
    
    //根据主键修改运营活动信息
    
    public ResultBase<String> updateMarketingActivities(RunMarketingActivitiesRepo runMarketingActivitiesRepo) throws Exception {
    	ResultBase<String> result = new ResultBase<String>();   	
    	log.info("{}-update bububaoMarketing。。。Repository。。。",ThreadLocalUtil.getRequestNo());
    	BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = new BububaoMarketingActivitiesDO();
        BeanUtils.copyProperties(runMarketingActivitiesRepo, bububaoMarketingActivitiesDO);
        String id = bububaoMarketingActivitiesDO.getId();
        /**文件上传**/
        runMarketingActivitiesRepo.setId(id);
        ResultBase<String> flagRs = ossTool.handleImg(id,runMarketingActivitiesRepo.getMarketingImgFile());
        if(!flagRs.isSuccess()){
        	result.setSuccess(false);
        	result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
        	result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
        	return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        bububaoMarketingActivitiesDO.setActivitiesIcon(fileUrl);
        bububaoMarketingActivitiesDAO.update(bububaoMarketingActivitiesDO);
        result.setSuccess(true);
        result.setValue(RunConstants.UPDATE_TRUE);
    	return result;
    }
    
    //删除信息
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        bububaoMarketingActivitiesDAO.updateByid(id);
        result.setSuccess(true);
        return result;
    }

  //根据id 查询一个对象信息
    
    public RunMarketingActivitiesRepo selectOneData(String id){
    	RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
    	BububaoMarketingActivitiesDO bububaoMarketingActivitiesDO = bububaoMarketingActivitiesDAO.selectOneDataById(id);
    	if(bububaoMarketingActivitiesDO!=null){
    		BeanUtils.copyProperties(bububaoMarketingActivitiesDO, runMarketingActivitiesRepo);  	
    	}   	
    	return  runMarketingActivitiesRepo;
    }
}
