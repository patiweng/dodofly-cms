package com.zhongan.app.run.cms.common.csvutil;

import com.csvreader.CsvReader;
import com.csvreader.CsvWriter;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.common.csvutil.annotion.Convert;
import com.zhongan.app.run.cms.common.csvutil.conver.MapConvert;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * csv文件工具类
 * 
 * @author lichao002
 * @date 2018-06-11
 */
@Slf4j
public class CSVUtil {

    public static <T> List<T> readCSV(InputStream inputStream, char separator, String charset, Convert convert,
                                      List<String> titles, Class<T> clazz) {
        try {
            List<T> list = Lists.newArrayList();
            //1、创建CSV读对象
            CsvReader reader = new CsvReader(inputStream, separator, Charset.forName(charset));
            //2、跳过表头 如果需要表头的话，这句可以忽略
            reader.readHeaders();
            while (reader.readRecord()) {
                list.add(convert.readConvert(reader.getValues(), separator, titles, clazz));
            }
            reader.close();
            return list;
        } catch (Exception e) {
            log.error("Exception:", e);
            throw new RuntimeException("获取CSV数据失败", e);
        }
    }

    public static <T> void writeCSV(OutputStream outputStream, char separator, String charset, Convert convert,
                                    List<String> titles, List<T> datas, List<String> enTitles, Class<T> clazz) {
        try {
            // 设置bom头(不设置，mac环境下打开是乱码)
            outputStream.write(new byte[] { (byte) 0xEF, (byte) 0xBB, (byte) 0xBF });
            CsvWriter writer = new CsvWriter(outputStream, separator, Charset.forName(charset));
            writer.writeRecord(titles.toArray(new String[titles.size()]));
            List<String[]> datasList = convert.writeConvertContent(datas, clazz, enTitles);
            int size = datasList.size();
            for (String[] data : datasList) {
                writer.writeRecord(data);
            }
            writer.close();
        } catch (Exception e) {
            log.error("Exception:", e);
        }

    }

    public static <T extends Map> List<T> readCSVToMap(InputStream inputStream, char separator, String charset,
                                                       Convert convert, Class<T> clazz) {
        List<T> list = null;
        try {
            list = Lists.newArrayList();
            //1、创建CSV读对象
            CsvReader reader = new CsvReader(inputStream, separator, Charset.forName(charset));
            //2、跳过表头 如果需要表头的话，这句可以忽略
            //reader.readHeaders();
            List<String> title = null;
            if (reader.readRecord()) {
                title = Arrays.asList(reader.getValues());
            }
            while (reader.readRecord()) {
                String[] values = reader.getValues();
                if (StringUtils.isBlank(values[0])) {
                    break;
                }
                list.add(convert.readConvert(values, separator, title, clazz));
            }
        } catch (Exception e) {
            log.error("Exception:", e);
        }

        return list;
    }

    public static void main(String[] args) {
        //        try {
        //            File file  = new File("C:\\Users\\lichao002\\Desktop\\业务员二维码-20180628.csv");
        //            List<HashMap> hashMaps = readCSVToMap(new FileInputStream(file), ',', "utf-8", new MapConvert(),
        //                    HashMap.class);
        //            System.out.println(hashMaps);
        //        }catch (Exception e){
        //
        //        }

        List<String> list = Lists.newArrayList();
        list.add("1");
        String integer = list.get(0);
        integer = "ss";
        System.out.println(list);
    }
}
