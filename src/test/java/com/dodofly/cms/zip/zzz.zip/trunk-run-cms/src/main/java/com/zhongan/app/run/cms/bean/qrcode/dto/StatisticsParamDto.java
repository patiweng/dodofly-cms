package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

/**
 * 参数数据 类StatisticsParamDto.java的实现描述：TODO 类实现描述
 * 
 * @author zhangjin 2018年6月7日 下午1:44:26
 */
@Data
public class StatisticsParamDto{
    /**
     * 一级机构id
     */
    private Long    oneOrgId;

    /**
     * 二级机构id
     */
    private Long    twoOrgId;
    /**
     * 三级机构id
     */
    private Long    threeOrgId;

    /**
     * 四级机构id
     */
    private Long    fourOrgId;

    /**
     * 五级机构id
     */
    private Long    fiveOrgId;

    /**
     * 业务员code
     */
    private String  salesCode;
    /**
     * 开始时间
     */
    private String  sdate;
    /**
     * 结束时间
     */
    private String  edate;
    /**
     * 页面数量
     */
    private Integer pageSize;
    /**
     * 当前页
     */
    private Integer currentPage;
    
    /**
     * 分页开始索引
     */
    private Integer        start;

    /**
     * 分页结束索引
     */
    private Integer        end;


}
