package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class UserAllStepDO {

    private String userId;
    private String allSteps;

}
