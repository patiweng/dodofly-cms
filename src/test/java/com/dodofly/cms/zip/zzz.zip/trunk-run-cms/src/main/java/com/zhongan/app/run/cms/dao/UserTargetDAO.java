package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.UserTargetDO;

@Component
public interface UserTargetDAO {
    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<UserTargetDO> selectDataByCdt(UserTargetDO userTargetDO);
}
