package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoWechatQrcodeDO {
	
	 private String id;
	 private String ticket;
	 private String unionId;
	 private String groupId;
	 private String createTime;
	 private String modifyTime;
	 private String extId;
	 private String sceneStr;
	 private String iticId;
	 private String codeSource;

}
