package com.zhongan.app.run.cms.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.RunCampaignListBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCampaignListDTO;
import com.zhongan.app.run.cms.bean.web.RunCampaignListPageDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.service.RunCampaignListService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;


@RestController
@RequestMapping("/run/cms/campaign")
@Slf4j
public class RunCampaignListController {
	
	 @Resource
	 private  RunCampaignListService runCampaignListServiceImpl;
	 
	 
		/**
	     * cms营销活动信息查询C003 (根据营销活动ID 查询营销活动名称)(根据渠道编码、步数查询保额)(公共)p1
	     * 
	     * @return
	     */
		 
		  @RequestMapping(value = "/select/campaignlist", method = RequestMethod.POST)
		    public ResultBase<List<RunCampaignListDTO>> selectCampaign(@RequestBody RunCampaignListDTO runCampaignListDTO) {	
			  log.info("{}-/select/campaignlist...p1,param={" + runCampaignListDTO.toString() + "}",ThreadLocalUtil.getRequestNo());
			  ResultBase<List<RunCampaignListDTO>> result = new ResultBase<List<RunCampaignListDTO>>();
			  RunCampaignListBO runCampaignListBO =  new RunCampaignListBO();
			  BeanUtils.copyProperties(runCampaignListDTO,runCampaignListBO);	
			  result =  runCampaignListServiceImpl.selectCampaignInfo(runCampaignListBO);
			  log.info("{}-/select/campaignlist...p1  return,data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());
		      return result;
		    }	
		  
		  
		  /**
		     * cms营销活动信息查询C003(根据渠道编码、步数查询保额)(页面专属)p2
		     * 
		     * @return
		     */
			 
		@RequestMapping(value = "/select/campaigninfo", method = RequestMethod.POST)
			 public ResultBase<List<RunCampaignListDTO>> selectCampaignInfo(@RequestBody RunCampaignListDTO runCampaignListDTO) {	
			   log.info("{}-/select/campaignlist...p2,param={" + runCampaignListDTO.toString() + "}",ThreadLocalUtil.getRequestNo());
			   ResultBase<List<RunCampaignListDTO>> result = new ResultBase<List<RunCampaignListDTO>>();
				RunCampaignListBO runCampaignListBO =  new RunCampaignListBO();
				BeanUtils.copyProperties(runCampaignListDTO,runCampaignListBO);	
				result =  runCampaignListServiceImpl.selectCampaignData(runCampaignListBO);
				log.info("{}-/select/campaignlist...p2  return,data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());
			   return result;
		 }	
		
		  /**
	     * cms营销活动信息查询（分页）
	     * 
	     * @return
	     */
		 
		@RequestMapping(value = "/select/campaigninfopage")
	    public ModelAndView selectcampaigninfopage(RunCampaignListDTO runCampaignListDTO, HttpServletRequest request) {
	    	 log.info("{}-into /select/campaigninfopage, param={ " + runCampaignListDTO.toString() + " }",ThreadLocalUtil.getRequestNo());
	         Page<RunCampaignListDTO> runCampaignListDTOPage = new Page<RunCampaignListDTO>(runCampaignListDTO.getPageSize(), runCampaignListDTO.getCurrentPage());
	         runCampaignListDTOPage.setParam(runCampaignListDTO);
	         RunCampaignListPageDTO result = runCampaignListServiceImpl.selectCampaigninfoPage(runCampaignListDTOPage);
	         runCampaignListDTOPage = result.getRunCampaignListDTODTOPage();

	         Map<String, Object> model = Maps.newHashMap();
	         if (null != runCampaignListDTOPage) {
	             model.put("runCampaignList", runCampaignListDTOPage.getResultList());
	         }
	         //将活动类型转换
	         for(RunChannelListDTO runChannelListDTO :result.getRunChannelListDTOList()){
	        	 if(runChannelListDTO.getType().equals(RunConstants.IS_ZHONGJI)){
	        		 runChannelListDTO.setTypeName(RunConstants.IS_ZHONGJI_NAME);
	        	 }else{
	        		 runChannelListDTO.setTypeName(RunConstants.IS_YIWAI);
	        	 }
	         }
	         model.put("role", result.getRole());
	         model.put("runCampaignListDTO", runCampaignListDTO);
	         model.put("page", runCampaignListDTOPage);
	         model.put("channelList", result.getRunChannelListDTOList());
	         log.info("{}-/select/campaigninfopage return, data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());
	         return new ModelAndView("cms/campaign_list", model);
	    }	  
		
		 /**
	     * cms营销活动信息修改和添加
	     * 
	     * @return
	     */
		
		 @RequestMapping(value = "/updateorinset", method = RequestMethod.POST)
		    public ResultBase<String> updateOrInsertCampaignList(RunCampaignListDTO runCampaignListDTO) {	
			  log.info("{}-/updateorinset,param={" + runCampaignListDTO.toString() + "}",ThreadLocalUtil.getRequestNo());
			  ResultBase<String> result = new ResultBase<String>();
		      Map<String, Object> model = Maps.newHashMap();
		      if("".equals(runCampaignListDTO.getId())){
		    	  runCampaignListDTO.setId(null);
		      }
		      model.put("runCampaignListDTO", runCampaignListDTO);		      
			  //新建
			  if(null == runCampaignListDTO.getId()){				  
				  result = runCampaignListServiceImpl.insertCampaignList(runCampaignListDTO);				  				  
			  //修改  
			  }else{				  				  
				  result = runCampaignListServiceImpl.updateCampaignList(runCampaignListDTO);				  				  
			  }
			  log.info("{}-/updateorinset  return,data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());
		      return result;
		    }	    
		
		
		
		 /**
	     * cms营销活动信息删除
	     * 
	     * @return
	     */
		 
		    @RequestMapping(value = "/delete/campaignlist/{id}", method = RequestMethod.GET) 
		    public ResultBase<String> deleteCampaignListOne(@PathVariable String id){
		    	 log.info("{}-/delete/delete/campaignlist/{id}, param={ " + id.toString() + " }",ThreadLocalUtil.getRequestNo());
		    	 ResultBase<String> result= new ResultBase<String>();
		    	 if(id!=null){
		    	  result= runCampaignListServiceImpl.deleteCampaignList(id);
		    	 }    	 	    	 
		    	 log.info("{}-/delete/delete/campaignlist/{id} return, data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());	
		    	 return result;
		    }	    
		    
		    /**
		     * cms营销活动根据ID 查询结果信息
		     * 
		     * @return
		     */
		
		    @RequestMapping(value = "/selectone/campaignlistone/{id}", method = RequestMethod.GET) 
		    public RunCampaignListDTO selectCampaignListOne(@PathVariable String id){
		    	 log.info("{}-/selectone/campaignlist/{id}, param={ " + id.toString() + " }",ThreadLocalUtil.getRequestNo());
		    	 RunCampaignListDTO runCampaignListDTO = new RunCampaignListDTO();
		    	 if(id!=null){
		    		 runCampaignListDTO = runCampaignListServiceImpl.selectOneCampaignList(id);
		    	 }    	 	    	 
		    	 log.info("{}-/selectone/campaignlist/{id} return, data={" + runCampaignListDTO.toString() + "}",ThreadLocalUtil.getRequestNo());	
		    	 return runCampaignListDTO;
		    }	    
		    
}
