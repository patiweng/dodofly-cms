package com.zhongan.app.run.cms.repository;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoIssRewardsDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.dao.BububaoIssRewardsDAO;
import com.zhongan.app.run.common.utils.AppUtil;

@Slf4j
@Component
public class RunIssRewardsRepository {
	
	@Resource
	private BububaoIssRewardsDAO bububaoIssRewardsDAO;
	
	/**
	 * 判断客户当天是否已抽过奖 true-已抽过  false-未抽过
	 * @param unionId
	 * @return
	 */
	public ResultBase<String> checkUserRewards(String unionId){
		ResultBase<String> result = new ResultBase<String>();
		String nowDay = AppUtil.getNowTimeString();
		BububaoIssRewardsDO bububaoIssRewardsDO = new BububaoIssRewardsDO();
		bububaoIssRewardsDO.setUnionId(unionId);
		bububaoIssRewardsDO.setDate(nowDay);
		List<BububaoIssRewardsDO> issList = bububaoIssRewardsDAO.selectIssRewards(bububaoIssRewardsDO);
		if(issList != null && issList.size() > 0){
			result.setSuccess(true);
			return result;
		}else{
			result.setSuccess(false);
			return result;
		}
	}
}
