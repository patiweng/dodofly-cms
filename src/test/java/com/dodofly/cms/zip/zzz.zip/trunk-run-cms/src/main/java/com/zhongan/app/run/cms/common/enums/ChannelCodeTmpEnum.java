package com.zhongan.app.run.cms.common.enums;

public enum ChannelCodeTmpEnum {
	CHANEL_WEIXIN("zaWechatBububao", "微信渠道"),
	CHANEL_XIAOMI("xiaomiApp", "小米渠道"),
	CHANEL_LEDONGLI("ledongli", "乐动力渠道"),
	CHANEL_ZHONGAN("zhonganApp", "众安APP"),
	CHANEL_SHUASHUA("ishuashua", "刷刷渠道"),
	CHANEL_GUODIAN("guodian", "国家电网"),
	CHANEL_JILI("jiLiWechat", "吉利"),
	CHANEL_KUNLUN("kunlun", "昆仑保险经纪"),
    CHANEL_MEIZU("meizu", "魅族渠道"),
    CHANEL_BONG("bong", "bong手环渠道"),
    CHANEL_FHJR("qyfengjr", "凤凰金融"),
    CHANEL_ZASPORT("zasport", "众安运动"),
    CHANEL_HUAWEI("huawei", "华为运动"),
    CHANEL_ALI("aliHealth", "阿里健康"),
    CHANEL_LHBANK("lanHaiBankWechat", "蓝海银行"),
    CHANEL_ZUIFULI("zuifuli", "最福利"),
    CHANEL_LEXIN("leXinSport", "乐心运动"),
    CHANEL_QITA("qita", "其他"),;

    private String code;
    private String value;

    public static ChannelCodeTmpEnum getEnumByCode(String code) {
        for (ChannelCodeTmpEnum codeEnum : ChannelCodeTmpEnum.values()) {
            if (codeEnum.getCode().equals(code)) {
                return codeEnum;
            }
        }
        return CHANEL_QITA;
    }

    private ChannelCodeTmpEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
