package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoActivityPresentDO {

    private String id;
    private String activityId;
    private String presentId;
    private String presentNumber;
    private String havePresentedNumber;
    private String presentOrder;
    private String isRepeated;
    private String creator;
    private String modifier;
    private String createTime;
    private String modifyTime;
    private String isDeleted;
}
