package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.StaticsService;

/**
 * 业务统计报表-临时用
 * @author songchengsong
 *
 */
@RestController
@RequestMapping("/run/cms/excel")
@Slf4j
public class StaticsController {
	
	@Resource
	private StaticsService staticsServiceImpl;
	
	@RequestMapping(value = "/staticsall/{sDate}/{eDate}", method = RequestMethod.GET)
	public ResultBase<String> staticsAll(HttpServletResponse response, @PathVariable String sDate,
            @PathVariable String eDate){
		log.info("汇总业务统计开始执行");
		return staticsServiceImpl.staticsAll(response, sDate, eDate);
	}
	@RequestMapping(value = "/staticsxubao/{sDate}/{eDate}", method = RequestMethod.GET)
	public ResultBase<String> staticsXuBao(HttpServletResponse response, @PathVariable String sDate,
            @PathVariable String eDate){
		log.info("续保业务统计开始执行");
		return staticsServiceImpl.staticsXuBao(response, sDate, eDate);
	}
	
	@RequestMapping(value = "/staticsuvpv/{from}/{sDate}/{eDate}", method = RequestMethod.GET)
	public ResultBase<String> staticsUvPv(@PathVariable String from,@PathVariable String sDate,
            @PathVariable String eDate){
		ResultBase<String> result = new ResultBase<String>();
		result = staticsServiceImpl.staticsUvPv(from, sDate, eDate);
		return result;
	}
}
