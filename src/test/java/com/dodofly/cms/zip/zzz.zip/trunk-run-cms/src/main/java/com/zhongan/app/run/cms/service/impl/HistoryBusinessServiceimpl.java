package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.zhongan.app.run.cms.bean.web.HistoryBusinessDTO;
import com.zhongan.app.run.cms.bean.web.HistoryBusinessQueryDTO;
import com.zhongan.app.run.cms.conver.HistoryBusinessConvert;
import com.zhongan.app.run.cms.dao.HistoryBusinessMapper;
import com.zhongan.app.run.cms.dao.bean.HistoryBusinessCriteria;
import com.zhongan.app.run.cms.dao.bean.HistoryBusinessCriteria.Criteria;
import com.zhongan.app.run.cms.service.HistoryBusinessService;
import com.zhongan.pipeline.utils.StringUtils;

@Service
public class HistoryBusinessServiceimpl implements HistoryBusinessService {

    @Resource
    private HistoryBusinessMapper historyBusinessMapper;

    @Override
    public List<HistoryBusinessDTO> queryByCondition(HistoryBusinessQueryDTO queryDTO) {
        return HistoryBusinessConvert.converToDTOs(historyBusinessMapper.selectByCriteria(buildCriteria(queryDTO)));
    }

    private HistoryBusinessCriteria buildCriteria(HistoryBusinessQueryDTO queryDTO) {
        HistoryBusinessCriteria businessCriteria = new HistoryBusinessCriteria();
        Criteria createCriteria = businessCriteria.createCriteria();
        if (null != queryDTO.getBizTime()) {
            createCriteria.andBizTimeEqualTo(queryDTO.getBizTime());
        }
        if (StringUtils.isNotEmpty(queryDTO.getSourceCode())) {
            createCriteria.andSourceCodeEqualTo(queryDTO.getSourceCode());
        }
        return businessCriteria;
    }
}
