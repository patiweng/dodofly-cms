package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;
import com.zhongan.app.run.cms.dao.TransLogDAO;

@Repository
public class TransLogRepository {
    @Resource
    private TransLogDAO transLogDAO;

    public List<TransLogDO> selectTransLogByDate(Map<String, String> map) {
        List<TransLogDO> list = transLogDAO.selectTransLogByDate(map);
        return list;
    }

}
