package com.zhongan.app.run.cms.common.excelutil.cellconver;

import java.util.List;
import java.util.Map;

import com.zhongan.app.run.cms.common.excelutil.annotion.CellConvert;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;

public class ReadStringConvert implements CellConvert {

    @Override
    public <T> T readConvert(Map<String, Cell> map, Class<T> clazz) {
        Cell cell = map.get("clientId");
        cell.setCellType(HSSFCell.CELL_TYPE_STRING);
        return (T) cell.getStringCellValue();
    }

    @Override
    public <T> void writeConvertHead(Class<T> clazz, Sheet sheet) {
    }

    @Override
    public <T> void writeConvertContent(List<T> dataList, Class<T> clazz, Sheet sheet) {
    }

}
