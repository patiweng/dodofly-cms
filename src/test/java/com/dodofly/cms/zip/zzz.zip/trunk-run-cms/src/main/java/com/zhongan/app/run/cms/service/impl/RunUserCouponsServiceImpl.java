package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.bo.RunUserCouponsBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunUserCouponsRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserCouponsDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.AppUtil;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.repository.RunUserCouponsRepository;
import com.zhongan.app.run.cms.service.RunUserCouponsService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RunUserCouponsServiceImpl implements RunUserCouponsService {

    @Resource
    private RunUserCouponsRepository runUserCouponsRepository;

    @Override
    public ResultBase<Page<RunUserCouponsDTO>> selectRunUserCouponsInfo(Page<RunUserCouponsDTO> runUserCouponsDTOpagedata) {
        ResultBase<Page<RunUserCouponsDTO>> result = new ResultBase<Page<RunUserCouponsDTO>>();
        log.info("{}-RunUserCoupons...select...begin...", ThreadLocalUtil.getRequestNo());
        //参数的校验
        ResultBase<String> valResult = CheckBitparam(runUserCouponsDTOpagedata);
        if (!valResult.isSuccess()) {
            log.info("{}-fail--param:" + valResult.getErrorCode() + "-" + valResult.getErrorMessage(),
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            Page<RunUserCouponsRepo> runUserCouponsRepoPage = new Page<RunUserCouponsRepo>();
            BeanUtils.copyProperties(runUserCouponsDTOpagedata, runUserCouponsRepoPage);
            runUserCouponsRepoPage = runUserCouponsRepository.selectRunUserCouponsData(runUserCouponsRepoPage);
            List<RunUserCouponsRepo> runUserCouponsRepoList = runUserCouponsRepoPage.getResultList();
            if (null != runUserCouponsRepoList && 0 != runUserCouponsRepoList.size()) {
                List<RunUserCouponsDTO> runUserCouponsBOList = Lists.newArrayList();
                RunUserCouponsDTO runUserCouponsDTO = null;
                for (RunUserCouponsRepo runUserCouponsRepolist : runUserCouponsRepoList) {
                    runUserCouponsDTO = new RunUserCouponsDTO();
                    BeanUtils.copyProperties(runUserCouponsRepolist, runUserCouponsDTO);
                    runUserCouponsBOList.add(runUserCouponsDTO);
                }
                runUserCouponsDTOpagedata.setResultList(runUserCouponsBOList);
                runUserCouponsDTOpagedata.setTotalItem(runUserCouponsRepoPage.getTotalItem());
                result.setValue(runUserCouponsDTOpagedata);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-runUserCoupons select fail,please find error to..."
                    + "error location polynomial : RunUserCouponsServiceImpl--selectRunUserCouponsInfo()"
                    + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    //入参数的校验
    @SuppressWarnings({ "unchecked" })
    private ResultBase<String> CheckBitparam(Page<RunUserCouponsDTO> runUserCouponsDTOpagedata) {
        log.info("{}-param check code...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        //用户ID
        if (StringUtils.isEmpty(runUserCouponsDTOpagedata.getParam().getUnionId())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100008, result);
        }
        result.setSuccess(true);
        return result;
    }

    @Override
    public ResultBase<Integer> update(RunUserCouponsBO userCouponsBO) {
        ResultBase<Integer> result = new ResultBase<Integer>();
        try {
            RunUserCouponsRepo userCouponsRepo = new RunUserCouponsRepo();
            BeanUtils.copyProperties(userCouponsBO, userCouponsRepo);
            Integer count = runUserCouponsRepository.update(userCouponsRepo);
            result.setValue(count);
            result.setSuccess(true);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
        } catch (Exception e) {
            log.error("{}-", e.getMessage(), e, ThreadLocalUtil.getRequestNo());
            log.error("{}-when updateUserCoupons, error occured...", ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<String> insert(RunUserCouponsBO userCouponsBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunUserCouponsRepo userCouponsRepo = new RunUserCouponsRepo();
            BeanUtils.copyProperties(userCouponsBO, userCouponsRepo);
            runUserCouponsRepository.insert(userCouponsRepo);
            result.setSuccess(true);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
        } catch (Exception e) {
            log.error("{}-", e.getMessage(), e, ThreadLocalUtil.getRequestNo());
            log.error("{}-when insertUserCoupons, error occured...", ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    public ResultBase<Boolean> isUserCoupons(RunUserCouponsBO userCouponsBO) {
        ResultBase<Boolean> result = new ResultBase<Boolean>();
        boolean flag = false;
        try {
            RunUserCouponsRepo userCouponsRepo = new RunUserCouponsRepo();
            BeanUtils.copyProperties(userCouponsBO, userCouponsRepo);
            Integer runUserCoupons = runUserCouponsRepository.selectUserCoupons(userCouponsRepo);
            if (null != runUserCoupons && runUserCoupons > 0) {
                flag = true;
            }
            result.setSuccess(true);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
        } catch (Exception e) {
            log.error("{}-RunUserUserConponsServiceImpl.isUserCoupons.......fail==={}", e);
            result.setSuccess(false);
            result.setErrorMessage("查询是否领取积分明细异常");
        }
        result.setValue(flag);
        return result;
    }

    @Override
    public ResultBase<String> sendRenewalInsuranceCoupons(RunUserCouponsBO userCouponsBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunUserCouponsRepo userCouponsRepo = new RunUserCouponsRepo();
            BeanUtils.copyProperties(userCouponsBO, userCouponsRepo);
            userCouponsRepo.setUsed("0");
            String currentDate = DateTimeUtils.getCurrentDateString();
            userCouponsRepo.setStartTime(DateTimeUtils.dateStringAddDays(currentDate, 1));
            userCouponsRepo.setEndTime(DateTimeUtils.dateStringAddDays(currentDate, 1 + userCouponsRepo.getFreeDays()));
            userCouponsRepo.setExpired("0");
            userCouponsRepo.setType("1");
            runUserCouponsRepository.insert(userCouponsRepo);
            result.setSuccess(true);
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
        } catch (Exception e) {
            log.error("{}-", e.getMessage(), e, ThreadLocalUtil.getRequestNo());
            log.error("{}-when sendRenewalInsuranceCoupons, error occured...", ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;

    }

}
