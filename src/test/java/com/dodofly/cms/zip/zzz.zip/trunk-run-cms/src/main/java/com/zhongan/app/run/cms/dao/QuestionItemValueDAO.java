package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.QuestionItemValueDO;

@Component
public interface QuestionItemValueDAO {
    /**
     * 根据id查询
     * 
     * @param id
     * @return
     */
    QuestionItemValueDO selectDataById(Long id);

    /**
     * 根据条件查询
     * 
     * @param questionItemValueDO
     * @return
     */
    List<QuestionItemValueDO> selectDataByCdt(QuestionItemValueDO questionItemValueDO);

    /**
     * 分页查询QuestionListItemValue信息
     * 
     * @param map
     * @return
     */
    List<QuestionItemValueDO> selectQuestionItemValueList(Map map);

    /**
     * 查询QuestionListItemValue条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 插入数据
     * 
     * @param questionItemValueDO
     */
    void insert(QuestionItemValueDO questionItemValueDO);

    /**
     * 更新数据
     * 
     * @param questionItemValueDO
     */
    void update(QuestionItemValueDO questionItemValueDO);

    /**
     * 更新数据为无效数据
     * 
     * @param id
     */
    void updateDeletedById(String id);
}
