package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.AnalysisMonitorDO;

@Component
public interface AnalysisMonitorDAO {

    /**
     * 分页查询列表
     * 
     * @return
     */
    List<AnalysisMonitorDO> selectAnalysisMonitorlList(Map map);

    /**
     * 查询总条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);
}
