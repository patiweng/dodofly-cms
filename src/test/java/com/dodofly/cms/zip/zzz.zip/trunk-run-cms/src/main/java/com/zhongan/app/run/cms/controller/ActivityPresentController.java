package com.zhongan.app.run.cms.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.ActivityPresentBO;
import com.zhongan.app.run.cms.bean.bo.RafflePresentBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.ActivityPresentListPageDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.ActivityPresentService;
import com.zhongan.app.run.cms.service.RafflePresentService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class ActivityPresentController {
    @Resource
    private ActivityPresentService activityPresentServiceImpl;
    
    @Resource
    private RafflePresentService rafflePresentServiceImpl;

    @RequestMapping(value = "/selectactivitypresent", method = RequestMethod.POST)
    public ResultBase<List<ActivityPresentDTO>> selectActivityPresent(@RequestBody ActivityPresentDTO activityPresentDTO) {
        log.info("{}-into /selectactivitypresent, param={ " + activityPresentDTO.toString() + " }");
        ResultBase<List<ActivityPresentDTO>> result = new ResultBase<List<ActivityPresentDTO>>();
        ActivityPresentBO activityPresentBO = new ActivityPresentBO();
        BeanUtils.copyProperties(activityPresentDTO, activityPresentBO);
        result = activityPresentServiceImpl.selectActivityPresentData(activityPresentBO);
        log.info("{}-/selectactivitypresent return, data={" + result + "}");
        return result;
    }

    /**
     * 查询所有信息 分页。。。
     * 
     * @return
     */ 
    @RequestMapping(value = "/selectactivitypresentpage",method = RequestMethod.GET)
    public ModelAndView selectActivityPresentListPage(@RequestParam(value = "id",required = true) String id, 
    		@RequestParam(value= "currentPage" ,required = false) Integer currentPage, HttpServletRequest request,
            HttpServletResponse  response) {
    	 ActivityPresentDTO activityPresentDTO = new ActivityPresentDTO();
    	 activityPresentDTO.setActivityId(id);
    	 if(currentPage!=null || !"".equals(currentPage)){
    		 activityPresentDTO.setCurrentPage(currentPage);
    	 }
    	 log.info("{}-into /c, param={ " + activityPresentDTO.toString() + " }",ThreadLocalUtil.getRequestNo());   	 
         Page<ActivityPresentDTO> activityPresentListPage = new Page<ActivityPresentDTO>(10, activityPresentDTO.getCurrentPage());
         activityPresentListPage.setParam(activityPresentDTO);
         ActivityPresentListPageDTO result = activityPresentServiceImpl.selectActivityPresentPage(activityPresentListPage);
         //礼物列表
         RafflePresentBO rafflePresentBO = new RafflePresentBO();
         ResultBase<List<RafflePresentDTO>> presentListend = rafflePresentServiceImpl.selectPresentData(rafflePresentBO);
         List<RafflePresentDTO> presentList = Lists.newArrayList();
         if(presentListend.getValue().size()>0){
        	 presentList = presentListend.getValue();
         }
         activityPresentListPage = result.getActivityPresentDTOPage();
         Map<String, Object> model = Maps.newHashMap();
         if (null != activityPresentListPage) {
             model.put("activitypresentlistPage", activityPresentListPage.getResultList());
         }
         if (null != activityPresentListPage) {
             model.put("currentPage", activityPresentListPage.getCurrentPage());
         }
         model.put("presentList", presentList);
         model.put("role", result.getRole());
         model.put("activityPresentDTO", activityPresentDTO);
         model.put("page", activityPresentListPage);
         log.info("{}-/selectactivitypresentpage return, data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());
         return new ModelAndView("cms/activitypresent", model);
    }	  
    
    
    /** 
     * 新增 修改信息  后台
     * 
     * @return
     */

    @RequestMapping(value = "/insertorupdateactpre", method = RequestMethod.POST)
    public ResultBase<String> insertorupdate(ActivityPresentDTO activityPresentDTO) {
        log.info("{}-/insertorupdateactpre,param={" + activityPresentDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        Map<String, Object> model = Maps.newHashMap();
        model.put("activityPresentDTO", activityPresentDTO);    
        if("".equals(activityPresentDTO.getId())){
        	activityPresentDTO.setId(null);
	      }
        ActivityPresentBO activityPresentBO = new ActivityPresentBO();
        BeanUtils.copyProperties(activityPresentDTO, activityPresentBO);
        if(null==activityPresentBO.getId()){
        	result = activityPresentServiceImpl.insertActivityPresentData(activityPresentBO);
        }
        else{
        	result = activityPresentServiceImpl.updateActivityPresentData(activityPresentBO);
        }
        log.info("{}-/insertorupdateactpre  return,data={" + result.toString() + "}");
        return result;
    }

    
    /**
     * 新增信息
     * 
     * @return
     */

    @RequestMapping(value = "/insertactivitypresent", method = RequestMethod.POST)
    public ResultBase<String> insertActivityPresent(@RequestBody ActivityPresentDTO activityPresentDTO) {
        log.info("{}-/insertdata,param={" + activityPresentDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        ActivityPresentBO activityPresentBO = new ActivityPresentBO();
        BeanUtils.copyProperties(activityPresentDTO, activityPresentBO);
        result = activityPresentServiceImpl.insertActivityPresentData(activityPresentBO);
        log.info("{}-/insertdata  return,data={" + result.toString() + "}");
        return result;
    }

    /**
     * 修改信息
     * 
     * @return
     */

    @RequestMapping(value = "/updateactivitypresent", method = RequestMethod.POST)
    public ResultBase<String> updateActivityPresent(@RequestBody ActivityPresentDTO activityPresentDTO) {
        log.info("{}-/uodatedata,param={" + activityPresentDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        ActivityPresentBO activityPresentBO = new ActivityPresentBO();
        BeanUtils.copyProperties(activityPresentDTO, activityPresentBO);
        result = activityPresentServiceImpl.updateActivityPresentData(activityPresentBO);
        log.info("{}-/uodatedata  return,data={" + result.toString() + "}");
        return result;
    }
    
    /**
     * 根据主键查询单条   后台
     * 
     * @return
     */
    @RequestMapping(value = "/selectactpreone/{id}", method = RequestMethod.GET)
    public ActivityPresentDTO selectOneData(@PathVariable String id) {
        log.info("{}-into /selectactpreone, param={ " + id + " }");
        ActivityPresentDTO result = new ActivityPresentDTO();        
        result = activityPresentServiceImpl.selectDataByid(id);
        log.info("{}-/selectactpreone return, data={" + result + "}");
        return result;
    }
    
    /**
     * 根据主键删除
     * 
     * @return
     */  
 
    @RequestMapping(value = "/deleteactivitypresent/{id}", method = RequestMethod.GET) 
    public ResultBase<String> deleteActivityPresentData(@PathVariable String id){
    	 log.info("{}-/deleteactivitypresent/{id}, param={ " + id.toString() + " }",ThreadLocalUtil.getRequestNo());
    	 ResultBase<String> result= new ResultBase<String>();
    	 if(id!=null){
    	  result= activityPresentServiceImpl.deleteActivityPresent(id);
    	 }    	 	    	 
    	 log.info("{}-/deleteactivitypresent/{id} return, data={" + result.toString() + "}",ThreadLocalUtil.getRequestNo());	
    	 return result;
    }	    


}
