package com.zhongan.app.run.cms.service;

import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.QuestionItemDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemPageDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemValueDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemValuePageDTO;
import com.zhongan.app.run.cms.bean.web.QuestionListDTO;
import com.zhongan.app.run.cms.bean.web.QuestionListPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserQuestionDTO;

public interface HealthQuestionnaireService {

    /**
     * 查询问卷题目
     * 
     * @param questionListDTO
     * @return
     */
    ResultBase<JSONObject> selectQuestionnaireTag(QuestionListDTO questionListDTO);

    /**
     * 新增用户问卷答题记录
     * 
     * @param userQuestions
     * @return
     */
    ResultBase<String> insertUserQuestion(List<UserQuestionDTO> userQuestions);

    /**
     * 根据条件查询用户问卷答案表
     * 
     * @param userQuestionDTO
     * @return
     */
    ResultBase<List<UserQuestionDTO>> selectUserQuestionByCdt(UserQuestionDTO userQuestionDTO);

    /**
     * 插入问卷信息
     * 
     * @param questionListDTO
     * @return
     */
    ResultBase<String> insertQustionnaireData(QuestionListDTO questionListDTO);

    /**
     * 分页查询问卷
     * 
     * @param questionListDTOPage
     * @return
     */
    QuestionListPageDTO selectQustionnaireListPage(Page<QuestionListDTO> questionListDTOPage);

    /**
     * 更新问卷
     * 
     * @param questionListDTO
     * @return
     */
    ResultBase<String> updateQustionnaireData(QuestionListDTO questionListDTO);

    /**
     * 设置问卷失效
     * 
     * @param id
     * @return
     */
    ResultBase<String> deleteQustionnaire(String id);

    /**
     * 插入问题信息
     * 
     * @param questionItemDTO
     * @return
     */
    ResultBase<String> insertQustionItemData(QuestionItemDTO questionItemDTO);

    /**
     * 分页查询问题
     * 
     * @param questionItemDTO
     * @return
     */
    QuestionItemPageDTO selectQustionItemListPage(Page<QuestionItemDTO> questionItemDTO);

    /**
     * 更新问题信息
     * 
     * @param questionItemDTO
     * @return
     */
    ResultBase<String> updateQustionItemData(QuestionItemDTO questionItemDTO);

    /**
     * 设置问题失效
     * 
     * @param id
     * @return
     */
    ResultBase<String> deleteQustionItem(String id);

    /**
     * 条件查询问题
     * 
     * @param questionItemDTO
     * @return
     */
    ResultBase<List<QuestionItemDTO>> selectQuestionItemByCdt(QuestionItemDTO questionItemDTO);

    /**
     * 插入问题选项信息
     * 
     * @param questionItemValueDTO
     * @return
     */
    ResultBase<String> insertQustionItemValueData(QuestionItemValueDTO questionItemValueDTO);

    /**
     * 更新问题选项信息
     * 
     * @param questionItemValueDTO
     * @return
     */
    ResultBase<String> updateQustionItemValueData(QuestionItemValueDTO questionItemValueDTO);

    /**
     * 设置问题选项失效
     * 
     * @param id
     * @return
     */
    ResultBase<String> deleteQustionItemValue(String id);

    /**
     * 条件查询问题选项
     * 
     * @param questionItemValueDTO
     * @return
     */
    ResultBase<List<QuestionItemValueDTO>> selectQuestionItemValueByCdt(QuestionItemValueDTO questionItemValueDTO);

    /**
     * 根据id查询问卷
     * 
     * @param id
     * @return
     */
    QuestionListDTO selectOneQustionnaire(String id);

    /**
     * 根据id查询问题
     * 
     * @param id
     * @return
     */
    QuestionItemDTO selectOneQustionItem(String id);

    /**
     * 根据id查询选项
     * 
     * @param id
     * @return
     */
    QuestionItemValueDTO selectOneQustionItemValue(String id);

    /**
     * 分页查询选项
     * 
     * @param questionItemValueDTOPage
     * @return
     */
    QuestionItemValuePageDTO selectQustionItemValueListPage(Page<QuestionItemValueDTO> questionItemValueDTOPage);
}
