package com.zhongan.app.run.cms.dao;

import java.util.List;
import com.zhongan.app.run.cms.bean.dataobject.CmsUserDO;

public interface CmsUserDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<CmsUserDO> selectDataByCdt(CmsUserDO cmsUserDO);
		 /**
	    * 根据条件查询数据
	    * @return
	    */
	   CmsUserDO selectByNameAndPwd(CmsUserDO cmsUserDO);
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   CmsUserDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param CmsUserDO
	    */
	   void insert(CmsUserDO cmsUserDO);
	   
	   /**
	    * 更新数据
	    * @param CmsUserDO
	    */
	   void update(CmsUserDO cmsUserDO);
}
