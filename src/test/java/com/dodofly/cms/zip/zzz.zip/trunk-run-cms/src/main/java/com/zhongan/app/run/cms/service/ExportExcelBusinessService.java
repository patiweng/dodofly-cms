package com.zhongan.app.run.cms.service;

import javax.servlet.http.HttpServletResponse;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessDTO;
import com.zhongan.app.run.cms.bean.web.AnalysisBusinessPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface ExportExcelBusinessService {

    void doExportExcelBusiness(HttpServletResponse response, String sdate, String edate);

    ResultBase<String> getTodayDataAnalysisBusiness();

    AnalysisBusinessPageDTO selectAnalysisBusinessList(Page<AnalysisBusinessDTO> analysisBusinessPage);

}
