package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.bo.UserPropertyBO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface UserPropertyService {

    ResultBase<UserPropertyBO> selectUserPropertyByUnionid(Long unionid);

}
