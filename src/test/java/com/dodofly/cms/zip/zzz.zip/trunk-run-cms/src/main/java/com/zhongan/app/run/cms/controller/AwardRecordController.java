package com.zhongan.app.run.cms.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AwardRecordDTO;
import com.zhongan.app.run.cms.bean.web.AwardRecordPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.AwardRecordService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 类AwardRecordController.java的实现描述：特殊奖励配置表controller
 * 
 * @author panchuanhe 2017年3月16日 上午11:38:20
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class AwardRecordController {

    @Resource
    private AwardRecordService awardRecordServiceImpl;

    /**
     * 分页查询用户奖励记录表
     * 
     * @param AwardRecordDTO
     * @param request
     * @return
     */
    @RequestMapping(value = "/select/selectawardrecordlistpage")
    public ModelAndView selectAwardRecordListPage(AwardRecordDTO awardRecordDTO, HttpServletRequest request) {
        log.info("{}-info/select/selectAwardRecordlistpage,param={" + awardRecordDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        Page<AwardRecordDTO> page = new Page<AwardRecordDTO>(awardRecordDTO.getPageSize(),
                awardRecordDTO.getCurrentPage());
        awardRecordDTO=formatParam(awardRecordDTO);
        page.setParam(awardRecordDTO);
        AwardRecordPageDTO result = awardRecordServiceImpl.selectAwardRecordListPage(page);
        page=result.getAwardRecordPage();
        Map<String, Object> model = Maps.newHashMap();
        model.put("awardRecordList", page.getResultList());
        model.put("awardRecordDTO", awardRecordDTO);
        model.put("page", page);
        model.put("channelList", result.getRunChannelListDTOList());
        log.info("{}-/select/selectAwardRecordlistpage return, data={" + page.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/awardrecord", model);
    }

    /**
     * 根据id查询一条
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/select/selectawardrecordone", method = RequestMethod.GET)
    public AwardRecordDTO selectAwardRecordOne(String id) {
        log.info("{}-info/select/selectAwardRecordOne,param={" + id.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<AwardRecordDTO> result = awardRecordServiceImpl.selectAwardRecordOne(id);
        return result.getValue();
    }

    /**
     * 新增特殊奖励配置
     * 
     * @param AwardRecordDTO
     * @return
     */
    @RequestMapping(value = "/insert/insertawardrecord", method = RequestMethod.POST)
    public ResultBase<String> insertAwardRecord(AwardRecordDTO awardRecordDTO) {
        log.info("{}-info/insert/insertAwardRecord,param={" + awardRecordDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return awardRecordServiceImpl.updateById(awardRecordDTO);
    }

    /**
     * 获取数据渲染礼物名称下拉框
     * 
     * @return
     */
    @RequestMapping(value = "/getpresentnamearrlist", method = RequestMethod.GET)
    public ResultBase<String> getPresentNameArrList(String identify) {
        log.info("{}-info/getPresentNameArrList,param={" + identify + "}", ThreadLocalUtil.getRequestNo());
        return awardRecordServiceImpl.getPresentNameArrList(identify);
    }

    /**
     * 导出excel
     * 
     * @param awardRecordDTO
     */
    @RequestMapping(value = "/excel/doexportexcel/{identify}/{presentId}/{customerPhone}/{channelFrom}/{sdate}/{edate}", method = RequestMethod.GET)
    public void doExportExcel(HttpServletResponse response, @PathVariable String identify,
                              @PathVariable String presentId, @PathVariable String customerPhone,
                              @PathVariable String channelFrom, @PathVariable String sdate, @PathVariable String edate) {
        log.info("{}-info/doExportExcel", ThreadLocalUtil.getRequestNo());
        awardRecordServiceImpl.doExportExcel(response, formatParam(identify, presentId, customerPhone,channelFrom, sdate, edate));
    }

    public AwardRecordDTO formatParam(String identify, String presentId, String customerPhone, String channelFrom,
                                      String sdate, String edate) {
        AwardRecordDTO awardRecordDTO = new AwardRecordDTO();
        if (!"null".equals(identify)) {
            awardRecordDTO.setIdentify(identify);
        }
        if ("0".equals(presentId)) {
            awardRecordDTO.setPresentId(null);
        }else{
            awardRecordDTO.setPresentId(Long.valueOf(presentId));
        }
        if ("0".equals(channelFrom)) {
            awardRecordDTO.setChannelFrom(null);
        }else{
            awardRecordDTO.setChannelFrom(channelFrom);
        }
        if (!"null".equals(customerPhone)) {
            awardRecordDTO.setCustomerPhone(customerPhone);
        }
        if (!"null".equals(sdate)) {
            awardRecordDTO.setSdate(sdate);
        }
        if (!"null".equals(edate)) {
            awardRecordDTO.setEdate(edate);
        }
        return awardRecordDTO;
    }
    
    public AwardRecordDTO formatParam(AwardRecordDTO awardRecordDTO) {
        if (awardRecordDTO.getPresentId()==null||awardRecordDTO.getPresentId()==0) {
            awardRecordDTO.setPresentId(null);
        }
        if ("0".equals(awardRecordDTO.getChannelFrom())) {
            awardRecordDTO.setChannelFrom(null);
        }
        return awardRecordDTO;
    }
    /**
     * 根据条件查（unionid）中奖记录
     * 
     * @param awardRecordDTO
     * @return
     */
    @RequestMapping(value = "/select/selectDataByCdt", method = RequestMethod.POST)
    public ResultBase<List<AwardRecordDTO>> selectDataByCdt(@RequestBody AwardRecordDTO awardRecordDTO) {
        log.info("{}-/apply/insert--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(awardRecordDTO));
        return awardRecordServiceImpl.selectDataByCdt(awardRecordDTO);
    }
}
