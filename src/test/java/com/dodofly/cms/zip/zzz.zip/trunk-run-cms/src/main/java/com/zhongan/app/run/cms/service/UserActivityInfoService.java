package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserActivityInfoDTO;

/**
 * 用户活动信息
 * 
 * @author yangzhen001
 */
public interface UserActivityInfoService {

    ResultBase<UserActivityInfoDTO> selectUserActivityIsOpen(UserActivityInfoDTO userActParam);

    ResultBase<List<UserActivityInfoDTO>> selectUserActivityInfoByCdt(UserActivityInfoDTO info);

    ResultBase<String> inOrUpUserActivityInfor(UserActivityInfoDTO info);

    ResultBase<Integer> selectUserActivityCountByCdt(UserActivityInfoDTO info);

    ResultBase<String> selectUserGainPointTotal(UserActivityInfoDTO info);

    ResultBase<List<UserActivityInfoDTO>> selectUserFirstActivityInfoByCdt(UserActivityInfoDTO info);

    ResultBase<List<String>> selectUnionidByCdtDistinctPage(UserActivityInfoDTO info);

    ResultBase<Integer> selectUserActivityCountByCdtDistinct(UserActivityInfoDTO info);

    ResultBase<UserActivityInfoDTO> queryUserActivityInfoByUnionidAndDate(UserActivityInfoDTO userActivityParam);

}
