package com.zhongan.app.run.cms.controller;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.QuestionItemDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemPageDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemValueDTO;
import com.zhongan.app.run.cms.bean.web.QuestionItemValuePageDTO;
import com.zhongan.app.run.cms.bean.web.QuestionListDTO;
import com.zhongan.app.run.cms.bean.web.QuestionListPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserQuestionDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.utils.CustomMultipartFileEditor;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.service.HealthQuestionnaireService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 健康问卷
 * 
 * @author panchuanhe 2017年5月4日 下午3:28:38
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/healthquestionnaire")
public class HealthQuestionnaireController {

    @Resource
    private HealthQuestionnaireService healthQuestionnaireServiceImpl;

    @Resource
    private OssTool                    ossTool;

    @InitBinder
    protected void initBinder(DataBinder binder) throws ServletException {
        binder.registerCustomEditor(MultipartFile.class, new CustomMultipartFileEditor());
    }

    /**
     * 查询问卷题目
     * 
     * @param questionListDTO
     * @return
     */
    @RequestMapping(value = "/select/selectquestionnairetag", method = RequestMethod.POST)
    public ResultBase<JSONObject> selectQuestionnaireTag(@RequestBody QuestionListDTO questionListDTO) {
        log.info("/select/selectquestionnairetag  start……param=={}", questionListDTO.toString());
        return healthQuestionnaireServiceImpl.selectQuestionnaireTag(questionListDTO);
    }

    /**
     * 保存用户答题记录
     * 
     * @param userQuestions
     * @return
     */
    @RequestMapping(value = "/insert/insertuserquestion", method = RequestMethod.POST)
    public ResultBase<String> insertUserQuestion(@RequestBody List<UserQuestionDTO> userQuestions) {
        log.info("/insert/insertuserquestion  start……param=={}", userQuestions.toString());
        return healthQuestionnaireServiceImpl.insertUserQuestion(userQuestions);
    }

    /**
     * 根据条件查询问卷答案表
     * 
     * @param userQuestionDTO
     * @return
     */
    @RequestMapping(value = "/select/selectuserquestionbycdt", method = RequestMethod.POST)
    ResultBase<List<UserQuestionDTO>> selectUserQuestionByCdt(@RequestBody UserQuestionDTO userQuestionDTO) {
        log.info("/select/selectuserquestionbycdt  start……param=={}", userQuestionDTO.toString());
        return healthQuestionnaireServiceImpl.selectUserQuestionByCdt(userQuestionDTO);
    }

    /**
     * 主键查询问卷
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/select/questionnaireOne/{id}", method = RequestMethod.GET)
    public QuestionListDTO selectQuestionnaireOne(@PathVariable String id) {
        log.info("{}-/select/questionnaireOne/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        QuestionListDTO questionListDTO = new QuestionListDTO();
        if (id != null) {
            questionListDTO = healthQuestionnaireServiceImpl.selectOneQustionnaire(id);
        }
        log.info("{}-/select/questionnaireOne/{id} return, data={" + questionListDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return questionListDTO;
    }

    /**
     * 分页查询问卷的信息
     * 
     * @return
     */
    @RequestMapping(value = "/select/questionnairelistpage")
    public ModelAndView selectQuestionnaireListPage(QuestionListDTO questionListDTO, HttpServletRequest request) {
        log.info("{}-into /select/questionnaireListPage, param={ " + questionListDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        validParamQuestionnaire(questionListDTO);
        Page<QuestionListDTO> questionnaireListPage = new Page<QuestionListDTO>(questionListDTO.getPageSize(),
                questionListDTO.getCurrentPage());
        questionnaireListPage.setParam(questionListDTO);
        QuestionListPageDTO result = healthQuestionnaireServiceImpl.selectQustionnaireListPage(questionnaireListPage);
        questionnaireListPage = result.getQuestionListDTO();

        Map<String, Object> model = Maps.newHashMap();
        if (null != questionnaireListPage) {
            model.put("questionnaireListPage", questionnaireListPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("questionListDTO", questionListDTO);
        model.put("page", questionnaireListPage);
        log.info("{}-/select/questionnaireListPage return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/questionnaire", model);
    }

    //入参校验
    private QuestionListDTO validParamQuestionnaire(QuestionListDTO questionnaireListDTO) {
        if (!"0".equals(questionnaireListDTO.getQueryType())) {
            questionnaireListDTO.setQueryType("0");
        }
        return questionnaireListDTO;
    }

    /**
     * 根据主键修改问卷信息(添加一条新的问卷信息)
     * 
     * @return
     */
    @RequestMapping(value = "/updateOrInsetQuestionnaire", method = RequestMethod.POST)
    public ResultBase<String> updateOrInsertQuestionnaire(QuestionListDTO questionListDTO) {
        log.info("{}-/updateorinset,param={" + questionListDTO.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if ("".equals(questionListDTO.getId())) {
            questionListDTO.setId(null);
        }
        if (null == questionListDTO.getId()) {
            //新建
            result = healthQuestionnaireServiceImpl.insertQustionnaireData(questionListDTO);
        } else {
            //修改  
            result = healthQuestionnaireServiceImpl.updateQustionnaireData(questionListDTO);
        }
        log.info("{}-/updateorinsetquestionnaire  return,data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据主键删除问卷
     * 
     * @return
     */

    @RequestMapping(value = "/delete/questionnaire/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteQuestionnaireOne(@PathVariable String id) {
        log.info("{}-/delete/questionnaire/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = healthQuestionnaireServiceImpl.deleteQustionnaire(id);
        }
        log.info("{}-/delete/questionnaire/{id} return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 主键查询问题
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/select/questionItemOne/{id}", method = RequestMethod.GET)
    public QuestionItemDTO selectQuestionItemOne(@PathVariable String id) {
        log.info("{}-/select/questionItemOne/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        QuestionItemDTO questionItemDTO = new QuestionItemDTO();
        if (id != null) {
            questionItemDTO = healthQuestionnaireServiceImpl.selectOneQustionItem(id);
        }
        log.info("{}-/select/questionItemOne/{id} return, data={" + questionItemDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return questionItemDTO;
    }

    /**
     * 分页查询问题的信息
     * 
     * @return
     */
    @RequestMapping(value = "/select/questionitemlistpage")
    public ModelAndView selectQuestionItemPage(QuestionItemDTO questionItemDTO, HttpServletRequest request) {
        log.info("{}-into /select/questionitemlistpage, param={ " + questionItemDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<QuestionItemDTO> questionItemListPage = new Page<QuestionItemDTO>(questionItemDTO.getPageSize(),
                questionItemDTO.getCurrentPage());
        questionItemListPage.setParam(questionItemDTO);
        QuestionItemPageDTO result = healthQuestionnaireServiceImpl.selectQustionItemListPage(questionItemListPage);
        questionItemListPage = result.getQuestionItemDTO();

        Map<String, Object> model = Maps.newHashMap();
        if (null != questionItemListPage) {
            model.put("questionItemListPage", questionItemListPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("questionItemDTO", questionItemDTO);
        model.put("page", questionItemListPage);
        log.info("{}-/select/questionitemlistpage return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/question_item", model);
    }

    /**
     * 根据主键修改问题信息(添加一条新的问题信息)
     * 
     * @return
     */
    @RequestMapping(value = "/updateOrInsetQuestionItem", method = RequestMethod.POST)
    public ResultBase<String> updateOrInsertQuestionItem(QuestionItemDTO questionItemDTO) {
        log.info("{}-/updateOrInsertQuestionItem,param={" + questionItemDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        questionItemDTO.setInputCheck(JSONObject.toJSONString(questionItemDTO.getCheck()));
        ResultBase<String> result = new ResultBase<String>();
        if ("".equals(questionItemDTO.getId())) {
            questionItemDTO.setId(null);
        }
        if (null == questionItemDTO.getId()) {
            //新建
            result = healthQuestionnaireServiceImpl.insertQustionItemData(questionItemDTO);
        } else {
            //修改  
            result = healthQuestionnaireServiceImpl.updateQustionItemData(questionItemDTO);
        }
        log.info("{}-/updateOrInsertQuestionItem  return,data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据主键删除问题
     * 
     * @return
     */

    @RequestMapping(value = "/delete/questionItem/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteQuestionItemOne(@PathVariable String id) {
        log.info("{}-/delete/deleteQuestionItemOne/{id}, param={ " + id.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = healthQuestionnaireServiceImpl.deleteQustionItem(id);
        }
        log.info("{}-/delete/deleteQuestionItemOne/{id} return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 主键查询问题选项
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/select/questionItemValueOne/{id}", method = RequestMethod.GET)
    public QuestionItemValueDTO selectQuestionItemValueOne(@PathVariable String id) {
        log.info("{}-/select/questionItemValueOne/{id}, param={ " + id.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        QuestionItemValueDTO questionItemValueDTO = new QuestionItemValueDTO();
        if (id != null) {
            questionItemValueDTO = healthQuestionnaireServiceImpl.selectOneQustionItemValue(id);
        }
        log.info("{}-/select/questionItemValueOne/{id} return, data={" + questionItemValueDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return questionItemValueDTO;
    }

    /**
     * 分页查询问题选项
     * 
     * @return
     */
    @RequestMapping(value = "/select/questionitemvaluelistpage")
    public ModelAndView selectQuestionItemValuePage(QuestionItemValueDTO questionItemValueDTO,
                                                    HttpServletRequest request) {
        log.info("{}-into /select/questionitemvaluelistpage, param={ " + questionItemValueDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<QuestionItemValueDTO> questionItemValueListPage = new Page<QuestionItemValueDTO>(
                questionItemValueDTO.getPageSize(), questionItemValueDTO.getCurrentPage());
        questionItemValueListPage.setParam(questionItemValueDTO);
        QuestionItemValuePageDTO result = healthQuestionnaireServiceImpl
                .selectQustionItemValueListPage(questionItemValueListPage);
        questionItemValueListPage = result.getQuestionItemValueDTO();

        Map<String, Object> model = Maps.newHashMap();
        if (null != questionItemValueListPage) {
            model.put("questionItemValueListPage", questionItemValueListPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("questionItemValueDTO", questionItemValueDTO);
        model.put("page", questionItemValueListPage);
        log.info("{}-/select/questionitemvaluelistpage return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/question_item_value", model);
    }

    /**
     * 根据主键修改问题选项信息(添加一条新的问题选项信息)
     * 
     * @return
     */
    @RequestMapping(value = "/updateOrInsetQuestionItemValue", method = RequestMethod.POST)
    public ResultBase<String> updateOrInsertQuestionItemValue(QuestionItemValueDTO questionItemValueDTO) {
        log.info("{}-/updateOrInsertQuestionItemValue,param={" + questionItemValueDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if ("".equals(questionItemValueDTO.getId())) {
            questionItemValueDTO.setId(null);
        }
        if (null == questionItemValueDTO.getId()) {
            //新建
            result = healthQuestionnaireServiceImpl.insertQustionItemValueData(questionItemValueDTO);
        } else {
            //修改  
            result = healthQuestionnaireServiceImpl.updateQustionItemValueData(questionItemValueDTO);
        }
        log.info("{}-/updateOrInsertQuestionItemValue  return,data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据主键删除问题选项
     * 
     * @return
     */

    @RequestMapping(value = "/delete/questionItemValue/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteQuestionItemValueOne(@PathVariable String id) {
        log.info("{}-/delete/deleteQuestionItemValueOne/{id}, param={ " + id.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = healthQuestionnaireServiceImpl.deleteQustionItemValue(id);
        }
        log.info("{}-/delete/deleteQuestionItemValueOne/{id} return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 从oss上获取图片
     * 
     * @return
     */

    @RequestMapping(value = "/getimg/marketing/{imgurl}", method = RequestMethod.GET)
    public void getImg(@PathVariable String imgurl, HttpServletResponse response) {
        log.info("{}-into /bops/getimg/marketing, param={ " + imgurl + " }", ThreadLocalUtil.getRequestNo());
        InputStream ins = null;
        OutputStream outs = null;
        try {
            response.setDateHeader("Expires", 0);
            response.addHeader("Cache-Control", "post-check=0, pre-check=0");
            response.setHeader("Pragma", "no-cache");
            response.setContentType("image/png");
            response.setCharacterEncoding("text/html;charaset=UTF-8");
            ins = ossTool.downloadFile(RunConstants.PROJECT + RunConstants.MARKETING_IMG_PATH + imgurl
                    + RunConstants.MARKETING_IMG_SUFFIX);
            outs = response.getOutputStream();
            int iread = 0;
            byte[] buf = new byte[1024];
            while ((iread = ins.read(buf, 0, 1024)) != -1) {
                outs.write(buf, 0, iread);
            }
            outs.flush();
        } catch (Exception exp) {
            log.error("{}-", exp.getMessage(), exp, ThreadLocalUtil.getRequestNo());
        } finally {
            if (ins != null) {
                try {
                    ins.close();
                } catch (Exception ex) {
                    log.error("{}-", ex.getMessage(), ex, ThreadLocalUtil.getRequestNo());
                }
            }
            if (outs != null) {
                try {
                    outs.close();
                } catch (Exception ex) {
                    log.error("{}-", ex.getMessage(), ex, ThreadLocalUtil.getRequestNo());
                }
            }
        }
        log.info("{}-/getimg/marketing/ return", ThreadLocalUtil.getRequestNo());
    }
}
