package com.zhongan.app.run.cms.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.dataobject.SpecialAwardDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.SpecialAwardRepo;
import com.zhongan.app.run.cms.dao.SpecialAwardDAO;

@Repository
public class SpecialAwardRepository {

    @Resource
    private SpecialAwardDAO specialAwardDAO;

    public SpecialAwardRepo selectDataByRequireidsAndTimes(List<Integer> requireids, int playTimes) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("requireids", requireids);
        map.put("playTimes", playTimes);
        List<SpecialAwardDO> specialAwardDOs = specialAwardDAO.selectDataByRequireidsAndTimes(map);
        SpecialAwardRepo specialAwardRepo = null;
        if (0 != specialAwardDOs.size()) {
            SpecialAwardDO specialAwardDO = specialAwardDOs.get(0);
            specialAwardRepo = new SpecialAwardRepo();
            BeanUtils.copyProperties(specialAwardDO, specialAwardRepo);
        }
        return specialAwardRepo;
    }

    public int update(SpecialAwardRepo specialAwardRepo) {
        SpecialAwardDO specialAwardDO = new SpecialAwardDO();
        BeanUtils.copyProperties(specialAwardRepo, specialAwardDO);
        return specialAwardDAO.update(specialAwardDO);
    }

    public Page<SpecialAwardRepo> selectSpecialAwardListPage(Page<SpecialAwardRepo> page)
            throws CloneNotSupportedException {
        SpecialAwardDO specialAwardDO = new SpecialAwardDO();
        BeanUtils.copyProperties(page.getParam(), specialAwardDO);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", page.getStartRow());
        map.put("pageSize", page.getPageSize());
        map.put("specialAwardDO", specialAwardDO);
        List<SpecialAwardDO> specialAwardDOList = specialAwardDAO.selectSpecialAwardListPage(map);
        List<SpecialAwardRepo> specialAwardRepoList = Lists.newArrayList();
        if (specialAwardDOList != null && specialAwardDOList.size() > 0) {
            SpecialAwardRepo specialAwardRepo = new SpecialAwardRepo();
            for (SpecialAwardDO specialAwardDO__ : specialAwardDOList) {
                SpecialAwardRepo clone = (SpecialAwardRepo) specialAwardRepo.clone();
                BeanUtils.copyProperties(specialAwardDO__, clone);
                specialAwardRepoList.add(clone);
            }
        }
        page.setResultList(specialAwardRepoList);
        Integer count = specialAwardDAO.selectCounts(map);
        page.setTotalItem(count);
        return page;
    }

    public Long insertSpecialAward(SpecialAwardRepo specialAwardRepo) {
        SpecialAwardDO specialAwardDO = new SpecialAwardDO();
        BeanUtils.copyProperties(specialAwardRepo, specialAwardDO);
        return specialAwardDAO.insert(specialAwardDO);
    }

    public void deleteById(Long id) {
        specialAwardDAO.deleteById(id);
    }

    public void updateById(SpecialAwardRepo specialAwardRepo) {
        SpecialAwardDO specialAwardDO = new SpecialAwardDO();
        BeanUtils.copyProperties(specialAwardRepo, specialAwardDO);
        specialAwardDAO.update(specialAwardDO);
    }

    public SpecialAwardRepo selectSpecialAwardOne(String id) {
        if (StringUtil.isNotBlank(id)) {
            SpecialAwardDO specialAwardDO = specialAwardDAO.selectDataById(Long.valueOf(id));
            if (null != specialAwardDO) {
                SpecialAwardRepo specialAwardRepo = new SpecialAwardRepo();
                BeanUtils.copyProperties(specialAwardDO, specialAwardRepo);
                return specialAwardRepo;
            }
        }
        return null;
    }
}
