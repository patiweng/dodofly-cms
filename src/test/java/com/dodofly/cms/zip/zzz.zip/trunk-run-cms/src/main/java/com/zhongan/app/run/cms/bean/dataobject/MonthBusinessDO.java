package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class MonthBusinessDO implements Cloneable {
    private Long    id;
    private String  user_month;
    private String  user_year;
    private Long    new_add_user;
    private Long    xubao_add_user;
    private String  user_premium;

    private Integer pageSize;
    private Integer currentPage;
    private String  sdate;
    private String  edate;
    private String  bopsFlag;

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            log.error("clone  fail===={}", e);
        }
        return null;
    }
}
