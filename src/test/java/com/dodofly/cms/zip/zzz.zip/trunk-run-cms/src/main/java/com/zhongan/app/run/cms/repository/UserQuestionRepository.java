package com.zhongan.app.run.cms.repository;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.UserQuestionDO;
import com.zhongan.app.run.cms.bean.repo.UserQuestionRepo;
import com.zhongan.app.run.cms.dao.UserQuestionDAO;

@Repository
public class UserQuestionRepository {
    @Resource
    private UserQuestionDAO userQuestionDAO;

    @Resource
    private Sequence        seqUserQuestion;

    public UserQuestionRepo selectDataById(Long id) {
        UserQuestionDO userQuestionDO = userQuestionDAO.selectDataById(id);
        UserQuestionRepo qRepo = null;
        if (null != userQuestionDO) {
            qRepo = new UserQuestionRepo();
            BeanUtils.copyProperties(userQuestionDO, qRepo);
        }
        return qRepo;
    }

    public List<UserQuestionRepo> selectDataByCdt(UserQuestionRepo userQuestionRepo) {
        List<UserQuestionRepo> repoList = Lists.newArrayList();
        UserQuestionDO userQuestionDO = new UserQuestionDO();
        BeanUtils.copyProperties(userQuestionRepo, userQuestionDO);
        List<UserQuestionDO> doList = userQuestionDAO.selectDataByCdt(userQuestionDO);
        if (null != doList && doList.size() > 0) {
            UserQuestionRepo repo = null;
            for (UserQuestionDO qdo : doList) {
                repo = new UserQuestionRepo();
                BeanUtils.copyProperties(qdo, repo);
                repoList.add(repo);
            }
        }
        return repoList;
    }

    public void save(UserQuestionRepo userQuestionRepo) throws Exception {
        UserQuestionDO userQuestionDO = new UserQuestionDO();
        BeanUtils.copyProperties(userQuestionRepo, userQuestionDO);
        Long id = seqUserQuestion.nextValue();
        userQuestionDO.setId(id);
        userQuestionDAO.insert(userQuestionDO);
    }
}
