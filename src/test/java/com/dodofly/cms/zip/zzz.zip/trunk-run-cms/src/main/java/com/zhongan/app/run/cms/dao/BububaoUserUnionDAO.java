package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoUserSourceDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoUserUnionDO;

@Component
public interface BububaoUserUnionDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoUserUnionDO> selectDataByCdt(BububaoUserUnionDO bububaoUserUnionDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoUserUnionDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoUserUnionDO
	    */
	   void insert(BububaoUserUnionDO bububaoUserUnionDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoUserUnionDO
	    */
	   void update(BububaoUserUnionDO bububaoUserUnionDO);
}
