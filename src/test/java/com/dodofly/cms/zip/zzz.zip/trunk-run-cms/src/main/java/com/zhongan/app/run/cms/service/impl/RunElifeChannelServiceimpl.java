package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductResDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelResDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductResDTO;
import com.zhongan.app.run.cms.conver.RunElifeConvert;
import com.zhongan.app.run.cms.dao.RunElifeChannelMapper;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelCriteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelDO;
import com.zhongan.app.run.cms.service.IRunElifeChannelService;
import com.zhongan.health.common.share.bean.PageDTO;
import com.zhongan.health.common.share.enm.YesOrNo;

@Service("runElifeChannelService")
@Slf4j
public class RunElifeChannelServiceimpl implements IRunElifeChannelService {

    @Resource
    private RunElifeChannelMapper             channelMapper;

    @Resource
    private RunElifeChannelProductServiceImpl channelProductServiceImpl;

    @Resource
    private RunElifeProductServiceImpl        productServiceImpl;

    @Resource
    private Sequence                          seqRunElifeChannel;

    @Override
    public PageDTO<RunElifeChannelResDTO> queryList(RunElifeChannelQueryDTO dto) throws Exception {
        PageDTO<RunElifeChannelResDTO> pageDTO = new PageDTO<RunElifeChannelResDTO>();
        int size = dto.getPageSize();
        int currentPage = dto.getCurrentPage() < 1 ? 1 : dto.getCurrentPage();
        pageDTO.setCurrentPage(currentPage);
        pageDTO.setPageSize(size);
        RunElifeChannelCriteria criteria = buildCriteria(RunElifeConvert.convertChannelDTO(dto));
        int count = channelMapper.countByCriteria(criteria);
        if (count > 0) {
            int start = (currentPage - 1) * size;
            PageInfo pageInfo = new PageInfo();
            pageInfo.setOffset(start);
            pageInfo.setSize(size);
            List<RunElifeChannelDO> channelProductDOs = channelMapper.selectByCriteriaWithPage(criteria, pageInfo);
            pageDTO.setResultList(RunElifeConvert.convertChannelResDTOs(channelProductDOs));
            pageDTO.setTotalItem(count);
        }
        return pageDTO;
    }

    @Override
    public Integer saveOrUpdate(RunElifeChannelDTO dto) throws Exception {
        List<RunElifeChannelDO> channelDOs = channelMapper.selectByCriteria(buildCriteria(dto));
        if (CollectionUtils.isEmpty(channelDOs)) {
            RunElifeChannelDO converChannelDo = RunElifeConvert.converChannelDo(dto);
            converChannelDo.setId(seqRunElifeChannel.nextValue());
            return channelMapper.insert(converChannelDo);
        } else {
            return channelMapper.updateByPrimaryKeySelective(RunElifeConvert.converChannelDo(dto));
        }
    }

    @Override
    public JSONObject queryByCondition(RunElifeChannelDTO dto) throws Exception {
        JSONObject json = new JSONObject();
        //渠道信息
        RunElifeChannelResDTO channelResDTO = RunElifeConvert.converChannelResDTO(channelMapper
                .selectByCriteria(buildCriteria(dto)));
        if (null == channelResDTO) {
            log.warn("无对应的渠道信息 param{}", JSON.toJSONString(dto));
            return json;
        }
        json.put("channel", channelResDTO);
        //渠道产品信息
        RunElifeChannelProductDTO channelProductDTO = new RunElifeChannelProductDTO();
        channelProductDTO.setChannelId(channelResDTO.getId());
        List<RunElifeChannelProductResDTO> channelProductResDTOs = channelProductServiceImpl
                .queryByCondition(channelProductDTO);
        if (CollectionUtils.isEmpty(channelProductResDTOs)) {
            log.warn("无对应的渠道产品信息 param{}", JSON.toJSONString(dto));
            return json;
        }

        for (RunElifeChannelProductResDTO channelProductResDTO : channelProductResDTOs) {
            //产品信息
            RunElifeProductDTO dto2 = new RunElifeProductDTO();
            dto2.setBizRule(dto.getBizRule());
            dto2.setBizValue(dto.getBizValue());
            dto2.setId(channelProductResDTO.getProductId());
            RunElifeProductResDTO productResDTO = productServiceImpl.queryByCondition(dto2);
            if (null == productResDTO) {
                continue;
            }
            json.put("product", productResDTO);
            json.put("channelProduct", channelProductResDTO);
        }
        return json;
    }

    @Override
    public Integer getCount(RunElifeChannelDTO dto) throws Exception {
        return channelMapper.countByCriteria(buildCriteria(dto));
    }

    private RunElifeChannelCriteria buildCriteria(RunElifeChannelDTO queryDTO) {
        RunElifeChannelCriteria channelCriteria = new RunElifeChannelCriteria();
        Criteria createCriteria = channelCriteria.createCriteria();
        if (StringUtils.isNotBlank(queryDTO.getChannelCode())) {
            createCriteria.andChannelCodeEqualTo(queryDTO.getChannelCode());
        }
        if (StringUtils.isNotBlank(queryDTO.getChannelType())) {
            createCriteria.andChannelTypeEqualTo(queryDTO.getChannelType());
        }
        if (StringUtils.isNotBlank(queryDTO.getChannelContactName())) {
            createCriteria.andChannelContactNameEqualTo(queryDTO.getChannelContactName());
        }
        if (StringUtils.isNotBlank(queryDTO.getChannelContactPhone())) {
            createCriteria.andChannelContactPhoneEqualTo(queryDTO.getChannelContactPhone());
        }
        if (StringUtils.isNotBlank(queryDTO.getStatus())) {
            createCriteria.andStatusEqualTo(queryDTO.getStatus());
        }
        createCriteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return channelCriteria;
    }

    @Override
    public Integer deleteById(Long id) {
        RunElifeChannelDO dto = new RunElifeChannelDO();
        dto.setId(id);
        dto.setIsDeleted(YesOrNo.YES.getCode());
        return channelMapper.updateByPrimaryKeySelective(dto);
    }
}
