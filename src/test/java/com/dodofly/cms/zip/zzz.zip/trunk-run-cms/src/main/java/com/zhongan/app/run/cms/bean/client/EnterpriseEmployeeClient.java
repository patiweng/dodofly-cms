package com.zhongan.app.run.cms.bean.client;

import lombok.Data;

@Data
public class EnterpriseEmployeeClient {
    //主键
    private Integer id;
    //用户unionid
    private Long    unionid;
    //员工真实姓名
    private String  name;
    //身份证号
    private String  identity;
    //手机号
    private String  phone;
    //公司名称
    private String  enterprise;
    //公司代码
    private String  enterprise_code;
    //事业群
    private String  business_group;
    //事业群代码
    private String  business_group_code;
    //部门
    private String  department;
    //部门代码
    private String  department_code;
    //职位
    private String  position;
    //职位代码
    private String  position_code;
    //企业头像
    private String  corp_headimg;
    //红包余额
    private Integer hongbao_balance;
    //已发红包金额
    private Integer hongbao_paid;
    //当前企业步步保状态
    private Integer status;
    //创建时间
    private String  createtime;
    //修改时间
    private String  modifytime;

    private Integer level_2;

    private Integer level_3;

    private Integer level_4;

    private String  f;
    
    private String icon_url;
}
