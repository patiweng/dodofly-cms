package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoRewardsDO {
	 private String id;
	 private String activityid;
	 private String unionid;
	 private String award;
	 private String date;
	 private String payment;
	 private String name;
	 private String address;
	 private String phone;
	 private String createtime;
	 private String modifytime;
}
