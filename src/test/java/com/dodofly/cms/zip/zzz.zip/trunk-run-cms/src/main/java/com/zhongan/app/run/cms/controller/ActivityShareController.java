package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.ActivityShareDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.ActivityShareService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 续保分享邀请
 * 
 * @author yangzhen001
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class ActivityShareController {

    @Resource
    private ActivityShareService activityShareServiceImpl;

    /**
     * 根据条件查询续保用户分享信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/queryActivityShareInfoByCdt", method = RequestMethod.POST)
    public ResultBase<List<ActivityShareDTO>> queryActivityShareInfoByCdt(@RequestBody ActivityShareDTO info) {
        log.info("{}-into /queryActivityShareInfoByCdt, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<List<ActivityShareDTO>> resultBase = activityShareServiceImpl.queryActivityShareInfoByCdt(info);
        log.info("{}-/queryActivityShareInfoByCdt return, data={}", JSONObject.toJSONString(resultBase),
                ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 根据条件查询跟新 /插入用户分享信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/inOrUpUserActivityShareInfoByCdt", method = RequestMethod.POST)
    public ResultBase<String> inOrUpUserActivityShareInfoByCdt(@RequestBody ActivityShareDTO info) {
        log.info("{}-into /inOrUpUserActivityShareInfoByCdt, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<String> resultBase = activityShareServiceImpl.inOrUpUserActivityShareInfoByCdt(info);
        log.info("{}-/inOrUpUserActivityShareInfoByCdt return, data={}", JSONObject.toJSONString(resultBase),
                ThreadLocalUtil.getRequestNo());
        return resultBase;
    }
}
