package com.zhongan.app.run.cms.common.excelutil.format;

import com.zhongan.app.run.cms.common.excelutil.annotion.CellValueFormat;
import org.apache.commons.lang.StringUtils;
import org.apache.poi.ss.usermodel.Cell;

/**
 * @Description: DefaultValueFormat
 * @author lichao002 2016年7月8日 下午4:54:01
 */
public class DefaultCellValueFormat extends CellValueFormat {

    @Override
    public Object readFormat(Cell cell, Class<?> propertyClass, String propertyName) {


        if(cell == null){
            return null;
        }

        cell.setCellType(Cell.CELL_TYPE_STRING);
        String cellSrcValue = cell.getStringCellValue();

        if (StringUtils.isBlank(cellSrcValue)) {
            return null;
        }
        Object destValue = null;

        if (propertyClass.equals(String.class)) {
            destValue = cellSrcValue;
        } else if (propertyClass.equals(Long.class)) {
            //destValue = Double.valueOf(cell.getNumericCellValue()).longValue();
            destValue = Long.parseLong(cellSrcValue);
        } else if (propertyClass.equals(Integer.class)) {
            //destValue = Integer.valueOf(getNumberStr(cellSrcValue));
            destValue = Integer.parseInt(cellSrcValue);
        } else if (propertyClass.equals(Short.class)) {
            //destValue = Short.valueOf(getNumberStr(cellSrcValue));
            destValue = Short.parseShort(cellSrcValue);
        } else if (propertyClass.equals(Double.class)) {
            destValue = Double.parseDouble(cellSrcValue);
            //destValue = Double.valueOf(cellSrcValue);
        } else if (propertyClass.equals(Float.class)) {
            destValue = Float.parseFloat(cellSrcValue);
            //destValue = Double.valueOf(cellSrcValue);
        } else {
            throw new RuntimeException("不识别的类型" + propertyClass.getName());
        }

        return destValue;
    }

    @Override
    public String writeFormat(Object value, Class<?> propertyClass, String propertyName) {
        if(value == null){
            return null;
        }

        return value.toString();
    }
    /**
     * @Title: getNumberStr
     * @Description: 去掉小数点
     * @author lichao002
     * @param number
     * @return
     */
    private static String getNumberStr(String number) {
        int index = number.indexOf(".");
        if(index != -1){
            return number.substring(0, index);
        }else{
            return number;
        }
    }
}
