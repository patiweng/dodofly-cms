package com.zhongan.app.run.cms.service.qrcode.impl;

import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.service.qrcode.OssService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.io.InputStream;

@Slf4j
@Service
public class OssServiceImpl implements OssService {

    @Resource
    private OssTool ossTool;

    @Override
    public BaseResult<String> uploadFile(HttpServletRequest request, String fileName, String fileFormat) {
        BaseResult<String> result = new BaseResult<String>();
        InputStream inputStream = null;

        log.info("{}-------------OssServiceImpl.uploadFile----------------start,fileName:{},fileFormat:{}",
                ThreadLocalUtil.getRequestNo(), fileName, fileFormat);
        // 转型为MultipartHttpRequest：
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        // 获得文件：
        MultipartFile multipartFile = multipartRequest.getFile(fileName);
        // 获得文件名：
        String filename = multipartFile.getOriginalFilename();
        String format = filename.substring(filename.lastIndexOf(".") + 1);
        if (!fileFormat.equals(format.toLowerCase())) {
            result.setCode(AppErrEnum.FILE_FORMAT_ERROR.getCode());
            result.setMessage(AppErrEnum.FILE_FORMAT_ERROR.getValue());
            return result;
        }
        StringBuffer buffer = new StringBuffer();
        buffer.append(System.currentTimeMillis()).append("_").append(filename);
        String url = null;
        try {
            inputStream = multipartFile.getInputStream();
            url = ossTool.uploadFile(inputStream, buffer.toString());
        } catch (Exception e) {
            log.error("{}-------------OssServiceImpl.uploadFile----------------exception：",
                    ThreadLocalUtil.getRequestNo(), e);
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
            return result;
        } finally {
            try {
                if (inputStream != null) {
                    inputStream.close();
                }
            } catch (Exception e) {
                log.error("{}-------------OssServiceImpl.uploadFile----------------关闭流exception：",
                        ThreadLocalUtil.getRequestNo(), e);
            }
        }
        log.info("{}-------------OssServiceImpl.uploadFile----------------上传oss返回url：{}",
                ThreadLocalUtil.getRequestNo(), url);
        result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
        result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        result.setResult(url);

        log.info("{}-------------OssServiceImpl.uploadFile----------------end", ThreadLocalUtil.getRequestNo());
        return result;
    }
}
