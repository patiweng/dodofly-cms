package com.zhongan.app.run.cms.bean.dataobject;

import java.util.Date;

import lombok.Data;

@Data
public class AwardRuleDO implements Cloneable {

    private Long    id;

    private Long    activityPresentId;

    private Date    earliestTime;

    private Date    lastestTime;

    private Integer minRenewalTimes;

    private Integer maxRenewalTimes;

    private Double  minPayMoney;

    private Double  maxPayMoney;

    private Integer minAliveDays;

    private Integer maxAliveDays;

    private String  probability;

    private Integer requireid;

    private String  creator;

    private String  modifier;

    private Date    createtime;

    private Date    modifytime;

    private String  isDeleted;

    private String  activityId;

    private String  healthScore;

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
