package com.zhongan.app.run.cms.bean.qrcode.model;

import lombok.Data;

import java.util.Date;

/**
 * 机构业务员管理
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Data
public class BububaoThirdSalesDO {

    /**
     * 业务员id
     */
    private Long   id;

    /**
     * 业务员code
     */
    private String salesCode;

    /**
     * 业务员名称
     */
    private String salesName;

    /**
     * 是否为团队长
     */
    private String isLeader;

    /**
     * 机构id
     */
    private Long   orgId;

    /**
     * 上级id
     */
    private Long   parentSalesId;

    /**
     * 是否可为代理人
     */
    private String isSalesAgent;

    /**
     * 是否需要关注步步保 N、Y
     */
    private String isFollowBububao;

    /**
     * 是否删除 N、Y
     */
    private String isDeleted;

    /**
     * 创建人
     */
    private String creator;

    /**
     * 创建时间
     */
    private Date   gmtCreated;

    /**
     * 修改人
     */
    private String modifier;

    /**
     * 更新时间
     */
    private Date   gmtModified;
}
