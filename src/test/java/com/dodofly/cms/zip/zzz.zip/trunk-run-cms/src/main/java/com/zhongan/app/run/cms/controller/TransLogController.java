package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.TransLogService;

@RestController
@RequestMapping("/run/cms/translog")
@Slf4j
public class TransLogController {
    @Resource
    private TransLogService transLogServiceImpl;

    @RequestMapping(value = "/select/querytranslogbydate/{sourceCode}/{sdate}/{edate}", method = RequestMethod.POST)
    public ResultBase<List<TransLogDO>> queryTransLogByDate(@PathVariable String sourceCode,
                                                            @PathVariable String sdate, @PathVariable String edate) {

        ResultBase<List<TransLogDO>> result = new ResultBase<List<TransLogDO>>();
        result = transLogServiceImpl.queryTransLogByDate(sourceCode, sdate, edate);
        return result;

    }
}
