package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.bean.dataobject.BububaoFromScancodeDO;

@Component
public interface BububaoFromScancodeDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoFromScancodeDO> selectDataByCdt(BububaoFromScancodeDO bububaoFromScancodeDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoFromScancodeDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoFromScancodeDO
	    */
	   void insert(BububaoFromScancodeDO bububaoFromScancodeDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoFromScancodeDO
	    */
	   void update(BububaoFromScancodeDO bububaoFromScancodeDO);
}
