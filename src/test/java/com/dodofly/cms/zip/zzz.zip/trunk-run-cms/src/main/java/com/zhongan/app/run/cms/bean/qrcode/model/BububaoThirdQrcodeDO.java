package com.zhongan.app.run.cms.bean.qrcode.model;

import lombok.Data;

import java.util.Date;

/**
 * 二维码管理
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Data
public class BububaoThirdQrcodeDO {

    /**
     * 二维码id'
     */
    private Long    id;

    /**
     * 数据id
     */
    private Long    dataId;

    /**
     * 数据类型 1 机构 2 个人
     */
    private Integer dataType;

    /**
     * 二维码地址
     */
    private String  qrcodeUrl;

    /**
     * 扫描次数
     */
    private Integer scanNum;

    /**
     * 投保次数
     */
    private Integer insureNum;

    /**
     * 投保用户数
     */
    private Integer holderNum;

    /**
     * 是否删除 N、Y
     */
    private String  isDeleted;

    /**
     * 创建人
     */
    private String  creator;

    /**
     * 创建时间
     */
    private Date    gmtCreated;

    /**
     * 修改人
     */
    private String  modifier;

    /**
     * 更新时间
     */
    private Date    gmtModified;
}
