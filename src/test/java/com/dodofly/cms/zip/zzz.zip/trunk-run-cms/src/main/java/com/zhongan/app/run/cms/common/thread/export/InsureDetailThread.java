package com.zhongan.app.run.cms.common.thread.export;

import java.io.ByteArrayOutputStream;
import java.util.Date;
import java.util.List;

import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import com.zhongan.app.run.cms.common.constants.QrCodeConstants;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.csvutil.CSVUtil;
import com.zhongan.app.run.cms.common.csvutil.conver.DefaultConvert;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.StreamUtil;
import com.zhongan.app.run.cms.dao.qrcode.BububaoExportLogDao;

import lombok.extern.slf4j.Slf4j;

/**
 * 类InsureDetailThread.java的实现描述：异步下载扫码投保明细上传到OSS
 * 
 * @author zhangjin 2018年6月8日 上午10:22:51
 */
@Slf4j
public class InsureDetailThread implements Runnable {

    /**
     * 投保统计数据集合
     */
    private List<ResultInsureDto> allOrgs;

    /**
     * 投保统计数据参数
     */
    private Long                  param;

    private OssTool               ossTool;

    private BububaoExportLogDao   bububaoExportLogDao;

    private String                downLoadFile;

    public InsureDetailThread(BububaoExportLogDao bububaoExportLogDao, List<ResultInsureDto> allOrgs, OssTool ossTool,
                              Long param, String downLoadFile) {
        this.bububaoExportLogDao = bububaoExportLogDao;
        this.allOrgs = allOrgs;
        this.ossTool = ossTool;
        this.param = param;
        this.downLoadFile = downLoadFile;
    }

    @Override
    public void run() {
        BububaoExportLogDO ExportLogDO = new BububaoExportLogDO();
        ByteArrayOutputStream outputStream = null;
        try {
            ExportLogDO.setId(param);
            ExportLogDO.setGmtCreated(new Date());
            outputStream = new ByteArrayOutputStream();
            CSVUtil.writeCSV(outputStream, ',', "utf-8", new DefaultConvert(), QrCodeConstants.getDetailExportTitle(),
                    allOrgs, QrCodeConstants.getDetailExportEnTitle(), ResultInsureDto.class);
            String nowTime = DateTimeUtils.formatCurrentTime(DateTimeUtils.NOMARK_DATETIME_PATTERN);
            String fileName = RunConstants.UPLOAD_FILE_DETAILS + nowTime;
            ossTool.uploadFile(StreamUtil.parse(outputStream), fileName);
            //组织下载url
            String qrCodeUrl = downLoadFile + RunConstants.DOWNLOAD_URL + fileName;
            ExportLogDO.setDownloadUrl(qrCodeUrl);
            ExportLogDO.setStatus(2);
        } catch (Exception e) {
            log.error("Exception:", e);
            ExportLogDO.setIsDeleted("Y");
        } finally {
            try {
                if (outputStream != null) {
                    outputStream.close();
                }
            } catch (Exception e) {
                log.error("Exception:", e);
            }
        }
        //修改导出管理表数据
        bububaoExportLogDao.updateByPrimaryKeySelective(ExportLogDO);
    }

}
