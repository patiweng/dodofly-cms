package com.zhongan.app.run.cms.dao;

import java.util.List;

import com.zhongan.app.run.cms.bean.dataobject.StaticsCollectionDO;
import com.zhongan.app.run.cms.bean.dataobject.UserInsuranceDO;

public interface StaticsCollectionDAO {
	
	List<StaticsCollectionDO> selectFromVisit(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectAllVisit(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectAllActive(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectOldActive(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectNewActive(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectFromActive(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectUserCount(StaticsCollectionDO staticsCollectionDO);
	List<UserInsuranceDO> selectUserInsure(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectBugInsure(StaticsCollectionDO staticsCollectionDO);
	
	List<StaticsCollectionDO> selectUv(StaticsCollectionDO staticsCollectionDO);
	List<StaticsCollectionDO> selectPv(StaticsCollectionDO staticsCollectionDO);
}
