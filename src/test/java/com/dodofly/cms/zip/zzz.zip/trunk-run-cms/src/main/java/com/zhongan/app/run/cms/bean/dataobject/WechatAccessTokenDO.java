package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class WechatAccessTokenDO {
	
	private String id;
	private String flag;
	private String appId;
	private String secret;
	private String accessToken;
	private String expireTime;
	private String jsapiTicket;
	private String jsapiExpireTime;
	private String apiTicket;
	private String apiExpireTime;
	private String createTime;
	private String modifyTime;

}
