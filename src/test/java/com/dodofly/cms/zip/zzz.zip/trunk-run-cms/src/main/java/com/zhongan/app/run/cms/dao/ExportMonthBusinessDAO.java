package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.MonthBusinessDO;

@Component
public interface ExportMonthBusinessDAO {

    List<MonthBusinessDO> selectMonthBusinessList(Map<String, Object> map);

    Integer selectCounts(Map<String, Object> map);

    List<MonthBusinessDO> queryMonthListForExcel(Map<String, String> map);

}
