package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.dao.CmsAuthorityDAO;
import com.zhongan.app.run.cms.dao.CmsMenuDAO;
import com.zhongan.app.run.cms.bean.dataobject.CmsAuthorityDO;
import com.zhongan.app.run.cms.bean.dataobject.CmsMenuDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunSysMenuDTO;


@Component
public class RunUserMenuRepository {
	@Resource
	private CmsMenuDAO cmsMenuDAO;
	@Resource
	private CmsAuthorityDAO cmsAuthorityDAO;
	
	public ResultBase<List<RunSysMenuDTO>> queryMenuByUserId(String userId){
		ResultBase<List<RunSysMenuDTO>>  result = new ResultBase<List<RunSysMenuDTO>> ();
		List<RunSysMenuDTO> menuList = new ArrayList<RunSysMenuDTO>();
		CmsAuthorityDO cmsAuthorityDO = new CmsAuthorityDO();
		cmsAuthorityDO.setUserId(userId);
		List<CmsAuthorityDO> authList = cmsAuthorityDAO.selectDataByCdt(cmsAuthorityDO);
		if(authList != null && authList.size() > 0){
			for(CmsAuthorityDO data:authList){
				CmsMenuDO menuDO = cmsMenuDAO.selectOneDataById(data.getMenuId());
				RunSysMenuDTO menuDTO = new RunSysMenuDTO();
				BeanUtils.copyProperties(menuDO, menuDTO);
				menuList.add(menuDTO);
			}
		}
		result.setSuccess(true);
		result.setValue(menuList);
		return result;
	}
}
