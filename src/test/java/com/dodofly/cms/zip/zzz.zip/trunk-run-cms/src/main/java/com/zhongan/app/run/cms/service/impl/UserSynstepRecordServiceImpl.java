package com.zhongan.app.run.cms.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.BububaoUserSynstepRecordDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserActivityInfoDTO;
import com.zhongan.app.run.cms.bean.web.UserCarveUpLoginRecordDTO;
import com.zhongan.app.run.cms.bean.web.UserCarveUpLoginRecordParamDTO;
import com.zhongan.app.run.cms.bean.web.UserInsuranceDTO;
import com.zhongan.app.run.cms.bean.web.UserStepDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.dao.BububaoUserSynstepRecordMapper;
import com.zhongan.app.run.cms.dao.bean.BububaoUserSynstepRecordCriteria;
import com.zhongan.app.run.cms.dao.bean.BububaoUserSynstepRecordCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.BububaoUserSynstepRecordDO;
import com.zhongan.app.run.cms.service.UserActivityInfoService;
import com.zhongan.app.run.cms.service.UserSynstepRecordService;
import com.zhongan.app.run.cms.service.client.RunPolicyFeignClient;
import com.zhongan.app.run.cms.service.client.RunStepFeignClient;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.PageDTO;
import com.zhongan.health.common.share.enm.YesOrNo;
import com.zhongan.health.common.utils.DateUtils;

/**
 * 瓜分奖励活动用户活动信息
 * 
 * @author yangzhen001
 */
@Service
@Slf4j
public class UserSynstepRecordServiceImpl implements UserSynstepRecordService {

    @Resource
    private BububaoUserSynstepRecordMapper bububaoUserSynstepRecordMapper;
    @Resource
    private RunPolicyFeignClient           runPolicyFeignClient;

    @Resource
    private UserActivityInfoService        userActivityInfoServiceImpl;
    @Resource
    private RunStepFeignClient             runStepFeignClient;
    @Resource
    private ThreadPoolTaskExecutor         executorService;

    /**
     * 插入用户登陆信息
     */
    @Override
    public ResultBase<Integer> insertUserSynstepRecord(BububaoUserSynstepRecordDTO info) {
        ResultBase<Integer> result = new ResultBase<Integer>();
        try {
            ResultBase<Integer> chackParam = this.chackParam(info);
            if (!chackParam.isSuccess()) {
                log.error("{}--insertUserSynstepRecord>>chackParam,入参校验失败,return>>>>>{}",
                        ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(chackParam));
                return result;
            }
            BububaoUserSynstepRecordDO userSynstepRecordDO = new BububaoUserSynstepRecordDO();
            BeanUtils.copyProperties(info, userSynstepRecordDO);
            userSynstepRecordDO.setGmtCreated(new Date());
            userSynstepRecordDO.setGmtModified(new Date());
            bububaoUserSynstepRecordMapper.insertSelective(userSynstepRecordDO);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--insertUserSynstepRecord,param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;

    }

    /**
     * 入参校验
     * 
     * @param info
     * @return
     */
    private ResultBase<Integer> chackParam(BububaoUserSynstepRecordDTO info) {
        log.info("{}--UserSynstepRecordServiceImpl,入参校验,param>>>>>{}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        if (null == info.getUnionid()) {
            return new ResultBase<Integer>(false, AppErrEnum.ERROR_USERACTIVITY_20003.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20003.getValue());
        }
        if (null == info.getUserid()) {
            return new ResultBase<Integer>(false, AppErrEnum.ERROR_USERACTIVITY_20006.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20006.getValue());
        }
        if (StringUtils.isBlank(info.getChannelFrom())) {
            return new ResultBase<Integer>(false, AppErrEnum.ERROR_USERACTIVITY_20004.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20004.getValue());
        }
        return new ResultBase<Integer>(null);
    }

    /**
     * 查询用户登陆记录
     */
    @Override
    public ResultBase<List<BububaoUserSynstepRecordDTO>> selectUserSynstepRecord(BububaoUserSynstepRecordDTO info) {
        ResultBase<List<BububaoUserSynstepRecordDTO>> result = new ResultBase<List<BububaoUserSynstepRecordDTO>>();
        try {
            BububaoUserSynstepRecordDO userSynstepRecordDO = new BububaoUserSynstepRecordDO();
            BeanUtils.copyProperties(info, userSynstepRecordDO);
            List<BububaoUserSynstepRecordDO> selectByExample = bububaoUserSynstepRecordMapper.selectByExample(this
                    .buildUserSynstepRecordCriteria(info));
            List<BububaoUserSynstepRecordDTO> list = null;
            if (CollectionUtils.isNotEmpty(selectByExample)) {
                list = Lists.newArrayList();
                BububaoUserSynstepRecordDTO dto = null;
                for (BububaoUserSynstepRecordDO userSynstepRecord : selectByExample) {
                    dto = new BububaoUserSynstepRecordDTO();
                    BeanUtils.copyProperties(userSynstepRecord, dto);
                    list.add(dto);
                }
            }
            result.setValue(list);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--insertUserSynstepRecord,param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;

    }

    /**
     * 分页查询用户登陆记录
     */
    public ResultBase<List<BububaoUserSynstepRecordDTO>> selectUserSynstepRecordWithPage(BububaoUserSynstepRecordDTO info) {
        ResultBase<List<BububaoUserSynstepRecordDTO>> result = new ResultBase<List<BububaoUserSynstepRecordDTO>>();
        try {
            PageInfo pageInfo = new PageInfo();
            pageInfo.setSize(info.getSize());
            pageInfo.setOffset((info.getCurrentPage() - 1) * info.getSize());
            List<BububaoUserSynstepRecordDO> selectByExample = bububaoUserSynstepRecordMapper.selectByCriteriaWithPage(
                    buildUserSynstepRecordCriteria(info), pageInfo);
            List<BububaoUserSynstepRecordDTO> list = null;
            if (CollectionUtils.isNotEmpty(selectByExample)) {
                list = Lists.newArrayList();
                BububaoUserSynstepRecordDTO dto = null;
                for (BububaoUserSynstepRecordDO userSynstepRecord : selectByExample) {
                    dto = new BububaoUserSynstepRecordDTO();
                    BeanUtils.copyProperties(userSynstepRecord, dto);
                    list.add(dto);
                }
            }
            result.setValue(list);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--selectUserSynstepRecordWithPage,param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;

    }

    /**
     * 查询用户记录总数
     */
    public ResultBase<Long> selectUserSynstepRecordCount(BububaoUserSynstepRecordDTO info) {
        ResultBase<Long> result = new ResultBase<Long>();
        try {
            BububaoUserSynstepRecordDO userSynstepRecordDO = new BububaoUserSynstepRecordDO();
            BeanUtils.copyProperties(info, userSynstepRecordDO);
            long countByExample = bububaoUserSynstepRecordMapper.countByExample(this
                    .buildUserSynstepRecordCriteria(info));
            result.setValue(countByExample);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--selectUserSynstepRecordCount,param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;

    }

    private BububaoUserSynstepRecordCriteria buildUserSynstepRecordCriteria(BububaoUserSynstepRecordDTO dto) {
        BububaoUserSynstepRecordCriteria userSynstepRecordCriteria = new BububaoUserSynstepRecordCriteria();
        userSynstepRecordCriteria.setOrderByClause("id DESC");
        Criteria criteria = userSynstepRecordCriteria.createCriteria();
        if (null != dto.getUnionid()) {
            criteria.andUnionidEqualTo(dto.getUnionid());
        }
        if (null != dto.getUserid()) {
            criteria.andUseridEqualTo(dto.getUserid());
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (null != dto.getDate()) {
            criteria.andDateEqualTo(dto.getDate());
        }
        if (null != dto.getDeleteDate()) {
            criteria.andDateEqualTo(dto.getDeleteDate());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userSynstepRecordCriteria;
    }

    /**
     * cms用户参加瓜分活动用户参赛数据信息
     * 
     * @param info
     * @return
     */
    @Override
    public PageDTO<UserCarveUpLoginRecordDTO> selectUserCarveUpRewardDetilInfo(UserCarveUpLoginRecordParamDTO info) {
        boolean reward = this.chackParamtUserCarveUpReward(info);
        List<UserCarveUpLoginRecordDTO> list = Lists.newArrayList();
        PageDTO<UserCarveUpLoginRecordDTO> page = new PageDTO<UserCarveUpLoginRecordDTO>();
        if (!reward) {
            page.setCurrentPage(info.getCurrentPage() == 0 ? 1 : info.getCurrentPage());
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }
        //根据条件获取用户基础信息
        UserInsuranceDTO userInsuranceDTO = new UserInsuranceDTO();
        userInsuranceDTO.setHolderPhone(info.getPhone());
        userInsuranceDTO.setHolderIdentity(info.getIdentity());
        ResultBase<UserInsuranceDTO> selectPolicyByCdt = runPolicyFeignClient.selectPolicyByCdt(userInsuranceDTO);
        if (!selectPolicyByCdt.isSuccess()) {
            log.error("{}--selectUserCarveUpRewardDetilInfo>>selectPolicyByCdt,获取用户保单信息出错,return>>>>>{}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(selectPolicyByCdt));
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }
        if (null == selectPolicyByCdt.getValue()) {
            log.error("{}--selectUserCarveUpRewardDetilInfo>>selectPolicyByCdt,用户保单信息未空",
                    ThreadLocalUtil.getRequestNo());
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }
        Long unionid = selectPolicyByCdt.getValue().getUnionid();
        String holderPhone = selectPolicyByCdt.getValue().getHolderPhone();
        String holderIdentity = selectPolicyByCdt.getValue().getHolderIdentity();
        String holderName = selectPolicyByCdt.getValue().getHolderName();
        //获取用户活动信息
        UserActivityInfoDTO userActivityParam = new UserActivityInfoDTO();
        userActivityParam.setUnionid(unionid);
        userActivityParam.setNowTime(DateTimeUtils.covertStringToDate(info.getDate()));
        ResultBase<UserActivityInfoDTO> userActivityResultBase = userActivityInfoServiceImpl
                .queryUserActivityInfoByUnionidAndDate(userActivityParam);
        log.info("{}--queryUserActivityInfoByUnionidAndDate,获取用户活动信息,param>>>>>{}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(userActivityParam));
        if (!userActivityResultBase.isSuccess()) {
            log.error("{}--queryUserActivityInfoByUnionidAndDate,获取用户活动信息失败,return>>>>>{}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(userActivityResultBase));
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }
        if (null == userActivityResultBase.getValue()) {
            log.info("{}--queryUserActivityInfoByUnionidAndDate,用户没有活动信息", ThreadLocalUtil.getRequestNo());
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }
        //获取用户当天最大步数
        UserStepDTO dtoIn = new UserStepDTO();
        dtoIn.setQryStartDate(info.getDate());
        dtoIn.setQryEndDate(info.getDate());
        dtoIn.setUnionId(String.valueOf(unionid));
        ResultBase<List<UserStepDTO>> resultStep = runStepFeignClient.selectUserStepsByUnionIdAndDate(dtoIn);
        log.info("获取用户最大步数>>param={},result={}", JSON.toJSONString(dtoIn), JSON.toJSONString(resultStep));
        if (!resultStep.isSuccess()) {
            log.error("获取用户最大步数失败 selectUserStepsByUnionIdAndDate unionid>>>>{}", unionid);
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }
        String maxSteps = "0";
        if (CollectionUtils.isNotEmpty(resultStep.getValue())) {
            maxSteps = resultStep.getValue().get(0).getMaxSteps();
        }
        //获取用户登陆记录总数
        BububaoUserSynstepRecordDTO userSynstepRecordParam = new BububaoUserSynstepRecordDTO();
        userSynstepRecordParam.setUnionid(unionid);
        userSynstepRecordParam.setDate(DateTimeUtils.covertStringToDate(info.getDate()));
        ResultBase<Long> count = this.selectUserSynstepRecordCount(userSynstepRecordParam);
        if (!count.isSuccess()) {
            log.error("{}--selectUserSynstepRecordCount,获取用户登陆记录总数失败,return>>>>>{}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(userSynstepRecordParam));
            page.setResultList(list);
            page.setTotalItem(0);
            return page;

        }
        userSynstepRecordParam.setCurrentPage(info.getCurrentPage() == 0 ? 1 : info.getCurrentPage());
        userSynstepRecordParam.setSize(info.getPageSize());
        //获取用户登陆信息
        ResultBase<List<BububaoUserSynstepRecordDTO>> selectUserSynstepRecord = this
                .selectUserSynstepRecordWithPage(userSynstepRecordParam);
        log.info("{}--selectUserSynstepRecordWithPage,获取用户登陆信息,param>>>>>{}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(userSynstepRecordParam));
        if (!selectUserSynstepRecord.isSuccess()) {
            log.error("{}--selectUserSynstepRecordWithPage,获取用户登陆信息失败,return>>>>>{}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(selectUserSynstepRecord));
            page.setResultList(list);
            page.setTotalItem(0);
            return page;
        }

        if (CollectionUtils.isNotEmpty(selectUserSynstepRecord.getValue())) {
            UserCarveUpLoginRecordDTO dto = null;
            List<BububaoUserSynstepRecordDTO> value = selectUserSynstepRecord.getValue();
            for (BububaoUserSynstepRecordDTO userSynstepRecord : value) {
                dto = new UserCarveUpLoginRecordDTO();
                dto.setUnionid(unionid);
                dto.setIdentity(holderIdentity);
                dto.setIdentityName(holderName);
                dto.setPhone(holderPhone);
                String inputPoint = userActivityResultBase.getValue().getInputPoint();
                String gainPoint = userActivityResultBase.getValue().getGainPoint();
                String isStandard = userActivityResultBase.getValue().getIsStandard();
                dto.setGainPoint(gainPoint);
                dto.setInputPoint(inputPoint);
                dto.setIsStandard(isStandard);
                dto.setChannelFrom(userSynstepRecord.getChannelFrom());
                dto.setGmtCreated(DateTimeUtils.covertTimeToString(userSynstepRecord.getGmtCreated()));
                dto.setSteps(userSynstepRecord.getSteps());
                dto.setDate(DateTimeUtils.covertDateToString(userSynstepRecord.getDate()));
                dto.setMaxSteps(maxSteps);
                list.add(dto);
            }

        }
        page.setCurrentPage(info.getCurrentPage() == 0 ? 1 : info.getCurrentPage());
        page.setTotalItem(count.getValue().intValue());
        page.setResultList(list);
        return page;
    }

    private boolean chackParamtUserCarveUpReward(UserCarveUpLoginRecordParamDTO info) {
        if (StringUtils.isNotBlank(info.getPhone())) {
            return true;
        }
        return false;
    }

    /**
     * 删除用户超过day天的数据
     */
    @Override
    public ResultBase<String> deleteSynStepRecordByDays(List<String> dateList, int days) {
        ResultBase<String> result = new ResultBase<>();
        long total = 0;
        try {
            List<Date> datesBetweenTwoDate = null;
            if (CollectionUtils.isNotEmpty(dateList)) {
                Date start = DateTimeUtils.covertStringToDate(dateList.get(0));
                Date end = DateTimeUtils.covertStringToDate(dateList.get(1));
                datesBetweenTwoDate = DateTimeUtils.getDatesBetweenTwoDate(start, end);
            } else {
                datesBetweenTwoDate = new ArrayList<Date>();
                for (int i = 0; i < days; i++) {
                    Date dateNDays = DateUtils.getDateNDays(new Date(), days * (-1));
                    Date parseDateYYYY_MM_DD = DateUtils.parseDateYYYY_MM_DD(DateUtils.formatDateYYYY_MM_DD(dateNDays));
                    Date date = DateUtils.getDateNDays(parseDateYYYY_MM_DD, -i);
                    datesBetweenTwoDate.add(date);
                }
            }

            for (int a = 0; a < datesBetweenTwoDate.size(); a++) {
                //获取用户登陆记录总数
                BububaoUserSynstepRecordDTO userSynstepRecordParam = new BububaoUserSynstepRecordDTO();
                userSynstepRecordParam.setDeleteDate(datesBetweenTwoDate.get(a));
                ResultBase<Long> count = this.selectUserSynstepRecordCount(userSynstepRecordParam);
                log.info("{}--selectUserSynstepRecordCount,param>>>>>{},result:{}", ThreadLocalUtil.getRequestNo(),
                        JSON.toJSONString(userSynstepRecordParam), JSON.toJSONString(count));
                if (!count.isSuccess()) {
                    log.error("{}--selectUserSynstepRecordCount,param>>>>>{}", ThreadLocalUtil.getRequestNo());
                    result.setSuccess(false);
                    result.setErrorCode(count.getErrorCode());
                    result.setErrorMessage(count.getErrorMessage());
                    return result;
                }
                if (0 == count.getValue()) {
                    continue;
                }
                /*
                 * // 总页数 long longValue = count.getValue().longValue(); total =
                 * total + longValue; long pageCount = (longValue % 1000 == 0) ?
                 * longValue / 1000 : longValue / 1000 + 1;
                 */
                BububaoUserSynstepRecordDO record = new BububaoUserSynstepRecordDO();
                record.setDate(datesBetweenTwoDate.get(a));
                bububaoUserSynstepRecordMapper.deleteBySelective(record);
            }
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--deleteSynStepRecordInfoOverDay,Exception={}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        result.setValue("all=" + total);
        log.info("{}--deleteSynStepRecordInfoOverDay,result:{}", ThreadLocalUtil.getRequestNo(),
                JSON.toJSONString(result));
        return result;
    }

}
