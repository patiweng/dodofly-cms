package com.zhongan.app.run.cms.conver;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.BeanUtils;

import com.zhongan.app.run.cms.bean.web.HistoryBusinessDTO;
import com.zhongan.app.run.cms.dao.bean.HistoryBusinessDO;

public class HistoryBusinessConvert {

    public static List<HistoryBusinessDTO> converToDTOs(List<HistoryBusinessDO> dos) {
        if (CollectionUtils.isEmpty(dos)) {
            return null;
        }
        List<HistoryBusinessDTO> businessDTOs = new ArrayList<HistoryBusinessDTO>();
        for (HistoryBusinessDO businessDO : dos) {
            businessDTOs.add(converToDTO(businessDO));
        }
        return businessDTOs;
    }

    private static HistoryBusinessDTO converToDTO(HistoryBusinessDO businessDO) {
        if (null == businessDO) {
            return null;
        }
        HistoryBusinessDTO businessDTO = new HistoryBusinessDTO();
        BeanUtils.copyProperties(businessDO, businessDTO);
        return businessDTO;
    }
}
