package com.zhongan.app.run.cms.controller;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.RunChannelListBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListPageDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.utils.CustomMultipartFileEditor;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.service.RunChannelListService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/channel")
@Slf4j
public class RunChannelListController {
    @Resource
    private RunChannelListService runChannelListServiceImpl;

    @Resource
    private OssTool               ossTool;

    @InitBinder
    protected void initBinder(DataBinder binder) throws ServletException {
        binder.registerCustomEditor(MultipartFile.class, new CustomMultipartFileEditor());
    }

    /**
     * cms渠道信息查询C001 (支付方式查询)(根据渠道号查询是否已领取)
     * 
     * @return
     */

    @RequestMapping(value = "/select/channellist", method = RequestMethod.POST)
    public ResultBase<RunChannelListDTO> selectChannelList(@RequestBody RunChannelListDTO runChannelListDTO) {
        log.info("{}-/select/channellist,param={" + runChannelListDTO.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<RunChannelListDTO> result = new ResultBase<RunChannelListDTO>();
        RunChannelListBO runChannelListBO = new RunChannelListBO();
        BeanUtils.copyProperties(runChannelListDTO, runChannelListBO);
        result = runChannelListServiceImpl.selectChannelListInfo(runChannelListBO);
        log.info("{}-/select/channellist  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 查询所有的渠道信息 分页。。。
     * 
     * @return
     */
    @RequestMapping(value = "/select/channellistpage")
    public ModelAndView selectChannelListPage(RunChannelListDTO runChannelListDTO, HttpServletRequest request) {
        log.info("{}-into /select/channellistpage, param={ " + runChannelListDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<RunChannelListDTO> runChannelListPage = new Page<RunChannelListDTO>(runChannelListDTO.getPageSize(),
                runChannelListDTO.getCurrentPage());
        runChannelListPage.setParam(runChannelListDTO);
        RunChannelListPageDTO result = runChannelListServiceImpl.selectRunChannelListPage(runChannelListPage);
        runChannelListPage = result.getRunChannelListDTODTOPage();
        Map<String, Object> model = Maps.newHashMap();
        if (null != runChannelListPage) {
            model.put("channellistPage", runChannelListPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("runChannelListDTO", runChannelListDTO);
        model.put("page", runChannelListPage);
        log.info("{}-/select/channellistpage return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/channel_list", model);
    }

    /**
     * 根据主键修改渠道信息(添加一条新的渠道)
     * 
     * @return
     */

    @RequestMapping(value = "/updateorinset", method = RequestMethod.POST)
    public ResultBase<String> updateOrInsertChannelList(RunChannelListDTO runChannelListDTO) {
        log.info("{}-/updateorinset,param={" + runChannelListDTO.toString() + "}", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        Map<String, Object> model = Maps.newHashMap();
        //替换支付方式的连接字符
        String pay = runChannelListDTO.getPay();
        String payend = pay.replaceAll(",", "^");
        runChannelListDTO.setPay(payend);
        if ("".equals(runChannelListDTO.getId())) {
            runChannelListDTO.setId(null);
        }
        model.put("runChannelListDTO", runChannelListDTO);
        //新建
        if (null == runChannelListDTO.getId()) {
            result = runChannelListServiceImpl.insertChannelList(runChannelListDTO);
            //修改  
        } else {
            result = runChannelListServiceImpl.updateChannelList(runChannelListDTO);
        }
        log.info("{}-/updateorinset  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据主键删除渠道
     * 
     * @return
     */

    @RequestMapping(value = "/delete/channellist/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteChannelListOne(@PathVariable String id) {
        log.info("{}-/delete/channellist/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = runChannelListServiceImpl.deleteChannelList(id);
        }
        log.info("{}-/delete/channellist/{id} return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * cms渠道根据ID 查询结果信息
     * 
     * @return
     */

    @RequestMapping(value = "/select/channellistOne/{id}", method = RequestMethod.GET)
    public RunChannelListDTO selectRunChannelListOne(@PathVariable String id) {
        log.info("{}-/select/channellistOne{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        RunChannelListDTO runChannelListDTO = new RunChannelListDTO();
        if (id != null) {
            runChannelListDTO = runChannelListServiceImpl.selectOneChannelList(id);
        }
        log.info("{}-/select/channellistOne/{id} return, data={" + runChannelListDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return runChannelListDTO;
    }

    /**
     * 从oss上获取图片
     * 
     * @return
     */

    @RequestMapping(value = "/getimg/channellist/{imgurl}", method = RequestMethod.GET)
    public void getImg(@PathVariable String imgurl, HttpServletResponse response) {
        log.info("{}-into /bops/getimg/channellist, param={ " + imgurl + " }", ThreadLocalUtil.getRequestNo());
        InputStream ins = null;
        OutputStream outs = null;
        try {
            response.setDateHeader("Expires", 0);
            response.addHeader("Cache-Control", "post-check=0, pre-check=0");
            response.setHeader("Pragma", "no-cache");
            response.setContentType("image/png");
            response.setCharacterEncoding("text/html;charaset=UTF-8");
            ins = ossTool.downloadFile(RunConstants.PROJECT + RunConstants.CHANNELLIST_IMG_PATH + imgurl
                    + RunConstants.MARKETING_IMG_SUFFIX);
            outs = response.getOutputStream();
            int iread = 0;
            byte[] buf = new byte[1024];
            while ((iread = ins.read(buf, 0, 1024)) != -1) {
                outs.write(buf, 0, iread);
            }
            outs.flush();
        } catch (Exception exp) {
            log.error(exp.getMessage(), exp);
        } finally {
            if (ins != null) {
                try {
                    ins.close();
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            }
            if (outs != null) {
                try {
                    outs.close();
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            }
        }
        log.info("{}-/getimg/channellist/ return", ThreadLocalUtil.getRequestNo());
    }

    /**
     * 从oss上获取图片(two)
     * 
     * @return
     */

    @RequestMapping(value = "/getimg/channellisttwo/{imgurl}", method = RequestMethod.GET)
    public void getImgTwo(@PathVariable String imgurl, HttpServletResponse response) {
        log.info("{}-into /bops/getimg/channellisttwo, param={ " + imgurl + " }", ThreadLocalUtil.getRequestNo());
        InputStream ins = null;
        OutputStream outs = null;
        try {
            response.setDateHeader("Expires", 0);
            response.addHeader("Cache-Control", "post-check=0, pre-check=0");
            response.setHeader("Pragma", "no-cache");
            response.setContentType("image/png");
            response.setCharacterEncoding("text/html;charaset=UTF-8");
            ins = ossTool.downloadFile(RunConstants.PROJECT + RunConstants.CHANNELLIST_TWO_IMG_PATH + imgurl
                    + RunConstants.MARKETING_IMG_SUFFIX);
            outs = response.getOutputStream();
            int iread = 0;
            byte[] buf = new byte[1024];
            while ((iread = ins.read(buf, 0, 1024)) != -1) {
                outs.write(buf, 0, iread);
            }
            outs.flush();
        } catch (Exception exp) {
            log.error(exp.getMessage(), exp);
        } finally {
            if (ins != null) {
                try {
                    ins.close();
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            }
            if (outs != null) {
                try {
                    outs.close();
                } catch (Exception ex) {
                    log.error(ex.getMessage(), ex);
                }
            }
        }
        log.info("{}-/getimg/channellisttwo/ return", ThreadLocalUtil.getRequestNo());
    }
}
