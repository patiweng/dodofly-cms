package com.zhongan.app.run.cms.common.thread.export;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultOrgDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import com.zhongan.app.run.cms.common.constants.QrCodeConstants;
import com.zhongan.app.run.cms.common.csvutil.CSVUtil;
import com.zhongan.app.run.cms.common.csvutil.conver.DefaultConvert;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.common.utils.StreamUtil;
import com.zhongan.app.run.cms.common.ziputil.ZIPUtil;
import com.zhongan.app.run.cms.dao.qrcode.BububaoExportLogDao;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

@Slf4j
public class OrgExportThread implements Runnable {

    private BububaoExportLogDao bububaoExportLogDao;

    private BububaoExportLogDO exportLog;

    private List<ResultOrgDto> allOrgs;

    private OssTool ossTool;

    private String downLoadFile;

    public OrgExportThread(BububaoExportLogDao bububaoExportLogDao, List<ResultOrgDto> allOrgs, OssTool ossTool, BububaoExportLogDO exportLog, String downLoadFile){
        this.bububaoExportLogDao = bububaoExportLogDao;
        this.allOrgs = allOrgs;
        this.ossTool = ossTool;
        this.exportLog = exportLog;
        this.downLoadFile = downLoadFile;
    }

    @Override
    public void run() {
        ByteArrayOutputStream outputStream = null;
        ByteArrayOutputStream zipOutputStream = null;
        ZipOutputStream zipOutput = null;
        try {
            outputStream = new ByteArrayOutputStream();
            CSVUtil.writeCSV(outputStream, ',', "utf-8", new DefaultConvert(), QrCodeConstants.getOrgExportTitle(), allOrgs, QrCodeConstants.getOrgExportEnTitle(), ResultOrgDto.class);
            int size = allOrgs.size();
            List<String> urls = Lists.newArrayList();
            List<String> fileNames = Lists.newArrayList();
            for (int i = 0 ; i < size ; i++){
                urls.add(allOrgs.get(i).getQrcodeUrl());
                fileNames.add((i + 1) + QrCodeConstants.getPNGExName());
            }
            zipOutputStream = new ByteArrayOutputStream();
            try {
                zipOutput = new ZipOutputStream(zipOutputStream, Charset.forName("utf-8"));
                ZIPUtil.zipUrls(urls, zipOutput, fileNames, ossTool);
                ZIPUtil.zipInput(StreamUtil.parse(outputStream), zipOutput, QrCodeConstants.getCSVOrgName());
            }catch (Exception e){
                log.error("ZIP Exception:", e);
                throw  e;
            }finally {
                try{
                    if(zipOutput != null){
                        zipOutput.closeEntry();
                        zipOutput.close();
                    }
                }catch (Exception e){
                    log.error("Exception:", e);
                }
            }

            String url = ossTool.uploadFile(StreamUtil.parse(zipOutputStream), QrCodeConstants.getOssOrgZIPName());
            exportLog.setStatus(2);
            exportLog.setDownloadUrl(downLoadFile + QrCodeConstants.getDownLoadFolder() + url);
        }catch (Exception e){
            log.error("Exception:", e);
            exportLog.setIsDeleted("Y");
        }finally {
            try {
                if(zipOutputStream != null){
                    zipOutputStream.close();
                }
                if (outputStream != null){
                    outputStream.close();
                }
            }catch (Exception e){
                log.error("Exception:", e);
            }

        }
        bububaoExportLogDao.updateByPrimaryKeySelective(exportLog);
    }

}
