package com.zhongan.app.run.cms.bean.qrcode.model;

import lombok.Data;

import java.util.Date;

/**
 * 导出管理
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Data
public class BububaoExportLogDO {

    /**
     * 导出id
     */
    private Long    id;

    /**
     * 模块code 1 机构 2 业务员 3 扫码统计 4 扫码明细
     */
    private Integer moduleCode;

    /**
     * 查询条件
     */
    private String  condition;

    /**
     * 下载地址
     */
    private String  downloadUrl;

    /**
     * 状态 1 创建 2 完成
     */
    private Integer status;

    /**
     * 可使用时间
     */
    private Date    useTime;

    /**
     * 是否删除 N、Y
     */
    private String  isDeleted;

    /**
     * 创建人
     */
    private String  creator;

    /**
     * 创建时间
     */
    private Date    gmtCreated;

    /**
     * 修改人
     */
    private String  modifier;

    /**
     * 更新时间
     */
    private Date    gmtModified;
}
