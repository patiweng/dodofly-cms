package com.zhongan.app.run.cms.service;

import javax.servlet.http.HttpServletResponse;

public interface ExportSevenDayAllPassService {

    void doExcelExportSevenDayAllPass(HttpServletResponse response, String sdate, String edate, String sourceCode);

    void doExportExcelTop100AllSteps(HttpServletResponse response, String sdate, String edate, String sourceCode);

}
