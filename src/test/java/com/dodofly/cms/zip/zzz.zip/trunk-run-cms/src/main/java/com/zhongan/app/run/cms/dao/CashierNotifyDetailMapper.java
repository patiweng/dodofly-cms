package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.CashierNotifyDetailCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierNotifyDetailDO;

public interface CashierNotifyDetailMapper {
    /** @mbggenerated
     */
    int countByCriteria(CashierNotifyDetailCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(CashierNotifyDetailCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from bububao_cashier_notify_detail", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into bububao_cashier_notify_detail (id, cashier_id, ", "order_no, third_order_no, ",
            "pay_channel_user_no, amt, ", "order_time, notify_info, ", "extra_info, creator, ",
            "gmt_created, modifier, gmt_modified, ", "is_deleted)",
            "values (#{id,jdbcType=BIGINT}, #{cashierId,jdbcType=BIGINT}, ",
            "#{orderNo,jdbcType=VARCHAR}, #{thirdOrderNo,jdbcType=VARCHAR}, ",
            "#{payChannelUserNo,jdbcType=VARCHAR}, #{amt,jdbcType=DECIMAL}, ",
            "#{orderTime,jdbcType=TIMESTAMP}, #{notifyInfo,jdbcType=VARCHAR}, ",
            "#{extraInfo,jdbcType=VARCHAR}, ifnull(#{creator,jdbcType=VARCHAR}, 'system'), ",
            "now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), now(), ", "#{isDeleted,jdbcType=CHAR})" })
    int insert(CashierNotifyDetailDO record);

    /** @mbggenerated
     */
    int insertSelective(CashierNotifyDetailDO record);

    /** @mbggenerated
     */
    List<CashierNotifyDetailDO> selectByCriteriaWithPage(@Param("criteria") CashierNotifyDetailCriteria criteria,
                                                         @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<CashierNotifyDetailDO> selectByCriteria(CashierNotifyDetailCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select", "id, cashier_id, order_no, third_order_no, pay_channel_user_no, amt, order_time, ",
            "notify_info, extra_info, creator, gmt_created, modifier, gmt_modified, is_deleted",
            "from bububao_cashier_notify_detail", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    CashierNotifyDetailDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") CashierNotifyDetailDO record,
                                  @Param("criteria") CashierNotifyDetailCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") CashierNotifyDetailDO record,
                         @Param("criteria") CashierNotifyDetailCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(CashierNotifyDetailDO record);

    /** @mbggenerated
     */
    @Update({ "update bububao_cashier_notify_detail", "set cashier_id = #{cashierId,jdbcType=BIGINT},",
            "order_no = #{orderNo,jdbcType=VARCHAR},", "third_order_no = #{thirdOrderNo,jdbcType=VARCHAR},",
            "pay_channel_user_no = #{payChannelUserNo,jdbcType=VARCHAR},", "amt = #{amt,jdbcType=DECIMAL},",
            "order_time = #{orderTime,jdbcType=TIMESTAMP},", "notify_info = #{notifyInfo,jdbcType=VARCHAR},",
            "extra_info = #{extraInfo,jdbcType=VARCHAR},", "creator = #{creator,jdbcType=VARCHAR},",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(CashierNotifyDetailDO record);
}
