package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.bo.RunUserCouponsBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserCouponsDTO;
import com.zhongan.app.run.cms.service.RunUserCouponsService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/coupons")
@Slf4j
public class RunUserCouponsController {
    @Resource
    private RunUserCouponsService runUserCouponsServiceImpl;

    /**
     * cms用户优惠券信息查询C001 (优惠券查询)分页
     * 
     * @return
     */
    @RequestMapping(value = "/select/usercoupons", method = RequestMethod.POST)
    public ResultBase<Page<RunUserCouponsDTO>> selectRunUserCoupons(@RequestBody Page<RunUserCouponsDTO> runUserCouponsDTOpage) {
        log.info("{}-/select/usercoupons,param={" + runUserCouponsDTOpage.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<Page<RunUserCouponsDTO>> result = new ResultBase<Page<RunUserCouponsDTO>>();
        Page<RunUserCouponsDTO> runUserCouponsDTOpagedata = new Page<RunUserCouponsDTO>(
                runUserCouponsDTOpage.getPageSize(), runUserCouponsDTOpage.getCurrentPage());
        runUserCouponsDTOpagedata.setParam(runUserCouponsDTOpage.getParam());
        ResultBase<Page<RunUserCouponsDTO>> temp = runUserCouponsServiceImpl
                .selectRunUserCouponsInfo(runUserCouponsDTOpagedata);
        BeanUtils.copyProperties(temp, result);
        log.info("{}-/select/usercoupons  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    @RequestMapping(value = "/updateusercoupons", method = RequestMethod.POST)
    public ResultBase<Integer> update(@RequestBody RunUserCouponsDTO userCouponsDTO) {
        log.info("{}-into /updateUserCoupons, param={ " + userCouponsDTO + " }", ThreadLocalUtil.getRequestNo());
        RunUserCouponsBO userCouponsBO = new RunUserCouponsBO();
        BeanUtils.copyProperties(userCouponsDTO, userCouponsBO);
        ResultBase<Integer> result = runUserCouponsServiceImpl.update(userCouponsBO);
        log.info("{}-/updateUserCoupons return, data={" + result + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    @RequestMapping(value = "/insertusercoupons", method = RequestMethod.POST)
    public ResultBase<String> insert(@RequestBody RunUserCouponsDTO userCouponsDTO) {
        log.info("{}-into /insertUserCoupons, param={ " + userCouponsDTO + " }", ThreadLocalUtil.getRequestNo());
        RunUserCouponsBO userCouponsBO = new RunUserCouponsBO();
        BeanUtils.copyProperties(userCouponsDTO, userCouponsBO);
        ResultBase<String> result = runUserCouponsServiceImpl.insert(userCouponsBO);
        log.info("{}-/insertUserCoupons return, data={" + result + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据unionid查询是否领取积分
     * 
     * @param unionid
     * @return
     */
    @RequestMapping(value = "/find/isUserCoupons", method = RequestMethod.POST)
    public ResultBase<Boolean> isUserCoupons(@RequestBody RunUserCouponsDTO userCouponsDTO) {
        log.info("{}-into /isUserCoupons, param={ " + userCouponsDTO + " }", ThreadLocalUtil.getRequestNo());
        RunUserCouponsBO userCouponsBO = new RunUserCouponsBO();
        BeanUtils.copyProperties(userCouponsDTO, userCouponsBO);
        ResultBase<Boolean> result = runUserCouponsServiceImpl.isUserCoupons(userCouponsBO);
        log.info("{}-/isUserCoupons return, data={" + result + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 步步保续保券发放 开放给直营
     * 
     * @param userCouponsDTO
     * @return
     */
    @RequestMapping(value = "/sendRenewalInsuranceCoupons", method = RequestMethod.POST)
    public ResultBase<String> insertCouponsOpenForZhiying(@RequestBody RunUserCouponsDTO userCouponsDTO) {
        log.info("{}-into /sendRenewalInsuranceCoupons, param={ " + userCouponsDTO + " }",
                ThreadLocalUtil.getRequestNo());
        RunUserCouponsBO userCouponsBO = new RunUserCouponsBO();
        BeanUtils.copyProperties(userCouponsDTO, userCouponsBO);
        ResultBase<String> result = runUserCouponsServiceImpl.sendRenewalInsuranceCoupons(userCouponsBO);
        log.info("{}-/sendRenewalInsuranceCoupons return, data={" + result + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }
}
