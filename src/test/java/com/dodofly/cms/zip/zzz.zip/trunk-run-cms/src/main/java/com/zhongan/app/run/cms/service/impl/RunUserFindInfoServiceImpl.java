package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.zhongan.app.run.cms.bean.repo.RunUserFindInfoRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserFindInfoDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.RunUserFindInfoRepository;
import com.zhongan.app.run.cms.service.RunUserFindInfoService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RunUserFindInfoServiceImpl implements RunUserFindInfoService {

    @Resource
    private RunUserFindInfoRepository runUserFindInfoRepository;

    @Override
    public ResultBase<List<RunUserFindInfoDTO>> findInfoSource(RunUserFindInfoDTO runUserFindInfoDTO) {
        ResultBase<List<RunUserFindInfoDTO>> result = new ResultBase<List<RunUserFindInfoDTO>>();
        log.info("{}-userSourceInfo select begin...", ThreadLocalUtil.getRequestNo());
        try {
            RunUserFindInfoRepo runUserFindInfoRepo = new RunUserFindInfoRepo();
            BeanUtils.copyProperties(runUserFindInfoDTO, runUserFindInfoRepo);
            result = runUserFindInfoRepository.selectUserSourceInfo(runUserFindInfoRepo);
            if (result.getValue().size() > 0) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-userSourceInfo select fail,please find error to..."
                    + "error location polynomial : RunUserFindInfoServiceImpl--findInfoSource()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...", ThreadLocalUtil.getRequestNo());
        }
        return result;
    }

    @Override
    public ResultBase<List<RunUserFindInfoDTO>> findSourceInfoByCdt(RunUserFindInfoDTO runUserFindInfoDTO) {
        ResultBase<List<RunUserFindInfoDTO>> result = null;
        try {
            result = this.chackParam(runUserFindInfoDTO);
            if (!result.isSuccess()) {
                log.warn("{}-findSourceInfoByCdt>>chackParam", ThreadLocalUtil.getRequestNo(),
                        JSON.toJSONString(result));
                return result;
            }
            result = this.findInfoSource(runUserFindInfoDTO);
        } catch (Exception e) {
            log.error("{}-findSourceInfoByCdt-{}", ThreadLocalUtil.getRequestNo(), e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    private ResultBase<List<RunUserFindInfoDTO>> chackParam(RunUserFindInfoDTO runUserFindInfoDTO) {
        if (StringUtils.isBlank(runUserFindInfoDTO.getId())) {
            return new ResultBase<List<RunUserFindInfoDTO>>(AppErrEnum.ERROR_USERACTIVITY_20006.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20006.getValue());
        }
        return new ResultBase<List<RunUserFindInfoDTO>>(null);
    }
}
