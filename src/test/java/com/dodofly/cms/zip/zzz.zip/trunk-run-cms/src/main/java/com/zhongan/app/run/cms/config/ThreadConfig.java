package com.zhongan.app.run.cms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * 类ThreadConfig的实现描述：<br/>
 * 线程池工具类
 */
@Configuration
public class ThreadConfig {

    @Bean(name = "executorService")
    public ThreadPoolTaskExecutor getExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(8);
        return executor;
    }

}
