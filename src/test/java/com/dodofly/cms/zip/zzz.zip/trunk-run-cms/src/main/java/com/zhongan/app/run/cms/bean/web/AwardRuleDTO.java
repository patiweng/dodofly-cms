package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

import lombok.Data;

/**
 * 类AwardRuleDTO.java的实现描述：活动奖品规则表
 * 
 * @author panchuanhe 2017年3月10日 上午11:15:24
 */
@Data
public class AwardRuleDTO implements Cloneable {

    private Long    id;

    private Long    activityPresentId;

    private Date    earliestTime;

    private Date    lastestTime;

    private String  earliestTime_;

    private String  lastestTime_;

    private Integer minRenewalTimes;

    private Integer maxRenewalTimes;

    private Double  minPayMoney;

    private Double  maxPayMoney;

    private Integer minAliveDays;

    private Integer maxAliveDays;

    private String  probability;

    private Integer requireid;

    private String  creator;

    private String  modifier;

    private Date    createtime;

    private Date    modifytime;

    private String  isDeleted;

    private String  presentName;
    private String  presentId;
    private String  activityId;

    private Integer pageSize;
    private Integer currentPage;

    private String  healthScore;

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
