package com.zhongan.app.run.cms.service;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface StaticsService {
	public ResultBase<String> staticsUvPv(String from,String sdate,String edate);
	
	public ResultBase<String> staticsAll(HttpServletResponse response,String sDate,String eDate);
	
	public ResultBase<String> staticsXuBao(HttpServletResponse response,String sDate,String eDate);
}
