package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.bo.UserPropertyBO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserPropertyDTO;
import com.zhongan.app.run.cms.service.UserPropertyService;

@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class UserPropertyController {

    @Resource
    private UserPropertyService userPropertyServiceImpl;

    @RequestMapping(value = "/selectuserpropertybyunionid/{unionid}", method = RequestMethod.GET)
    public ResultBase<UserPropertyDTO> selectUserPropertyByUnionid(@PathVariable Long unionid) {
        log.info("{}-into /selectUserPropertyByUnionid, param={unionid= " + unionid + " }");
        ResultBase<UserPropertyDTO> result = new ResultBase<UserPropertyDTO>();
        ResultBase<UserPropertyBO> temp = userPropertyServiceImpl.selectUserPropertyByUnionid(unionid);
        BeanUtils.copyProperties(temp, result);
        log.info("{}-/selectUserPropertyByUnionid return, data={" + result + "}");
        return result;
    }

}
