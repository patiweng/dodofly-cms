package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCmsUserDTO;
import com.zhongan.app.run.cms.bean.web.UserLoginDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.service.RunUserLoginService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/sys")
@Slf4j
public class RunUserLoginController {

    @Resource
    private RunUserLoginService    runUserLoginServiceImpl;
    @Autowired
    private HttpServletRequest request;

    /**
     * cms初始化页面
     * 
     * @return
     */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public ModelAndView sysInit(UserLoginDTO userLoginDTO) {
        Map<String, Object> model = Maps.newHashMap();
        model.put("userLoginDTO", userLoginDTO);
        return new ModelAndView("cms/login", model);
    }
    /**
     * cm欢迎页面
     * 
     * @return
     */
    @RequestMapping(value = "/hello", method = RequestMethod.GET)
    public ModelAndView hello() {
        Map<String, Object> model = Maps.newHashMap();
        return new ModelAndView("cms/hello", model);
    }
    
    /**
     * CMS登录
     * 
     * @return
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView sysLogin(UserLoginDTO userLoginDTO, HttpServletResponse response) {
        Map<String, Object> model = Maps.newHashMap();
        UserLoginDTO logResultDTO = new UserLoginDTO();
        log.info("{}-login start user {}", userLoginDTO.getUserName(),ThreadLocalUtil.getRequestNo());
        ResultBase<RunCmsUserDTO> logRs = runUserLoginServiceImpl.login(userLoginDTO.getUserName(), userLoginDTO.getUserPassword());
        if (logRs.isSuccess()) {
            log.info("login success");
            /** SID写入COOKIE **/
            String sid = logRs.getValue().getLoginToken();
            Cookie secookie = new Cookie(RunConstants.LoginModelConst.LOGIN_ZASID, sid);
//            secookie.setSecure(true);
//            secookie.setHttpOnly(true); //HttpOnly flag
            secookie.setPath("/");
            secookie.setMaxAge(24 * 60 * 60);
            //secookie.setDomain(".zhonganonline.com");
            response.addCookie(secookie);
            return new ModelAndView("redirect:/run/cms/channel/select/channellistpage?bopsFlag=1", model);
        } else {
            log.info("{}-login fail",ThreadLocalUtil.getRequestNo());
            logResultDTO.setErrCode(logRs.getErrorCode());
            logResultDTO.setErrMsg(logRs.getErrorMessage());
            model.put("userLoginDTO", logResultDTO);
            return new ModelAndView("cms/login", model);
        }

    }
    @RequestMapping(value = "/editpasswd/{userName}/{oPwd}/{nPwd}", method = RequestMethod.GET)
    public ResultBase<String> editPasswd(@PathVariable String userName,@PathVariable String oPwd,@PathVariable String nPwd){
    	ResultBase<String> result = runUserLoginServiceImpl.editPwd(userName, oPwd, nPwd);
    	return result;
    }
}
