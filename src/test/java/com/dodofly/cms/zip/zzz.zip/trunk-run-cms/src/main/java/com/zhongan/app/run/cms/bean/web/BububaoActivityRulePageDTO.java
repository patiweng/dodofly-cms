package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;
import java.util.List;

import lombok.Data;

import com.zhongan.health.common.share.bean.PageDTO;

/**
 * @author yangzhen001
 */
@Data
public class BububaoActivityRulePageDTO implements Serializable {

    private static final long               serialVersionUID = 1L;
    private PageDTO<BububaoActivityRuleDTO> page;
    private List<RunChannelListDTO>         channelList;

}
