package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityPresentDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoPresentDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.BububaoPresentRepo;
import com.zhongan.app.run.cms.bean.repo.RafflePresentRepo;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.OssTool;
import com.zhongan.app.run.cms.dao.BububaoActivityPresentDAO;
import com.zhongan.app.run.cms.dao.BububaoPresentDAO;
import com.zhongan.app.run.cms.service.ActivityPresentService;
import com.zhongan.app.run.common.utils.RedisUtil;

@Slf4j
@Component
public class RafflePresentRepository {

    @Resource
    private BububaoPresentDAO         bububaoPresentDAO;
    @Resource
    private BububaoActivityPresentDAO activityPresentDAO;
    @Resource
    private ActivityPresentService    activityPresentServiceImpl;
    @Resource
    private RedisUtil                 redisUtil;

    @Resource
    private Sequence                  seqPresent;
    @Resource
    private OssTool                   ossTool;
    @Value("${za.run.img.domain.url}")
    private String                    imgDomain;

    public BububaoPresentRepo selectOneDataById(String id) {
        BububaoPresentRepo presentRepo = null;
        BububaoPresentDO presentDO = bububaoPresentDAO.selectOneDataById(id);
        if (null != presentDO) {
            presentRepo = new BububaoPresentRepo();
            BeanUtils.copyProperties(presentDO, presentRepo);
        }
        return presentRepo;
    }

    public RafflePresentDTO selectPresentByid(String id) {
        RafflePresentDTO rafflePresentDTO = new RafflePresentDTO();
        log.info("select presentbuid ...Repository");
        BububaoPresentDO bububaoPresentDO = bububaoPresentDAO.selectOneDataById(id);
        if (bububaoPresentDO != null) {
            BeanUtils.copyProperties(bububaoPresentDO, rafflePresentDTO);
        }
        return rafflePresentDTO;
    }

    //分页

    public Page<RafflePresentRepo> selectPresentListPage(Page<RafflePresentRepo> rafflePresentRepoPage) {

        BububaoPresentDO bububaoPresentDO = new BububaoPresentDO();
        if (null != rafflePresentRepoPage.getParam()) {
            BeanUtils.copyProperties(rafflePresentRepoPage.getParam(), bububaoPresentDO);
        }
        bububaoPresentDO.setIsDeleted(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", rafflePresentRepoPage.getStartRow());
        map.put("pageSize", rafflePresentRepoPage.getPageSize());
        map.put("bububaoPresentDO", bububaoPresentDO);
        List<BububaoPresentDO> bububaoPresentDOList = bububaoPresentDAO.selectBububaoPresentList(map);
        List<RafflePresentRepo> rafflePresentRepoList = Lists.newArrayList();
        if (null != bububaoPresentDOList && 0 != bububaoPresentDOList.size()) {
            RafflePresentRepo RafflePresentRepo = null;
            for (BububaoPresentDO bububaoPresentDOlists : bububaoPresentDOList) {
                RafflePresentRepo = new RafflePresentRepo();
                BeanUtils.copyProperties(bububaoPresentDOlists, RafflePresentRepo);
                rafflePresentRepoList.add(RafflePresentRepo);
            }
        }
        rafflePresentRepoPage.setResultList(rafflePresentRepoList);
        Integer counts = bububaoPresentDAO.selectCounts(map);
        rafflePresentRepoPage.setTotalItem(counts);
        return rafflePresentRepoPage;
    }

    public ResultBase<List<RafflePresentDTO>> selectPresentList(RafflePresentRepo rafflePresentRepo) {
        log.info("{}-select  RafflePresent。。。Repository。。。");
        ResultBase<List<RafflePresentDTO>> result = new ResultBase<List<RafflePresentDTO>>();
        List<RafflePresentDTO> listresult = new ArrayList<RafflePresentDTO>();
        BububaoPresentDO bububaoPresentDO = new BububaoPresentDO();
        BeanUtils.copyProperties(rafflePresentRepo, bububaoPresentDO);
        List<BububaoPresentDO> resultlist = bububaoPresentDAO.selectDataByCdt(bububaoPresentDO);
        if (resultlist.size() > 0) {
            for (BububaoPresentDO bububaoPresent : resultlist) {
                RafflePresentDTO rafflePresentDTO = new RafflePresentDTO();
                BeanUtils.copyProperties(bububaoPresent, rafflePresentDTO);
                listresult.add(rafflePresentDTO);
            }
        }
        result.setSuccess(true);
        result.setValue(listresult);
        return result;
    }

    //插入一条信息
    public ResultBase<String> savePresent(RafflePresentRepo rafflePresentRepo) throws Exception {
        log.info("{}-insert BububaoPresentDO。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        BububaoPresentDO bububaoPresentDO = new BububaoPresentDO();
        BeanUtils.copyProperties(rafflePresentRepo, bububaoPresentDO);
        Long id = seqPresent.nextValue();
        /** 文件上传 **/
        rafflePresentRepo.setId(String.valueOf(id));
        ResultBase<String> flagRs = ossTool.handleImgPresent(rafflePresentRepo.getId(), RunConstants.PICTRUE,
                rafflePresentRepo.getPresentImgFile());
        ResultBase<String> flagRsBig = ossTool.handleImgPresent(rafflePresentRepo.getId(), RunConstants.PICTRUEBIG,
                rafflePresentRepo.getPresentImgFileTwo());
        if (!flagRs.isSuccess() || !flagRsBig.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
            return result;
        }
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        bububaoPresentDO.setIdentify(fileUrl);
        bububaoPresentDO.setId(id.toString());
        bububaoPresentDO.setCreator(RunConstants.SYSTEM_NAME);
        bububaoPresentDAO.insert(bububaoPresentDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    //删除信息
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        bububaoPresentDAO.updateByid(id);
        activityPresentDAO.updateByPresentid(id);
        BububaoActivityPresentDO bububaoActivityPresentDOTwo = new BububaoActivityPresentDO();
        bububaoActivityPresentDOTwo.setPresentId(id);
        List<BububaoActivityPresentDO> list = activityPresentDAO.selectDataByCdtNew(bububaoActivityPresentDOTwo);
        if (list.size() > 0) {
            for (BububaoActivityPresentDO bububaoActivityPresentDOs : list) {
                activityPresentServiceImpl.updateActivityPresentLists(bububaoActivityPresentDOs.getActivityId());
            }
        }
        result.setSuccess(true);
        return result;
    }

    //修改一条信息
    public ResultBase<String> updatePresent(RafflePresentRepo rafflePresentRepo) throws Exception {
        log.info("{}-update BububaoPresentDO。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        BububaoPresentDO bububaoPresentDO = new BububaoPresentDO();
        BeanUtils.copyProperties(rafflePresentRepo, bububaoPresentDO);
        /** 文件上传 **/

        ResultBase<String> flagRs = ossTool.handleImgPresent(rafflePresentRepo.getId(), RunConstants.PICTRUE,
                rafflePresentRepo.getPresentImgFile());

        ResultBase<String> flagRsBig = ossTool.handleImgPresent(rafflePresentRepo.getId(), RunConstants.PICTRUEBIG,
                rafflePresentRepo.getPresentImgFileTwo());
        if (!flagRsBig.isSuccess() || !flagRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERAURHORITY_200001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERAURHORITY_200001.getValue());
            return result;
        }

        //截取最后两个字符入库
        String fileUrl = imgDomain + RunConstants.CMS_UPLOAD_GETURL + flagRs.getValue();
        if (rafflePresentRepo.getPresentImgFile() == null && rafflePresentRepo.getPresentImgFileTwo() == null) {
            String fileUrlend = fileUrl.substring(0, fileUrl.length() - 2);
            bububaoPresentDO.setIdentify(fileUrlend);
        } else {
            bububaoPresentDO.setIdentify(fileUrl);
        }
        bububaoPresentDAO.update(bububaoPresentDO);
        result.setSuccess(true);
        return result;
    }

    public List<BububaoPresentRepo> selectPresentNameList(String activityId) {
        List<BububaoPresentRepo> repoList = Lists.newArrayList();
        List<BububaoPresentDO> doList = bububaoPresentDAO.selectPresentNameList(activityId);
        if (null != doList && doList.size() > 0) {
            BububaoPresentRepo bububaoPresentRepo = null;
            for (BububaoPresentDO bububaoPresentDO : doList) {
                bububaoPresentRepo = new BububaoPresentRepo();
                BeanUtils.copyProperties(bububaoPresentDO, bububaoPresentRepo);
                repoList.add(bububaoPresentRepo);
            }
        }
        return repoList;
    }
}
