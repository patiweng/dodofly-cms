package com.zhongan.app.run.cms.common.utils;

import net.sourceforge.pinyin4j.PinyinHelper;
import org.apache.commons.lang.StringUtils;

/**
 * 字符串拼音处理
 * @author lichao002
 * @date 2018-06-07
 */
public class PinyinUtil {

    /**
     * 获取字符串首字母
     * @param str
     * @return
     */
    public static String getInitials(String str){
        StringBuffer buffer = new StringBuffer();
        if(StringUtils.isNotBlank(str)){
            for(int i = 0; i < str.length() ; i++){
                char word = str.charAt(i);
                String[] pinyinArray = PinyinHelper.toGwoyeuRomatzyhStringArray(word);
                if(pinyinArray != null && pinyinArray.length > 0){
                    buffer.append(pinyinArray[0].charAt(0));
                }else{
                    buffer.append(word);
                }
            }
        }
        return buffer.toString().toUpperCase();
    }

    public static void main(String[] args){
        System.out.println(getInitials("我抽到"));
    }
}
