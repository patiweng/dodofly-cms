package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class UserStepDO {
    
    /**序号**/
    private String id;
    /**对应渠道的sourceid**/
    private String userId;
    /**真正的用户ID**/
    private String unionId;
    /**步数**/
    private String steps;
    /**最大步数**/
    private String maxSteps;
    /**步数所属的日期**/
    private String date;
    /**是否免费**/
    private String free;
    /**数据创建时间**/
    private String createTime;
    /**数据更新时间**/
    private String modifyTime;
    /**脚本状态**/
    private String status;
    /**平均步数**/
    private String avgSteps;
    /**数据更新时间**/
    private String updateTime;
    private String qryStartDate;
    private String qryEndDate;
    private String sourceUnionId;
}
