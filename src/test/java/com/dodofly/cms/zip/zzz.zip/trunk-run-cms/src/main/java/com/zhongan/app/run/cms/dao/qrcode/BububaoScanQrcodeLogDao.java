package com.zhongan.app.run.cms.dao.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.StatisticsParamDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoScanQrcodeLogDO;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * 扫码日志 Dao层
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Component
public interface BububaoScanQrcodeLogDao {

    /**
     * 根据id删除扫码日志
     * 
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Long id);

    /**
     * 保存扫码日志
     * 
     * @param record
     * @return
     */
    int insert(BububaoScanQrcodeLogDO record);

    /**
     * 保存扫码日志
     * 
     * @param record
     * @return
     */
    int insertSelective(BububaoScanQrcodeLogDO record);

    /**
     * 根据id查询扫码日志
     * 
     * @param id
     * @return
     */
    BububaoScanQrcodeLogDO selectByPrimaryKey(Long id);

    /**
     * 更新扫码日志
     * 
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(BububaoScanQrcodeLogDO record);

    /**
     * 根据id更新扫码日志
     * 
     * @param record
     * @return
     */
    int updateByPrimaryKey(BububaoScanQrcodeLogDO record);

    /**
     * 根据条件查询数量
     * 
     * @param record
     * @return
     */
    int selectCountsByCdt(BububaoScanQrcodeLogDO record);

    /**
     * 根据条件查询去重投保用数数
     * 
     * @param record
     * @return
     */
    int selectDistinctCounts(BububaoScanQrcodeLogDO record);

    /**
     * @param record
     * @return
     */
    List<BububaoScanQrcodeLogDO> selectDataByCdt(BububaoScanQrcodeLogDO record);
    
    /**
     * 投保统计分页
     * @param paramDto
     * @return
     */
    List<ResultInsureDto> selectStatisticsPage(StatisticsParamDto paramDto);
    
    /**
     * 投保统计总条数
     * @param paramDto
     * @return
     */
    Integer selectStatisticsCounts(StatisticsParamDto paramDto);
    
    /**
     * 投保统计明细分页
     * @param paramDto
     * @return
     */
    List<ResultInsureDto> selectStatisticsDetailPage(StatisticsParamDto paramDto);
    
    /**
     * 投保统计明细总条数
     * @param paramDto
     * @return
     */
    Integer selectStatisticsDetailCount(StatisticsParamDto paramDto);

    /**
     * 逻辑删除扫码记录
     * @param scanDataId
     * @param scanDataType
     * @param modifier
     * @return
     */
    Integer deleteScanLogByDataIdAndType(@Param("scanDataId") Long scanDataId, @Param("scanDataType") Integer scanDataType, @Param("modifier") String modifier);
}
