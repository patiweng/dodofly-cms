package com.zhongan.app.run.cms.dao;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.UserActivityInfoDTO;
import com.zhongan.app.run.cms.dao.bean.UserActivityInfoCriteria;
import com.zhongan.app.run.cms.dao.bean.UserActivityInfoDO;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

public interface UserActivityInfoMapper {
    /**
     * @mbggenerated
     */
    int countByCriteria(UserActivityInfoCriteria criteria);

    /**
     * @mbggenerated
     */
    int deleteByCriteria(UserActivityInfoCriteria criteria);

    /**
     * @mbggenerated
     */
    @Delete({ "delete from bububao_user_activity_info", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /**
     * @mbggenerated
     */
    @Insert({ "insert into bububao_user_activity_info (id, unionid, ", "channel_from, activity_id, ",
            "children_id, input_point, ", "gain_point, activity_begin_time, ", "activity_end_time, is_discount, ",
            "is_lazy, is_standard, steps, ", "creator, modifier, ",
            "gmt_created, gmt_modified, is_deleted, extra_info)",
            "values (#{id,jdbcType=BIGINT}, #{unionid,jdbcType=BIGINT}, ",
            "#{channelFrom,jdbcType=VARCHAR}, #{activityId,jdbcType=VARCHAR}, ",
            "#{childrenId,jdbcType=VARCHAR}, #{inputPoint,jdbcType=VARCHAR}, ",
            "#{gainPoint,jdbcType=VARCHAR}, #{activityBeginTime,jdbcType=TIMESTAMP}, ",
            "#{activityEndTime,jdbcType=TIMESTAMP}, #{isDiscount,jdbcType=CHAR}, ",
            "#{isLazy,jdbcType=CHAR}, #{isStandard,jdbcType=CHAR}, #{steps,jdbcType=VARCHAR}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), now(), #{isDeleted,jdbcType=CHAR}, #{extraInfo,jdbcType=VARCHAR})" })
    int insert(UserActivityInfoDO record);

    /**
     * @mbggenerated
     */
    int insertSelective(UserActivityInfoDO record);

    /**
     * @mbggenerated
     */
    List<UserActivityInfoDO> selectByCriteriaWithPage(@Param("criteria") UserActivityInfoCriteria criteria,
                                                      @Param("pageInfo") PageInfo pageInfo);

    /**
     * @mbggenerated
     */
    List<UserActivityInfoDO> selectByCriteria(UserActivityInfoCriteria criteria);

    /**
     * @mbggenerated
     */
    @Select({ "select", "id, unionid, channel_from, activity_id, children_id, input_point, gain_point, ",
            "activity_begin_time, activity_end_time, is_discount, is_lazy, is_standard, steps, ",
            "creator, modifier, gmt_created, gmt_modified, is_deleted, extra_info", "from bububao_user_activity_info",
            "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    UserActivityInfoDO selectByPrimaryKey(@Param("id") Long id);

    /**
     * @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") UserActivityInfoDO record,
                                  @Param("criteria") UserActivityInfoCriteria criteria);

    /**
     * @mbggenerated
     */
    int updateByCriteria(@Param("record") UserActivityInfoDO record,
                         @Param("criteria") UserActivityInfoCriteria criteria);

    /**
     * @mbggenerated
     */
    int updateByPrimaryKeySelective(UserActivityInfoDO record);

    /**
     * @mbggenerated
     */
    @Update({ "update bububao_user_activity_info", "set unionid = #{unionid,jdbcType=BIGINT},",
            "channel_from = #{channelFrom,jdbcType=VARCHAR},", "activity_id = #{activityId,jdbcType=VARCHAR},",
            "children_id = #{childrenId,jdbcType=VARCHAR},", "input_point = #{inputPoint,jdbcType=VARCHAR},",
            "gain_point = #{gainPoint,jdbcType=VARCHAR},",
            "activity_begin_time = #{activityBeginTime,jdbcType=TIMESTAMP},",
            "activity_end_time = #{activityEndTime,jdbcType=TIMESTAMP},", "is_discount = #{isDiscount,jdbcType=CHAR},",
            "is_lazy = #{isLazy,jdbcType=CHAR},", "is_standard = #{isStandard,jdbcType=CHAR},",
            "steps = #{steps,jdbcType=VARCHAR},", "creator = #{creator,jdbcType=VARCHAR},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR},", "extra_info = #{extraInfo,jdbcType=VARCHAR}",
            "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(UserActivityInfoDO record);

    Integer selectUserActivityCountByCdtDistinct(UserActivityInfoDTO info);

    List<String> selectUnionidByCdtDistinctPage(@Param("record") UserActivityInfoDTO record,
                                                @Param("pageInfo") PageInfo pageInfo);
}
