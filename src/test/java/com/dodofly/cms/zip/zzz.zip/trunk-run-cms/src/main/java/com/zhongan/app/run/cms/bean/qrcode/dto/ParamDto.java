package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

import java.util.List;

/**
 * 参数数据
 * 
 * @author lichao002
 * @date 2018-06-04
 */
@Data
public class ParamDto {

    /**
     * 一级机构id
     */
    private Long           oneOrgId;

    /**
     * 二级机构id
     */
    private Long           twoOrgId;

    /**
     * 三级机构id
     */
    private Long           threeOrgId;

    /**
     * 四级机构id
     */
    private Long           fourOrgId;

    /**
     * 五级机构id
     */
    private Long           fiveOrgId;

    /**
     * 业务员id
     */
    private Long           salesId;

    /**
     * 业务员code
     */
    private String         salesCode;

    /**
     * 二维码id
     */
    private Long           qrcodeId;

    /**
     * 推广链接
     */
    private String         url;

    /**
     * 当前页
     */
    private Integer        currentPage;

    /**
     * 每页条数
     */
    private Integer        pageSize;

    /**
     * 分页开始索引
     */
    private Integer        start;

    /**
     * 分页结束索引
     */
    private Integer        end;

    /**
     * 选择的数据
     */
    private List<ParamDto> datas;
}
