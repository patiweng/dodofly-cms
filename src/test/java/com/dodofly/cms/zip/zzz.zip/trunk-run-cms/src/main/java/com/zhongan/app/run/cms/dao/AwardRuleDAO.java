package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import com.zhongan.app.run.cms.bean.dataobject.AwardRuleDO;

public interface AwardRuleDAO {

    /**
     * 根据id查询奖品规则
     * 
     * @param id
     * @return
     */
    AwardRuleDO selectDataById(Long id);

    /**
     * 根据条件查询奖品规则（跟入参做比较）
     * 
     * @param record
     * @return
     */
    List<AwardRuleDO> selectDataByAwardRuleCdt(Map map);

    /**
     * 新增奖品规则
     * 
     * @param record
     * @return
     */
    long insert(AwardRuleDO record);

    /**
     * 更新奖品规则
     * 
     * @param record
     * @return
     */
    int update(AwardRuleDO record);

    /**
     * 分页查询活动奖品规则
     * 
     * @param map
     * @return
     */
    List<AwardRuleDO> selectAwardRuleListPage(Map<String, Object> map);

    /**
     * 分页查询总条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map<String, Object> map);

    /**
     * 更具id删除
     * 
     * @param id
     */
    void deleteById(Long id);

    /**
     * 根据条件查询
     * 
     * @param awardRuleDO
     * @return
     */
    List<AwardRuleDO> selectAllDataByCdt(AwardRuleDO awardRuleDO);
}
