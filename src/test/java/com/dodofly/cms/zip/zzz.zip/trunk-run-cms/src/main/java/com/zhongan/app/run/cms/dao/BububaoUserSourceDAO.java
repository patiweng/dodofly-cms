package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoUserSourceDO;
import com.zhongan.app.run.cms.bean.dataobject.SourceUserDO;

@Component
public interface BububaoUserSourceDAO {
    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<BububaoUserSourceDO> selectDataByCdt(BububaoUserSourceDO bububaoUserSourceDO);

    /**
     * 根据unionId查询userSource
     * 
     * @param map
     * @return
     */
    List<BububaoUserSourceDO> selectSourceByUnionId(Map map);

    List<BububaoUserSourceDO> selectUserSourceBySource(Map map);

    List<BububaoUserSourceDO> selectSourceByUserId(Map map);

    /**
     * 根据id查询数据
     * 
     * @param id
     * @return
     */
    BububaoUserSourceDO selectOneDataById(String id);

    /**
     * 插入数据
     * 
     * @param BububaoUserSourceDO
     */
    void insert(BububaoUserSourceDO bububaoUserSourceDO);

    /**
     * 更新数据
     * 
     * @param BububaoUserSourceDO
     */
    void update(BububaoUserSourceDO bububaoUserSourceDO);

    /**
     * 查询用户数量(渠道分组)
     * 
     * @return
     */
    public List<SourceUserDO> selectUserSourceAll();

}
