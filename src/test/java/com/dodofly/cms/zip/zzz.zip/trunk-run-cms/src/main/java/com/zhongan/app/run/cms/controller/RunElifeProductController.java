package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSON;
import com.zhongan.app.run.cms.bean.web.RunElifeProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeProductResDTO;
import com.zhongan.app.run.cms.service.IRunElifeProductService;
import com.zhongan.app.run.common.utils.AppRunRuntimeException;
import com.zhongan.app.run.common.utils.BusinessErrorCode;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类RunElifeProductController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月27日 下午2:11:54
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/elifeProduct")
public class RunElifeProductController {

    @Resource
    private IRunElifeProductService runElifeProductService;

    @RequestMapping(value = "/queryList")
    public BaseResult<PageDTO<RunElifeProductResDTO>> queryList(@RequestBody RunElifeProductQueryDTO dto) {
        log.info("RunElifeProductController queryList param{}", JSON.toJSONString(dto));
        BaseResult<PageDTO<RunElifeProductResDTO>> baseResult = new BaseResult<PageDTO<RunElifeProductResDTO>>();
        try {
            baseResult.setSuccess(runElifeProductService.queryList(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeProductController queryList param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeProductController queryList param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/saveOrUpdate")
    public BaseResult<Integer> saveOrUpdate(@RequestBody RunElifeProductDTO dto) {
        log.info("RunElifeProductController saveOrUpdate param{}", JSON.toJSONString(dto));
        BaseResult<Integer> baseResult = new BaseResult<Integer>();
        try {
            baseResult.setSuccess(runElifeProductService.saveOrUpdate(dto));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeProductController saveOrUpdate param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeProductController saveOrUpdate param{} exception{}", JSON.toJSONString(dto), e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }

    @RequestMapping(value = "/delete")
    public BaseResult<Integer> delete(@RequestParam(name = "id", required = true) Long id) {
        log.info("RunElifeProductController delete id:{}", id);
        BaseResult<Integer> baseResult = new BaseResult<Integer>();
        try {
            baseResult.setSuccess(runElifeProductService.deleteById(id));
        } catch (AppRunRuntimeException e) {
            log.warn("RunElifeProductController delete id{} exception{}", id, e);
            throw new AppRunRuntimeException(e.getErrCode(), e.getErrMsg());
        } catch (Exception e) {
            log.error("RunElifeProductController delete id{} exception{}", id, e);
            throw new AppRunRuntimeException(BusinessErrorCode.SYSTEM_ERROR);
        }
        return baseResult;
    }
}
