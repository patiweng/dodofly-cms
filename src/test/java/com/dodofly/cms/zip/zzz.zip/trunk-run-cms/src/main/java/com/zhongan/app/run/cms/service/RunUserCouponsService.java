package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.bo.RunUserCouponsBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunUserCouponsDTO;

public interface RunUserCouponsService {

    /**
     * cms用户优惠券信息查询C001 (优惠券查询)
     * 
     * @return
     */
    public ResultBase<Page<RunUserCouponsDTO>> selectRunUserCouponsInfo(Page<RunUserCouponsDTO> runUserCouponsDTOpagedata);

    /**
     * 更新优惠劵信息
     * 
     * @param userCouponsBO
     * @return
     */
    public ResultBase<Integer> update(RunUserCouponsBO userCouponsBO);

    /**
     * 添加优惠劵信息
     * 
     * @param userCouponsBO
     * @return
     */
    public ResultBase<String> insert(RunUserCouponsBO userCouponsBO);

    /**
     * 查询是否领取优惠劵
     * 
     * @param userCouponsBO
     * @return
     */
    public ResultBase<Boolean> isUserCoupons(RunUserCouponsBO userCouponsBO);

    public ResultBase<String> sendRenewalInsuranceCoupons(RunUserCouponsBO userCouponsBO);

}
