package com.zhongan.app.run.cms.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.validation.DataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.RafflePresentBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.PresentListPageDTO;
import com.zhongan.app.run.cms.bean.web.RafflePresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.utils.CustomMultipartFileEditor;
import com.zhongan.app.run.cms.service.RafflePresentService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class RafflePresentController {

    @Resource
    private RafflePresentService rafflePresentServiceImpl;

    @InitBinder
    protected void initBinder(DataBinder binder) throws ServletException {
        binder.registerCustomEditor(MultipartFile.class, new CustomMultipartFileEditor());
    }

    /**
     * 临时页面
     * 
     * @return
     */
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public ModelAndView sysInit(RafflePresentDTO rafflePresentDTO) {
        Map<String, Object> model = Maps.newHashMap();
        model.put("rafflePresentDTO", rafflePresentDTO);
        return new ModelAndView("cms/present", model);
    }

    /**
     * 查询全部
     * 
     * @return
     */
    @RequestMapping(value = "/selectpresent", method = RequestMethod.POST)
    public ResultBase<List<RafflePresentDTO>> selectPresent(@RequestBody RafflePresentDTO rafflePresentDTO) {
        log.info("{}-into /selectapresent, param={ " + rafflePresentDTO.toString() + " }");
        ResultBase<List<RafflePresentDTO>> result = new ResultBase<List<RafflePresentDTO>>();
        RafflePresentBO rafflePresentBO = new RafflePresentBO();
        BeanUtils.copyProperties(rafflePresentDTO, rafflePresentBO);
        result = rafflePresentServiceImpl.selectPresentData(rafflePresentBO);
        log.info("{}-/selectapresent return, data={" + result + "}");
        return result;
    }

    /**
     * 查询所有信息 分页。。。
     * 
     * @return
     */
    @RequestMapping(value = "/select/presentpage")
    public ModelAndView selectPresentListPage(RafflePresentDTO rafflePresentDTO, HttpServletRequest request) {
        log.info("{}-into /selectpresentpage, param={ " + rafflePresentDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<RafflePresentDTO> presentListPage = new Page<RafflePresentDTO>(rafflePresentDTO.getPageSize(),
                rafflePresentDTO.getCurrentPage());
        presentListPage.setParam(rafflePresentDTO);
        PresentListPageDTO result = rafflePresentServiceImpl.selectPresentListPage(presentListPage);
        presentListPage = result.getRafflePresentDTODTOPage();
        Map<String, Object> model = Maps.newHashMap();
        if (null != presentListPage) {
            model.put("presentlistPage", presentListPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("rafflePresentDTO", rafflePresentDTO);
        model.put("page", presentListPage);
        log.info("{}-/selectpresentpage return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/present", model);
    }

    /**
     * 根据主键查询单条 前端
     * 
     * @return
     */
    @RequestMapping(value = "/selectpresentone/{id}", method = RequestMethod.GET)
    public ResultBase<RafflePresentDTO> selectPresentOneData(@PathVariable String id) {
        log.info("{}-into /selectapresentone, param={ " + id + " }");
        ResultBase<RafflePresentDTO> result = new ResultBase<RafflePresentDTO>();
        result = rafflePresentServiceImpl.selectPresentDataByid(id);
        log.info("{}-/selectapresentone return, data={" + result + "}");
        return result;
    }

    /**
     * 根据主键查询单条 后台
     * 
     * @return
     */
    @RequestMapping(value = "/selectone/{id}", method = RequestMethod.GET)
    public RafflePresentDTO selectOneData(@PathVariable String id) {
        log.info("{}-into /selectone, param={ " + id + " }");
        RafflePresentDTO result = new RafflePresentDTO();
        result = rafflePresentServiceImpl.selectDataByid(id);
        log.info("{}-/selectone return, data={" + result + "}");
        return result;
    }

    /**
     * 新增 修改信息 后台
     * 
     * @return
     */

    @RequestMapping(value = "/insertorupdate", method = RequestMethod.POST)
    public ResultBase<String> insertorupdate(RafflePresentDTO rafflePresentDTO) {
        log.info("{}-/insertorupdatedata,param={" + rafflePresentDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        Map<String, Object> model = Maps.newHashMap();
        model.put("rafflePresentDTO", rafflePresentDTO);
        if ("".equals(rafflePresentDTO.getId())) {
            rafflePresentDTO.setId(null);
        }
        RafflePresentBO rafflePresentBO = new RafflePresentBO();
        BeanUtils.copyProperties(rafflePresentDTO, rafflePresentBO);
        if (null == rafflePresentBO.getId()) {
            result = rafflePresentServiceImpl.insertPresentData(rafflePresentBO);
        } else {
            result = rafflePresentServiceImpl.updatePresentData(rafflePresentBO);
        }
        log.info("{}-/insertorupdatedata  return,data={" + result.toString() + "}");
        return result;
    }

    /**
     * 修改信息 前端
     * 
     * @return
     */

    @RequestMapping(value = "/updatepresentdata", method = RequestMethod.POST)
    public ResultBase<String> updatePresent(@RequestBody RafflePresentDTO rafflePresentDTO) {
        log.info("{}-/uodatedata,param={" + rafflePresentDTO.toString() + "}");
        ResultBase<String> result = new ResultBase<String>();
        RafflePresentBO rafflePresentBO = new RafflePresentBO();
        BeanUtils.copyProperties(rafflePresentDTO, rafflePresentBO);
        result = rafflePresentServiceImpl.updatePresentData(rafflePresentBO);
        log.info("{}-/uodatedata  return,data={" + result.toString() + "}");
        return result;
    }

    /**
     * 根据礼物类型查询礼物信息
     * 
     * @return
     */
    @RequestMapping(value = "/selectbytype", method = RequestMethod.POST)
    public List<RafflePresentDTO> selectBytype(RafflePresentDTO rafflePresentDTO) {
        List<RafflePresentDTO> raffleList = Lists.newArrayList();
        RafflePresentBO rafflePresentBO = new RafflePresentBO();
        BeanUtils.copyProperties(rafflePresentDTO, rafflePresentBO);
        ResultBase<List<RafflePresentDTO>> result = rafflePresentServiceImpl.selectPresentData(rafflePresentBO);
        if (result.getValue() != null) {
            raffleList = result.getValue();
        }
        return raffleList;
    }

    /**
     * 根据主键删除
     * 
     * @return
     */

    @RequestMapping(value = "/deletepresentdata/{id}", method = RequestMethod.GET)
    public ResultBase<String> deletePresentData(@PathVariable String id) {
        log.info("{}-/deletepresentdata/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = rafflePresentServiceImpl.deletePresent(id);
        }
        log.info("{}-/deletepresentdata/{id} return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 根据活动id（activityId）查询所有奖品
     * 
     * @param activityPresentDTO
     * @return
     */
    @RequestMapping(value = "/select/selectpresentbyactivityid", method = RequestMethod.POST)
    public ResultBase<List<RafflePresentDTO>> selectPresentByActivityId(@RequestBody ActivityPresentDTO activityPresentDTO) {
        log.info("{}-/select/selectpresentbyactivityid--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(activityPresentDTO));
        return rafflePresentServiceImpl.selectPresentByActivityId(activityPresentDTO);
    }

}
