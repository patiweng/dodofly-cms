package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;

import org.springframework.web.multipart.MultipartFile;

@Data
public class QuestionItemRepo {
    private Long          id;
    private Long          queryId;
    private String        itemTitle;
    private String        queryIcon;
    private String        tagCode;
    private Integer       sort;
    private String        type;
    private String        unit;
    private String        inputCheck;
    private String        creator;
    private String        modifier;
    private String        createtime;
    private String        modifytime;
    private String        isDeleted;
    private MultipartFile marketingImgFile; //上传到OSS 的图片
}
