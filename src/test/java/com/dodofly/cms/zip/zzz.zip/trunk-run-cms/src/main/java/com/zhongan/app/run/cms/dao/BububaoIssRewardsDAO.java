package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.bean.dataobject.BububaoIssRewardsDO;

@Component
public interface BububaoIssRewardsDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoIssRewardsDO> selectDataByCdt(BububaoIssRewardsDO bububaoIssRewardsDO);
	   
		 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoIssRewardsDO> selectIssRewards(BububaoIssRewardsDO bububaoIssRewardsDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoIssRewardsDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoIssRewardsDO
	    */
	   void insert(BububaoIssRewardsDO bububaoIssRewardsDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoIssRewardsDO
	    */
	   void update(BububaoIssRewardsDO bububaoIssRewardsDO);
}
