package com.zhongan.app.run.cms.controller.qrcode;

import java.util.List;

import javax.annotation.Resource;




import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoScanQrcodeLogDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoThirdQrcodeDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoScanQrcodeLogDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdOrgDO;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdQrcodeDO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.service.qrcode.BububaoScanQrcodeLogService;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdOrgService;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdQrcodeService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;

/**
 * 二维码推广公共调用 类QrcodeController.java的实现描述：TODO 类实现描述
 * 
 * @author zhangjin 2018年6月15日 上午10:50:34
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/qrcode")
public class QrcodeController {

    @Resource
    private BububaoScanQrcodeLogService bububaoScanQrcodeLogServiceImpl;

    @Resource
    private BububaoThirdQrcodeService   bububaoThirdQrcodeServiceImpl;

    @Resource
    private BububaoThirdOrgService      bububaoThirdOrgServiceImpl;

    /**
     * 插入扫码日志记录
     * 
     * @param bububaoScanQrcodeLogDTO
     * @return
     */
    @RequestMapping(value = "/insertScanQrcodeLog", method = RequestMethod.POST)
    public BaseResult<Integer> insertScanQrcodeLog(@RequestBody BububaoScanQrcodeLogDto bububaoScanQrcodeLogDTO) {
        log.info("{}-/insertScanQrcodeLog--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(bububaoScanQrcodeLogDTO));
        BaseResult<Integer> result = bububaoScanQrcodeLogServiceImpl.insertScanQrcodeLog(bububaoScanQrcodeLogDTO);
        log.info("{}-/insertScanQrcodeLog return, data={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(result));
        return result;
    }

    /**
     * 查询扫码日志记录
     * 
     * @param bububaoScanQrcodeLogDTO
     * @return
     */
    @RequestMapping(value = "/selectScanQrcodeLog", method = RequestMethod.POST)
    public BaseResult<List<BububaoScanQrcodeLogDto>> selectScanQrcodeLog(@RequestBody BububaoScanQrcodeLogDto bububaoScanQrcodeLogDTO) {
        log.info("{}-/selectScanQrcodeLog--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(bububaoScanQrcodeLogDTO));
        BaseResult<List<BububaoScanQrcodeLogDto>> result = new BaseResult<List<BububaoScanQrcodeLogDto>>();
        result = bububaoScanQrcodeLogServiceImpl.selectScanQrcodeLog(bububaoScanQrcodeLogDTO);
        log.info("{}-/selectScanQrcodeLog return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 修改二维码管理表(根据dataId和dataType修改数量)
     * 
     * @param thirdQrcodeDTO
     * @return
     */
    @RequestMapping(value = "/updateThirdQrcode", method = RequestMethod.POST)
    public BaseResult<Integer> updateThirdQrcode(@RequestBody BububaoThirdQrcodeDto thirdQrcodeDTO) {
        log.info("{}-/updateThirdQrcode--param==={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(thirdQrcodeDTO));
        BaseResult<Integer> result = new BaseResult<Integer>();
        result = bububaoThirdQrcodeServiceImpl.updateThirdQrcode(thirdQrcodeDTO);
        log.info("{}-/updateThirdQrcode return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 用于查询条件，通过父级id查询子级机构
     * 
     * @param orgId
     * @return
     */
    @RequestMapping(value = "/condition/{orgId}", method = RequestMethod.GET)
    public BaseResult<List<BububaoThirdOrgDO>> conditionOrgs(@PathVariable Long orgId) {
        log.info("{}------------BububaoThirdOrgController.conditionOrgs---------start,orgId:{}",
                ThreadLocalUtil.getRequestNo(), orgId);
        BaseResult<List<BububaoThirdOrgDO>> result = null;
        try {
            result = bububaoThirdOrgServiceImpl.selectCondition(orgId);
            result.setCode(AppErrEnum.SUCCESS_SYS_0000.getCode());
            result.setMessage(AppErrEnum.SUCCESS_SYS_0000.getValue());
        } catch (Exception e) {
            log.error("{}------------BububaoThirdOrgController.conditionOrgs---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<List<BububaoThirdOrgDO>>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdOrgController.conditionOrgs---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

}
