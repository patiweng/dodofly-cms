package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoEmployeePinyinDO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoEmployeeTmpDO;

@Component
public interface BububaoEmployeeTmpDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoEmployeeTmpDO> selectDataByCdt(BububaoEmployeeTmpDO bububaoEmployeeTmpDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoEmployeeTmpDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoEmployeeTmpDO
	    */
	   void insert(BububaoEmployeeTmpDO bububaoEmployeeTmpDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoEmployeeTmpDO
	    */
	   void update(BububaoEmployeeTmpDO bububaoEmployeeTmpDO);
}
