package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

import lombok.Data;

@Data
public class CardCouponsDTO {
    private Long   id;

    private Long   activityId;

    private Long   presentId;

    private Long   unionid;

    private String cardType;

    private String cardNum;

    private String cardPassword;

    private String cardAmount;

    private String isUsed;

    private Date   sendTime;

    private String creator;

    private String modifier;

    private Date   gmtCreated;

    private Date   gmtModified;

    private String isDeleted;

}
