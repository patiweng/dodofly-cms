package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

import com.zhongan.health.common.share.bean.PageDTO;

public class CashierHelpPayDetailQueryDTO extends PageDTO<CashierHelpPayDetailQueryDTO> {

    /**
     * 
     */
    private static final long serialVersionUID = 6126829839968495126L;

    /**
     * 代收代付ID
     */
    private Long              cashierId;

    /**
     * 用户合同号
     */
    private String            userContractNo;

    /**
     * 业务时间
     */
    private Date              bizTime;

    /**
     * 业务状态(1:已开通 2:未开通)
     */
    private Long              bizStatus;

    /**
     * 渠道信息
     */
    private String            bizChannel;

    public Long getCashierId() {
        return cashierId;
    }

    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    public String getUserContractNo() {
        return userContractNo;
    }

    public void setUserContractNo(String userContractNo) {
        this.userContractNo = userContractNo;
    }

    public Date getBizTime() {
        return bizTime;
    }

    public void setBizTime(Date bizTime) {
        this.bizTime = bizTime;
    }

    public Long getBizStatus() {
        return bizStatus;
    }

    public void setBizStatus(Long bizStatus) {
        this.bizStatus = bizStatus;
    }

    public String getBizChannel() {
        return bizChannel;
    }

    public void setBizChannel(String bizChannel) {
        this.bizChannel = bizChannel;
    }
}
