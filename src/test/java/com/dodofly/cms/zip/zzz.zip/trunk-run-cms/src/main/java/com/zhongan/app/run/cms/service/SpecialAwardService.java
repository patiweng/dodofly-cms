package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.SpecialAwardDTO;

public interface SpecialAwardService {

    /**
     * 分页查询特殊奖励配置
     * 
     * @param page
     * @return
     */
    Page<SpecialAwardDTO> selectSpecialAwardListPage(Page<SpecialAwardDTO> page);

    /**
     * 新增
     * 
     * @param SpecialAwardDTO
     * @return
     */
    ResultBase<String> insertSpecialAward(SpecialAwardDTO specialAwardDTO);

    /**
     * 根据id删除
     */
    ResultBase<String> deleteById(Long id);

    /**
     * 更新
     * 
     * @param SpecialAwardDTO
     * @return
     */
    ResultBase<String> updateById(SpecialAwardDTO specialAwardDTO);

    /**
     * 根据id查询一条
     * 
     * @param id
     * @return
     */
    ResultBase<SpecialAwardDTO> selectSpecialAwardOne(String id);
}
