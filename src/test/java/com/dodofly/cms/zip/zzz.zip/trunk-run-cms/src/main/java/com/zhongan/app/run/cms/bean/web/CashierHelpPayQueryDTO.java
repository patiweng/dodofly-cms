package com.zhongan.app.run.cms.bean.web;

import com.zhongan.health.common.share.bean.PageDTO;

public class CashierHelpPayQueryDTO extends PageDTO<CashierHelpPayQueryDTO> {

    /**
     * 
     */
    private static final long serialVersionUID = -764656388142292411L;

    /**
     * 手机号
     */
    private String            phone;

    /**
     * 证件号码
     */
    private String            certNo;

    /**
     * 开通渠道
     */
    private String            openChannel;

    /**
     * 开通状态
     */
    private Long              openStauts;

    /**
     * 开始时间
     */
    private String            startTime;

    /**
     * 结束时间
     */
    private String            endTime;

    /**
     * 开通活动来源
     */
    private String            bizActivity;

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getCertNo() {
        return certNo;
    }

    public void setCertNo(String certNo) {
        this.certNo = certNo;
    }

    public String getOpenChannel() {
        return openChannel;
    }

    public void setOpenChannel(String openChannel) {
        this.openChannel = openChannel;
    }

    public Long getOpenStauts() {
        return openStauts;
    }

    public void setOpenStauts(Long openStauts) {
        this.openStauts = openStauts;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getBizActivity() {
        return bizActivity;
    }

    public void setBizActivity(String bizActivity) {
        this.bizActivity = bizActivity;
    }

}
