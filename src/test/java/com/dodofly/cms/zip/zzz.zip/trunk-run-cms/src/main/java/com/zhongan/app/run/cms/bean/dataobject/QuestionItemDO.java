package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class QuestionItemDO {
    private Long    id;
    private Long    queryId;
    private String  itemTitle;
    private String  queryIcon;
    private String  tagCode;
    private Integer sort;
    private String  type;
    private String  unit;
    private String  inputCheck;
    private String  creator;
    private String  modifier;
    private String  createtime;
    private String  modifytime;
    private String  isDeleted;
}
