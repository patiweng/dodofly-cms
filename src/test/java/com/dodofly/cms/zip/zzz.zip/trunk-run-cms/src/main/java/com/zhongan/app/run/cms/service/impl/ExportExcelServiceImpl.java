package com.zhongan.app.run.cms.service.impl;

import java.io.InputStream;
import java.io.OutputStream;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.ibm.icu.text.DecimalFormat;
import com.zhongan.app.run.cms.bean.client.AnalysisMonitorClient;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.AnalysisMonitorRepo;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorDTO;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.ReadExcel;
import com.zhongan.app.run.cms.repository.AnalysisMonitorRepository;
import com.zhongan.app.run.cms.service.ExportExcelService;
import com.zhongan.app.run.cms.service.client.RunAnalysisFeignClient;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class ExportExcelServiceImpl implements ExportExcelService {
    @Resource
    private AnalysisMonitorRepository analysisMonitorRepository;
    @Resource
    private RunAnalysisFeignClient    runAnalysisFeignClient;

    @Override
    public void doExportExcelForRegRate(HttpServletResponse response, String sdate, String edate) {
        log.info("{}-doExportExcelForRegRate start……", ThreadLocalUtil.getRequestNo());
        List<AnalysisMonitorClient> list = new ArrayList<AnalysisMonitorClient>();
        int zHelloindexCount = 0, zInsureindexCount = 0, zInsuresucCount = 0, zInsureerrCount = 0;
        try {
            log.info("准备执行runAnalysisFeignClient.queryListForExcel方法……");
            ResultBase<List<AnalysisMonitorClient>> result = runAnalysisFeignClient.queryListForExcel(sdate, edate);
            log.info("查询结果为runAnalysisFeignClient.queryListForExcel======" + JSONObject.toJSONString(result));
            String path = this.getClass().getResource("/static/excel/reg.xlsx").getPath();
            InputStream is = this.getClass().getResourceAsStream("/static/excel/reg.xlsx");
            log.info("excel模版的路径为=================" + path);
            /*    int indexOf = path.indexOf("/");
                String srcXlsxPath = path.substring(indexOf + 1);*/
            Workbook workbook = new XSSFWorkbook(is);
            //Workbook workbook = ReadExcel.openExcleFile(path);//获取工作簿7
            if (workbook == null) {
                log.info("workbook对象为null");
            }
            Sheet sheet = workbook.getSheetAt(0);//获取页签
            if (null != result && result.isSuccess() && result.getValue().size() > 0) {
                list = result.getValue();
                log.info("数据条数list.size()=============" + list.size());
                for (int i = 0; i < list.size(); i++) {
                    //第一行不用copy
                    if (i != 0) {
                        ReadExcel.copyRows(sheet, 4, 4, 3 + i);
                    }
                    AnalysisMonitorClient analysisMonitorClient = list.get(i);
                    Row rowx = sheet.getRow(3 + i);
                    rowx.getCell(0).setCellValue(i + 1);
                    rowx.getCell(1).setCellValue(analysisMonitorClient.getSourceName());
                    rowx.getCell(2).setCellValue(analysisMonitorClient.getHelloindexCount());
                    rowx.getCell(3).setCellValue(analysisMonitorClient.getInsureindexCount());
                    rowx.getCell(4).setCellValue(formatPercentum(analysisMonitorClient.getInsureconverRate()));
                    rowx.getCell(5).setCellValue(analysisMonitorClient.getInsuresucCount());
                    rowx.getCell(6).setCellValue(formatPercentum(analysisMonitorClient.getInsuresucRate()));
                    rowx.getCell(7).setCellValue(analysisMonitorClient.getInsureerrCount());
                    rowx.getCell(8).setCellValue(formatPercentum(analysisMonitorClient.getInsureerrRate()));

                    zHelloindexCount += Integer.valueOf(analysisMonitorClient.getHelloindexCount());
                    zInsureindexCount += Integer.valueOf(analysisMonitorClient.getInsureindexCount());
                    zInsuresucCount += Integer.valueOf(analysisMonitorClient.getInsuresucCount());
                    zInsureerrCount += Integer.valueOf(analysisMonitorClient.getInsureerrCount());
                }
                //添加合计行
                ReadExcel.copyRows(sheet, 4, 4, 3 + list.size());
                Row rowlast = sheet.getRow(3 + list.size());
                rowlast.getCell(0).setCellValue("--");
                rowlast.getCell(1).setCellValue("总概");
                rowlast.getCell(2).setCellValue(zHelloindexCount);
                rowlast.getCell(3).setCellValue(zInsureindexCount);
                rowlast.getCell(4).setCellValue(countRate(zInsureindexCount, zHelloindexCount));
                rowlast.getCell(5).setCellValue(zInsuresucCount);
                rowlast.getCell(6).setCellValue(countRate(zInsuresucCount, zHelloindexCount));
                rowlast.getCell(7).setCellValue(zInsureerrCount);
                rowlast.getCell(8).setCellValue(countRate(zInsureerrCount, zHelloindexCount));
            }
            String title = "注册转化率";
            response.setHeader("Content-disposition",
                    "attachment;filename=" + new String((title + ".xlsx").getBytes("gb2312"), "iso8859-1"));
            OutputStream ouputStream = response.getOutputStream();
            workbook.write(ouputStream);
            ouputStream.flush();
            ouputStream.close();
        } catch (Exception e) {
            log.error("{}-doExportExcelForRegRate fail……", e);
        }
    }

    /**
     * 字符串转百分比
     * 
     * @param rate
     * @return
     */
    private String formatPercentum(String rate) {
        NumberFormat nf = NumberFormat.getPercentInstance();
        String format = nf.format(Double.valueOf(rate));
        return format;
    }

    private String countRate(Integer index, Integer count) {
        if (index == 0 || count == 0) {
            return "0%";
        }
        float num = (float) index / count;
        DecimalFormat df = new DecimalFormat("0.00");//格式化小数  
        String s = df.format(num);//返回的是String类型 
        return formatPercentum(s);
    }

    /**
     * 查询打点分析表 分页……
     */
    @Override
    public AnalysisMonitorPageDTO selectAnalysisMonitorList(Page<AnalysisMonitorDTO> analysisMonitorPage) {
        AnalysisMonitorPageDTO analysisMonitorPageDTO = new AnalysisMonitorPageDTO();
        Page<AnalysisMonitorRepo> analysisMonitorRepoPage = new Page<AnalysisMonitorRepo>();
        BeanUtils.copyProperties(analysisMonitorPage, analysisMonitorRepoPage);
        analysisMonitorRepoPage = analysisMonitorRepository.selectAnalysisMonitorPage(analysisMonitorPage);
        List<AnalysisMonitorRepo> analysisMonitorRepoList = analysisMonitorRepoPage.getResultList();
        List<AnalysisMonitorDTO> analysisMonitorDTOList = Lists.newArrayList();
        if (analysisMonitorRepoList != null && analysisMonitorRepoList.size() > 0) {
            AnalysisMonitorDTO analysisMonitorDTO = new AnalysisMonitorDTO();
            for (AnalysisMonitorRepo analysisMonitorRepo : analysisMonitorRepoList) {
                AnalysisMonitorDTO clone = (AnalysisMonitorDTO) analysisMonitorDTO.clone();
                BeanUtils.copyProperties(analysisMonitorRepo, clone);
                analysisMonitorDTOList.add(clone);
            }
        }
        analysisMonitorPage.setResultList(analysisMonitorDTOList);
        analysisMonitorPage.setTotalItem(analysisMonitorRepoPage.getTotalItem());
        analysisMonitorPageDTO.setAnalysisMonitorDTOPage(analysisMonitorPage);
        return analysisMonitorPageDTO;
    }

    @Override
    public ResultBase<String> addAnalysisMonitorofTodayData() {
        log.info("{}-ExportExcelServiceImpl.addAnalysisMonitorofTodayData start……", ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            return runAnalysisFeignClient.addAnalysisMonitorOfTodayData();
        } catch (Exception e) {
            log.info("{}-ExportExcelServiceImpl.addAnalysisMonitorofTodayData faile异常了……", e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            resultBase.setSuccess(false);
        }
        return resultBase;
    }
}
