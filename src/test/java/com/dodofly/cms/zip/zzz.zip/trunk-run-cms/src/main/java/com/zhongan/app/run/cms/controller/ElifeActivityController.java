package com.zhongan.app.run.cms.controller;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.common.utils.RedisUtil;

@Slf4j
@RestController
@RequestMapping("/run/cms/elife")
public class ElifeActivityController {

    @Resource
    private RedisUtil redisUtil;

    @RequestMapping(value = "/changeactivitystatus/{activitySwitch}", method = RequestMethod.GET)
    public ResultBase<String> changeActivityStatus(@PathVariable String activitySwitch) {
        log.info("更改尊享e生状态，activitySwitch={}", activitySwitch);
        if (activitySwitch.equals("0") || activitySwitch.equals("1")) {
            ResultBase<String> result = new ResultBase<>();
            if (redisUtil.update("elife_activity_status", activitySwitch)) {
                result.setSuccess(true);
                result.setValue("更新成功,现在的状态是" + activitySwitch);
            } else {
                result.setSuccess(false);
                result.setValue("更新失败");
            }
            return result;
        }
        return null;
    }

    @RequestMapping(value = "/getactivitystatus", method = RequestMethod.GET)
    public String getActivityStatus() {
        return "活动开关状态（1开启）：" + redisUtil.getString("elife_activity_status");
    }
}
