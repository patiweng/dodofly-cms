package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class UserStepCountDO {

    private String  userId;

    private Integer countStep;

}
