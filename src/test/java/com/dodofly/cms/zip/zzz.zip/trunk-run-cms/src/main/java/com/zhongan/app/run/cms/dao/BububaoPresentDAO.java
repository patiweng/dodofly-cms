package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoPresentDO;

@Component
public interface BububaoPresentDAO {
    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<BububaoPresentDO> selectDataByCdt(BububaoPresentDO bububaoPresentDO);

    /**
     * 根据id查询数据
     * 
     * @param id
     * @return
     */
    BububaoPresentDO selectOneDataById(String id);

    /**
     * 分页查询BububaopresentListDO信息
     * 
     * @param map
     * @return
     */
    List<BububaoPresentDO> selectBububaoPresentList(Map map);

    /**
     * 查询BububaopresentListDO条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 更新数据为无效数据
     * 
     * @param id
     */
    void updateByid(String id);

    /**
     * 插入数据
     * 
     * @param BububaoPresentDO
     */
    void insert(BububaoPresentDO bububaoPresentDO);

    /**
     * 更新数据
     * 
     * @param BububaoPresentDO
     */
    void update(BububaoPresentDO bububaoPresentDO);

    /**
     * 根据活动id查询该活动下配置的礼物
     * 
     * @param activityId
     * @return
     */
    List<BububaoPresentDO> selectPresentNameList(String activityId);
}
