package com.zhongan.app.run.cms.common.csvutil.conver;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.common.csvutil.annotion.Convert;
import com.zhongan.app.run.cms.common.csvutil.utils.BeanUtils;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;

@Slf4j
public class DefaultConvert implements Convert {

    @Override
    public <T> T readConvert(String[] values, char separator, List<String> titles, Class<T> clazz) {
        try {
            T t = clazz.newInstance();

            Map<String, BeanUtils.PropertyDesc> proMap = BeanUtils.getBeanAnnotion(clazz);
            int length = values.length;
            int size = titles.size();
            boolean isAllNull = true;
            for(int i = 0 , j = 0 ; i < length && j < size ; i++ , j++){
                BeanUtils.PropertyDesc propertyDesc = proMap.get(titles.get(i));
                if(propertyDesc != null){
                    if(propertyDesc.setValue(t, values[j])){
                        isAllNull = false;
                    }
                }
            }
            if(isAllNull){
                return null;
            }
            return t;
        }catch (Exception e){
            log.error("Exception:", e);
            throw new RuntimeException("cell转换bean失败", e);
        }

    }

    @Override
    public <T> List<String[]> writeConvertContent(List<T> datas, Class<T> clazz, List<String> titles) {
        Map<String, BeanUtils.PropertyDesc> proMap = BeanUtils.getBeanAnnotion(clazz);
        int titlesSize = titles.size();
        int datasSize = datas.size();
        List<BeanUtils.PropertyDesc> pds = Lists.newArrayList();
        for(int i = 0 ; i < titlesSize ; i++){
            pds.add(proMap.get(titles.get(i)));
        }
        List<String[]> datasList = Lists.newArrayList();
        for(int i = 0 ; i < datasSize ; i++ ){
            T t = datas.get(i);
            String[] data = new String[titlesSize + 1];
            data[0] = new Integer(i + 1).toString();
            for (int j = 0 ; j < titlesSize ; j++){
                data[j + 1] = pds.get(j).getValue(t);
            }
            datasList.add(data);
        }
        return datasList;
    }
}
