package com.zhongan.app.run.cms.common.constants;

import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;

import java.util.Date;
import java.util.List;

public class QrCodeConstants {

    public static String getDownLoadFolder(){
        return "/run/cms/qrcode/getFile/";
    }
    public static String getCSVOrgName(){
        String name = "机构二维码-";
        name = name + DateTimeUtils.convertDate2String(new Date(), DateTimeUtils.DATE_FORMAT_YYYYMMDD) + ".csv";
        return name;
    }

    public static String getCSVSalesName(){
        String name = "业务员二维码-";
        name = name + DateTimeUtils.convertDate2String(new Date(), DateTimeUtils.DATE_FORMAT_YYYYMMDD) + ".csv";
        return name;
    }

    public static String getCSVExName(){
        return ".csv";
    }

    public static String getPNGExName(){
        return ".png";
    }

    public static String getOssOrgFolder(){
        String folder = "qr/code/org/";
        folder = folder + DateTimeUtils.convertDate2String(new Date(), "yyyy/MM/dd/");
        return folder;
    }

    public static String getOssOrgZIPName(){
        String name = "组织机构二维码";
        name = name + DateTimeUtils.convertDate2String(new Date(), DateTimeUtils.DATE_FORMAT_YYYYMMDD + "_") + new Date().getTime() + ".zip";
        return name;
    }

    public static String getOssSalesFolder(){
        String folder = "qr/code/sales/";
        folder = folder + DateTimeUtils.convertDate2String(new Date(), "yyyy/MM/dd/");
        return folder;
    }

    public static String getOssSalseZIPName(){
        String name = "业务员二维码-";
        name = name + DateTimeUtils.convertDate2String(new Date(), DateTimeUtils.DATE_FORMAT_YYYYMMDD + "_") + new Date().getTime() + ".zip";
        return name;
    }

    public static List<String> getOrgImportTitle(){
        return Lists.newArrayList("oneOrgName", "twoOrgName", "threeOrgName", "fourOrgName", "isFollowBububao");
    }

    public static List<String> getOrgExportTitle(){
        return Lists.newArrayList("序号", "总公司", "二级机构", "三级机构", "四级机构", "五级机构");
    }

    public static List<String> getOrgExportEnTitle(){
        return Lists.newArrayList("oneOrgName", "twoOrgName", "threeOrgName", "fourOrgName", "fiveOrgName");
    }

    public static List<String> getSalesImportTitle(){
        return Lists.newArrayList("oneOrgName", "twoOrgName", "threeOrgName", "salesCode", "isLeader", "isFollowBububao");
    }

    public static List<String> getSalesExportTitle(){
        return Lists.newArrayList("序号", "总公司", "二级机构", "三级机构", "四级机构", "五级机构", "业务员工号");
    }

    public static List<String> getSalesExportEnTitle(){
        return Lists.newArrayList("oneOrgName", "twoOrgName", "threeOrgName", "fourOrgName", "fiveOrgName", "salesCode");
    }
    
    public static List<String> getStatisticsExportTitle(){
        return Lists.newArrayList("序号", "总公司", "二级机构", "三级机构", "四级机构","五级机构","业务员","是否团队长","投保总用户数","投保总保单数","扫码总次数");
    }
    
    public static List<String> getStatisticsExportEnTitle(){
        return Lists.newArrayList("oneOrgName", "twoOrgName", "threeOrgName", "fourOrgName", "fiveOrgName", "salesCode", "isLeader", "holderNum", "insureNum", "scanNum");
    }
    
    public static List<String> getDetailExportTitle(){
        return Lists.newArrayList("序号", "总公司", "二级机构", "三级机构", "四级机构","五级机构","业务员","是否团队长","保单号","姓名","身份证","手机号码","起保日期","终保日期","保费","保额");
    }
    
    public static List<String> getDetailExportEnTitle(){
        return Lists.newArrayList("oneOrgName", "twoOrgName", "threeOrgName", "fourOrgName", "fiveOrgName", "salesCode", "isLeader", "scanPolicyNo", "holderName", "holderIdentity", "holderPhone", "policyStartTime", "policyEndTime", "originPremium", "originSum");
    }

    public static String getQrcodeName(Integer type, Long id, String format){
        StringBuffer buffer = new StringBuffer();
        buffer.append(System.currentTimeMillis()).append("_").append(type).append("_")
                .append(id).append(".").append(format);
        return buffer.toString();
    }
}
