package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoUserCouponsDO;

@Component
public interface BububaoUserCouponsDAO {
    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<BububaoUserCouponsDO> selectDataByCdt(BububaoUserCouponsDO bububaoUserCouponsDO);

    /**
     * 根据id查询数据
     * 
     * @param id
     * @return
     */
    BububaoUserCouponsDO selectOneDataById(String id);

    /**
     * 插入数据
     * 
     * @param BububaoUserCouponsDO
     */
    void insert(BububaoUserCouponsDO bububaoUserCouponsDO);

    /**
     * 更新数据
     * 
     * @param BububaoUserCouponsDO
     */
    int update(BububaoUserCouponsDO bububaoUserCouponsDO);

    /**
     * 分页查询UserCoupons信息
     * 
     * @param map
     * @return
     */
    List<BububaoUserCouponsDO> selectBububaoUserCoupons(Map map);

    /**
     * 查询UserCoupons条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    Integer selectNums(Map map);
}
