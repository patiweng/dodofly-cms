package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.BububaoActivityRuleDTO;
import com.zhongan.app.run.cms.bean.web.BububaoActivityRulePageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.service.ActivityRuleService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 活动规则配置信息
 * 
 * @author yangzhen001
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activityRule")
public class ActivityRuleController {

    @Resource
    private ActivityRuleService activityRuleServiceImpl;

    /**
     * 查询活动规则配置信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/insertorupdateActivityRule", method = RequestMethod.POST)
    public ResultBase<String> insertorupdateActivityRule(BububaoActivityRuleDTO info) {
        log.info("{}-into /insertorupdateActivityRule, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<String> resultBase = activityRuleServiceImpl.insertorupdateActivityRule(info);
        log.info("{}-/insertorupdateActivityRule return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 查询活动规则配置信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/queryActivityRuleByCdt", method = RequestMethod.POST)
    public ResultBase<List<BububaoActivityRuleDTO>> queryActivityRuleByCdt(@RequestBody BububaoActivityRuleDTO info) {
        log.info("{}-into /queryActivityRuleByCdt, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<List<BububaoActivityRuleDTO>> resultBase = activityRuleServiceImpl.queryActivityRuleByCdt(info);
        log.info("{}-/queryActivityRuleByCdt return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 插入活动规则配置信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/insertActivityRuleInfo", method = RequestMethod.POST)
    public ResultBase<String> insertActivityRuleInfo(@RequestBody BububaoActivityRuleDTO info) {
        log.info("{}-into /insertActivityRuleInfo, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<String> resultBase = activityRuleServiceImpl.insertActivityRuleInfo(info);
        log.info("{}-/insertActivityRuleInfo return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 跟新活动规则配置信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/updateActivityRuleInfo", method = RequestMethod.POST)
    public ResultBase<String> updateActivityRuleInfo(@RequestBody BububaoActivityRuleDTO info) {
        log.info("{}-into /updateActivityRuleInfo, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(info));
        ResultBase<String> resultBase = activityRuleServiceImpl.updateActivityRuleInfo(info);
        log.info("{}-/updateActivityRuleInfo return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 查询活动规则配置信息分页
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/selectActivityRuleByCdtPage")
    public ModelAndView selectActivityRuleByCdtPage(BububaoActivityRuleDTO param) {
        log.info("{}-into /selectActivityRuleByCdtPage, param={} ", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(param));
        BububaoActivityRulePageDTO page = activityRuleServiceImpl.selectActivityRuleByCdtPage(param);
        //将活动类型转换
        List<RunChannelListDTO> channelList = page.getChannelList();
        for (RunChannelListDTO runChannelListDTO : channelList) {
            if (runChannelListDTO.getType().equals(RunConstants.IS_ZHONGJI)) {
                runChannelListDTO.setTypeName(RunConstants.IS_ZHONGJI_NAME);
            } else {
                runChannelListDTO.setTypeName(RunConstants.IS_YIWAI);
            }
        }
        PageDTO<BububaoActivityRuleDTO> pagedto = page.getPage();
        ModelAndView modelAndView = new ModelAndView("cms/activityRuleInfo");
        modelAndView.addObject("activityRuleList", pagedto.getResultList());
        modelAndView.addObject("activityRuleParam", param);
        modelAndView.addObject("page", pagedto);
        modelAndView.addObject("totalPage", pagedto.getTotalPage());
        modelAndView.addObject("channelList", channelList);
        log.info("{}-/selectActivityRuleByCdtPage return, data={}", ThreadLocalUtil.getRequestNo(),
                JSON.toJSONString(pagedto));
        return modelAndView;
    }

    @RequestMapping(value = "/selectActivityRuleOne/{id}", method = RequestMethod.GET)
    public BububaoActivityRuleDTO selectActivityRuleOne(@PathVariable Long id) {
        log.info("{}-into /selectActivityRuleOne, id={} ", ThreadLocalUtil.getRequestNo(), id);
        BububaoActivityRuleDTO dto = activityRuleServiceImpl.selectActivityRuleOne(id);
        log.info("{}-/selectActivityRuleOne return, data={}", ThreadLocalUtil.getRequestNo(), JSON.toJSONString(dto));
        return dto;
    }

    /**
     * 删除活动规则配置信息
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/deleteActivityRuleById/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteActivityRuleById(@PathVariable("id") Long id) {
        log.info("{}-into /deleteActivityRuleById,id:{}", ThreadLocalUtil.getRequestNo(), id);
        ResultBase<String> result = activityRuleServiceImpl.deleteActivityRuleById(id);
        log.info("{}-/deleteActivityRuleById return:{}", ThreadLocalUtil.getRequestNo(), JSON.toJSONString(result));
        return result;
    }

    /**
     * copy活动规则配置信息
     * 
     * @param id
     * @return
     */
    @RequestMapping(value = "/copyActivityRuleById/{id}", method = RequestMethod.GET)
    public ResultBase<String> copyActivityRuleById(@PathVariable("id") Long id) {
        log.info("{}-into /copyActivityRuleById,id:{}", ThreadLocalUtil.getRequestNo(), id);
        ResultBase<String> result = activityRuleServiceImpl.copyActivityRuleById(id);
        log.info("{}-/copyActivityRuleById return:{}", ThreadLocalUtil.getRequestNo(), JSON.toJSONString(result));
        return result;
    }
}
