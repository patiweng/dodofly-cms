package com.zhongan.app.run.cms.dao.qrcode;

import java.util.List;

import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultSalesDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdSalesDO;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

/**
 * 机构业务员管理 Dao层
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Component
public interface BububaoThirdSalesDao {

    /**
     * 根据业务员id删除业务员信息
     * 
     * @param id
     * @return
     */
    Integer deleteByPrimaryKey(Long id);

    /**
     * 保存业务员信息
     * 
     * @param record
     * @return
     */
    Integer insert(BububaoThirdSalesDO record);

    /**
     * 保存业务员信息
     * 
     * @param record
     * @return
     */
    Integer insertSelective(BububaoThirdSalesDO record);

    /**
     * 根据业务员id查询业务员信息
     * 
     * @param id
     * @return
     */
    BububaoThirdSalesDO selectByPrimaryKey(Long id);

    /**
     * 更新业务员信息
     * 
     * @param record
     * @return
     */
    Integer updateByPrimaryKeySelective(BububaoThirdSalesDO record);

    /**
     * 根据业务员id更新业务员信息
     * 
     * @param record
     * @return
     */
    Integer updateByPrimaryKey(BububaoThirdSalesDO record);

    /**
     * 根据条件查询业务员信息
     * 
     * @param record
     * @return
     */
    public List<BububaoThirdSalesDO> selectDataByCdt(BububaoThirdSalesDO record);

    /**
     * 根据业务员code、机构id、父级业务员id查询业务员信息
     * 
     * @param salesCode
     * @param orgId
     * @param parentSalesId
     * @return
     */
    public List<BububaoThirdSalesDO> selectByCodeAndOrgId(@Param("salesCode") String salesCode,
                                                             @Param("orgId") Long orgId,
                                                             @Param("parentSalesId") Long parentSalesId);

    /**
     * 逻辑删除业务员
     * 
     * @param id
     * @param modifier
     */
    public void deleteBySalesId(@Param("id") Long id, @Param("modifier") String modifier);

    /**
     * 根据业务员id查询业务员编号
     * 
     * @param id
     * @return
     */
    public String selectSalesCodeById(Long id);

    /**
     * 五级机构业务员分页查询
     * @param paramDto
     * @return
     */
    List<ResultSalesDto> selectSalessPage(ParamDto paramDto);

    /**
     * 五级机构业务员查询总数
     * @param paramDto
     * @return
     */
    Integer selectSalessCount(ParamDto paramDto);
}
