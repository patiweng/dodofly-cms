package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierHelpPayResDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeResDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.service.ICashierHelpPayService;
import com.zhongan.app.run.cms.service.ICashierPayTradeService;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类CashierPayTradeController.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年1月29日 下午2:31:59
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/cashierPayTrade")
public class CashierPayTradeController {

    @Resource
    private ICashierPayTradeService  cashierPayTradeService;

    @Resource
    private ICashierHelpPayService   cashierHelpPayService;

    @Resource
    private RunChannelListRepository runChannelListRepository;

    @RequestMapping(value = "/queryCashierPayTradeList")
    public ModelAndView selectActivityPresentListPage(CashierPayTradeQueryDTO queryDTO) {
        log.info("CashierPayTradeController selectActivityPresentListPage param{}", JSON.toJSONString(queryDTO));
        ModelAndView modelAndView = new ModelAndView("cms/cashierPayTrade");
        try {
            PageDTO<CashierPayTradeResDTO> pageDTO = cashierPayTradeService.queryCashierPayTradeList(queryDTO);
            modelAndView.addObject("page", pageDTO);
            modelAndView.addObject("totalPage", pageDTO.getTotalPage());
            modelAndView.addObject("cashierPayTradeList", pageDTO.getResultList());
            modelAndView.addObject("cashierPayTradeQueryDTO", queryDTO);
            //渠道信息
            RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
            ResultBase<List<RunChannelListDTO>> resultchannel = runChannelListRepository
                    .selectRunChannelListDataList(runChannelListRepo);
            modelAndView.addObject("channelList", resultchannel.getValue());
        } catch (Exception e) {
            log.info("CashierPayTradeController selectActivityPresentListPage param{} exception{}",
                    JSON.toJSONString(queryDTO), e);
        }
        return modelAndView;
    }

    @RequestMapping(value = "/saveOrUpdateCashierPayTrade", method = RequestMethod.POST)
    public ResultBase<Long> saveOrUpdateCashierPayTrade(@RequestBody CashierPayTradeDTO payTradeDTO) {
        log.info("CashierPayTradeController saveOrUpdateCashierPayTrade param{}", JSON.toJSONString(payTradeDTO));
        ResultBase<Long> resultBase = new ResultBase<Long>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierPayTradeService.saveOrUpdateCashierPayTrade(payTradeDTO));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierHelpPayController saveOrUpdateCashierHelpPay param{} exception{}",
                    JSON.toJSONString(payTradeDTO), e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            return resultBase;
        }
    }

    @RequestMapping(value = "/queryCashierPayTradeByCondition", method = RequestMethod.POST)
    public ResultBase<CashierPayTradeResDTO> queryCashierPayTradeByCondition(@RequestBody CashierPayTradeDTO payTradeDTO) {
        log.info("CashierPayTradeController queryCashierPayTrade param{}", JSON.toJSONString(payTradeDTO));
        ResultBase<CashierPayTradeResDTO> resultBase = new ResultBase<CashierPayTradeResDTO>();
        try {
            resultBase.setSuccess(Boolean.TRUE);
            resultBase.setValue(cashierPayTradeService.queryCashierPayTradeByCondition(payTradeDTO));
            return resultBase;
        } catch (Exception e) {
            log.info("CashierHelpPayController queryCashierPayTradeByPolicyNo param{} exception{}",
                    JSON.toJSONString(payTradeDTO), e);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            return resultBase;
        }
    }
}
