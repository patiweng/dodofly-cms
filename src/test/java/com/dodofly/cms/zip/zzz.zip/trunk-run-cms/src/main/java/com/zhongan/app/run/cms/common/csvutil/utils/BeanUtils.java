package com.zhongan.app.run.cms.common.csvutil.utils;

import com.zhongan.app.run.cms.common.csvutil.annotion.ValueFormat;
import com.zhongan.app.run.cms.common.csvutil.annotion.Property;
import com.zhongan.app.run.cms.common.csvutil.format.BooleanValueFormat;
import com.zhongan.app.run.cms.common.csvutil.format.DefaultValueFormat;

import lombok.extern.slf4j.Slf4j;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class BeanUtils {
    private static final Map<Class<?>, Map<String, PropertyDesc>> cache = new ConcurrentHashMap<Class<?>, Map<String, PropertyDesc>>();

    private static final DefaultValueFormat DEFAULTCELLVALUEFORMAT = new DefaultValueFormat();

    public static Map<String, PropertyDesc> getBeanAnnotion(Class<?> clazz) {
        Map<String, PropertyDesc> map = cache.get(clazz);
        if (map != null) {
            return map;
        }

        try {
            map = new LinkedHashMap<String, PropertyDesc>();

            PropertyDescriptor[] ps = Introspector.getBeanInfo(clazz).getPropertyDescriptors();
            Map<String, PropertyDescriptor> tempPsMap = new HashMap<String, PropertyDescriptor>();
            for (PropertyDescriptor pd : ps) {
                tempPsMap.put(pd.getName(), pd);
            }

            Field[] fields = clazz.getDeclaredFields();
            List<PropertyDesc> listPD = new ArrayList<PropertyDesc>(fields.length);

            for (Field field : fields) {
                Property property = field.getAnnotation(Property.class);
                if (property != null) {
                    listPD.add(new PropertyDesc(tempPsMap.get(field.getName()), property));
                }
            }

            // 排序
            Collections.sort(listPD, new Comparator<PropertyDesc>() {
                @Override
                public int compare(PropertyDesc o1, PropertyDesc o2) {
                    return o1.getOrder() - o2.getOrder();
                }
            });

            for (PropertyDesc p : listPD) {
                map.put(p.getTitle(), p);
            }
            cache.put(clazz, map);
            return map;
        } catch (Exception e) {
            log.error("error",e);
            throw new RuntimeException("未知异常", e);
        }
    }

    public static class PropertyDesc {

        private Class<?> propertyClass;

        private String propertyName;
        private Method readMethod;
        private Method writeMethod;

        private Property property;

        private ValueFormat valueFormat;

        public PropertyDesc(PropertyDescriptor pd, Property property) {
            this.propertyClass = pd.getPropertyType();
            this.readMethod = pd.getReadMethod();
            this.writeMethod = pd.getWriteMethod();
            this.property = property;
            this.propertyName = pd.getName();
            Class<? extends ValueFormat> clazz = property.format();
            if (clazz == DefaultValueFormat.class) {

                if("".equals(property.formatParam())){
                    this.valueFormat = DEFAULTCELLVALUEFORMAT;
                }else{
                    this.valueFormat = new BooleanValueFormat();
                }

            } else if(clazz == BooleanValueFormat.class){
                this.valueFormat = new BooleanValueFormat();
            }else{
                try {
                    this.valueFormat = clazz.newInstance();
                } catch (Exception e) {
                    log.error("error",e);
                    throw new RuntimeException("构造格式化类初始化失败 class " + clazz.getName(), e);
                }
            }
            this.valueFormat.setFormatParam(property.formatParam());
        }

        public String getTitle() {
            return this.property.title();
        }

        public int getOrder() {
            return this.property.order();
        }

        /**
         *
         * @param t
         * @param obj
         * @return  成功设置值得话返回true  如果值为空的话 返回false;
         */
        public boolean setValue(Object t, Object obj) {

            Object value = this.valueFormat.readFormat(obj, propertyClass, this.propertyName);
            if (value == null) {
                return false;
            }

            try {
                this.writeMethod.invoke(t, new Object[] { value });
                return true;
            } catch (Exception e) {
                log.error("error",e);
                throw new RuntimeException("写入属性失败", e);
            }
        }

        /**
         * 去掉小数点
         * @param t
         * @return
         */
        public String getValue(Object t) {
            try {
                String value = this.valueFormat
                        .writeFormat(this.readMethod.invoke(t, new Object[] {}), this.propertyClass, this.propertyName);
                if (value == null) {
                    value = "";
                }
                return value.toString();
            } catch (Exception e) {
                log.error("error",e);
                throw new RuntimeException("读取属性失败", e);
            }
        }

    }
}
