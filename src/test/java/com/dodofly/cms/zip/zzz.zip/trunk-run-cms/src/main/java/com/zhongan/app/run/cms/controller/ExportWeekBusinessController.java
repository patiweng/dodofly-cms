package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.WeekBusinessDTO;
import com.zhongan.app.run.cms.bean.web.WeekBusinessPageDTO;
import com.zhongan.app.run.cms.service.ExportWeekBusinessService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/excelbusiness")
@Slf4j
public class ExportWeekBusinessController {

    @Resource
    private ExportWeekBusinessService exportWeekBusinessServiceImpl;

    /**
     * 分页查询
     * 
     * @param request
     * @param weekBusinessDTO
     * @return
     */
    @RequestMapping(value = "/select/selectweekbusinesslistpage")
    public ModelAndView selectWeekBusinessListPage(HttpServletRequest request, WeekBusinessDTO weekBusinessDTO) {
        log.info("{}-into /select/selectweekbusinesslistpage,param={ " + weekBusinessDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<WeekBusinessDTO> weekBusinessPage = new Page<WeekBusinessDTO>(weekBusinessDTO.getPageSize(),
                weekBusinessDTO.getCurrentPage());
        weekBusinessPage.setParam(weekBusinessDTO);
        WeekBusinessPageDTO result = exportWeekBusinessServiceImpl.selectWeekBusinessList(weekBusinessPage);
        weekBusinessPage = result.getWeekBusinessPageDTO();
        Map<String, Object> model = Maps.newHashMap();
        if (null != weekBusinessPage) {
            model.put("weekBusinessList", weekBusinessPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("weekBusinessDTO", weekBusinessDTO);
        model.put("page", weekBusinessPage);
        return new ModelAndView("cms/weekBusiness", model);
    }

    @RequestMapping(value = "/select/doexportexcelweekbusiness", method = RequestMethod.GET)
    public void doExportExcelWeekBusiness(HttpServletResponse response) {
        log.info("{}-/doExportExcelWeekBusiness,doExportExcelBusiness start……", ThreadLocalUtil.getRequestNo());
        exportWeekBusinessServiceImpl.doExportExcelWeekBusiness(response);
    }

}
