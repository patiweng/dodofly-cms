package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.QuestionListDO;

@Component
public interface QuestionListDAO {

    /**
     * 根据id查询
     * 
     * @param id
     * @return
     */
    QuestionListDO selectDataById(Long id);

    /**
     * 根据条件查询
     * 
     * @param questionListDO
     * @return
     */
    List<QuestionListDO> selectDataByCdt(QuestionListDO questionListDO);

    /**
     * 分页查询QuestionList信息
     * 
     * @param map
     * @return
     */
    List<QuestionListDO> selectQuestionList(Map map);

    /**
     * 查询QuestionList条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 插入数据
     * 
     * @param questionListDO
     */
    void insert(QuestionListDO questionListDO);

    /**
     * 更新数据
     * 
     * @param questionListDO
     */
    void update(QuestionListDO questionListDO);

    /**
     * 更新数据为无效数据
     * 
     * @param id
     */
    void updateDeletedById(String id);
}
