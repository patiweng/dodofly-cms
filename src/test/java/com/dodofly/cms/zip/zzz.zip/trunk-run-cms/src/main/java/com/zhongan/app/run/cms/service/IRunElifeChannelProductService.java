package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductResDTO;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类IRunElifeChannelProductService.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月28日 下午2:19:13
 */
public interface IRunElifeChannelProductService {

    /**
     * 查询列表
     * 
     * @param dto
     * @return
     */
    public PageDTO<RunElifeChannelProductResDTO> queryList(RunElifeChannelProductQueryDTO dto) throws Exception;

    /**
     * 保存或更新
     * 
     * @param dto
     * @return
     */
    public Integer saveOrUpdate(RunElifeChannelProductDTO dto) throws Exception;

    /**
     * 根据条件查询
     * 
     * @param dto
     * @return
     */
    public List<RunElifeChannelProductResDTO> queryByCondition(RunElifeChannelProductDTO dto) throws Exception;

    /**
     * 根据主键查询
     * 
     * @param id
     * @return
     * @throws Exception
     */
    public RunElifeChannelProductResDTO queryById(Long id) throws Exception;

    /**
     * 查询总数
     * 
     * @param dto
     * @return
     */
    public Integer getCount(RunElifeChannelProductDTO dto) throws Exception;

    /**
     * 删除记录
     * 
     * @param id
     * @return
     */
    public Integer deleteById(Long id) throws Exception;

}
