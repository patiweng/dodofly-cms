package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class RunUserPassWdEditDTO {
	
	private String id;
	private String oldPassWd;
	private String newPassWd;
	private String operator;
	private String errMsg;
}
