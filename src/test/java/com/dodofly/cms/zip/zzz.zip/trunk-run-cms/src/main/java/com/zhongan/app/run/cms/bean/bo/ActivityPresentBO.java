package com.zhongan.app.run.cms.bean.bo;

import lombok.Data;

@Data
public class ActivityPresentBO {
    private String id;
    private String activityId;
    private String presentId;
    private String presentNumber;
    private String havePresentedNumber;
    private String presentOrder;
    private String isRepeated;
    private String creator;
    private String modifier;
    private String createTime;
    private String modifyTime;
    private String isDeleted;
}
