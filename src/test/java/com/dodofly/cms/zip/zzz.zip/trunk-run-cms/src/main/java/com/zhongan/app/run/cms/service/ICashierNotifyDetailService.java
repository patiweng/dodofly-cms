package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.CashierNotifyDetailDTO;

/**
 * 类ICashierNotifyDetailService.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年9月19日 下午2:46:22
 */
public interface ICashierNotifyDetailService {

    public Long saveOrUpdate(CashierNotifyDetailDTO dto) throws Exception;

    public List<CashierNotifyDetailDTO> queryByCondition(CashierNotifyDetailDTO dto);
}
