package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

/**
 * 返回数据
 * 
 * @author lichao002
 * @date 2018-06-04
 */
@Data
public class ResultDto<T> {

    /**
     * 返回value
     */
    private T       value;

    /**
     * 处理是否正确
     */
    private boolean isSuccess;

    /**
     * 返回信息
     */
    private String  message;

    /**
     * 返回信息code
     */
    private String  code;

    /**
     * 当前页
     */
    private Integer currentPage;

    /**
     * 每页条数
     */
    private Integer pageSize;

    /**
     * 总条数
     */
    private Integer totleSize;

    /**
     * 总页数
     */
    private Integer totlePage;
}
