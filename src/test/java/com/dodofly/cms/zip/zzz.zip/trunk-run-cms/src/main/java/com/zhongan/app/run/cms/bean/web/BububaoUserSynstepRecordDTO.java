package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

import com.zhongan.app.run.cms.bean.page.PageInfo;

@Data
public class BububaoUserSynstepRecordDTO extends PageInfo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
    private Long              id;

    /**
     * 用户id
     */
    private Long              unionid;

    /**
     * 用户来原表id
     */
    private Long              userid;

    /**
     * 用户活动渠道来源
     */
    private String            channelFrom;

    /**
     * 对应步数的时期
     */
    private Date              date;

    /**
     * 用户每一次登陆进来的步数
     */
    private String            steps;

    private String            creator;

    private String            modifier;

    private Date              gmtCreated;

    private Date              gmtModified;

    /**
     * 是否删除
     */
    private String            isDeleted;

    /**
     * 扩展信息
     */
    private String            extraInfo;

    /**
     * 删除之前的数据
     */
    private Date              deleteDate;

}
