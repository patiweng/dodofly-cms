package com.zhongan.app.run.cms.common.enums;

public enum AppErrEnum {

    /**************** 登录模块 ********************/
    ERROR_USERLOGIN_100001("CS100001", "用户名或密码错误"),
    ERROR_USERLOGIN_100002("CS100002", "入参不能为空"),
    ERROR_USERLOGIN_100003("CS100003", "用户名不能为空"),
    ERROR_USERLOGIN_100004("CS100004", "密码不能为空"),
    ERROR_USERLOGIN_100005("CS100005", "密码加密失败"),
    ERROR_USERLOGIN_100006("CS100006", "密码更新失败"),
    ERROR_USERLOGIN_100007("CS100007", "营销活动id不能为空"),
    ERROR_USERLOGIN_100008("CS100008", "用户id不能为空"),
    ERROR_USERLOGIN_100009("CS100009", "渠道号不能为空"),
    ERROR_USERLOGIN_100010("CS100010", "渠道名稱不能为空"),
    ERROR_USERLOGIN_100011("CS100011", "MD5加密异常"),
    ERROR_USERLOGIN_100012("CS100012", "用户当前步数不能为空"),
    /**************** 权限模块 ********************/
    ERROR_USERAURHORITY_100101("CS100101", "入参不能为空"),
    ERROR_USERAURHORITY_100102("CS100102", "生成序列异常"),
    ERROR_USERAURHORITY_200001("CS200001", "文件上传失败"),
    /**************** 错误模块 ********************/
    SUCCESS_RUNUSER_00001("CS-0", "注册成功"),
    ERROR_RUNUSER_00001("CS-1", "注册失败"),
    SUCCESS_RUNUSER_10001("CS-0", "插入成功"),
    ERROR_RUNUSER_10001("CS-1", "插入失败"),
    ERROR_RUNUSER_10002("CS-1", "插入失败,该组合已存在！"),
    ERROR_RUNUSER_10003("CS-1", "插入失败,渠道编码已存在！"),
    ERROR_RUNUSER_10004("CS-1", "插入失败,渠道编码的改活动类型已存在！"),
    ERROR_RUNUSER_10005("CS-1", "插入失败,渠道编码不存在！"),
    SUCCESS_RUNUSER_00002("CS-0", "查询成功"),
    ERROR_RUNUSER_00002("CS-1", "查询失败"),
    SUCCESS_RUNUSER_NO_DATA("CS-100", "未查到数据"),
    SUCCESS_RUNUSER_00003("CS-0", "修改成功"),
    ERROR_RUNUSER_00003("CS-1", "修改失败"),
    SUCCESS_RUNUSER_00004("CS-0", "删除成功"),
    ERROR_RUNUSER_00004("CS-1", "删除失败"),
    /**************** 权限模块 ********************/
    ERROR_USERCREATE_100201("CS100201", "该用户名已存在"),
    ERROR_USERCREATE_00("CS00", "处理成功"),
    /********************* 二维码推广 ****************************/
    SUCCESS_QRCODE_20000("CS20000", "查询结果数据过多，请次日在“异步查询历史”中查看及下载"),
    DELETE_INFO_NULL("CS1001", "删除信息为空"),
    FILE_FORMAT_ERROR("CS3001", "文件格式错误"),
    DELETE_INFO_EXIST_INSURE("CS3002", "第%d条数据存在投保信息"),
    /********************* 系统全局 ****************************/
    SUCCESS_SYS_0000("CS0000", "成功"),
    ERROR_SYS_0001("CS0001", "系统异常"),
    ERROR_USERACTIVITY_20001("CS20001", "一级活动id不能为null"),
    ERROR_USERACTIVITY_20002("CS20002", "二级活动id不能为null"),
    ERROR_USERACTIVITY_20003("CS20003", "用户UnionId不能为null"),
    ERROR_USERACTIVITY_20004("CS20004", "用户渠道不能为null"),
    ERROR_USERACTIVITY_20005("CS20005", "被邀请人UnionId不能为null"),
    ERROR_USERACTIVITY_20006("CS20006", "用户来源id不能是空"),
    ERROR_USERACTIVITY_20007("CS20007", "用户保单信息为空"),
    ERROR_USERACTIVITY_20008("CS20008", "用户活动信息为空"),
    ERROR_USERACTIVITY_20009("CS20009", "被邀请人openid不能为null"),
    ERROR_USERACTIVITY_20010("CS20010", "时间为空"), ;

    private String code;
    private String value;

    private AppErrEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
