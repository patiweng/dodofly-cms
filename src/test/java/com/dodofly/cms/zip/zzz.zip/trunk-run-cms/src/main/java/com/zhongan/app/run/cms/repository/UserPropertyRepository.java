package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.zhongan.app.run.cms.bean.dataobject.UserPropertyDO;
import com.zhongan.app.run.cms.bean.repo.UserPropertyRepo;
import com.zhongan.app.run.cms.dao.UserPropertyDAO;

@Repository
public class UserPropertyRepository {

    @Resource
    private UserPropertyDAO userPropertyDAO;

    public List<UserPropertyRepo> selectDataByCdt(UserPropertyRepo userPropertyRepo) {
        UserPropertyDO userPropertyDO = new UserPropertyDO();
        BeanUtils.copyProperties(userPropertyRepo, userPropertyDO);
        List<UserPropertyDO> userPropertyDOs = userPropertyDAO.selectDataByCdt(userPropertyDO);
        List<UserPropertyRepo> userPropertyRepos = new ArrayList<UserPropertyRepo>();
        if (0 != userPropertyDOs.size()) {
            UserPropertyRepo userPropertyRepoOut = null;
            for (UserPropertyDO userPropertyDOOut : userPropertyDOs) {
                userPropertyRepoOut = new UserPropertyRepo();
                BeanUtils.copyProperties(userPropertyDOOut, userPropertyRepoOut);
                userPropertyRepos.add(userPropertyRepoOut);
            }
        }
        return userPropertyRepos;
    }

}
