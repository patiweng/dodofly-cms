package com.zhongan.app.run.cms.dao.qrcode;

import java.util.List;
import java.util.Map;

import com.zhongan.app.run.cms.bean.qrcode.model.BububaoExportLogDO;
import org.springframework.stereotype.Component;

/**
 * 导出管理 Dao层
 * 
 * @author lichao002
 * @date 2018-06-01
 */
@Component
public interface BububaoExportLogDao {

    /**
     * 根据id删除导出日志
     * 
     * @param id
     * @return
     */
    int deleteByPrimaryKey(Long id);

    /**
     * 保存导出日志
     * 
     * @param record
     * @return
     */
    int insert(BububaoExportLogDO record);

    /**
     * 保存导出日志
     * 
     * @param record
     * @return
     */
    int insertSelective(BububaoExportLogDO record);

    /**
     * 根据id查询导出日志
     * 
     * @param id
     * @return
     */
    BububaoExportLogDO selectByPrimaryKey(Long id);

    /**
     * 更新导出日志
     * 
     * @param record
     * @return
     */
    int updateByPrimaryKeySelective(BububaoExportLogDO record);

    /**
     * 根据id更新导出日志
     * 
     * @param record
     * @return
     */
    int updateByPrimaryKey(BububaoExportLogDO record);

    /**
     * 分页查询导出管理日志
     * 
     * @param map
     * @return
     */
    List<BububaoExportLogDO> selectExportLogListPage(Map<String, Object> map);

    /**
     * 查询数量
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map<String, Object> map);
}
