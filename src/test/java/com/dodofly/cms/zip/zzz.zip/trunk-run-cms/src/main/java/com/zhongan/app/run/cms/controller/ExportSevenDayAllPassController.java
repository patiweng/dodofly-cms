package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.service.ExportSevenDayAllPassService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/excelsevendayallpass")
@Slf4j
public class ExportSevenDayAllPassController {

    @Resource
    private ExportSevenDayAllPassService exportSevenDayAllPassServiceImpl;

    @RequestMapping(value = "/doexportexcelsevendayallpass/{sdate}/{edate}/{sourceCode}", method = RequestMethod.GET)
    public void doExportExcelSevenDayAllPass(HttpServletResponse response, @PathVariable String sdate,
                                             @PathVariable String edate, @PathVariable String sourceCode) {

        log.info("{}-/doExportExcelSevenDayAllPass,doExportExcelSevenDayAllPass start……",
                ThreadLocalUtil.getRequestNo());

        exportSevenDayAllPassServiceImpl.doExcelExportSevenDayAllPass(response, sdate, edate, sourceCode);

    }

    @RequestMapping(value = "/doexportexceltop100allsteps/{sdate}/{edate}/{sourceCode}", method = RequestMethod.GET)
    public void doExportExcelTop100AllSteps(HttpServletResponse response, @PathVariable String sdate,
                                            @PathVariable String edate, @PathVariable String sourceCode) {
        log.info("{}-/doExportExcelTop100AllSteps,doExportExcelTop100AllSteps start……", ThreadLocalUtil.getRequestNo());
        exportSevenDayAllPassServiceImpl.doExportExcelTop100AllSteps(response, sdate, edate, sourceCode);

    }

    @RequestMapping(value = "/selectsevendaypage", method = RequestMethod.GET)
    public ModelAndView selectSevenDayPage(HttpServletRequest request) {
        log.info("{}-into /selectSevenDayPage");
        Map<String, Object> model = Maps.newHashMap();
        model.put("sevenDayAllPassList", null);
        model.put("role", null);
        model.put("sevenDayAllPassDTO", null);
        model.put("page", null);
        return new ModelAndView("cms/sevenDayAllPass", model);
    }

}
