package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;

@Data
public class UserQuestionRepo {
    private Long   id;
    private Long   userId;
    private Long   queryId;
    private Long   itemId;
    private String itemType;
    private String itemValue;
    private String creator;
    private String modifier;
    private String createtime;
    private String modifytime;
    private String isDeleted;
}
