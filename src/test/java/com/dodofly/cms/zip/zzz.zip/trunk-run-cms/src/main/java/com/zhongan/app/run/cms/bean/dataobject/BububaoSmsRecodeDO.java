package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoSmsRecodeDO {
	
	 private String id;
	 private String phones;
	 private String status;
	 private String type;
	 private String templateNo;
	 private String sendTime;
	 private String parameters;
	 private String errorCode;
	 private String createTime;
	 private String modifyTime;

}
