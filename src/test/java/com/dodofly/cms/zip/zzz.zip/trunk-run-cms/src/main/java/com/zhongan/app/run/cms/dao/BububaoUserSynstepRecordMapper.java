package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.BububaoUserSynstepRecordCriteria;
import com.zhongan.app.run.cms.dao.bean.BububaoUserSynstepRecordDO;

@Component
public interface BububaoUserSynstepRecordMapper {

    /**
     * 根据条件查询数据总数
     * 
     * @return
     */
    long countByExample(BububaoUserSynstepRecordCriteria example);

    int deleteByExample(BububaoUserSynstepRecordCriteria example);

    int deleteByPrimaryKey(Long id);

    int insert(BububaoUserSynstepRecordDO record);

    int insertSelective(BububaoUserSynstepRecordDO record);

    List<BububaoUserSynstepRecordDO> selectByExample(BububaoUserSynstepRecordCriteria example);

    BububaoUserSynstepRecordDO selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") BububaoUserSynstepRecordDO record,
                                 @Param("example") BububaoUserSynstepRecordCriteria example);

    int updateByExample(@Param("record") BububaoUserSynstepRecordDO record,
                        @Param("example") BububaoUserSynstepRecordCriteria example);

    int updateByPrimaryKeySelective(BububaoUserSynstepRecordDO record);

    int updateByPrimaryKey(BububaoUserSynstepRecordDO record);

    List<BububaoUserSynstepRecordDO> selectByCriteriaWithPage(@Param("example") BububaoUserSynstepRecordCriteria example,
                                                              @Param("pageInfo") PageInfo pageInfo);

    int deleteBySelective(BububaoUserSynstepRecordDO record);
}
