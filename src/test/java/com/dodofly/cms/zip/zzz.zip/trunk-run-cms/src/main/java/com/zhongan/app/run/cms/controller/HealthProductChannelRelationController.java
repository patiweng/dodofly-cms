package com.zhongan.app.run.cms.controller;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.bo.HealthProductChannelRelationBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationDTO;
import com.zhongan.app.run.cms.bean.web.HealthProductChannelRelationPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.service.HealthProductChannelRelationService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@RestController
@RequestMapping("/run/cms/health/campaign")
@Slf4j
public class HealthProductChannelRelationController {

    @Resource
    private HealthProductChannelRelationService healthProductChannelRelationServiceImpl;

    /**
     * cms营销活动信息查询C003 (根据营销活动ID 查询营销活动名称)(根据渠道编码、步数查询保额)(公共)p1
     * 
     * @return
     */

    @RequestMapping(value = "/select/campaignlist", method = RequestMethod.POST)
    public ResultBase<List<HealthProductChannelRelationDTO>> selectRelation(@RequestBody HealthProductChannelRelationDTO healthProductChannelRelationDTO) {
        log.info("{}-/select/campaignlist...p1,param={" + healthProductChannelRelationDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<List<HealthProductChannelRelationDTO>> result = new ResultBase<List<HealthProductChannelRelationDTO>>();
        HealthProductChannelRelationBO healthProductChannelRelationBO = new HealthProductChannelRelationBO();
        BeanUtils.copyProperties(healthProductChannelRelationDTO, healthProductChannelRelationBO);
        result = healthProductChannelRelationServiceImpl.selectCampaignInfo(healthProductChannelRelationBO);
        log.info("{}-/select/campaignlist...p1  return,data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * cms营销活动信息查询（分页）
     * 
     * @return
     */

    @RequestMapping(value = "/select/campaigninfopage")
    public ModelAndView selectcampaigninfopage(HealthProductChannelRelationDTO healthProductChannelRelationDTO,
                                               HttpServletRequest request) {
        log.info("{}-into /select/campaigninfopage, param={ " + healthProductChannelRelationDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<HealthProductChannelRelationDTO> healthProductChannelRelationDTOPage = new Page<HealthProductChannelRelationDTO>(
                healthProductChannelRelationDTO.getPageSize(), healthProductChannelRelationDTO.getCurrentPage());
        healthProductChannelRelationDTOPage.setParam(healthProductChannelRelationDTO);
        HealthProductChannelRelationPageDTO result = healthProductChannelRelationServiceImpl
                .selectCampaigninfoPage(healthProductChannelRelationDTOPage);
        healthProductChannelRelationDTOPage = result.getHealthCampaignListDTOPage();

        Map<String, Object> model = Maps.newHashMap();
        if (null != healthProductChannelRelationDTOPage) {
            model.put("healthProductChannelRelation", healthProductChannelRelationDTOPage.getResultList());
        }
        //将活动类型转换
        for (RunChannelListDTO runChannelListDTO : result.getRunChannelListDTOList()) {
            if (runChannelListDTO.getType().equals(RunConstants.IS_ZHONGJI)) {
                runChannelListDTO.setTypeName(RunConstants.IS_ZHONGJI_NAME);
            } else {
                runChannelListDTO.setTypeName(RunConstants.IS_YIWAI);
            }
        }
        model.put("role", result.getRole());
        model.put("healthProductChannelRelationDTO", healthProductChannelRelationDTO);
        model.put("page", healthProductChannelRelationDTOPage);
        model.put("channelList", result.getRunChannelListDTOList());
        log.info("{}-/select/campaigninfopage return, data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return new ModelAndView("cms/health_campaign_list", model);
    }

    /**
     * cms营销活动信息修改和添加
     * 
     * @return
     */

    @RequestMapping(value = "/updateorinset", method = RequestMethod.POST)
    public ResultBase<String> updateOrInsertCampaignList(HealthProductChannelRelationDTO healthProductChannelRelationDTO) {
        log.info("{}-/updateorinset,param={" + healthProductChannelRelationDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        Map<String, Object> model = Maps.newHashMap();
        if ("".equals(healthProductChannelRelationDTO.getId())) {
            healthProductChannelRelationDTO.setId(null);
        }
        model.put("healthProductChannelRelationDTO", healthProductChannelRelationDTO);
        //新建
        if (null == healthProductChannelRelationDTO.getId()) {
            result = healthProductChannelRelationServiceImpl.insertCampaignList(healthProductChannelRelationDTO);
            //修改  
        } else {
            result = healthProductChannelRelationServiceImpl.updateCampaignList(healthProductChannelRelationDTO);
        }
        log.info("{}-/updateorinset  return,data={" + result.toString() + "}", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * cms营销活动信息删除
     * 
     * @return
     */

    @RequestMapping(value = "/delete/campaignlist/{id}", method = RequestMethod.GET)
    public ResultBase<String> deleteCampaignListOne(@PathVariable String id) {
        log.info("{}-/delete/delete/campaignlist/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        if (id != null) {
            result = healthProductChannelRelationServiceImpl.deleteCampaignList(id);
        }
        log.info("{}-/delete/delete/campaignlist/{id} return, data={" + result.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * cms营销活动根据ID 查询结果信息
     * 
     * @return
     */

    @RequestMapping(value = "/selectone/campaignlistone/{id}", method = RequestMethod.GET)
    public HealthProductChannelRelationDTO selectCampaignListOne(@PathVariable String id) {
        log.info("{}-/selectone/campaignlist/{id}, param={ " + id.toString() + " }", ThreadLocalUtil.getRequestNo());
        HealthProductChannelRelationDTO healthProductChannelRelationDTO = new HealthProductChannelRelationDTO();
        if (id != null) {
            healthProductChannelRelationDTO = healthProductChannelRelationServiceImpl.selectOneCampaignList(id);
        }
        log.info("{}-/selectone/campaignlist/{id} return, data={" + healthProductChannelRelationDTO.toString() + "}",
                ThreadLocalUtil.getRequestNo());
        return healthProductChannelRelationDTO;
    }

}
