package com.zhongan.app.run.cms.service.client;

import java.util.List;

import org.springframework.cloud.netflix.feign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.zhongan.app.run.cms.bean.client.UserSourceCountClient;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserInsuranceDTO;

@FeignClient(name = "za-run-policy", url = "${za.run.policy.feignclient.url}")
public interface RunPolicyFeignClient {
    @RequestMapping(value = "/run/policy/business/queryuserinsurebydate/{userDate}", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryUserInsureByDate(@PathVariable("userDate") String userDate);

    @RequestMapping(value = "/run/policy/business/queryuserinsureall", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryUserInsureAll();

    @RequestMapping(value = "/run/policy/business/queryinsurancebydateallmonth/{sdate}/{edate}", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryInsuranceByDateAllMonth(@PathVariable("sdate") String sdate,
                                                                                @PathVariable("edate") String edate);

    @RequestMapping(value = "/run/policy/business/queryinsurancebydateallmonthedate/{edate}", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryInsuranceByDateAllMonthEdate(@PathVariable("edate") String edate);

    @RequestMapping(value = "/run/policy/business/queryinsurancebydateallmonthsdate/{sdate}", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryInsuranceByDateAllMonthSdate(@PathVariable("sdate") String sdate);

    @RequestMapping(value = "/run/policy/business/queryuserinsureallmonth", method = RequestMethod.GET)
    public ResultBase<List<UserSourceCountClient>> queryUserInsureAllMonth();

    @RequestMapping(value = "/run/policy/select/selectpolicybycdt", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResultBase<UserInsuranceDTO> selectPolicyByCdt(UserInsuranceDTO userInsuranceDTO);

}
