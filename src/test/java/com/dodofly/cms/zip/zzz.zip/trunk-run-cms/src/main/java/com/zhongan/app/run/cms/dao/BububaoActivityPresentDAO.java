package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityPresentDO;

@Component
public interface BububaoActivityPresentDAO {

    /**
     * 根据条件查询数据
     * 
     * @return
     */
    List<BububaoActivityPresentDO> selectDataByCdt(BububaoActivityPresentDO bububaoActivityPresentDO);
    /**
     * 根据条件查询数据 --新--缓存专用
     * 
     * @return
     */
    List<BububaoActivityPresentDO> selectDataByCdtNew(BububaoActivityPresentDO bububaoActivityPresentDO);

    /**
     * 根据id查询数据
     * 
     * @param id
     * @return
     */
    BububaoActivityPresentDO selectOneDataById(String id);
    /**
     * 更新数据为无效数据
     * 
     * @param id
     */
    void updateByid(String id);
    /**
     * 更新数据为无效数据 (先删除礼物列表后)
     * 
     * @param 礼物id
     */
    void updateByPresentid(String id);
    /**
     * 插入数据
     * 
     * @param BububaoActivityPresentDO
     */
    void insert(BububaoActivityPresentDO bububaoActivityPresentDO);
    /**
     * 分页查询BububaoActivitypresentDO信息
     * 
     * @param map
     * @return
     */
    List<BububaoActivityPresentDO> selectActivityPresentList(Map map);
    /**
     * 查询BububaoctivitypresentDO条数
     * 
     * @param map
     * @return
     */
    Integer selectCounts(Map map);

    /**
     * 更新数据
     * 
     * @param BububaoActivityPresentDO
     */
    void update(BububaoActivityPresentDO bububaoActivityPresentDO);

    /**
     * 更新数据 或奖次数 +1
     * 
     * @param BububaoActivityDO
     */
    void updateById(String id);
}
