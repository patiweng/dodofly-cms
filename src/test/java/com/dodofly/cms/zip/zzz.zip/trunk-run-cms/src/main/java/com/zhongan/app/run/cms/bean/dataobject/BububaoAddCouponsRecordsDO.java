package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoAddCouponsRecordsDO {

	 private String id ;    // 主键
	 private String unionId;
	 private String couponId;  //添加的优惠券的id
	 private String coupon; // 添加的优惠券的金额
	 private String smsinput;//短信输入信息
	 private String smsoutput;// 短信发送返回结果
	 private String status;// 添加优惠券状态：0:初始化;1:添加成功;2:添加失败;3:发送短信失败;4:添加并发送短信成功;
	 private String createTime;// 创建时间
	 private String modifyTime;//	 修改时间
	 	
}
