package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class QuestionItemCheck {
    private String inputType;
    private String allowBlank;
    private String blankText;
    private String maxLength;
    private String maxLengthText;
    private String minLength;
    private String minLengthText;
    private String maxValue;
    private String maxValueText;
    private String minValue;
    private String minValueText;
}
