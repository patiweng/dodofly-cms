package com.zhongan.app.run.cms.controller;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserInviteInfoDTO;
import com.zhongan.app.run.cms.service.UserInviteService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 瓜分奖励活动 用户好友邀请
 * 
 * @author yangzhen001
 */
@Slf4j
@RestController
@RequestMapping("/run/cms/activity")
public class UserInviteController {

    @Resource
    private UserInviteService userInviteServiceImpl;

    /**
     * /查询用户邀请好友列表
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/queryFriendsListByCdt", method = RequestMethod.POST)
    public ResultBase<List<UserInviteInfoDTO>> queryFriendsListByCdt(@RequestBody UserInviteInfoDTO info) {
        log.info("{}-into /queryFriendsList, param={UserActivityInfoDTO= " + JSONObject.toJSONString(info) + " }",
                ThreadLocalUtil.getRequestNo());
        ResultBase<List<UserInviteInfoDTO>> resultBase = userInviteServiceImpl.queryFriendsListByCdt(info);
        log.info("{}-/queryFriendsList return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * /跟新或插入好友信息
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/useFriendJoin", method = RequestMethod.POST)
    public ResultBase<String> useFriendJoin(@RequestBody UserInviteInfoDTO info) {
        log.info("{}-into /useFriendJoin, param={UserActivityInfoDTO= " + JSONObject.toJSONString(info) + " }",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = userInviteServiceImpl.useFriendJoin(info);
        log.info("{}-/useFriendJoin return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 单纯插入
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/insertFriendInfo", method = RequestMethod.POST)
    public ResultBase<String> insertFriendInfo(@RequestBody UserInviteInfoDTO info) {
        log.info("{}-into /insertFriendInfo, param={UserActivityInfoDTO= " + JSONObject.toJSONString(info) + " }",
                ThreadLocalUtil.getRequestNo());
        ResultBase<String> resultBase = userInviteServiceImpl.insertFriendInfo(info);
        log.info("{}-/insertFriendInfo return, data={" + resultBase + "}", ThreadLocalUtil.getRequestNo());
        return resultBase;
    }

    /**
     * 判断或插入
     * 
     * @param info
     * @return
     */
    @RequestMapping(value = "/inseOrJudgeIsInvite", method = RequestMethod.POST)
    public ResultBase<Boolean> inseOrJudgeIsInvite(@RequestBody UserInviteInfoDTO info) {
        log.info("{}-into /inseOrJudgeIsInvite, param:{}", JSONObject.toJSONString(info),
                ThreadLocalUtil.getRequestNo());
        ResultBase<Boolean> resultBase = userInviteServiceImpl.inseOrJudgeIsInvite(info);
        log.info("{}-/inseOrJudgeIsInvite return, data={}", ThreadLocalUtil.getRequestNo(),
                JSONObject.toJSONString(resultBase));
        return resultBase;
    }
}
