package com.zhongan.app.run.cms.bean.web;

import java.io.Serializable;
import java.util.Date;

import lombok.Data;

/**
 * 被邀请用户信息
 * 
 * @author yangzhen001
 */
@Data
public class UserInviteInfoDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long              id;
    /** 用户id */
    private Long              unionid;
    /**
     * 用户openid
     */
    private String            openid;
    /** 被邀请用户来源 */
    private String            channelFrom;
    /** 被邀请活动来源 */
    private String            activityType;
    /** 一级活动id */
    private String            activityId;
    /** 被邀请用户在来源方的Openid */
    private String            joinOpenid;
    /** 被邀请用户id */
    private Long              joinUnionid;
    /** 昵称 */
    private String            nickName;
    /** 头像 */
    private String            headimgurl;
    /** 实现日期 */
    private Date              gmtCreated;
    /** 与要邀请人关系 */
    private String            relation;
    /** 好友生效状态 */
    private String            state;

}
