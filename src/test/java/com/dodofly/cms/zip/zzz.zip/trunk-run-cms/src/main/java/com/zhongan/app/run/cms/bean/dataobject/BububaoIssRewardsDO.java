package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;

@Data
public class BububaoIssRewardsDO {

	 private String id;
	 private String activityId;
	 private String unionId;
	 private String award;
	 private String date;
	 private String payment;
	 private String name;
	 private String address;
	 private String phone;
	 private String createTime;
	 private String modifytime;
}
