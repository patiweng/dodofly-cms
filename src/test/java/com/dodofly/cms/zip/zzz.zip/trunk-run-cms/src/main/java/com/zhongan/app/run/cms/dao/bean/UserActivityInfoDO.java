package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class UserActivityInfoDO {
    /**
     * 主键 This field corresponds to the column bububao_user_activity_info.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 用户id This field corresponds to the column bububao_user_activity_info.unionid
     *
     * @mbggenerated
     */
    private Long   unionid;

    /**
     * 用户活动渠道来源 This field corresponds to the column
     * bububao_user_activity_info.channel_from
     *
     * @mbggenerated
     */
    private String channelFrom;

    /**
     * 一级活动id This field corresponds to the column
     * bububao_user_activity_info.activity_id
     *
     * @mbggenerated
     */
    private String activityId;

    /**
     * 二级活动id This field corresponds to the column
     * bububao_user_activity_info.children_id
     *
     * @mbggenerated
     */
    private String childrenId;

    /**
     * 该场活动用户投入的积分 This field corresponds to the column
     * bububao_user_activity_info.input_point
     *
     * @mbggenerated
     */
    private String inputPoint;

    /**
     * 该场活动结束用户获取的积分 This field corresponds to the column
     * bububao_user_activity_info.gain_point
     *
     * @mbggenerated
     */
    private String gainPoint;

    /**
     * 活动开始时间 This field corresponds to the column
     * bububao_user_activity_info.activity_begin_time
     *
     * @mbggenerated
     */
    private Date   activityBeginTime;

    /**
     * 活动结束时间 This field corresponds to the column
     * bububao_user_activity_info.activity_end_time
     *
     * @mbggenerated
     */
    private Date   activityEndTime;

    /**
     * 是否使用打折卡(Y/N) This field corresponds to the column
     * bububao_user_activity_info.is_discount
     *
     * @mbggenerated
     */
    private String isDiscount;

    /**
     * 是否使用懒人卡(Y/N) This field corresponds to the column
     * bububao_user_activity_info.is_lazy
     *
     * @mbggenerated
     */
    private String isLazy;
    
    /**
     * 是否使用复活卡(Y/N) This field corresponds to the column
     * bububao_user_activity_info.is_resurgence
     *
     * @mbggenerated
     */
    private String isResurgence;

    /**
     * 用户是否已达标 1达标 0未达标 This field corresponds to the column
     * bububao_user_activity_info.is_standard
     *
     * @mbggenerated
     */
    private String isStandard;

    /**
     * 在活动结束后的最大步数 This field corresponds to the column
     * bububao_user_activity_info.steps
     *
     * @mbggenerated
     */
    private String steps;

    /**
     * 创建者 This field corresponds to the column bububao_user_activity_info.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 修改者 This field corresponds to the column bububao_user_activity_info.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 创建时间 This field corresponds to the column
     * bububao_user_activity_info.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改时间 This field corresponds to the column
     * bububao_user_activity_info.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * 是否删除（Y/N，默认为:N） This field corresponds to the column
     * bububao_user_activity_info.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /**
     * 扩展信息 This field corresponds to the column
     * bububao_user_activity_info.extra_info
     *
     * @mbggenerated
     */
    private String extraInfo;

    /**
     * @mbggenerated
     */
    public UserActivityInfoDO(Long id, Long unionid, String channelFrom, String activityId, String childrenId,
                              String inputPoint, String gainPoint, Date activityBeginTime, Date activityEndTime,
                              String isDiscount, String isLazy,String isResurgence, String isStandard, String steps, String creator,
                              String modifier, Date gmtCreated, Date gmtModified, String isDeleted, String extraInfo) {
        this.id = id;
        this.unionid = unionid;
        this.channelFrom = channelFrom;
        this.activityId = activityId;
        this.childrenId = childrenId;
        this.inputPoint = inputPoint;
        this.gainPoint = gainPoint;
        this.activityBeginTime = activityBeginTime;
        this.activityEndTime = activityEndTime;
        this.isDiscount = isDiscount;
        this.isLazy = isLazy;
        this.isResurgence = isResurgence;
        this.isStandard = isStandard;
        this.steps = steps;
        this.creator = creator;
        this.modifier = modifier;
        this.gmtCreated = gmtCreated;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
        this.extraInfo = extraInfo;
    }

    /**
     * @mbggenerated
     */
    public UserActivityInfoDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.id
     *
     * @return the value of bububao_user_activity_info.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.id
     *
     * @param id the value for bububao_user_activity_info.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.unionid
     *
     * @return the value of bububao_user_activity_info.unionid
     * @mbggenerated
     */
    public Long getUnionid() {
        return unionid;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.unionid
     *
     * @param unionid the value for bububao_user_activity_info.unionid
     * @mbggenerated
     */
    public void setUnionid(Long unionid) {
        this.unionid = unionid;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.channel_from
     *
     * @return the value of bububao_user_activity_info.channel_from
     * @mbggenerated
     */
    public String getChannelFrom() {
        return channelFrom;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.channel_from
     *
     * @param channelFrom the value for bububao_user_activity_info.channel_from
     * @mbggenerated
     */
    public void setChannelFrom(String channelFrom) {
        this.channelFrom = channelFrom;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.activity_id
     *
     * @return the value of bububao_user_activity_info.activity_id
     * @mbggenerated
     */
    public String getActivityId() {
        return activityId;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.activity_id
     *
     * @param activityId the value for bububao_user_activity_info.activity_id
     * @mbggenerated
     */
    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.children_id
     *
     * @return the value of bububao_user_activity_info.children_id
     * @mbggenerated
     */
    public String getChildrenId() {
        return childrenId;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.children_id
     *
     * @param childrenId the value for bububao_user_activity_info.children_id
     * @mbggenerated
     */
    public void setChildrenId(String childrenId) {
        this.childrenId = childrenId;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.input_point
     *
     * @return the value of bububao_user_activity_info.input_point
     * @mbggenerated
     */
    public String getInputPoint() {
        return inputPoint;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.input_point
     *
     * @param inputPoint the value for bububao_user_activity_info.input_point
     * @mbggenerated
     */
    public void setInputPoint(String inputPoint) {
        this.inputPoint = inputPoint;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.gain_point
     *
     * @return the value of bububao_user_activity_info.gain_point
     * @mbggenerated
     */
    public String getGainPoint() {
        return gainPoint;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.gain_point
     *
     * @param gainPoint the value for bububao_user_activity_info.gain_point
     * @mbggenerated
     */
    public void setGainPoint(String gainPoint) {
        this.gainPoint = gainPoint;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.activity_begin_time
     *
     * @return the value of bububao_user_activity_info.activity_begin_time
     * @mbggenerated
     */
    public Date getActivityBeginTime() {
        return activityBeginTime;
    }

    /**
     * Sets the value of the database column
     * bububao_user_activity_info.activity_begin_time
     *
     * @param activityBeginTime the value for
     *            bububao_user_activity_info.activity_begin_time
     * @mbggenerated
     */
    public void setActivityBeginTime(Date activityBeginTime) {
        this.activityBeginTime = activityBeginTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.activity_end_time
     *
     * @return the value of bububao_user_activity_info.activity_end_time
     * @mbggenerated
     */
    public Date getActivityEndTime() {
        return activityEndTime;
    }

    /**
     * Sets the value of the database column
     * bububao_user_activity_info.activity_end_time
     *
     * @param activityEndTime the value for
     *            bububao_user_activity_info.activity_end_time
     * @mbggenerated
     */
    public void setActivityEndTime(Date activityEndTime) {
        this.activityEndTime = activityEndTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.is_discount
     *
     * @return the value of bububao_user_activity_info.is_discount
     * @mbggenerated
     */
    public String getIsDiscount() {
        return isDiscount;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.is_discount
     *
     * @param isDiscount the value for bububao_user_activity_info.is_discount
     * @mbggenerated
     */
    public void setIsDiscount(String isDiscount) {
        this.isDiscount = isDiscount;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.is_lazy
     *
     * @return the value of bububao_user_activity_info.is_lazy
     * @mbggenerated
     */
    public String getIsLazy() {
        return isLazy;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.is_lazy
     *
     * @param isLazy the value for bububao_user_activity_info.is_lazy
     * @mbggenerated
     */
    public void setIsLazy(String isLazy) {
        this.isLazy = isLazy;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.is_standard
     *
     * @return the value of bububao_user_activity_info.is_standard
     * @mbggenerated
     */
    public String getIsStandard() {
        return isStandard;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.is_standard
     *
     * @param isStandard the value for bububao_user_activity_info.is_standard
     * @mbggenerated
     */
    public void setIsStandard(String isStandard) {
        this.isStandard = isStandard;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.steps
     *
     * @return the value of bububao_user_activity_info.steps
     * @mbggenerated
     */
    public String getSteps() {
        return steps;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.steps
     *
     * @param steps the value for bububao_user_activity_info.steps
     * @mbggenerated
     */
    public void setSteps(String steps) {
        this.steps = steps;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.creator
     *
     * @return the value of bububao_user_activity_info.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.creator
     *
     * @param creator the value for bububao_user_activity_info.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.modifier
     *
     * @return the value of bububao_user_activity_info.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.modifier
     *
     * @param modifier the value for bububao_user_activity_info.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.gmt_created
     *
     * @return the value of bububao_user_activity_info.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.gmt_created
     *
     * @param gmtCreated the value for bububao_user_activity_info.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.gmt_modified
     *
     * @return the value of bububao_user_activity_info.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.gmt_modified
     *
     * @param gmtModified the value for bububao_user_activity_info.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.is_deleted
     *
     * @return the value of bububao_user_activity_info.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.is_deleted
     *
     * @param isDeleted the value for bububao_user_activity_info.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.extra_info
     *
     * @return the value of bububao_user_activity_info.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column bububao_user_activity_info.extra_info
     *
     * @param extraInfo the value for bububao_user_activity_info.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }
    
    /**
     * This method returns the value of the database column
     * bububao_user_activity_info.is_resurgence
     *
     * @return the value of bububao_user_activity_info.is_resurgence
     * @mbggenerated
     */
    public String getIsResurgence() {
        return isResurgence;
    }

    /**
     * Sets the value of the database column
     * bububao_user_activity_info.is_resurgence
     *
     * @param extraInfo the value for bububao_user_activity_info.is_resurgence
     * @mbggenerated
     */
    public void setIsResurgence(String isResurgence) {
        this.isResurgence = isResurgence;
    }
}
