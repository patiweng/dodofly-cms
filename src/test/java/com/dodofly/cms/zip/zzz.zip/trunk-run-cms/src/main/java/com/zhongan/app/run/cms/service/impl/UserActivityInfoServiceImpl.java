package com.zhongan.app.run.cms.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.UserActivityInfoDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.utils.AppUtil;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.conver.UserActivityInfoConvert;
import com.zhongan.app.run.cms.dao.UserActivityInfoMapper;
import com.zhongan.app.run.cms.dao.bean.UserActivityInfoCriteria;
import com.zhongan.app.run.cms.dao.bean.UserActivityInfoCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.UserActivityInfoDO;
import com.zhongan.app.run.cms.service.UserActivityInfoService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.enm.YesOrNo;
import com.zhongan.health.common.utils.DateUtils;

/**
 * 瓜分奖励活动用户活动信息
 * 
 * @author yangzhen001
 */
@Service
@Slf4j
public class UserActivityInfoServiceImpl implements UserActivityInfoService {

    @Resource
    private UserActivityInfoMapper userActivityInfoMapper;

    /**
     * 查询用户是否有正在开赛的比赛
     */
    @Override
    public ResultBase<UserActivityInfoDTO> selectUserActivityIsOpen(UserActivityInfoDTO info) {
        ResultBase<UserActivityInfoDTO> resultBase = new ResultBase<UserActivityInfoDTO>();
        try {
            List<UserActivityInfoDO> userActivityInfo = userActivityInfoMapper
                    .selectByCriteria(buildUserActivityInfoIsOpen(info));
            log.info("{}--selectUserActivityIsOpen, param={},result={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info));
            List<UserActivityInfoDTO> userActivityInfoDTOs = Lists.newArrayList();
            if (CollectionUtils.isNotEmpty(userActivityInfo)) {
                userActivityInfoDTOs = UserActivityInfoConvert.convertResDTO(userActivityInfo);
                resultBase.setValue(userActivityInfoDTOs.get(0));
            }
            resultBase.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--selectUserActivityIsOpen 查询出错 param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    /**
     * /根据条件查询用户参赛信息
     */
    @Override
    public ResultBase<List<UserActivityInfoDTO>> selectUserActivityInfoByCdt(UserActivityInfoDTO info) {
        ResultBase<List<UserActivityInfoDTO>> resultBase = new ResultBase<List<UserActivityInfoDTO>>();
        try {
            List<UserActivityInfoDTO> userActivityInfoByCdt = null;
            if (0 == info.getSize()) {
                List<UserActivityInfoDO> selectByCriteria = userActivityInfoMapper
                        .selectByCriteria(buildUserActivityInfoCriteria(info));
                if (CollectionUtils.isNotEmpty(selectByCriteria)) {
                    userActivityInfoByCdt = UserActivityInfoConvert.convertResDTO(selectByCriteria);
                }
                log.info("{}--selectUserActivityInfoByCdt, param={},result={}", ThreadLocalUtil.getRequestNo(),
                        JSONObject.toJSONString(info), JSONObject.toJSONString(userActivityInfoByCdt));
            } else {
                PageInfo pageInfo = new PageInfo();
                pageInfo.setSize(info.getSize());
                pageInfo.setOffset((info.getCurrentPage() - 1) * info.getSize());
                userActivityInfoByCdt = this.selectUserActivityInfoByCdtWithPage(info, pageInfo);
                log.info("{}--selectUserActivityInfoByCdtWithPage, param={},pageInfo={},result={}",
                        ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info),
                        JSONObject.toJSONString(pageInfo), JSONObject.toJSONString(userActivityInfoByCdt));
            }
            resultBase.setSuccess(true);
            resultBase.setValue(userActivityInfoByCdt);
        } catch (Exception e) {
            log.error("{}--selectUserActivityInfoByCdt 查询出错 param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    /**
     * /分页查询用户信息
     * 
     * @param info
     * @param pageInfo
     * @return
     */
    public List<UserActivityInfoDTO> selectUserActivityInfoByCdtWithPage(UserActivityInfoDTO info, PageInfo pageInfo) {
        List<UserActivityInfoDO> activityInfoByCdt = userActivityInfoMapper.selectByCriteriaWithPage(
                buildUserActivityInfoCriteria(info), pageInfo);
        log.info("{}--selectUserActivityInfoByCdtWithPage, param={},pageInfo={},result={}",
                ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info), JSONObject.toJSONString(pageInfo),
                JSONObject.toJSONString(activityInfoByCdt));
        List<UserActivityInfoDTO> list = null;
        if (CollectionUtils.isNotEmpty(activityInfoByCdt)) {
            list = UserActivityInfoConvert.convertResDTO(activityInfoByCdt);
        }
        return list;
    }

    /**
     * /更新或插入用户参赛信息
     */
    @Override
    public ResultBase<String> inOrUpUserActivityInfor(UserActivityInfoDTO info) {
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            resultBase = this.checkParam(info);
            if (!resultBase.isSuccess()) {
                return resultBase;
            }
            UserActivityInfoDTO param = new UserActivityInfoDTO();
            param.setActivityId(info.getActivityId());
            param.setChildrenId(info.getChildrenId());
            param.setUnionid(info.getUnionid());
           // param.setChannelFrom(info.getChannelFrom());
            List<UserActivityInfoDO> activityInfoByCdt = userActivityInfoMapper
                    .selectByCriteria(buildUserActivityInfoCriteria(param));
            log.info("{}--selectByCriteria, param={},result={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(param), JSONObject.toJSONString(activityInfoByCdt));
            UserActivityInfoDO bo = convertResDTO(info);
            if (CollectionUtils.isNotEmpty(activityInfoByCdt)) {
                bo.setId(activityInfoByCdt.get(0).getId());
                userActivityInfoMapper.updateByPrimaryKeySelective(bo);
            } else {
                bo.setGmtModified(new Date());
                bo.setGmtCreated(new Date());
                userActivityInfoMapper.insertSelective(bo);
            }
            resultBase.setSuccess(true);
        } catch (Exception e) {
            log.error("{}--inOrUpUserActivityInfor 查询出错 param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    private ResultBase<String> checkParam(UserActivityInfoDTO info) {
        if (StringUtils.isBlank(info.getActivityId())) {
            return new ResultBase<String>(false, AppErrEnum.ERROR_USERACTIVITY_20001.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20001.getValue());
        }
        if (StringUtils.isBlank(info.getChildrenId())) {
            return new ResultBase<String>(false, AppErrEnum.ERROR_USERACTIVITY_20002.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20002.getValue());
        }
        if (null == info.getUnionid()) {
            return new ResultBase<String>(false, AppErrEnum.ERROR_USERACTIVITY_20003.getCode(),
                    AppErrEnum.ERROR_USERACTIVITY_20003.getValue());
        }
        /*
         * if (StringUtils.isBlank(info.getChannelFrom())) { return new
         * ResultBase<String>(false,
         * AppErrEnum.ERROR_USERACTIVITY_20004.getCode(),
         * AppErrEnum.ERROR_USERACTIVITY_20004.getValue()); }
         */
        return new ResultBase<String>(null);
    }

    /***
     * /根据条件获取用户参赛数量
     */
    @Override
    public ResultBase<Integer> selectUserActivityCountByCdt(UserActivityInfoDTO info) {
        ResultBase<Integer> resultBase = new ResultBase<Integer>();
        try {
            Integer l = userActivityInfoMapper.countByCriteria(buildUserActivityInfoCriteria(info));
            log.info("{}--countByCriteria, param={},count={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), l);
            resultBase.setSuccess(true);
            resultBase.setValue(l);
        } catch (Exception e) {
            log.error("{}--selectUserActivityCountByCdt 查询出错 param>>>>>{},Exception={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    /**
     * /分页获得用户获取的积分总数
     */
    @Override
    public ResultBase<String> selectUserGainPointTotal(UserActivityInfoDTO info) {
        ResultBase<String> resultBase = new ResultBase<String>();
        try {
            Integer count = userActivityInfoMapper.countByCriteria(buildUserActivityInfoCriteria(info));
            log.info("{}--countByCriteria, param={},count={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), count);
            if (null == count || 0 == count) {
                resultBase.setSuccess(true);
                resultBase.setValue("0.00");
                return resultBase;
            }
            int pageCount = (count.intValue() % AppUtil.PAGESIZE == 0) ? count.intValue() / AppUtil.PAGESIZE : count
                    .intValue() / AppUtil.PAGESIZE + 1;
            UserActivityInfoDTO client = null;
            Double gainPoint = 0.00;
            Date nowTime = DateUtils.parseDateYYYY_MM_DD_HH_MM_SS(DateTimeUtils.getCurrentTimeString());
            for (int i = 1; i <= pageCount; i++) {
                client = new UserActivityInfoDTO();
                BeanUtils.copyProperties(info, client);
                client.setNowTime(nowTime);
                PageInfo pageInfo = new PageInfo();
                pageInfo.setSize(AppUtil.PAGESIZE);
                pageInfo.setOffset((i - 1) * AppUtil.PAGESIZE);
                List<UserActivityInfoDTO> withPage = this.selectUserActivityInfoByCdtWithPage(client, pageInfo);
                if (CollectionUtils.isNotEmpty(withPage)) {
                    for (UserActivityInfoDTO dto : withPage) {
                        Double total = Double.valueOf(dto.getGainPoint()) - Double.valueOf(dto.getInputPoint());
                        gainPoint += total < 0 ? 0.0 : total;
                    }
                }
            }
            BigDecimal change = new BigDecimal(gainPoint);
            BigDecimal setScale = change.setScale(2, BigDecimal.ROUND_HALF_UP);
            resultBase.setSuccess(true);
            resultBase.setValue(setScale.toString());
        } catch (Exception e) {
            log.error("{}--selectUserGainPointTotal 查询出错 param>>>>>{},Exception={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    private UserActivityInfoCriteria buildUserActivityInfoCriteria(UserActivityInfoDTO dto) {
        UserActivityInfoCriteria userActivityInfoCriteria = new UserActivityInfoCriteria();
        userActivityInfoCriteria.setOrderByClause("id DESC");
        Criteria criteria = userActivityInfoCriteria.createCriteria();
        if (null != dto.getUnionid()) {
            criteria.andUnionidEqualTo(dto.getUnionid());
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (StringUtils.isNoneBlank(dto.getActivityId())) {
            criteria.andActivityIdEqualTo(dto.getActivityId());
        }
        if (StringUtils.isNoneBlank(dto.getChildrenId())) {
            criteria.andChildrenIdEqualTo(dto.getChildrenId());
        }
        if (StringUtils.isNoneBlank(dto.getInputPoint())) {
            criteria.andInputPointEqualTo(dto.getInputPoint());
        }
        if (StringUtils.isNoneBlank(dto.getGainPoint())) {
            criteria.andGainPointEqualTo(dto.getGainPoint());
        }
        if (StringUtils.isNoneBlank(dto.getIsDiscount())) {
            criteria.andIsDiscountEqualTo(dto.getIsDiscount());
        }
        if (StringUtils.isNoneBlank(dto.getIsLazy())) {
            criteria.andIsLazyEqualTo(dto.getIsLazy());
        }
        if (StringUtils.isNoneBlank(dto.getIsResurgence())) {
            criteria.andIsResurgenceEqualTo(dto.getIsResurgence());
        }
        if (StringUtils.isNoneBlank(dto.getIsStandard())) {
            criteria.andIsStandardEqualTo(dto.getIsStandard());
        }
        if (StringUtils.isNoneBlank(dto.getSteps())) {
            criteria.andStepsEqualTo(dto.getSteps());
        }
        if (null != dto.getNowTime()) {
            criteria.andActivityEndTimeLessThanOrEqualTo(dto.getNowTime());
        }
        if (null != dto.getActivityTime()) {
            criteria.andActivityEndTimeGreaterThanOrEqualTo(dto.getActivityTime());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userActivityInfoCriteria;
    }

    private UserActivityInfoCriteria buildUserActivityInfoIsOpen(UserActivityInfoDTO dto) {
        UserActivityInfoCriteria userActivityInfoCriteria = new UserActivityInfoCriteria();
        userActivityInfoCriteria.setOrderByClause("id DESC");
        Criteria criteria = userActivityInfoCriteria.createCriteria();
        if (null != dto.getUnionid()) {
            criteria.andUnionidEqualTo(dto.getUnionid());
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (StringUtils.isNoneBlank(dto.getActivityId())) {
            criteria.andActivityIdEqualTo(dto.getActivityId());
        }
        if (StringUtils.isNoneBlank(dto.getChildrenId())) {
            criteria.andChildrenIdEqualTo(dto.getChildrenId());
        }
        criteria.andActivityBeginTimeLessThan(DateUtils.currentDate());
        criteria.andActivityEndTimeGreaterThan(DateUtils.currentDate());
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userActivityInfoCriteria;
    }

    public static UserActivityInfoDO convertResDTO(UserActivityInfoDTO doOut) {
        UserActivityInfoDO dto = new UserActivityInfoDO();
        BeanUtils.copyProperties(doOut, dto);
        fieldConvert(doOut, dto);
        return dto;
    }

    private static void fieldConvert(UserActivityInfoDTO info, UserActivityInfoDO dto) {
        if (StringUtils.isNoneBlank(info.getActivityBeginTime())) {
            dto.setActivityBeginTime(DateUtils.parseDateYYYY_MM_DD_HH_MM_SS(info.getActivityBeginTime()));
        }
        if (StringUtils.isNoneBlank(info.getActivityEndTime())) {
            dto.setActivityEndTime(DateUtils.parseDateYYYY_MM_DD_HH_MM_SS(info.getActivityEndTime()));
        }
    }

    /**
     * 用户总数去重
     */
    @Override
    public ResultBase<Integer> selectUserActivityCountByCdtDistinct(UserActivityInfoDTO info) {

        ResultBase<Integer> resultBase = new ResultBase<Integer>();
        try {
            Integer count = userActivityInfoMapper.selectUserActivityCountByCdtDistinct(info);
            log.info("{}--selectUserActivityCountByCdtDistinct, param={},count={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), count);
            resultBase.setSuccess(true);
            resultBase.setValue(count);
        } catch (Exception e) {
            log.error("{}--selectUserActivityCountByCdtDistinct 查询出错 param>>>>>{},Exception={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    /**
     * 分页查询用户信息
     * 
     * @param info
     * @param pageInfo
     * @return
     */
    public ResultBase<List<String>> selectUnionidByCdtDistinctPage(UserActivityInfoDTO info) {
        ResultBase<List<String>> resultBase = new ResultBase<List<String>>();
        try {
            List<UserActivityInfoDTO> userActivityInfoByCdt = null;
            if (info.getSize() == AppUtil.PAGESIZE) {
                PageInfo pageInfo = new PageInfo();
                pageInfo.setSize(info.getSize());
                pageInfo.setOffset((info.getCurrentPage() - 1) * info.getSize());
                List<String> activityInfoByCdt = userActivityInfoMapper.selectUnionidByCdtDistinctPage(info, pageInfo);
                log.info("{}--selectUnionidByCdtDistinctPage, param={},pageInfo={},result={}",
                        ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info),
                        JSONObject.toJSONString(pageInfo), JSONObject.toJSONString(userActivityInfoByCdt));
                resultBase.setSuccess(true);
                resultBase.setValue(activityInfoByCdt);
            }
        } catch (Exception e) {
            log.error("{}--selectUnionidByCdtDistinctPage 查询出错 param>>>>>{},Exception={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    @Override
    public ResultBase<List<UserActivityInfoDTO>> selectUserFirstActivityInfoByCdt(UserActivityInfoDTO info) {
        ResultBase<List<UserActivityInfoDTO>> resultBase = new ResultBase<List<UserActivityInfoDTO>>();
        try {
            PageInfo pageInfo = new PageInfo();
            pageInfo.setSize(1);
            pageInfo.setOffset(0);
            List<UserActivityInfoDO> activityInfoByCdt = userActivityInfoMapper.selectByCriteriaWithPage(
                    buildUserFirstActivityInfoCriteria(info), pageInfo);
            log.info("{}--selectUserActivityInfoByCdtWithPage, param={},pageInfo={},result={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info), JSONObject.toJSONString(pageInfo),
                    JSONObject.toJSONString(activityInfoByCdt));
            List<UserActivityInfoDTO> list = null;
            if (CollectionUtils.isNotEmpty(activityInfoByCdt)) {
                list = UserActivityInfoConvert.convertResDTO(activityInfoByCdt);
            }
            log.info("{}--selectUserFirstActivityInfoByCdt, param={},result={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(info), JSONObject.toJSONString(activityInfoByCdt));
            resultBase.setSuccess(true);
            resultBase.setValue(list);
        } catch (Exception e) {
            log.error("{}--selectUserFirstActivityInfoByCdt 查询出错 param>>>>>{},Exception={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(info), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;
    }

    private UserActivityInfoCriteria buildUserFirstActivityInfoCriteria(UserActivityInfoDTO dto) {
        UserActivityInfoCriteria userActivityInfoCriteria = new UserActivityInfoCriteria();
        userActivityInfoCriteria.setOrderByClause("id ASC");
        Criteria criteria = userActivityInfoCriteria.createCriteria();
        if (null != dto.getUnionid()) {
            criteria.andUnionidEqualTo(dto.getUnionid());
        }
        if (StringUtils.isNoneBlank(dto.getChannelFrom())) {
            criteria.andChannelFromEqualTo(dto.getChannelFrom());
        }
        if (StringUtils.isNoneBlank(dto.getActivityId())) {
            criteria.andActivityIdEqualTo(dto.getActivityId());
        }
        if (StringUtils.isNoneBlank(dto.getChildrenId())) {
            criteria.andChildrenIdEqualTo(dto.getChildrenId());
        }
        if (StringUtils.isNoneBlank(dto.getInputPoint())) {
            criteria.andInputPointEqualTo(dto.getInputPoint());
        }
        if (StringUtils.isNoneBlank(dto.getGainPoint())) {
            criteria.andGainPointEqualTo(dto.getGainPoint());
        }
        if (StringUtils.isNoneBlank(dto.getIsDiscount())) {
            criteria.andIsDiscountEqualTo(dto.getIsDiscount());
        }
        if (StringUtils.isNoneBlank(dto.getIsLazy())) {
            criteria.andIsLazyEqualTo(dto.getIsLazy());
        }
        if (StringUtils.isNoneBlank(dto.getIsResurgence())) {
            criteria.andIsResurgenceEqualTo(dto.getIsResurgence());
        }
        if (StringUtils.isNoneBlank(dto.getIsStandard())) {
            criteria.andIsStandardEqualTo(dto.getIsStandard());
        }
        if (StringUtils.isNoneBlank(dto.getSteps())) {
            criteria.andStepsEqualTo(dto.getSteps());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userActivityInfoCriteria;
    }

    /**
     * 根据时间用户Unionid获取用户参赛信息
     */
    @Override
    public ResultBase<UserActivityInfoDTO> queryUserActivityInfoByUnionidAndDate(UserActivityInfoDTO userActivityParam) {
        ResultBase<UserActivityInfoDTO> resultBase = new ResultBase<UserActivityInfoDTO>();
        try {
            log.info("{}--selectByCriteria, param={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(userActivityParam));
            List<UserActivityInfoDO> activityInfoByCdt = userActivityInfoMapper
                    .selectByCriteria(buildUserActivityInfoByTimeCriteria(userActivityParam));
            UserActivityInfoDTO dto = null;
            if (CollectionUtils.isNotEmpty(activityInfoByCdt)) {
                dto = new UserActivityInfoDTO();
                UserActivityInfoDO userActivityInfoDO = activityInfoByCdt.get(0);
                BeanUtils.copyProperties(userActivityInfoDO, dto);
                UserActivityInfoConvert.fieldConvert(userActivityInfoDO, dto);
            }
            log.info("{}--selectUserFirstActivityInfoByCdt, param={},result={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(userActivityParam), JSONObject.toJSONString(dto));
            resultBase.setSuccess(true);
            resultBase.setValue(dto);
        } catch (Exception e) {
            log.error("{}--selectUserFirstActivityInfoByCdt 查询出错 param>>>>>{},Exception={}",
                    ThreadLocalUtil.getRequestNo(), JSONObject.toJSONString(userActivityParam), e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return resultBase;

    }

    public UserActivityInfoCriteria buildUserActivityInfoByTimeCriteria(UserActivityInfoDTO userActivityParam) {
        UserActivityInfoCriteria userActivityInfoCriteria = new UserActivityInfoCriteria();
        userActivityInfoCriteria.setOrderByClause("id DESC");
        Criteria criteria = userActivityInfoCriteria.createCriteria();
        if (null != userActivityParam.getUnionid()) {
            criteria.andUnionidEqualTo(userActivityParam.getUnionid());
        }
        if (null != userActivityParam.getNowTime()) {
            criteria.andActivityBeginTimeLessThanOrEqualTo(userActivityParam.getNowTime());
            criteria.andActivityEndTimeGreaterThanOrEqualTo(userActivityParam.getNowTime());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return userActivityInfoCriteria;
    }

}
