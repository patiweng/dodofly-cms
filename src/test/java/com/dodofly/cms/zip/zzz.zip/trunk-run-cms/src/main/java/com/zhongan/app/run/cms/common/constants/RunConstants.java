package com.zhongan.app.run.cms.common.constants;

public class RunConstants {

    /** message */
    public static final String SMS_SEND_USERNO          = "BEIJING";

    /** upload file project */
    public static final String PROJECT                  = "run/";

    public static final String MARKETING_IMG_PATH       = "marketing/";
    public static final String MARKETING_IMG_NAME       = "marketing.jpg";
    public static final String CMS_UPLOAD_PRE           = "RUN_CMS_";
    public static final String CMS_UPLOAD_PRE_PRESENT   = "RUN_CMS_PRE_";
    public static final String CMS_UPLOAD_GETURL        = "/run/proxy/getimg/";
    public static final String CHANNELLIST_IMG_PATH     = "channel/";
    public static final String CHANNELLIST_IMG_NAME     = "channel.jpg";

    public static final String CHANNELLIST_TWO_IMG_PATH = "channelt/";
    public static final String CHANNELLIST_TWO_IMG_NAME = "channelt.jpg";
    public static final String MARKETING_IMG_SUFFIX     = ".jpg";

    /*
     * 参数名-代码
     */
    public static final String PARAM_RETURN_CODE        = "returnCode";
    /**
     * 参数名-描述信息
     */
    public static final String PARAM_RETURN_MSG         = "returnMsg";

    /**
     * 大转盘上架奖品只能为6个，需与direct项目下数值保持一致
     */
    public static final String PRIZE_SIX                = "11";
    /**
     * 大转盘
     */
    public static final Long   ACT_TYPE_BIG_WHEEL       = 1L;
    /**
     * 不是付费
     */
    public static final String IS_NO_PAY_ACTIVITY       = "0";
    /**
     * 不是注册专属
     */
    public static final String IS_NO_INTRO_NAME         = "0";

    /**
     * 是付费
     */
    public static final String IS_PAY_ACTIVITY          = "1";
    /**
     * 数据是否有效 是0
     */
    public static final String IS_STATUS                = "0";
    /**
     * 活动类型是重疾的编码
     */
    public static final String IS_ZHONGJI               = "1";
    /**
     * 活动类型是重疾的
     */
    public static final String IS_ZHONGJI_NAME          = "重疾";
    /**
     * 活动类型是意外
     */
    public static final String IS_YIWAI                 = "意外";
    /**
     * 是注册专属
     */
    public static final String IS_INTRO_NAME            = "1";

    public static final String UPDATE_TRUE              = "0";
    /**
     * 奖品状态（已领取、未领取）
     */
    public static final String PRIZE_STATUS_Y           = "1";
    public static final String PRIZE_STATUS_N           = "2";
    /**
     * 短信内容
     */
    public static final String MESSAGE                  = "恭喜中奖，奖品已发送，敬请查收！";
    /**
     * 系统
     */
    public static final String SYSTEM_NAME              = "system";
    /**
     * hsf字典数据
     */
    public static final String SYS_CODE                 = "za-cms";
    public static final String DICT_CODE                = "online-area";
    public static final Long   VERSION                  = 10000L;

    public static final String FABU                     = "fabu";
    public static final String ZANCAN                   = "zancun";
    public static final String STATUSD                  = "4";
    public static final String STATUSZ                  = "3";

    /**
     * 超级管理员
     */
    public static final String SUPER_USER               = "0";
    /**
     * excel配置项
     */
    public static final String USERNAME                 = "userName";
    public static final String USERPHONE                = "userPhone";
    public static final String VEHICLELICENCEPLATENO    = "vehicleLicencePlateNo";
    public static final String GMTCREATED               = "gmtCreated";

    public static final String NAME                     = "姓名";
    public static final String PHONE                    = "手机号";
    public static final String VEHNO                    = "车牌号";
    public static final String GTIME                    = "时间";

    /******** 登录模块系统常量 **********/
    public static class LoginModelConst {
        /** 登录标识码 **/
        public static String LOGIN_ZASID     = "za_cms_login_sid";
        /** 拦截器过滤规则 **/
        public static String INTERCPT_FILTER = "/sys/index;/sys/login";
        /** 用户信息 **/
        public static String BOPS_USERINFO   = "userInfo";
        /** 当前选中菜单 **/
        public static String BOPS_NOWMENU    = "nowMenu";
        /** 登录超时时间 **/
        public static int    LOGIN_OUT_TIME  = 1800;

        public static String BOPS_FLAG       = "bopsFlag";

    }

    public static class MarketName {

        public static String ENTERPRISE_NAME = "企业专属";
    }

    /**
     * 礼物标识的小图片
     */
    public static final String PICTRUE    = "_1";

    /**
     * 礼物标识的大图片
     */
    public static final String PICTRUEBIG = "_2";

    /**
     * 小米马拉松双色球
     */
    public static String       CHROMOSPHERE = "chromosphere";
    /**
     * 小米马拉松大奖号
     */
    public static String       BIGPRIZE     = "bigPrize";
    
    /**
     * 二维码推广
     */
    public static final String      UPLOAD_FILE_STATISTICS            = "INSURE_STATISTICS";           //上传oss前缀（统计）
    public static final String      DOWNLOAD_URL                = "/run/cms/qrcode/getFile/";    //下载路径
    public static final String      UPLOAD_FILE_DETAILS        = "STATISTICS_DETAILS";       //上传oss前缀（明细）

    public static final String      USER_STATUS_ONEMOTHOUT = "1";
}
