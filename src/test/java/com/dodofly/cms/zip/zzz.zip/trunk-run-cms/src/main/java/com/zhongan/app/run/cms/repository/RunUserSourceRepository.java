package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.zhongan.app.run.cms.bean.dataobject.BububaoUserSourceDO;
import com.zhongan.app.run.cms.dao.BububaoUserSourceDAO;

@Repository
public class RunUserSourceRepository {

    @Resource
    private BububaoUserSourceDAO bububaoUserSourceDAO;

    public List<BububaoUserSourceDO> selectDataByCdt(BububaoUserSourceDO bububaoUserSourceDO) {
        return bububaoUserSourceDAO.selectDataByCdt(bububaoUserSourceDO);
    }

    public List<BububaoUserSourceDO> selectSourceByUnionId(Map map) {
        return bububaoUserSourceDAO.selectSourceByUnionId(map);
    }

    public List<BububaoUserSourceDO> selectUserSourceBySource(Map map) {
        return bububaoUserSourceDAO.selectUserSourceBySource(map);
    }

    public List<BububaoUserSourceDO> selectSourceByUserId(Map map) {
        return bububaoUserSourceDAO.selectSourceByUserId(map);
    }

}
