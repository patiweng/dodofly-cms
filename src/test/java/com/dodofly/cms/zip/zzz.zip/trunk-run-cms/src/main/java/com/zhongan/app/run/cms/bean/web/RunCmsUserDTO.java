package com.zhongan.app.run.cms.bean.web;

import java.util.List;

import lombok.Data;

@Data
public class RunCmsUserDTO{
	
	/**用户权限菜单信息**/
	private List<RunSysMenuDTO> privmenuList;
	private String userId;
	private String loginToken;
}
