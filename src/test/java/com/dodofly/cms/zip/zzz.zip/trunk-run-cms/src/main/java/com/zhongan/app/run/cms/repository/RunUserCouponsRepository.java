package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.dataobject.BububaoUserCouponsDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunUserCouponsRepo;
import com.zhongan.app.run.cms.dao.BububaoUserCouponsDAO;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Component
@Slf4j
public class RunUserCouponsRepository {

    @Resource
    private BububaoUserCouponsDAO bububaoUserCouponsDAO;

    public Page<RunUserCouponsRepo> selectRunUserCouponsData(Page<RunUserCouponsRepo> runUserCouponsRepoPage) {
        log.info("{}-select   BububaoUserCoupons。。。Repository。。。", ThreadLocalUtil.getRequestNo());
        BububaoUserCouponsDO bububaoUserCouponsDO = new BububaoUserCouponsDO();
        if (null != runUserCouponsRepoPage.getParam()) {
            BeanUtils.copyProperties(runUserCouponsRepoPage.getParam(), bububaoUserCouponsDO);
        }
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", runUserCouponsRepoPage.getStartRow());
        map.put("pageSize", runUserCouponsRepoPage.getPageSize());
        map.put("bububaoUserCouponsDO", bububaoUserCouponsDO);
        List<BububaoUserCouponsDO> bububaoUserCouponsDOList = bububaoUserCouponsDAO.selectBububaoUserCoupons(map);
        List<RunUserCouponsRepo> runUserCouponsRepoList = Lists.newArrayList();

        if (null != bububaoUserCouponsDOList && 0 != bububaoUserCouponsDOList.size()) {
            RunUserCouponsRepo runUserCouponsRepo = null;
            for (BububaoUserCouponsDO userCouponsDO : bububaoUserCouponsDOList) {
                runUserCouponsRepo = new RunUserCouponsRepo();
                BeanUtils.copyProperties(userCouponsDO, runUserCouponsRepo);
                fieldConvert(userCouponsDO, runUserCouponsRepo);
                runUserCouponsRepoList.add(runUserCouponsRepo);
            }
        }
        runUserCouponsRepoPage.setResultList(runUserCouponsRepoList);
        Integer counts = bububaoUserCouponsDAO.selectCounts(map);
        runUserCouponsRepoPage.setTotalItem(counts);
        return runUserCouponsRepoPage;
    }

    //数据库中保存日期为date格式，转换成yyyy-MM-dd格式字符串
    private void fieldConvert(BububaoUserCouponsDO userCouponsDO, RunUserCouponsRepo userCouponsRepo) {
        userCouponsRepo.setStartTime(userCouponsDO.getStartTime().substring(0, 10));
        userCouponsRepo.setEndTime(userCouponsDO.getEndTime().substring(0, 10));
    }

    public Integer update(RunUserCouponsRepo userCouponsRepo) {
        BububaoUserCouponsDO userCouponsDO = new BububaoUserCouponsDO();
        BeanUtils.copyProperties(userCouponsRepo, userCouponsDO);
        return bububaoUserCouponsDAO.update(userCouponsDO);
    }

    public void insert(RunUserCouponsRepo userCouponsRepo) {
        BububaoUserCouponsDO userCouponsDO = new BububaoUserCouponsDO();
        BeanUtils.copyProperties(userCouponsRepo, userCouponsDO);
        bububaoUserCouponsDAO.insert(userCouponsDO);
    }

    public Integer selectUserCoupons(RunUserCouponsRepo userCouponsRepo) {
        Map<String, Object> map = Maps.newHashMap();
        map.put("unionId", userCouponsRepo.getUnionId());
        map.put("status", userCouponsRepo.getStatus());
        return bububaoUserCouponsDAO.selectNums(map);
    }

}
