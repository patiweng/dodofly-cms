package com.zhongan.app.run.cms.service;

import javax.servlet.http.HttpServletResponse;

import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorDTO;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface ExportExcelService {

    /**
     * 定时任务，同步打点分析表
     * 
     * @param response
     * @param sdate
     * @param edate
     */
    void doExportExcelForRegRate(HttpServletResponse response, String sdate, String edate);

    /**
     * 查询打点分析列表 ，分页
     * 
     * @param analysisMonitorPage
     * @return
     */
    AnalysisMonitorPageDTO selectAnalysisMonitorList(Page<AnalysisMonitorDTO> analysisMonitorPage);

    /**
     * 同步当天数据
     * 
     * @return
     */
    ResultBase<String> addAnalysisMonitorofTodayData();

}
