package com.zhongan.app.run.cms.bean.web;

import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类RunElifeChannelProductQueryDTO.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月27日 下午2:32:04
 */
public class RunElifeChannelProductQueryDTO extends PageDTO<CashierHelpPayQueryDTO> {

    /**
     * 
     */
    private static final long serialVersionUID = -8558996668116166219L;

    private Long              id;

    /**
     * 渠道id
     */
    private Long              channelId;

    /**
     * 渠道名称
     */
    private String            channelName;

    /**
     * 产品ID
     */
    private Long              productId;

    /**
     * 产品名称
     */
    private String            productName;

    /**
     * 营销活动ID
     */
    private Long              campaignDefId;

    /**
     * 营销活动名称
     */
    private String            campaignDefName;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getChannelId() {
        return channelId;
    }

    public void setChannelId(Long channelId) {
        this.channelId = channelId;
    }

    public Long getProductId() {
        return productId;
    }

    public void setProductId(Long productId) {
        this.productId = productId;
    }

    public Long getCampaignDefId() {
        return campaignDefId;
    }

    public void setCampaignDefId(Long campaignDefId) {
        this.campaignDefId = campaignDefId;
    }

    public String getCampaignDefName() {
        return campaignDefName;
    }

    public void setCampaignDefName(String campaignDefName) {
        this.campaignDefName = campaignDefName;
    }

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

}
