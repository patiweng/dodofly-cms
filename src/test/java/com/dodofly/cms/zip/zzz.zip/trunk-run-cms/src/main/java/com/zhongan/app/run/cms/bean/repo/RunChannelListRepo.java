package com.zhongan.app.run.cms.bean.repo;

import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class RunChannelListRepo {
	
	private String id;//主键
	private String name;//渠道名称
	private String no;//渠道号
	private String title;//标题活动
	private String type;//活动类型
	private String OwnPlatForm;//自有平台  默认0
	private String pay;//支付方式
	private String url;//渠道链接
	private String createTime;//创建时间
	private String status;//渠道状态  默认0
	private String momentsTitle;//朋友圈标题
	private String momentsUrl;//朋友圈图片地址
	private String friendTitle;//好友标题
	private String friendUrl;//好友图片地址
	private String friendDescribe;//好友描述	  
	private String creater;//创建人
	private String deleteTime;//删除时间
	private String isGetFlag;//是否已领取
	
	 private MultipartFile     marketingImgFile; //上传到OSS 的图片
	 private MultipartFile     marketingImgFileTwo; //上传到OSS 好友的图片
}
