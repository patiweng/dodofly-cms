package com.zhongan.app.run.cms.common.csvutil.format;

import com.zhongan.app.run.cms.common.csvutil.annotion.ValueFormat;

public class DefaultValueFormat extends ValueFormat {
    @Override
    public Object readFormat(Object value, Class<?> propertyClass, String propertyName) {
        if(value == null){
            return null;
        }


        String strValue = value.toString().trim();

        Object destValue = null;

        if (propertyClass.equals(String.class)) {
            destValue = strValue;
        } else if (propertyClass.equals(Long.class)) {
            destValue = Long.parseLong(strValue);
        } else if (propertyClass.equals(Integer.class)) {
            destValue = Integer.parseInt(strValue);
        } else if (propertyClass.equals(Short.class)) {
            destValue = Short.parseShort(strValue);
        } else if (propertyClass.equals(Double.class)) {
            destValue = Double.parseDouble(strValue);
        } else if (propertyClass.equals(Float.class)) {
            destValue = Float.parseFloat(strValue);
        } else {
            throw new RuntimeException("不识别的类型" + propertyClass.getName());
        }

        return destValue;
    }

    @Override
    public String writeFormat(Object value, Class<?> propertyClass, String propertyName) {
        if(value == null){
            return null;
        }

        return value.toString();
    }
}
