package com.zhongan.app.run.cms.service.impl;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.zhongan.app.run.cms.common.constants.RunConstants;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jetty.util.StringUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.bo.RunMarketingActivitiesBO;
import com.zhongan.app.run.cms.bean.client.EnterpriseEmployeeClient;
import com.zhongan.app.run.cms.bean.dataobject.BububaoMarketingActivitiesDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RunAdvertHistoryRepo;
import com.zhongan.app.run.cms.bean.repo.RunChannelListRepo;
import com.zhongan.app.run.cms.bean.repo.RunMarketingActivitiesRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunAdvertHistoryDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesDTO;
import com.zhongan.app.run.cms.bean.web.RunMarketingActivitiesPageDTO;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.common.enums.MarketTypeEnum;
import com.zhongan.app.run.cms.common.utils.AppUtil;
import com.zhongan.app.run.cms.common.utils.DateTimeUtils;
import com.zhongan.app.run.cms.dao.BububaoMarketingActivitiesDAO;
import com.zhongan.app.run.cms.repository.RunAdvertHistoryRepository;
import com.zhongan.app.run.cms.repository.RunChannelListRepository;
import com.zhongan.app.run.cms.repository.RunIssRewardsRepository;
import com.zhongan.app.run.cms.repository.RunMarketingActivitiesRepository;
import com.zhongan.app.run.cms.service.RunMarketingActivitiesService;
import com.zhongan.app.run.cms.service.client.RunEnterPriseFeignClient;
import com.zhongan.app.run.common.constant.CommonConstant;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.utils.DateUtils;

@Service
@Slf4j
public class RunMarketingActivitiesServiceImpl implements RunMarketingActivitiesService {

    @Resource
    private RunMarketingActivitiesRepository runMarketingActivitiesRepository;

    @Resource
    private RunIssRewardsRepository          runIssRewardsRepository;

    @Resource
    private RunAdvertHistoryRepository       runAdvertHistoryRepository;

    @Resource
    private RunChannelListRepository         runChannelListRepository;

    @Resource
    private RunEnterPriseFeignClient         runEnterPriseFeignClient;

    @Resource
    private BububaoMarketingActivitiesDAO    bububaoMarketingActivitiesDAO;

    @Resource
    private RedisUtil                        redisUtil;

    /**
     * 判断用户是否为企业用户
     * 
     * @param unionId
     * @return
     */
    private ResultBase<EnterpriseEmployeeClient> checkEnterPrise(String unionId) {
        ResultBase<EnterpriseEmployeeClient> result = new ResultBase<EnterpriseEmployeeClient>();
        result.setSuccess(false);
        ResultBase<List<EnterpriseEmployeeClient>> enterRs = runEnterPriseFeignClient.enterpriseUnionidExist(unionId);
        if (!enterRs.isSuccess()) {
            result.setSuccess(false);
            return result;
        }
        List<EnterpriseEmployeeClient> enterList = enterRs.getValue();
        if (enterList != null && enterList.size() > 0) {

            result.setSuccess(true);
            result.setValue(enterList.get(0));
            return result;
        }
        return result;
    }

    @Override
    public ResultBase<List<RunMarketingActivitiesDTO>> selectRunMarketingAct(RunMarketingActivitiesBO runMarketingActivitiesBO) {
        log.info("{}-MarketingActivities select begin...", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        /*********************** 参数校验 **************************/
        ResultBase<String> valResult = CheckBitparam(runMarketingActivitiesBO);
        if (!valResult.isSuccess()) {
            log.info("{}-参数校验失败{}", JSONObject.toJSONString(valResult), ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            /*********************** 查询该渠道满足条件的运营活动 **************************/
            String sourceCode = runMarketingActivitiesBO.getAllChannel();
            String unionId = runMarketingActivitiesBO.getUnionId();
            String userStep = runMarketingActivitiesBO.getUserStep();
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
            runMarketingActivitiesRepo.setAllChannel(sourceCode);
            runMarketingActivitiesRepo.setUserStep(userStep);
            if (!StringUtils.isEmpty(runMarketingActivitiesBO.getActivityCode())) {
                runMarketingActivitiesRepo.setActivityCode(runMarketingActivitiesBO.getActivityCode());
            }
            ResultBase<List<RunMarketingActivitiesDTO>> resultMarketingActivities = runMarketingActivitiesRepository
                    .selectMarketingValRepo(runMarketingActivitiesRepo);
            List<RunMarketingActivitiesDTO> returnList = new ArrayList<RunMarketingActivitiesDTO>();
            /*********************** 开屏广告每个用户当天只展示一次 **************************/
            List<RunMarketingActivitiesDTO> marketList = resultMarketingActivities.getValue();
            if (marketList == null || marketList.size() == 0) {
                result.setSuccess(true);
                return result;
            }
            //组装tip消息的对象list
            List<RunMarketingActivitiesDTO> returnListTip = new ArrayList<RunMarketingActivitiesDTO>();
            JSONObject extraParam = JSONObject.parseObject(runMarketingActivitiesBO.getExtraParam());
            if (extraParam == null){
                extraParam = new JSONObject();
            }
            List<RunMarketingActivitiesDTO> firstAdver = Lists.newArrayList();
            List<RunMarketingActivitiesDTO> statusAdver = Lists.newArrayList();
            List<RunMarketingActivitiesDTO> adver = Lists.newArrayList();
            for (RunMarketingActivitiesDTO runMarketingActivities : resultMarketingActivities.getValue()) {
                String marketType = runMarketingActivities.getActivitiesType();
                /* 运营活动-支付完成海报，直接添加 */
                if (MarketTypeEnum.MARKET_TYPE_01.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_05.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_06.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_07.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_08.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_10.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_11.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_12.getCode().equals(marketType)
                        || MarketTypeEnum.MARKET_TYPE_14.getCode().equals(marketType)) {
                    returnList.add(runMarketingActivities);
                }
                /* 线下活动-判断是否属于企业专属-企业专属活动只有企业用户才添加 */
                if (MarketTypeEnum.MARKET_TYPE_02.getCode().equals(marketType)) {
                    String marketName = runMarketingActivities.getActivitiesName();
                    if (marketName.indexOf(CommonConstant.MarketName.ENTERPRISE_NAME) > -1) {
                        ResultBase<EnterpriseEmployeeClient> checkEnterRs = checkEnterPrise(unionId);
                        if (checkEnterRs.isSuccess()) {
                            /* 替换ICON为企业头像 */
                            //String iconUrl = checkEnterRs.getValue().getIcon_url();
                            //runMarketingActivities.setActivitiesIcon(iconUrl);
                            returnList.add(runMarketingActivities);
                        }
                    } else {
                        returnList.add(runMarketingActivities);
                    }
                }
                /* tip消息-添加到随机列表 */
                if (MarketTypeEnum.MARKET_TYPE_03.getCode().equals(marketType)) {
                    returnListTip.add(runMarketingActivities);
                }
                /* 1、开屏广告-判断是否展现过 2、抽奖专属-判断是否还能参加抽奖 */
                if (MarketTypeEnum.MARKET_TYPE_04.getCode().equals(marketType)) {
                    String marketName = runMarketingActivities.getActivitiesName();
                    if (marketName.indexOf(CommonConstant.MarketName.LOTTERY_NAME) > -1) {
                        /* 抽奖专属-判断是否还可以参加抽奖 */
                        ResultBase<String> checkRs = runIssRewardsRepository.checkUserRewards(unionId);
                        if (!checkRs.isSuccess()) {
                            returnList.add(runMarketingActivities);
                        }
                    } else {
                        /* 开屏广告-先确认当天是否展示过 */
                        boolean disFlag = true;
                        JSONObject mark = extraParam.getJSONObject(runMarketingActivities.getActivityMark());
                        String activityMark = runMarketingActivities.getActivityMark() == null || mark == null ? "" : runMarketingActivities.getActivityMark();
                        switch (activityMark){
                            case "firstMonthReward":
                                String code = mark.getString("code");
                                if (!StringUtils.equals(code, runMarketingActivities.getActivityCode())){
                                    disFlag = false;
                                }
                                if (disFlag){
                                    firstAdver.add(runMarketingActivities);
                                }
                                break;
                            case "userStatus":
                                String userStatus = mark.getString("userStatus");
                                String stepStatus = mark.getString("stepStatus");
                                Boolean display = mark.getBoolean("display");
                                if (display != null && !display){
                                    disFlag = false;
                                    break;
                                }
                                if (StringUtils.equals(RunConstants.USER_STATUS_ONEMOTHOUT, userStatus)){
                                    disFlag = isAdverDisplay(runMarketingActivities, unionId);
                                } else {
                                    if (StringUtils.equals(runMarketingActivities.getActivityCode(), "userStatus_" + stepStatus)){
                                        disFlag = isAdverDisplay(runMarketingActivities, unionId);
                                    }else {
                                        disFlag = false;
                                    }
                                }
                                if (disFlag){
                                    statusAdver.add(runMarketingActivities);
                                }
                                break;
                            default:
                                disFlag = isAdverDisplay(runMarketingActivities, unionId);
                                if (disFlag){
                                    adver.add(runMarketingActivities);
                                }
                                break;
                        }

                        log.info("{}-开屏记录展示结果{}", disFlag, ThreadLocalUtil.getRequestNo());
                        /* 未展示过开屏-返回给前端展示 */
//                        if (disFlag) {
//                            returnList.add(runMarketingActivities);
//                        }
                    }

                }
            }

            if (CollectionUtils.isNotEmpty(firstAdver)){
                returnList.addAll(firstAdver);
            } else if (CollectionUtils.isNotEmpty(adver)){
                setAdver(adver, returnList, unionId);
            }else if (CollectionUtils.isNotEmpty(statusAdver)){
                setAdver(statusAdver, returnList, unionId);
            }
            //遍历所以tip消息取随机的一条返回
            if (returnListTip != null && returnListTip.size() > 0) {
                SecureRandom r = new SecureRandom();
                int size = returnListTip.size();
                returnList.add(returnListTip.get(r.nextInt(size)));
            }
            result.setValue(returnList);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("查询运营活动异常{}", e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    private boolean isSaveAdverHistory(RunMarketingActivitiesDTO runMarketingActivities, String unionId) {
        RunAdvertHistoryRepo runAdvertHistoryRepo = new RunAdvertHistoryRepo();
        runAdvertHistoryRepo.setActivitiesId(runMarketingActivities.getId());
        runAdvertHistoryRepo.setUnionId(unionId);
        runAdvertHistoryRepo.setActivitiesName(runMarketingActivities.getActivitiesName());
        return runAdvertHistoryRepository.adverDisplay(runAdvertHistoryRepo);
    }

    private boolean isAdverDisplay(RunMarketingActivitiesDTO runMarketingActivities, String unionId){
        RunAdvertHistoryRepo runAdvertHistoryRepo = new RunAdvertHistoryRepo();
        runAdvertHistoryRepo.setActivitiesId(runMarketingActivities.getId());
        runAdvertHistoryRepo.setUnionId(unionId);
        return runAdvertHistoryRepository.isAdvertDisplay(runAdvertHistoryRepo);
    }

    private void setAdver(List<RunMarketingActivitiesDTO> formAvder, List<RunMarketingActivitiesDTO> toAvder, String unionId){
        for (RunMarketingActivitiesDTO runMarketingActivitiesDTO : formAvder){
            if(isSaveAdverHistory(runMarketingActivitiesDTO, unionId)){
                toAvder.add(runMarketingActivitiesDTO);
            }
        }
    }

    /**
     * 阿里渠道弹出框
     */
    @Override
    public ResultBase<List<RunMarketingActivitiesDTO>> selectRunMarketingActAliPop(String sourceCode) {

        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();

        RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
        runMarketingActivitiesRepo.setAllChannel(sourceCode);
        runMarketingActivitiesRepo.setUserStep("5000");
        ResultBase<List<RunMarketingActivitiesDTO>> resultMarketingActivities = runMarketingActivitiesRepository
                .selectMarketingValRepo(runMarketingActivitiesRepo);

        List<RunMarketingActivitiesDTO> returnList = new ArrayList<RunMarketingActivitiesDTO>();
        /*********************** 开屏广告每个用户当天只展示一次 **************************/
        List<RunMarketingActivitiesDTO> marketList = resultMarketingActivities.getValue();
        if (marketList == null || marketList.size() == 0) {
            result.setSuccess(true);
            return result;
        }
        for (RunMarketingActivitiesDTO runMarketingActivities : resultMarketingActivities.getValue()) {
            String marketType = runMarketingActivities.getActivitiesType();
            if (MarketTypeEnum.MARKET_TYPE_04.getCode().equals(marketType)) {
                returnList.add(runMarketingActivities);
            }
        }
        result.setValue(returnList);
        result.setSuccess(true);
        return result;
    }

    // 入参数的校验
    @SuppressWarnings({ "unchecked" })
    private ResultBase<String> CheckBitparam(RunMarketingActivitiesBO RunMarketingActivitiesBO) {
        log.info("{}-param check code...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        // 用户ID
        if (StringUtils.isEmpty(RunMarketingActivitiesBO.getUnionId())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100008, result);
        }
        // 渠道号不能为空
        if (StringUtils.isEmpty(RunMarketingActivitiesBO.getAllChannel())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100009, result);
        }
        // 用户当前步数不能为空
        if (StringUtils.isEmpty(RunMarketingActivitiesBO.getUserStep())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100012, result);
        }
        result.setSuccess(true);
        return result;
    }

    // 入参数的校验
    @SuppressWarnings({ "unchecked" })
    private ResultBase<String> CheckBitparamForThird(RunMarketingActivitiesBO RunMarketingActivitiesBO) {
        log.info("{}-param check code...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        // 渠道号不能为空
        if (StringUtils.isEmpty(RunMarketingActivitiesBO.getAllChannel())) {
            return (ResultBase<String>) AppUtil.createErrResult(AppErrEnum.ERROR_USERLOGIN_100009, result);
        }
        result.setSuccess(true);
        return result;
    }

    //运营活动信息的分页查询
    @Override
    public RunMarketingActivitiesPageDTO selectRunMarketingActPage(Page<RunMarketingActivitiesDTO> runMarketingActivitiesPage) {
        RunMarketingActivitiesPageDTO runMarketingActivitiesPageDTO = new RunMarketingActivitiesPageDTO();
        Page<RunMarketingActivitiesRepo> runMarketingActivitiesRepoPage = new Page<RunMarketingActivitiesRepo>();
        BeanUtils.copyProperties(runMarketingActivitiesPage, runMarketingActivitiesRepoPage);
        runMarketingActivitiesRepoPage = runMarketingActivitiesRepository
                .selectMarketingActivitiesPage(runMarketingActivitiesRepoPage);
        List<RunMarketingActivitiesRepo> runMarketingActivitiesRepolist = runMarketingActivitiesRepoPage
                .getResultList();
        List<RunMarketingActivitiesDTO> runMarketingActivitiesDTOList = Lists.newArrayList();
        ResultBase<List<RunChannelListDTO>> resultchannel = new ResultBase<List<RunChannelListDTO>>();
        RunChannelListRepo runChannelListRepo = new RunChannelListRepo();
        resultchannel = runChannelListRepository.selectRunChannelListDataList(runChannelListRepo);
        if (runMarketingActivitiesRepolist != null && runMarketingActivitiesRepolist.size() > 0) {
            RunMarketingActivitiesDTO runMarketingActivitiesDTO = null;
            for (RunMarketingActivitiesRepo runMarketingActivitiesRepo : runMarketingActivitiesRepolist) {
                runMarketingActivitiesDTO = new RunMarketingActivitiesDTO();
                BeanUtils.copyProperties(runMarketingActivitiesRepo, runMarketingActivitiesDTO);
                String imgUrl = runMarketingActivitiesRepo.getActivitiesIcon();
                if (!"".equals(imgUrl) && null != imgUrl) {
                    if (imgUrl.indexOf("run/marketing/") == 0) {
                        imgUrl = imgUrl.replace("run/marketing/", "");
                        runMarketingActivitiesDTO.setActivitiesIcon(imgUrl);
                    }
                }
                String startTime = runMarketingActivitiesRepo.getStartTime();
                String endTime = runMarketingActivitiesRepo.getEndTime();
                String st = startTime.substring(0, startTime.length() - 2);
                String et = endTime.substring(0, endTime.length() - 2);
                runMarketingActivitiesDTO.setStartTime(st);
                runMarketingActivitiesDTO.setEndTime(et);
                runMarketingActivitiesDTOList.add(runMarketingActivitiesDTO);
            }
        }
        runMarketingActivitiesPage.setResultList(runMarketingActivitiesDTOList);
        runMarketingActivitiesPage.setTotalItem(runMarketingActivitiesRepoPage.getTotalItem());
        runMarketingActivitiesPageDTO.setRunMarketingActivitiesDTOPage(runMarketingActivitiesPage);
        runMarketingActivitiesPageDTO.setRunChannelListDTOList(resultchannel.getValue());
        return runMarketingActivitiesPageDTO;
    }

    // 新建运营活动
    @Override
    public ResultBase<String> insertMarketing(RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
            BeanUtils.copyProperties(runMarketingActivitiesDTO, runMarketingActivitiesRepo);
            result = runMarketingActivitiesRepository.saveMarketingActivities(runMarketingActivitiesRepo);
            if (result.isSuccess()) {
                //缓存对象key：Id   value：activityId
                BububaoMarketingActivitiesDO list = bububaoMarketingActivitiesDAO
                        .selectOneDataById(runMarketingActivitiesRepo.getId());
                String activityid = null;
                if (list != null) {
                    activityid = list.getActivityId();
                }
                redisUtil.put("bububao_marketing_activities:" + runMarketingActivitiesRepo.getId(),
                        JSONObject.toJSONString(activityid));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save--MarketingActivities...."
                    + "error location polynomial : RunMarketingActivitiesServiceImpl--insertMarketing()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    // 根据主键修改运营活动
    @Override
    public ResultBase<String> updateMarketing(RunMarketingActivitiesDTO runMarketingActivitiesDTO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
            BeanUtils.copyProperties(runMarketingActivitiesDTO, runMarketingActivitiesRepo);
            result = runMarketingActivitiesRepository.updateMarketingActivities(runMarketingActivitiesRepo);
            if (result.isSuccess()) {
                //缓存对象key：Id   value：activityId
                BububaoMarketingActivitiesDO list = bububaoMarketingActivitiesDAO
                        .selectOneDataById(runMarketingActivitiesRepo.getId());
                String activityid = null;
                if (list != null) {
                    activityid = list.getActivityId();
                }
                redisUtil.put("bububao_marketing_activities:" + runMarketingActivitiesRepo.getId(),
                        JSONObject.toJSONString(activityid));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--MarketingActivities...."
                    + "error location polynomial : RunMarketingActivitiesServiceImpl--updateMarketing()" + "exception："
                    + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    // 根据主键删除运营活动
    @Override
    public ResultBase<String> deleteMarketingActivities(String id) {
        log.info("{}-delete MarketingActivities info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            result = runMarketingActivitiesRepository.deleteByid(id);
            //删除缓存
            if (result.isSuccess()) {
                redisUtil.delete("bububao_marketing_activities:" + id);
            }
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-MarketingActivities delete fail,please find error to...。"
                    + "error location polynomial:RunMarketingActivitiesServiceImpl--deleteMarketingActivities()"
                    + "exception：" + e, ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }

    // 根据ID 查询单个对象的信息
    @Override
    public RunMarketingActivitiesDTO selectOneMarketingActivities(String id) {
        log.info("{}-select one MarketingActivities info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        RunMarketingActivitiesDTO runMarketingActivitiesDTO = new RunMarketingActivitiesDTO();
        try {
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = runMarketingActivitiesRepository.selectOneData(id);
            if (runMarketingActivitiesRepo != null) {
                String startTime = runMarketingActivitiesRepo.getStartTime();
                String endTime = runMarketingActivitiesRepo.getEndTime();
                String st = startTime.substring(0, startTime.length() - 2);
                String et = endTime.substring(0, endTime.length() - 2);
                runMarketingActivitiesRepo.setStartTime(st);
                runMarketingActivitiesRepo.setEndTime(et);
                BeanUtils.copyProperties(runMarketingActivitiesRepo, runMarketingActivitiesDTO);
            }
        } catch (Exception e) {
            log.error("{}-MarketingActivities select one  fail,please find error to...。"
                    + "error location polynomial:RunMarketingActivitiesServiceImpl--selectOneMarketingActivities()"
                    + "exception：" + e, ThreadLocalUtil.getRequestNo());
        }
        return runMarketingActivitiesDTO;
    }

    @Override
    public ResultBase<RunMarketingActivitiesDTO> selectMarketingActivityById(String id) {
        ResultBase<RunMarketingActivitiesDTO> result = new ResultBase<RunMarketingActivitiesDTO>();
        try {
            RunMarketingActivitiesRepo marketingActivitiesRepo = new RunMarketingActivitiesRepo();
            log.info("redis start=====================3333333333333");
            String activityIdJson = redisUtil.getString("bububao_marketing_activities:" + id);
            log.info("redis end=====================3333333");
            String activityId = JSON.parseObject(activityIdJson, String.class);
            if (null != activityId) {
                marketingActivitiesRepo.setActivityId(activityId);
            } else {
                marketingActivitiesRepo = runMarketingActivitiesRepository.selectOneData(id);
                log.info("redis start=====================4444444444444");
                redisUtil.put("bububao_marketing_activities:" + id,
                        JSON.toJSONString(marketingActivitiesRepo.getActivityId()));
                log.info("redis start=====================44444444444444");
            }
            if (null != marketingActivitiesRepo.getActivityId()) {
                RunMarketingActivitiesDTO marketingActivitiesDTO = new RunMarketingActivitiesDTO();
                BeanUtils.copyProperties(marketingActivitiesRepo, marketingActivitiesDTO);
                result.setValue(marketingActivitiesDTO);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-", e, ThreadLocalUtil.getRequestNo());
            log.error("{}-when selectMarketingActivityById, error occured...", ThreadLocalUtil.getRequestNo());
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    @Override
    public ResultBase<List<RunMarketingActivitiesDTO>> selectRunMarketingActForThird(RunMarketingActivitiesBO RunMarketingActivitiesBO) {
        log.info("{}-selectRunMarketingActForThird select begin...", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        /*********************** 参数校验 **************************/
        ResultBase<String> valResult = CheckBitparamForThird(RunMarketingActivitiesBO);
        if (!valResult.isSuccess()) {
            log.info("{}-参数校验失败{}", JSONObject.toJSONString(valResult), ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            /*********************** 查询该渠道满足条件的运营活动 **************************/
            String sourceCode = RunMarketingActivitiesBO.getAllChannel();
            String activitiesType = RunMarketingActivitiesBO.getActivitiesType();
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
            runMarketingActivitiesRepo.setAllChannel(sourceCode);
            runMarketingActivitiesRepo.setUserStep("1");
            if (StringUtil.isNotBlank(activitiesType)) {
                runMarketingActivitiesRepo.setActivitiesType(activitiesType);
            }
            if (StringUtil.isNotBlank(RunMarketingActivitiesBO.getActivityCode())) {
                runMarketingActivitiesRepo.setActivityCode(RunMarketingActivitiesBO.getActivityCode());
            }
            ResultBase<List<RunMarketingActivitiesDTO>> resultMarketingActivities = runMarketingActivitiesRepository
                    .selectMarketingValRepo(runMarketingActivitiesRepo);
            result.setValue(resultMarketingActivities.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("查询运营活动异常{}", e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    /**
     * 活动专属 根据条件查询活动
     * 
     * @param runMarketingActivitiesDTO
     * @return
     */
    @Override
    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActivitiesByCdt(RunMarketingActivitiesBO runMarketingActivitiesBO) {
        log.info("{}-marketingActivitiesByCdt select begin...", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        /*********************** 参数校验 **************************/
        ResultBase<String> valResult = CheckBitparamForThird(runMarketingActivitiesBO);
        if (!valResult.isSuccess()) {
            log.info("{}-marketingActivitiesByCdt>参数校验失败{}", JSONObject.toJSONString(valResult),
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(valResult.getErrorCode());
            result.setErrorMessage(valResult.getErrorMessage());
            return result;
        }
        try {
            /*********************** 查询该渠道满足条件的运营活动 **************************/
            String sourceCode = runMarketingActivitiesBO.getAllChannel();
            String activitiesType = runMarketingActivitiesBO.getActivitiesType();
            String activityCode = runMarketingActivitiesBO.getActivityCode();
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
            runMarketingActivitiesRepo.setAllChannel(sourceCode);
            runMarketingActivitiesRepo.setUserStep("1");
            if (StringUtil.isNotBlank(activitiesType)) {
                runMarketingActivitiesRepo.setActivitiesType(activitiesType);
            }
            if (StringUtil.isNotBlank(activityCode)) {
                runMarketingActivitiesRepo.setActivityCode(activityCode);
            }
            ResultBase<List<RunMarketingActivitiesDTO>> resultMarketingActivities = runMarketingActivitiesRepository
                    .selectMarketingActivitiesRepo(runMarketingActivitiesRepo);
            log.info("{}-marketingActivitiesByCdt>>param={},result={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(runMarketingActivitiesRepo),
                    JSONObject.toJSONString(resultMarketingActivities));
            result.setValue(resultMarketingActivities.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("marketingActivitiesByCdt>查询运营活动异常{}", e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    /**
     * 根据活动code查询活动
     * 
     * @param runMarketingActivitiesDTO
     * @return
     */
    @Override
    public ResultBase<List<RunMarketingActivitiesDTO>> marketingActivitiesByCode(RunMarketingActivitiesBO runMarketingActivitiesBO) {
        log.info("{}-marketingActivitiesByCdt select begin...", ThreadLocalUtil.getRequestNo());
        ResultBase<List<RunMarketingActivitiesDTO>> result = new ResultBase<List<RunMarketingActivitiesDTO>>();
        try {
            /*********************** 查询该渠道满足条件的运营活动 **************************/
            // 活动code不能为空
            if (StringUtils.isEmpty(runMarketingActivitiesBO.getActivityCode())) {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100002.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100002.getValue());
                return result;
            }
            RunMarketingActivitiesRepo runMarketingActivitiesRepo = new RunMarketingActivitiesRepo();
            runMarketingActivitiesRepo.setActivityCode(runMarketingActivitiesBO.getActivityCode());
            if (StringUtil.isNotBlank(runMarketingActivitiesBO.getActivitiesType())) {
                runMarketingActivitiesRepo.setActivitiesType(runMarketingActivitiesBO.getActivitiesType());
            }
            ResultBase<List<RunMarketingActivitiesDTO>> resultMarketingActivities = runMarketingActivitiesRepository
                    .selectMarketingActivitiesRepo(runMarketingActivitiesRepo);
            log.info("{}-marketingActivitiesByCdt>>param={},result={}", ThreadLocalUtil.getRequestNo(),
                    JSONObject.toJSONString(runMarketingActivitiesRepo),
                    JSONObject.toJSONString(resultMarketingActivities));
            List<RunMarketingActivitiesDTO> value = resultMarketingActivities.getValue();
            if (CollectionUtils.isNotEmpty(value)) {
                for (RunMarketingActivitiesDTO pojo : value) {
                    String startTime = DateTimeUtils.covertTimeToString(DateTimeUtils.covertStringToTime(
                            pojo.getStartTime(), DateTimeUtils.ZH_CN_DATETIME_PATTERN_SSS));
                    String endTime = DateTimeUtils.covertTimeToString(DateTimeUtils.covertStringToTime(
                            pojo.getEndTime(), DateTimeUtils.ZH_CN_DATETIME_PATTERN_SSS));
                    pojo.setEndTime(endTime);
                    pojo.setStartTime(startTime);
                }
            }
            result.setValue(value);
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("marketingActivitiesByCdt>查询运营活动异常{}", e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
        }
        return result;
    }

    /**
     * 用户开屏信息
     */
    @Override
    public ResultBase<Boolean> advertHistoryByCdt(RunAdvertHistoryDTO info) {
        ResultBase<Boolean> resultBase = new ResultBase<>();
        resultBase = checkParam(info);
        if (!resultBase.isSuccess()) {
            log.error("advertHistoryByCdt,checkParam{}", JSON.toJSONString(resultBase));
            return resultBase;
        }
        RunAdvertHistoryRepo runAdvertHistoryRepo = new RunAdvertHistoryRepo();
        BeanUtils.copyProperties(info, runAdvertHistoryRepo);
        boolean adverDisplay = runAdvertHistoryRepository.advertHistoryByCdt(runAdvertHistoryRepo);
        resultBase.setSuccess(true);
        resultBase.setValue(adverDisplay);
        return resultBase;
    }

    private ResultBase<Boolean> checkParam(RunAdvertHistoryDTO info) {
        ResultBase<Boolean> result = new ResultBase<>();
        if (StringUtil.isBlank(info.getUnionId())) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERACTIVITY_20003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERACTIVITY_20003.getValue());
            return result;
        }
        if (StringUtil.isBlank(info.getActivitiesId())) {
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100007.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100007.getValue());
            return result;
        }
        result.setSuccess(true);
        return result;
    }

    /**
     * 删除一条数据
     */
    @Override
    public ResultBase<String> deleteByExample(Integer days) {
        ResultBase<String> resultBase = new ResultBase<>();
        try {
            if (null == days) {
                resultBase.setSuccess(false);
                resultBase.setErrorCode(AppErrEnum.ERROR_USERACTIVITY_20010.getCode());
                resultBase.setErrorMessage(AppErrEnum.ERROR_USERACTIVITY_20010.getValue());
                log.error("deleteByExample,checkParam{}", JSON.toJSONString(resultBase));
                return resultBase;
            }
            RunAdvertHistoryRepo runAdvertHistoryRepo = new RunAdvertHistoryRepo();
            Date dateNDays = DateUtils.getDateNDays(new Date(), days.intValue() * (-1));
            runAdvertHistoryRepo.setDisplayTime(DateUtils.shortFormat(dateNDays));
            resultBase = runAdvertHistoryRepository.deleteByExample(runAdvertHistoryRepo);
        } catch (Exception e) {
            log.error("deleteByExample,删除记录失败{}", e);
            resultBase.setSuccess(false);
            resultBase.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            resultBase.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
            return resultBase;
        }
        return resultBase;
    }
}
