package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.HistoryBusinessCriteria;
import com.zhongan.app.run.cms.dao.bean.HistoryBusinessDO;

public interface HistoryBusinessMapper {
    /**
     * @mbggenerated
     */
    int countByCriteria(HistoryBusinessCriteria criteria);

    /**
     * @mbggenerated
     */
    int deleteByCriteria(HistoryBusinessCriteria criteria);

    /**
     * @mbggenerated
     */
    @Delete({ "delete from bububao_history_business", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /**
     * @mbggenerated
     */
    @Insert({ "insert into bububao_history_business (id, biz_time, ", "source_code, source_name, ",
            "acc_num, ins_num, ", "ren_num, ren_pay_num, ", "ren_pay_fee, extra_info, ",
            "creator, gmt_created, modifier, ", "gmt_modified, is_deleted)",
            "values (#{id,jdbcType=BIGINT}, #{bizTime,jdbcType=DATE}, ",
            "#{sourceCode,jdbcType=VARCHAR}, #{sourceName,jdbcType=VARCHAR}, ",
            "#{accNum,jdbcType=DECIMAL}, #{insNum,jdbcType=DECIMAL}, ",
            "#{renNum,jdbcType=DECIMAL}, #{renPayNum,jdbcType=DECIMAL}, ",
            "#{renPayFee,jdbcType=DECIMAL}, #{extraInfo,jdbcType=VARCHAR}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), #{isDeleted,jdbcType=CHAR})" })
    int insert(HistoryBusinessDO record);

    /**
     * @mbggenerated
     */
    int insertSelective(HistoryBusinessDO record);

    /**
     * @mbggenerated
     */
    List<HistoryBusinessDO> selectByCriteriaWithPage(@Param("criteria") HistoryBusinessCriteria criteria,
                                                     @Param("pageInfo") PageInfo pageInfo);

    /**
     * @mbggenerated
     */
    List<HistoryBusinessDO> selectByCriteria(HistoryBusinessCriteria criteria);

    /**
     * @mbggenerated
     */
    @Select({ "select", "id, biz_time, source_code, source_name, acc_num, ins_num, ren_num, ren_pay_num, ",
            "ren_pay_fee, extra_info, creator, gmt_created, modifier, gmt_modified, is_deleted",
            "from bububao_history_business", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    HistoryBusinessDO selectByPrimaryKey(@Param("id") Long id);

    /**
     * @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") HistoryBusinessDO record,
                                  @Param("criteria") HistoryBusinessCriteria criteria);

    /**
     * @mbggenerated
     */
    int updateByCriteria(@Param("record") HistoryBusinessDO record, @Param("criteria") HistoryBusinessCriteria criteria);

    /**
     * @mbggenerated
     */
    int updateByPrimaryKeySelective(HistoryBusinessDO record);

    /**
     * @mbggenerated
     */
    @Update({ "update bububao_history_business", "set biz_time = #{bizTime,jdbcType=DATE},",
            "source_code = #{sourceCode,jdbcType=VARCHAR},", "source_name = #{sourceName,jdbcType=VARCHAR},",
            "acc_num = #{accNum,jdbcType=DECIMAL},", "ins_num = #{insNum,jdbcType=DECIMAL},",
            "ren_num = #{renNum,jdbcType=DECIMAL},", "ren_pay_num = #{renPayNum,jdbcType=DECIMAL},",
            "ren_pay_fee = #{renPayFee,jdbcType=DECIMAL},", "extra_info = #{extraInfo,jdbcType=VARCHAR},",
            "creator = #{creator,jdbcType=VARCHAR},", "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(HistoryBusinessDO record);
}
