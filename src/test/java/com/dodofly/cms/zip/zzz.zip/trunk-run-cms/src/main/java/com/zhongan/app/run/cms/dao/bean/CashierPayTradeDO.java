package com.zhongan.app.run.cms.dao.bean;

import java.math.BigDecimal;
import java.util.Date;

public class CashierPayTradeDO {
    /**
     * 主键 This field corresponds to the column bububao_cashier_pay_trade.id
     *
     * @mbggenerated
     */
    private Long       id;

    /**
     * 代收代付ID This field corresponds to the column
     * bububao_cashier_pay_trade.cashier_id
     *
     * @mbggenerated
     */
    private Long       cashierId;

    /**
     * 保单号 This field corresponds to the column
     * bububao_cashier_pay_trade.policy_no
     *
     * @mbggenerated
     */
    private String     policyNo;

    /**
     * 订单号 This field corresponds to the column
     * bububao_cashier_pay_trade.insured_id
     *
     * @mbggenerated
     */
    private String     insuredId;

    /**
     * 扣款金额 This field corresponds to the column
     * bububao_cashier_pay_trade.deductions_pay
     *
     * @mbggenerated
     */
    private BigDecimal deductionsPay;

    /**
     * 扣款次数 This field corresponds to the column
     * bububao_cashier_pay_trade.deductions_num
     *
     * @mbggenerated
     */
    private Long       deductionsNum;

    /**
     * 扣款日期 This field corresponds to the column
     * bububao_cashier_pay_trade.deductions_date
     *
     * @mbggenerated
     */
    private Date       deductionsDate;

    /**
     * 扣款状态(1：支付成功 2：支付失败 ) This field corresponds to the column
     * bububao_cashier_pay_trade.deductions_status
     *
     * @mbggenerated
     */
    private Long       deductionsStatus;

    /**
     * This field corresponds to the column bububao_cashier_pay_trade.creator
     *
     * @mbggenerated
     */
    private String     creator;

    /**
     * This field corresponds to the column
     * bububao_cashier_pay_trade.gmt_created
     *
     * @mbggenerated
     */
    private Date       gmtCreated;

    /**
     * This field corresponds to the column bububao_cashier_pay_trade.modifier
     *
     * @mbggenerated
     */
    private String     modifier;

    /**
     * This field corresponds to the column
     * bububao_cashier_pay_trade.gmt_modified
     *
     * @mbggenerated
     */
    private Date       gmtModified;

    /**
     * This field corresponds to the column bububao_cashier_pay_trade.is_deleted
     *
     * @mbggenerated
     */
    private String     isDeleted;

    /** @mbggenerated
     */
    public CashierPayTradeDO(Long id, Long cashierId, String policyNo, String insuredId, BigDecimal deductionsPay,
                             Long deductionsNum, Date deductionsDate, Long deductionsStatus, String creator,
                             Date gmtCreated, String modifier, Date gmtModified, String isDeleted) {
        this.id = id;
        this.cashierId = cashierId;
        this.policyNo = policyNo;
        this.insuredId = insuredId;
        this.deductionsPay = deductionsPay;
        this.deductionsNum = deductionsNum;
        this.deductionsDate = deductionsDate;
        this.deductionsStatus = deductionsStatus;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /** @mbggenerated
     */
    public CashierPayTradeDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.id
     *
     * @return the value of bububao_cashier_pay_trade.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_cashier_pay_trade.id
     *
     * @param id the value for bububao_cashier_pay_trade.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.cashier_id
     *
     * @return the value of bububao_cashier_pay_trade.cashier_id
     * @mbggenerated
     */
    public Long getCashierId() {
        return cashierId;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.cashier_id
     *
     * @param cashierId the value for bububao_cashier_pay_trade.cashier_id
     * @mbggenerated
     */
    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.policy_no
     *
     * @return the value of bububao_cashier_pay_trade.policy_no
     * @mbggenerated
     */
    public String getPolicyNo() {
        return policyNo;
    }

    /**
     * Sets the value of the database column bububao_cashier_pay_trade.policy_no
     *
     * @param policyNo the value for bububao_cashier_pay_trade.policy_no
     * @mbggenerated
     */
    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.insured_id
     *
     * @return the value of bububao_cashier_pay_trade.insured_id
     * @mbggenerated
     */
    public String getInsuredId() {
        return insuredId;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.insured_id
     *
     * @param insuredId the value for bububao_cashier_pay_trade.insured_id
     * @mbggenerated
     */
    public void setInsuredId(String insuredId) {
        this.insuredId = insuredId;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.deductions_pay
     *
     * @return the value of bububao_cashier_pay_trade.deductions_pay
     * @mbggenerated
     */
    public BigDecimal getDeductionsPay() {
        return deductionsPay;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.deductions_pay
     *
     * @param deductionsPay the value for
     *            bububao_cashier_pay_trade.deductions_pay
     * @mbggenerated
     */
    public void setDeductionsPay(BigDecimal deductionsPay) {
        this.deductionsPay = deductionsPay;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.deductions_num
     *
     * @return the value of bububao_cashier_pay_trade.deductions_num
     * @mbggenerated
     */
    public Long getDeductionsNum() {
        return deductionsNum;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.deductions_num
     *
     * @param deductionsNum the value for
     *            bububao_cashier_pay_trade.deductions_num
     * @mbggenerated
     */
    public void setDeductionsNum(Long deductionsNum) {
        this.deductionsNum = deductionsNum;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.deductions_date
     *
     * @return the value of bububao_cashier_pay_trade.deductions_date
     * @mbggenerated
     */
    public Date getDeductionsDate() {
        return deductionsDate;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.deductions_date
     *
     * @param deductionsDate the value for
     *            bububao_cashier_pay_trade.deductions_date
     * @mbggenerated
     */
    public void setDeductionsDate(Date deductionsDate) {
        this.deductionsDate = deductionsDate;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.deductions_status
     *
     * @return the value of bububao_cashier_pay_trade.deductions_status
     * @mbggenerated
     */
    public Long getDeductionsStatus() {
        return deductionsStatus;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.deductions_status
     *
     * @param deductionsStatus the value for
     *            bububao_cashier_pay_trade.deductions_status
     * @mbggenerated
     */
    public void setDeductionsStatus(Long deductionsStatus) {
        this.deductionsStatus = deductionsStatus;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.creator
     *
     * @return the value of bububao_cashier_pay_trade.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column bububao_cashier_pay_trade.creator
     *
     * @param creator the value for bububao_cashier_pay_trade.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.gmt_created
     *
     * @return the value of bububao_cashier_pay_trade.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.gmt_created
     *
     * @param gmtCreated the value for bububao_cashier_pay_trade.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.modifier
     *
     * @return the value of bububao_cashier_pay_trade.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column bububao_cashier_pay_trade.modifier
     *
     * @param modifier the value for bububao_cashier_pay_trade.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.gmt_modified
     *
     * @return the value of bububao_cashier_pay_trade.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.gmt_modified
     *
     * @param gmtModified the value for bububao_cashier_pay_trade.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_pay_trade.is_deleted
     *
     * @return the value of bububao_cashier_pay_trade.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_pay_trade.is_deleted
     *
     * @param isDeleted the value for bububao_cashier_pay_trade.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
