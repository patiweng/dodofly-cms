package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.WeekBusinessDO;

@Component
public interface ExportWeekBusinessDAO {

    List<WeekBusinessDO> selectWeekBusinessList(Map<String, Object> map);

    Integer selectCounts(Map<String, Object> map);

    List<WeekBusinessDO> queryWeekListForExcel(Map<String, String> map);

}
