package com.zhongan.app.run.cms.bean.dataobject;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class WeekBusinessDO implements Cloneable {
    private Long    id;
    private String  source_code;
    private String  source_name;
    private String  start_date;
    private String  end_date;
    private Long    new_shouquan_user;
    private Long    new_insure_user;
    private Long    active_all_user;
    private Long    active_old_user;
    private Long    active_new_user;
    private String  active_persent;
    private Long    premium_xubao_user;
    private Long    premium_mianfei_user;
    private Long    premium_fufei_user;
    private String  premium_shouru;
    private String  premium_ARPU;

    private Integer pageSize;
    private Integer currentPage;
    private String  sdate;
    private String  edate;
    private String  bopsFlag;

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            log.error("clone  fail===={}", e);
        }
        return null;
    }
}
