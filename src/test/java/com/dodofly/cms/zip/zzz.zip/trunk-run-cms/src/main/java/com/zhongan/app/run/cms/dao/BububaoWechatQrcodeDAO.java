package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.bean.dataobject.BububaoWechatQrcodeDO;

@Component
public interface BububaoWechatQrcodeDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoWechatQrcodeDO> selectDataByCdt(BububaoWechatQrcodeDO bububaoWechatQrcodeDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoWechatQrcodeDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoWechatQrcodeDO
	    */
	   void insert(BububaoWechatQrcodeDO bububaoWechatQrcodeDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoWechatQrcodeDO
	    */
	   void update(BububaoWechatQrcodeDO bububaoWechatQrcodeDO);
}
