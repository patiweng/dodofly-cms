package com.zhongan.app.run.cms.dao;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;

@Component
public interface TransLogDAO {

    List<TransLogDO> selectTransLogByDate(Map<String, String> map);

}
