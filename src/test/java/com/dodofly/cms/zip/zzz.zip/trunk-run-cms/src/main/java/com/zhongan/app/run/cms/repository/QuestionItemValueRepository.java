package com.zhongan.app.run.cms.repository;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.QuestionItemValueDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.QuestionItemValueRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.dao.QuestionItemValueDAO;

@Slf4j
@Repository
public class QuestionItemValueRepository {

    @Resource
    private QuestionItemValueDAO questionItemValueDAO;

    @Resource
    private Sequence             seqQuestionItemValue;

    public QuestionItemValueRepo selectDataById(Long id) {
        QuestionItemValueDO questionItemValueDO = questionItemValueDAO.selectDataById(id);
        QuestionItemValueRepo qRepo = null;
        if (null != questionItemValueDO) {
            qRepo = new QuestionItemValueRepo();
            BeanUtils.copyProperties(questionItemValueDO, qRepo);
        }
        return qRepo;
    }

    public List<QuestionItemValueRepo> selectDataByCdt(QuestionItemValueRepo questionItemValueRepo) {
        List<QuestionItemValueRepo> repoList = Lists.newArrayList();
        QuestionItemValueDO questionItemValueDO = new QuestionItemValueDO();
        BeanUtils.copyProperties(questionItemValueRepo, questionItemValueDO);
        List<QuestionItemValueDO> doList = questionItemValueDAO.selectDataByCdt(questionItemValueDO);
        if (null != doList && doList.size() > 0) {
            QuestionItemValueRepo repo = null;
            for (QuestionItemValueDO qdo : doList) {
                repo = new QuestionItemValueRepo();
                BeanUtils.copyProperties(qdo, repo);
                repoList.add(repo);
            }
        }
        return repoList;
    }

    /**
     * 分页查询
     * 
     * @param questionItemRepo
     * @return
     */
    public Page<QuestionItemValueRepo> selectQuestionItemValueDataPage(Page<QuestionItemValueRepo> questionItemValueRepo) {
        QuestionItemValueDO questionItemValueDO = new QuestionItemValueDO();
        if (null != questionItemValueRepo.getParam()) {
            BeanUtils.copyProperties(questionItemValueRepo.getParam(), questionItemValueDO);
        }
        questionItemValueDO.setIsDeleted(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", questionItemValueRepo.getStartRow());
        map.put("pageSize", questionItemValueRepo.getPageSize());
        map.put("questionItemValueDO", questionItemValueDO);
        List<QuestionItemValueDO> questionItemValueDOList = questionItemValueDAO.selectQuestionItemValueList(map);
        List<QuestionItemValueRepo> questionItemValueRepoList = Lists.newArrayList();
        if (null != questionItemValueDOList && 0 != questionItemValueDOList.size()) {
            QuestionItemValueRepo questionItemValueList = null;
            for (QuestionItemValueDO questionItemValueDOlists : questionItemValueDOList) {
                questionItemValueList = new QuestionItemValueRepo();
                BeanUtils.copyProperties(questionItemValueDOlists, questionItemValueList);
                questionItemValueRepoList.add(questionItemValueList);
            }
        }
        questionItemValueRepo.setResultList(questionItemValueRepoList);
        Integer counts = questionItemValueDAO.selectCounts(map);
        questionItemValueRepo.setTotalItem(counts);
        return questionItemValueRepo;
    }

    /**
     * 删除
     * 
     * @param id
     * @return
     */
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        questionItemValueDAO.updateDeletedById(id);
        result.setSuccess(true);
        return result;
    }

    /**
     * 插入一条新的记录
     * 
     * @param questionItemValueRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> saveQuestionItemValue(QuestionItemValueRepo questionItemValueRepo) throws Exception {
        log.info("{}-insert questionItemValue。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        QuestionItemValueDO questionItemValueDO = new QuestionItemValueDO();
        BeanUtils.copyProperties(questionItemValueRepo, questionItemValueDO);
        Long id = seqQuestionItemValue.nextValue();
        questionItemValueDO.setId(id);
        questionItemValueDO.setCreator(RunConstants.SYSTEM_NAME);
        questionItemValueDAO.insert(questionItemValueDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    /**
     * 根据主键修改信息
     * 
     * @param questionItemRepo
     * @return
     * @throws Exception
     */
    public ResultBase<String> updateQuestionItemList(QuestionItemValueRepo questionItemValueRepo) throws Exception {
        ResultBase<String> result = new ResultBase<String>();
        log.info("{}-update questionItemValue。。。Repository。。。");
        QuestionItemValueDO questionItemValueDO = new QuestionItemValueDO();
        BeanUtils.copyProperties(questionItemValueRepo, questionItemValueDO);
        questionItemValueDAO.update(questionItemValueDO);
        result.setSuccess(true);
        return result;
    }
}
