package com.zhongan.app.run.cms.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.google.common.collect.Maps;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorDTO;
import com.zhongan.app.run.cms.bean.web.AnalysisMonitorPageDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.service.ExportExcelService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

/**
 * 类ExportExcelForRegRateController.java的实现描述：注册转化率
 * 
 * @author panchuanhe 2017年1月11日 下午5:25:12
 */
@RestController
@RequestMapping("/run/cms/excel")
@Slf4j
public class ExportExcelController {
    @Resource
    private ExportExcelService exportExcelServiceImpl;

    /**
     * 导出 excel
     * 
     * @param response
     * @param sdate
     * @param edate
     */
    @RequestMapping(value = "/doexportexcelforregrate/{sdate}/{edate}", method = RequestMethod.GET)
    public void doExportExcelForRegRate(HttpServletResponse response, @PathVariable String sdate,
                                        @PathVariable String edate) {
        log.info("{}-/doexportexcelforregrate,doExportExcelForRegRate start……", ThreadLocalUtil.getRequestNo());
        exportExcelServiceImpl.doExportExcelForRegRate(response, sdate, edate);
    }

    /**
     * 查询打点分析表 分页。。。
     * 
     * @return
     */
    @RequestMapping(value = "/select/selectanalysismonitorlistpage")
    public ModelAndView selectAnalysisMonitorlistpage(AnalysisMonitorDTO analysisMonitorDTO, HttpServletRequest request) {
        log.info("{}-into /select/selectAnalysisMonitorlistpage,param={ " + analysisMonitorDTO.toString() + " }",
                ThreadLocalUtil.getRequestNo());
        Page<AnalysisMonitorDTO> analysisMonitorPage = new Page<AnalysisMonitorDTO>(analysisMonitorDTO.getPageSize(),
                analysisMonitorDTO.getCurrentPage());
        analysisMonitorPage.setParam(analysisMonitorDTO);
        AnalysisMonitorPageDTO result = exportExcelServiceImpl.selectAnalysisMonitorList(analysisMonitorPage);
        analysisMonitorPage = result.getAnalysisMonitorDTOPage();
        Map<String, Object> model = Maps.newHashMap();
        if (analysisMonitorPage != null) {
            model.put("analysisMonitorList", analysisMonitorPage.getResultList());
        }
        model.put("role", result.getRole());
        model.put("analysisMonitorDTO", analysisMonitorDTO);
        model.put("page", analysisMonitorPage);
        return new ModelAndView("cms/analysisMonitor", model);
    }

    @RequestMapping(value = "/add/addanalysismonitoroftodaydata", method = RequestMethod.POST)
    public ResultBase<String> addAnalysisMonitorofTodayData() {
        log.info("{}-into /add/addanalysismonitoroftodaydata", ThreadLocalUtil.getRequestNo());
        return exportExcelServiceImpl.addAnalysisMonitorofTodayData();
    }
}
