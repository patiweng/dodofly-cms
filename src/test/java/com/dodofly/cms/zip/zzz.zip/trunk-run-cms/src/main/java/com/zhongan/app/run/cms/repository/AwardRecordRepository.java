package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Repository;

import com.alibaba.common.lang.StringUtil;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.taobao.tddl.client.sequence.exception.SequenceException;
import com.zhongan.app.run.cms.bean.dataobject.AwardRecordDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.AwardRecordRepo;
import com.zhongan.app.run.cms.bean.web.AwardRecordDTO;
import com.zhongan.app.run.cms.dao.AwardRecordDAO;

@Repository
public class AwardRecordRepository {

    @Resource
    private AwardRecordDAO awardRecordDAO;
    @Resource
    private Sequence       awardRecordSequence;

    /**
     * 向用户奖励记录表中插入一条数据
     * 
     * @param awardRecordDO
     * @throws SequenceException
     */
    public long insertAwardRecord(AwardRecordDO awardRecordDO) throws SequenceException {
        long id = awardRecordSequence.nextValue();
        awardRecordDO.setId(id);
        awardRecordDAO.insertAwardRecord(awardRecordDO);
        return id;
    }

    public void updateAwardRecord(AwardRecordDTO awardRecordDTO) {
        awardRecordDAO.updateAwardRecord(awardRecordDTO);
    }

    /**
     * 根据条件查询奖励记录信息
     * 
     * @param awardRecordRepo
     * @return List<AwardRecordDO>
     */
    public List<AwardRecordRepo> selectAwardRecordsByCdt(AwardRecordRepo awardRecordRepo) {
        AwardRecordDO awardRecordDO = new AwardRecordDO();
        BeanUtils.copyProperties(awardRecordRepo, awardRecordDO);
        List<AwardRecordDO> awardRecordDOs = awardRecordDAO.selectDataByCdt(awardRecordDO);
        List<AwardRecordRepo> awardRecordRepos = new ArrayList<AwardRecordRepo>();
        if (0 != awardRecordDOs.size()) {
            AwardRecordRepo awardRecordRepoOut = null;
            for (AwardRecordDO awardRecordDOOut : awardRecordDOs) {
                awardRecordRepoOut = new AwardRecordRepo();
                BeanUtils.copyProperties(awardRecordDOOut, awardRecordRepoOut);
                awardRecordRepos.add(awardRecordRepoOut);
            }
        }
        return awardRecordRepos;
    }

    public Page<AwardRecordRepo> selectAwardRecordListPage(Page<AwardRecordRepo> page)
            throws CloneNotSupportedException {
        AwardRecordDO awardRecordDO = new AwardRecordDO();
        BeanUtils.copyProperties(page.getParam(), awardRecordDO);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", page.getStartRow());
        map.put("pageSize", page.getPageSize());
        map.put("awardRecordDO", awardRecordDO);
        List<AwardRecordDO> awardRecordDOList = awardRecordDAO.selectAwardRecordListPage(map);
        List<AwardRecordRepo> awardRecordRepoList = Lists.newArrayList();
        if (awardRecordDOList != null && awardRecordDOList.size() > 0) {
            AwardRecordRepo awardRecordRepo = new AwardRecordRepo();
            for (AwardRecordDO awardRecordDO__ : awardRecordDOList) {
                AwardRecordRepo clone = (AwardRecordRepo) awardRecordRepo.clone();
                BeanUtils.copyProperties(awardRecordDO__, clone);
                awardRecordRepoList.add(clone);
            }
        }
        page.setResultList(awardRecordRepoList);
        Integer count = awardRecordDAO.selectCounts(map);
        page.setTotalItem(count);
        return page;
    }

    public AwardRecordRepo selectAwardRecordOne(String id) {
        if (StringUtil.isNotBlank(id)) {
            AwardRecordDO awardRecordDO = awardRecordDAO.selectDataById(Long.valueOf(id));
            if (null != awardRecordDO) {
                AwardRecordRepo awardRecordRepo = new AwardRecordRepo();
                BeanUtils.copyProperties(awardRecordDO, awardRecordRepo);
                return awardRecordRepo;
            }
        }
        return null;
    }

    public void updateById(AwardRecordRepo awardRecordRepo) {
        AwardRecordDO awardRecordDO = new AwardRecordDO();
        BeanUtils.copyProperties(awardRecordRepo, awardRecordDO);
        awardRecordDAO.update(awardRecordDO);
    }

    public List<AwardRecordRepo> selectAwardRecordListOfExcel(AwardRecordRepo awardRecordRepo)
            throws CloneNotSupportedException {
        List<AwardRecordRepo> repoList = Lists.newArrayList();
        AwardRecordDO awardRecordDO = new AwardRecordDO();
        BeanUtils.copyProperties(awardRecordRepo, awardRecordDO);
        List<AwardRecordDO> doList = awardRecordDAO.selectAwardRecordListOfExcel(awardRecordDO);
        if (null != doList && doList.size() > 0) {
            AwardRecordRepo repo = new AwardRecordRepo();
            for (AwardRecordDO awardRecordDO2 : doList) {
                AwardRecordRepo clone = (AwardRecordRepo) repo.clone();
                BeanUtils.copyProperties(awardRecordDO2, clone);
                repoList.add(clone);
            }
        }
        return repoList;
    }
}
