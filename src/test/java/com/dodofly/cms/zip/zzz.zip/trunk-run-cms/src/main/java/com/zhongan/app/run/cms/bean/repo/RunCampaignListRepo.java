package com.zhongan.app.run.cms.bean.repo;

import lombok.Data;

@Data
public class RunCampaignListRepo {
	private String id;//主键
	private String channelNo;//渠道号
	private String name;//渠道名称
	private String campaignName;//营销活动名称
	private String campaignId;//营销活动ID
	private String packageId;//产品组合 id
	private String productCode;//产品组合code
	private String campaignType;//活动类型
	private String versionId;//版型 id	
	private String activityRequire;//活动要求
	private String targetCoverage;//保额
	private String payActivity;//付费活动  1，是   0，否
	private String introName;//注册专属  1，是  0，否
	private String createTime;//创建时间
	private String status;//状态  1=正常  0=无效
	private String channelId;//渠道ID核心
}
