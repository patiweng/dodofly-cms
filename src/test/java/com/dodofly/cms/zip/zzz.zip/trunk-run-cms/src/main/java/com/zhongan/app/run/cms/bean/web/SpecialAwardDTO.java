package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

import lombok.Data;

/**
 * 类SpecialAwardDTO.java的实现描述：特殊奖励配置表DTO
 * 
 * @author panchuanhe 2017年3月15日 下午4:56:34
 */
@Data
public class SpecialAwardDTO implements Cloneable {

    /******* id **********/
    private Long    id;
    /******** requireid *********/
    private Integer requireid;
    /******** 特殊奖励描述 *********/
    private String  description;
    /******** 最小抽奖次数 *********/
    private Integer minPlayTimes;
    /******** 最大抽奖次数 *********/
    private Integer maxPlayTimes;
    /******* 是否已被抽中 0 否 1 是 **********/
    private String  isWon;
    /********* 创建人（用户ID） ********/
    private String  creator;
    /******** 修改人（用户ID） *********/
    private Date    modifier;
    /******** 创建时间 *********/
    private Date    createtime;
    /********* 修改时间 ********/
    private String  modifytime;
    /******** 是否删除 0 否 1 是 *********/
    private String  isDeleted;

    private Integer pageSize;
    private Integer currentPage;

    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
