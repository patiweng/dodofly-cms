package com.zhongan.app.run.cms.bean.web;

import lombok.Data;

@Data
public class AwardInfoDTO {

    private Long   awardRecordId; //奖品记录表id
    private String awardName;    //奖品名称
    private String awardType;    //奖品类型
    private String awardIdentify; //奖品标识
    private String customerName; //中奖人
    private String customerPhone; //中奖人手机号

}
