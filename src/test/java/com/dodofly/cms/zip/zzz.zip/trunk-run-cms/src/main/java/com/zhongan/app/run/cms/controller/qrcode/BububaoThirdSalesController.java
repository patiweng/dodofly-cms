package com.zhongan.app.run.cms.controller.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultSalesDto;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.service.qrcode.BububaoThirdSalesService;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@RestController
@RequestMapping(value = "/run/cms/qrcode/sales")
@Slf4j
public class BububaoThirdSalesController {

    @Resource
    private BububaoThirdSalesService bububaoThirdSalesServiceImpl;

    /**
     * 批量保存业务员，csv导入
     * 
     * @param request
     * @param response
     * @return
     */
    @RequestMapping(value = "/csv/saveSaless", method = RequestMethod.POST)
    public BaseResult<String> saveSaless(HttpServletRequest request, HttpServletResponse response) {
        log.info("{}-------------BububaoThirdSalesController.saveSaless---------start", ThreadLocalUtil.getRequestNo());
        BaseResult<String> result = null;
        try {
            result = bububaoThirdSalesServiceImpl.insertBatchSaless(request, "files", "csv");
        } catch (Exception e) {
            log.error("{}-------------BububaoThirdSalesController.saveSaless---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}-------------BububaoThirdSalesController.saveSaless---------end");
        return result;
    }

    /**
     * 分页查询业务员信息
     * 
     * @param param
     * @return
     */
    @RequestMapping(value = "/select/page", method = RequestMethod.POST)
    public BaseResult<PageDTO<ResultSalesDto>> findSalessPage(@RequestBody ParamDto param) {
        log.info("{}-------------BububaoThirdSalesController.findSalessPage---------start,param:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<PageDTO<ResultSalesDto>> result = null;
        try {
            result = bububaoThirdSalesServiceImpl.findSalessPage(param);
        } catch (Exception e) {
            log.error("{}-------------BububaoThirdSalesController.findSalessPage---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<PageDTO<ResultSalesDto>>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}-------------BububaoThirdSalesController.findSalessPage---------end",
                ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 删除业务员信息
     * 
     * @param params
     * @return
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    public BaseResult<String> deleteSaless(@RequestBody List<ParamDto> params) {
        log.info("{}------------BububaoThirdSalesController.deleteSaless---------start,params:{}",
                ThreadLocalUtil.getRequestNo(), params);
        BaseResult<String> result = null;
        try {
            result = bububaoThirdSalesServiceImpl.deleteBatchSaless(params);
        } catch (Exception e) {
            log.error("{}------------BububaoThirdSalesController.deleteSaless---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdSalesController.deleteSaless---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }

    /**
     * 导出业务员信息
     * 
     * @param param
     * @return
     */
    @RequestMapping(value = "/export", method = RequestMethod.POST)
    public BaseResult<String> exportSaless(@RequestBody ParamDto param) {
        log.info("{}------------BububaoThirdSalesController.exportSaless---------start,params:{}",
                ThreadLocalUtil.getRequestNo(), param);
        BaseResult<String> result = null;
        try {
            result = bububaoThirdSalesServiceImpl.exportSaless(param);
        } catch (Exception e) {
            log.error("{}------------BububaoThirdSalesController.exportSaless---------exception:",
                    ThreadLocalUtil.getRequestNo(), e);
            result = new BaseResult<String>();
            result.setCode(AppErrEnum.ERROR_SYS_0001.getCode());
            result.setMessage(AppErrEnum.ERROR_SYS_0001.getValue());
        }
        log.info("{}------------BububaoThirdSalesController.exportSaless---------end", ThreadLocalUtil.getRequestNo());
        return result;
    }
}
