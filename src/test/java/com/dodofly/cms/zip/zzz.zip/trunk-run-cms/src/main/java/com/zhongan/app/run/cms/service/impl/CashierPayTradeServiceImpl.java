package com.zhongan.app.run.cms.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeQueryDTO;
import com.zhongan.app.run.cms.bean.web.CashierPayTradeResDTO;
import com.zhongan.app.run.cms.conver.CashierPayTradeConvert;
import com.zhongan.app.run.cms.dao.CashierPayTradeMapper;
import com.zhongan.app.run.cms.dao.bean.CashierPayTradeCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierPayTradeCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.CashierPayTradeDO;
import com.zhongan.app.run.cms.service.ICashierPayTradeService;
import com.zhongan.health.common.share.bean.PageDTO;

@Service("cashierPayTradeService")
public class CashierPayTradeServiceImpl implements ICashierPayTradeService {

    @Resource
    private CashierPayTradeMapper cashierPayTradeMapper;

    @Resource
    private Sequence              seqCashierPayTrade;

    @SuppressWarnings("rawtypes")
    @Override
    public PageDTO<CashierPayTradeResDTO> queryCashierPayTradeList(CashierPayTradeQueryDTO queryDTO) throws Exception {
        int currentPage = queryDTO.getCurrentPage() < 1 ? 1 : queryDTO.getCurrentPage();
        int startRow = queryDTO.getStartRow();
        if (startRow < 0) {
            startRow = queryDTO.getPageSize() * (currentPage - 1);
        }
        PageInfo pageInfo = new PageInfo(currentPage, queryDTO.getPageSize(), startRow);
        pageInfo.getParamMap().put("phone", queryDTO.getPhone());
        pageInfo.getParamMap().put("certNo", queryDTO.getCertNo());
        pageInfo.getParamMap().put("policyNo", queryDTO.getPolicyNo());
        pageInfo.getParamMap().put("startDate", queryDTO.getStartTime());
        pageInfo.getParamMap().put("endDate", queryDTO.getEndTime());
        pageInfo.getParamMap().put("deductionsStatus", queryDTO.getDeductionsStatus());
        pageInfo.getParamMap().put("openChannel", queryDTO.getOpenChannel());

        List<Map> results = this.cashierPayTradeMapper.queryCashierPayTradeList(pageInfo);
        Long totalCount = this.cashierPayTradeMapper.queryCashierPayTradeCount(pageInfo);

        PageDTO<CashierPayTradeResDTO> pageResult = new PageDTO<CashierPayTradeResDTO>(queryDTO.getPageSize(),
                currentPage);
        pageResult.setTotalItem(totalCount.intValue());
        pageResult.setResultList(CashierPayTradeConvert.convertToDTOs(results));
        return pageResult;
    }

    @Override
    public Long saveOrUpdateCashierPayTrade(CashierPayTradeDTO payTradeDTO) throws Exception {
        List<CashierPayTradeDO> payTradeDOs = cashierPayTradeMapper.selectByCriteria(buildCriteria(payTradeDTO));
        if (CollectionUtils.isEmpty(payTradeDOs)) {
            long nextValue = seqCashierPayTrade.nextValue();
            CashierPayTradeDO cashierPayTradeDO = CashierPayTradeConvert.convertToDO(payTradeDTO);
            cashierPayTradeDO.setId(nextValue);
            cashierPayTradeDO.setDeductionsNum(1L);
            cashierPayTradeMapper.insert(cashierPayTradeDO);
            return nextValue;
        } else {
            CashierPayTradeDO cashierPayTradeDO = payTradeDOs.get(0);
            Long deductionsNum = cashierPayTradeDO.getDeductionsNum();
            payTradeDTO.setId(cashierPayTradeDO.getId());
            payTradeDTO.setDeductionsNum(++deductionsNum);
            cashierPayTradeMapper.updateByPrimaryKeySelective(CashierPayTradeConvert.convertToDO(payTradeDTO));
            return cashierPayTradeDO.getId();
        }
    }

    @Override
    public CashierPayTradeResDTO queryCashierPayTradeByCondition(CashierPayTradeDTO payTradeDTO) throws Exception {
        List<CashierPayTradeDO> payTradeDOs = cashierPayTradeMapper.selectByCriteria(buildCriteria(payTradeDTO));
        if (CollectionUtils.isEmpty(payTradeDOs)) {
            return null;
        }
        return CashierPayTradeConvert.convertTradeResDTO(payTradeDOs);
    }

    public CashierPayTradeCriteria buildCriteria(CashierPayTradeDTO payTradeDTO) {
        CashierPayTradeCriteria cashierPayTradeCriteria = new CashierPayTradeCriteria();
        Criteria criteria = cashierPayTradeCriteria.createCriteria();
        if (StringUtils.isNotEmpty(payTradeDTO.getPolicyNo())) {
            criteria.andPolicyNoEqualTo(payTradeDTO.getPolicyNo());
        }
        if (StringUtils.isNotEmpty(payTradeDTO.getInsuredId())) {
            criteria.andInsuredIdEqualTo(payTradeDTO.getInsuredId());
        }
        return cashierPayTradeCriteria;
    }
}
