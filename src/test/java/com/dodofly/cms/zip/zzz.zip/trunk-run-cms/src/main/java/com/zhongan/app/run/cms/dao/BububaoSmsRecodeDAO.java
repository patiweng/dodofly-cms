package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.springframework.stereotype.Component;
import com.zhongan.app.run.cms.bean.dataobject.BububaoSmsRecodeDO;

@Component
public interface BububaoSmsRecodeDAO {
	 /**
	    * 根据条件查询数据
	    * @return
	    */
	   List<BububaoSmsRecodeDO> selectDataByCdt(BububaoSmsRecodeDO bububaoSmsRecodeDO);
	   
	   /**
	    * 根据id查询数据
	    * @param id
	    * @return
	    */
	   BububaoSmsRecodeDO selectOneDataById(String id);
	   
	   /**
	    * 插入数据
	    * @param BububaoSmsRecodeDO
	    */
	   void insert(BububaoSmsRecodeDO bububaoSmsRecodeDO);
	   
	   /**
	    * 更新数据
	    * @param BububaoSmsRecodeDO
	    */
	   void update(BububaoSmsRecodeDO bububaoSmsRecodeDO);
}
