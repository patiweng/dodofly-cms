package com.zhongan.app.run.cms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityPresentDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.ActivityPresentRepo;
import com.zhongan.app.run.cms.bean.web.ActivityPresentDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.dao.BububaoActivityPresentDAO;

@Slf4j
@Component
public class ActivityPresentRepository {

    @Resource
    private BububaoActivityPresentDAO activityPresentDAO;

    @Resource
    private Sequence                  seqActivityPresent;

    public ActivityPresentRepo selectDataById(Long id) {
        ActivityPresentRepo activityPresentRepo = null;
        BububaoActivityPresentDO bububaoActivityPresentDO = activityPresentDAO.selectOneDataById(id.toString());
        if (null != bububaoActivityPresentDO) {
            activityPresentRepo = new ActivityPresentRepo();
            BeanUtils.copyProperties(bububaoActivityPresentDO, activityPresentRepo);
        }
        return activityPresentRepo;
    }

    public List<ActivityPresentRepo> selectDataByCdt(ActivityPresentRepo activityPresentRepo) {
        BububaoActivityPresentDO bububaoActivityPresentDO = new BububaoActivityPresentDO();
        BeanUtils.copyProperties(activityPresentRepo, bububaoActivityPresentDO);
        List<BububaoActivityPresentDO> activityPresentDOs = activityPresentDAO
                .selectDataByCdt(bububaoActivityPresentDO);
        List<ActivityPresentRepo> activityPresentRepos = new ArrayList<ActivityPresentRepo>();
        if (0 != activityPresentDOs.size()) {
            ActivityPresentRepo activityPresentRepoOut = null;
            for (BububaoActivityPresentDO activityPresentDO : activityPresentDOs) {
                activityPresentRepoOut = new ActivityPresentRepo();
                BeanUtils.copyProperties(activityPresentDO, activityPresentRepoOut);
                activityPresentRepos.add(activityPresentRepoOut);
            }
        }
        return activityPresentRepos;
    }

    //删除信息
    public ResultBase<String> deleteByid(String id) {
        ResultBase<String> result = new ResultBase<String>();
        activityPresentDAO.updateByid(id);
        result.setSuccess(true);
        return result;
    }
    //分页

    public Page<ActivityPresentRepo> selectActivityPresentDataPage(Page<ActivityPresentRepo> activityPresentRepoPage) {

        BububaoActivityPresentDO bububaoActivityPresentDO = new BububaoActivityPresentDO();
        if (null != activityPresentRepoPage.getParam()) {
            BeanUtils.copyProperties(activityPresentRepoPage.getParam(), bububaoActivityPresentDO);
        }
        bububaoActivityPresentDO.setIsDeleted(RunConstants.IS_STATUS);
        Map<String, Object> map = Maps.newHashMap();
        map.put("startRow", activityPresentRepoPage.getStartRow());
        map.put("pageSize", activityPresentRepoPage.getPageSize());
        map.put("bububaoActivityPresentDO", bububaoActivityPresentDO);
        List<BububaoActivityPresentDO> bububaoActivityPresentDOList = activityPresentDAO.selectActivityPresentList(map);
        List<ActivityPresentRepo> activityPresentRepoList = Lists.newArrayList();
        if (null != bububaoActivityPresentDOList && 0 != bububaoActivityPresentDOList.size()) {
            ActivityPresentRepo ActivityPresentRepo = null;
            for (BububaoActivityPresentDO bububaoActivityPresentDOlists : bububaoActivityPresentDOList) {
            	ActivityPresentRepo = new ActivityPresentRepo();
                BeanUtils.copyProperties(bububaoActivityPresentDOlists, ActivityPresentRepo);
                activityPresentRepoList.add(ActivityPresentRepo);
            }
        }
        activityPresentRepoPage.setResultList(activityPresentRepoList);
        Integer counts = activityPresentDAO.selectCounts(map);
        activityPresentRepoPage.setTotalItem(counts);
        return activityPresentRepoPage;
    }

    
    public ResultBase<List<ActivityPresentDTO>> selectActivityPresentList(ActivityPresentRepo activityPresentRepo) {
        log.info("{}-select  ActivityPresent。。。Repository。。。");
        ResultBase<List<ActivityPresentDTO>> result = new ResultBase<List<ActivityPresentDTO>>();
        List<ActivityPresentDTO> listresult = new ArrayList<ActivityPresentDTO>();
        BububaoActivityPresentDO bububaoActivityPresentDO = new BububaoActivityPresentDO();
        BeanUtils.copyProperties(activityPresentRepo, bububaoActivityPresentDO);
        List<BububaoActivityPresentDO> resultlist = activityPresentDAO.selectDataByCdt(bububaoActivityPresentDO);
        if (resultlist.size() > 0) {
            for (BububaoActivityPresentDO bububaoActivityPresent : resultlist) {
                ActivityPresentDTO activityPresentDTO = new ActivityPresentDTO();
                BeanUtils.copyProperties(bububaoActivityPresent, activityPresentDTO);
                listresult.add(activityPresentDTO);
            }
        }
        result.setSuccess(true);
        result.setValue(listresult);
        return result;
    }

    //修改    送出的奖品数+1
    public void updateDataById(String id) {
        activityPresentDAO.updateById(id);
    }

    //插入一条新的记录
    public ResultBase<String> saveActivityPresent(ActivityPresentRepo activityPresentRepo) throws Exception {
        log.info("{}-insert ActivityPresent。。。Repository。。。");
        ResultBase<String> result = new ResultBase<String>();
        BububaoActivityPresentDO bububaoActivityPresentDO = new BububaoActivityPresentDO();
        BeanUtils.copyProperties(activityPresentRepo, bububaoActivityPresentDO);
        Long id = seqActivityPresent.nextValue();
        bububaoActivityPresentDO.setId(id.toString());
        activityPresentDAO.insert(bububaoActivityPresentDO);
        result.setValue(id.toString());
        result.setSuccess(true);
        return result;
    }

    
    public ActivityPresentDTO selectActivityPresentByid(String id) {
    	ActivityPresentDTO activityPresentDTO = new ActivityPresentDTO();
        log.info("select presentbuid ...Repository");
        BububaoActivityPresentDO bububaoActivityPresentDO = activityPresentDAO.selectOneDataById(id);
        if (bububaoActivityPresentDO != null) {
            BeanUtils.copyProperties(bububaoActivityPresentDO, activityPresentDTO);
        }
        return activityPresentDTO;
    }
    
    //根据主键修改信息

    public ResultBase<String> updateActivityPresentList(ActivityPresentRepo activityPresentRepo) throws Exception {
        ResultBase<String> result = new ResultBase<String>();
        log.info("{}-update bububaoCampaignList。。。Repository。。。");
        BububaoActivityPresentDO bububaoActivityPresentDO = new BububaoActivityPresentDO();
        BeanUtils.copyProperties(activityPresentRepo, bububaoActivityPresentDO);
        activityPresentDAO.update(bububaoActivityPresentDO);
        result.setSuccess(true);
        result.setValue(RunConstants.UPDATE_TRUE);
        return result;
    }

}
