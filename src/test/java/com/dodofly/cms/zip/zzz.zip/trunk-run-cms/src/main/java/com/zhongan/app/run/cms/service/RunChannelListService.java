package com.zhongan.app.run.cms.service;

import com.zhongan.app.run.cms.bean.bo.RunChannelListBO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunChannelListDTO;
import com.zhongan.app.run.cms.bean.web.RunChannelListPageDTO;

public interface RunChannelListService {

	/**
     * cms渠道信息查询C001
     * 
     * @return
     */
	public ResultBase<RunChannelListDTO> selectChannelListInfo(RunChannelListBO runChannelListBO);
	
	public RunChannelListPageDTO selectRunChannelListPage(Page<RunChannelListDTO> runChannelListPage);
	
	public ResultBase<String> insertChannelList(RunChannelListDTO runChannelListDTO);
	 
	public ResultBase<String> updateChannelList(RunChannelListDTO runChannelListDTO);
	
	public ResultBase<String> deleteChannelList(String id);
	
	public RunChannelListDTO selectOneChannelList(String id);
}
