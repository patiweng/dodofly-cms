package com.zhongan.app.run.cms.bean.qrcode.dto;

import lombok.Data;

@Data
public class UserInfoView {
    /**
     * 当前操作人员userId
     */
    private String operatorId;

    /**
     * 当前操作人员userName
     */
    private String operatorName;
}
