package com.zhongan.app.run.cms.bean.page;

import java.io.Serializable;
import java.util.Map;

import com.google.common.collect.Maps;

/**
 * 类PageInfo.java的实现描述：查询条件
 * 
 * @author chenqiang
 */
public class PageInfo implements Serializable {

    /**
         * 
         */
    private static final long   serialVersionUID = -221890175315952141L;

    /**
     * 当前页面
     */
    private int                 currentPage      = 1;                   //默认第一页

    /**
     * page size
     */
    private int                 size             = 10;
    /**
     * 起始条数
     */
    private int                 start;
    /**
     * 同start
     */
    private int                 offset;

    private Map<String, Object> paramMap         = Maps.newHashMap();

    public PageInfo() {

    }

    public PageInfo(int currentPage, int size, int start) {
        super();
        this.currentPage = currentPage;
        this.size = size;
        this.start = start;
        this.offset = start;
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public void setCurrentPage(int currentPage) {
        this.currentPage = currentPage;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public int getStart() {
        return start;
    }

    public void setStart(int start) {
        this.start = start;
    }

    public Map<String, Object> getParamMap() {
        return paramMap;
    }

    public void setParamMap(Map<String, Object> paramMap) {
        this.paramMap = paramMap;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

}
