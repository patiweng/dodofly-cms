package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.RunElifeProductCriteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeProductDO;

public interface RunElifeProductMapper {
    /** @mbggenerated
     */
    int countByCriteria(RunElifeProductCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(RunElifeProductCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from run_elife_product", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into run_elife_product (id, biz_rule, ", "biz_value, product_id, ",
            "product_name, product_version, ", "product_link, product_desc, ", "extra_info, creator, ",
            "gmt_created, modifier, gmt_modified, ", "is_deleted)",
            "values (#{id,jdbcType=BIGINT}, #{bizRule,jdbcType=VARCHAR}, ",
            "#{bizValue,jdbcType=VARCHAR}, #{productId,jdbcType=BIGINT}, ",
            "#{productName,jdbcType=VARCHAR}, #{productVersion,jdbcType=VARCHAR}, ",
            "#{productLink,jdbcType=VARCHAR}, #{productDesc,jdbcType=VARCHAR}, ",
            "#{extraInfo,jdbcType=VARCHAR}, ifnull(#{creator,jdbcType=VARCHAR}, 'system'), ",
            "now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), now(), ", "#{isDeleted,jdbcType=CHAR})" })
    int insert(RunElifeProductDO record);

    /** @mbggenerated
     */
    int insertSelective(RunElifeProductDO record);

    /** @mbggenerated
     */
    List<RunElifeProductDO> selectByCriteriaWithPage(@Param("criteria") RunElifeProductCriteria criteria,
                                                     @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<RunElifeProductDO> selectByCriteria(RunElifeProductCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select", "id, biz_rule, biz_value, product_id, product_name, product_version, product_link, ",
            "product_desc, extra_info, creator, gmt_created, modifier, gmt_modified, is_deleted",
            "from run_elife_product", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    RunElifeProductDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") RunElifeProductDO record,
                                  @Param("criteria") RunElifeProductCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") RunElifeProductDO record, @Param("criteria") RunElifeProductCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(RunElifeProductDO record);

    /** @mbggenerated
     */
    @Update({ "update run_elife_product", "set biz_rule = #{bizRule,jdbcType=VARCHAR},",
            "biz_value = #{bizValue,jdbcType=VARCHAR},", "product_id = #{productId,jdbcType=BIGINT},",
            "product_name = #{productName,jdbcType=VARCHAR},", "product_version = #{productVersion,jdbcType=VARCHAR},",
            "product_link = #{productLink,jdbcType=VARCHAR},", "product_desc = #{productDesc,jdbcType=VARCHAR},",
            "extra_info = #{extraInfo,jdbcType=VARCHAR},", "creator = #{creator,jdbcType=VARCHAR},",
            "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(RunElifeProductDO record);
}
