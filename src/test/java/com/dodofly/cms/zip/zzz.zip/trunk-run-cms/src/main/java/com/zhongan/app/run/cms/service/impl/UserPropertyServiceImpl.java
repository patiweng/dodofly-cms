package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.zhongan.app.run.cms.bean.bo.UserPropertyBO;
import com.zhongan.app.run.cms.bean.repo.UserPropertyRepo;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.UserPropertyRepository;
import com.zhongan.app.run.cms.service.UserPropertyService;

@Slf4j
@Service
public class UserPropertyServiceImpl implements UserPropertyService {

    @Resource
    private UserPropertyRepository userPropertyRepository;

    @Override
    public ResultBase<UserPropertyBO> selectUserPropertyByUnionid(Long unionid) {
        ResultBase<UserPropertyBO> result = new ResultBase<UserPropertyBO>();
        try {
            UserPropertyRepo userPropertyRepo = new UserPropertyRepo();
            userPropertyRepo.setUnionid(unionid);
            List<UserPropertyRepo> userPropertyRepos = userPropertyRepository.selectDataByCdt(userPropertyRepo);
            //用户属性表unionid唯一
            if (0 != userPropertyRepos.size()) {
                userPropertyRepo = userPropertyRepos.get(0);
                UserPropertyBO userPropertyBO = new UserPropertyBO();
                BeanUtils.copyProperties(userPropertyRepo, userPropertyBO);
                result.setValue(userPropertyBO);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-", e.getMessage(), e);
            log.error("{}-when selectUserPropertyByUnionid, error occured...");
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            return result;
        }
        return result;
    }

}
