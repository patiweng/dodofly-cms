package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.dataobject.TransLogDO;
import com.zhongan.app.run.cms.bean.web.ResultBase;

public interface TransLogService {

    public ResultBase<List<TransLogDO>> queryTransLogByDate(String sourceCode, String sdate, String edate);

}
