package com.zhongan.app.run.cms.service.impl;

import java.util.List;
import java.util.UUID;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.RunCmsUserDTO;
import com.zhongan.app.run.cms.bean.web.RunSysMenuDTO;
import com.zhongan.app.run.cms.common.constants.RunConstants;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.repository.RunUserLoginMgrRepository;
import com.zhongan.app.run.cms.repository.RunUserMenuRepository;
import com.zhongan.app.run.cms.service.RunUserLoginService;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RunUserLoginServiceImpl implements RunUserLoginService {

    @Resource
    private RunUserLoginMgrRepository runUserLoginMgrRepository;
    @Resource
    private RunUserMenuRepository     runUserMenuRepository;

    @Resource
    private RedisUtil                 redisUtil;

    public ResultBase<RunCmsUserDTO> login(String userName, String password) {
        ResultBase<RunCmsUserDTO> result = new ResultBase<RunCmsUserDTO>();
        RunCmsUserDTO returnDTO = new RunCmsUserDTO();
        /** 参数校验 **/
        if ("".equals(userName) || "".equals(password)) {
            log.info("{}-login fail,username or passwd is null", ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_USERLOGIN_100002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_USERLOGIN_100002.getValue());
            return result;
        }
        ResultBase<RunCmsUserDTO> checkRs = runUserLoginMgrRepository.checkLogin(userName, password);
        if (!checkRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(checkRs.getErrorCode());
            result.setErrorMessage(checkRs.getErrorMessage());
            return result;
        }
        RunCmsUserDTO userDTO = checkRs.getValue();
        String userId = userDTO.getUserId();
        returnDTO.setUserId(userId);
        /** 获取用户菜单 **/
        ResultBase<List<RunSysMenuDTO>> menuRs = runUserMenuRepository.queryMenuByUserId(userId);
        if (!menuRs.isSuccess()) {
            result.setSuccess(false);
            result.setErrorCode(menuRs.getErrorCode());
            result.setErrorMessage(menuRs.getErrorMessage());
            return result;
        }
        List<RunSysMenuDTO> privmenuList = menuRs.getValue();
        returnDTO.setPrivmenuList(privmenuList);
        /** 生成token,以token为key将登录用户信息存放redis,有效期为24小时 **/
        String uuid = String.valueOf(UUID.randomUUID());
        returnDTO.setLoginToken(uuid);
        redisUtil.put(RunConstants.LoginModelConst.LOGIN_ZASID + uuid, JSONObject.toJSONString(returnDTO),
                RunConstants.LoginModelConst.LOGIN_OUT_TIME);
        result.setSuccess(true);
        result.setValue(returnDTO);
        return result;
    }

    public ResultBase<RunCmsUserDTO> checkLogin(String token) {
        log.info("{}-user {} check login start", token, ThreadLocalUtil.getRequestNo());
        ResultBase<RunCmsUserDTO> result = new ResultBase<RunCmsUserDTO>();
        /** 获取用户信息 **/
        String logData = redisUtil.getString(RunConstants.LoginModelConst.LOGIN_ZASID + token);
        if (logData == null) {
            log.info("{}-token {} checklogin fail,tair not exist", RunConstants.LoginModelConst.LOGIN_ZASID + token,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            return result;
        }
        JSONObject jobj = JSONObject.parseObject(logData);
        RunCmsUserDTO loginDto = JSONObject.toJavaObject(jobj, RunCmsUserDTO.class);
        result.setSuccess(true);
        result.setValue(loginDto);
        /** 重新put一次tair更新登录有效时间 **/
        redisUtil.put(RunConstants.LoginModelConst.LOGIN_ZASID + token, JSONObject.toJSONString(loginDto),
                RunConstants.LoginModelConst.LOGIN_OUT_TIME);
        log.info("{}-user{} check login end", token, ThreadLocalUtil.getRequestNo());
        return result;
    }

    public ResultBase<String> editPwd(String userName, String oPwd, String nPwd) {
        ResultBase<String> result = runUserLoginMgrRepository.editPasswd(userName, oPwd, nPwd);
        return result;
    }
}
