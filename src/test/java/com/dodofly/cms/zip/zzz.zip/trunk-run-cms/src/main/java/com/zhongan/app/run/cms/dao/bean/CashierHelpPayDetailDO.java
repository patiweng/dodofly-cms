package com.zhongan.app.run.cms.dao.bean;

import java.util.Date;

public class CashierHelpPayDetailDO {
    /**
     * 主键 This field corresponds to the column
     * bububao_cashier_help_pay_detail.id
     *
     * @mbggenerated
     */
    private Long   id;

    /**
     * 代收代付ID This field corresponds to the column
     * bububao_cashier_help_pay_detail.cashier_id
     *
     * @mbggenerated
     */
    private Long   cashierId;

    /**
     * 用户合同号 This field corresponds to the column
     * bububao_cashier_help_pay_detail.user_contract_no
     *
     * @mbggenerated
     */
    private String userContractNo;

    /**
     * 代扣渠道：cashier(收银台),financial(金融) This field corresponds to the column
     * bububao_cashier_help_pay_detail.dk_source
     *
     * @mbggenerated
     */
    private String dkSource;

    /**
     * 业务时间 This field corresponds to the column
     * bububao_cashier_help_pay_detail.biz_time
     *
     * @mbggenerated
     */
    private Date   bizTime;

    /**
     * 业务状态(1:已开通 2:未开通) This field corresponds to the column
     * bububao_cashier_help_pay_detail.biz_status
     *
     * @mbggenerated
     */
    private Long   bizStatus;

    /**
     * 渠道信息 This field corresponds to the column
     * bububao_cashier_help_pay_detail.biz_channel
     *
     * @mbggenerated
     */
    private String bizChannel;

    /**
     * 扩展信息,json格式 This field corresponds to the column
     * bububao_cashier_help_pay_detail.extra_info
     *
     * @mbggenerated
     */
    private String extraInfo;

    /**
     * 创建人 This field corresponds to the column
     * bububao_cashier_help_pay_detail.creator
     *
     * @mbggenerated
     */
    private String creator;

    /**
     * 创建时间 This field corresponds to the column
     * bububao_cashier_help_pay_detail.gmt_created
     *
     * @mbggenerated
     */
    private Date   gmtCreated;

    /**
     * 修改人 This field corresponds to the column
     * bububao_cashier_help_pay_detail.modifier
     *
     * @mbggenerated
     */
    private String modifier;

    /**
     * 修改时间 This field corresponds to the column
     * bububao_cashier_help_pay_detail.gmt_modified
     *
     * @mbggenerated
     */
    private Date   gmtModified;

    /**
     * 是否删除 This field corresponds to the column
     * bububao_cashier_help_pay_detail.is_deleted
     *
     * @mbggenerated
     */
    private String isDeleted;

    /** @mbggenerated
     */
    public CashierHelpPayDetailDO(Long id, Long cashierId, String userContractNo, String dkSource, Date bizTime,
                                  Long bizStatus, String bizChannel, String extraInfo, String creator, Date gmtCreated,
                                  String modifier, Date gmtModified, String isDeleted) {
        this.id = id;
        this.cashierId = cashierId;
        this.userContractNo = userContractNo;
        this.dkSource = dkSource;
        this.bizTime = bizTime;
        this.bizStatus = bizStatus;
        this.bizChannel = bizChannel;
        this.extraInfo = extraInfo;
        this.creator = creator;
        this.gmtCreated = gmtCreated;
        this.modifier = modifier;
        this.gmtModified = gmtModified;
        this.isDeleted = isDeleted;
    }

    /** @mbggenerated
     */
    public CashierHelpPayDetailDO() {
        super();
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.id
     *
     * @return the value of bububao_cashier_help_pay_detail.id
     * @mbggenerated
     */
    public Long getId() {
        return id;
    }

    /**
     * Sets the value of the database column bububao_cashier_help_pay_detail.id
     *
     * @param id the value for bububao_cashier_help_pay_detail.id
     * @mbggenerated
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.cashier_id
     *
     * @return the value of bububao_cashier_help_pay_detail.cashier_id
     * @mbggenerated
     */
    public Long getCashierId() {
        return cashierId;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.cashier_id
     *
     * @param cashierId the value for bububao_cashier_help_pay_detail.cashier_id
     * @mbggenerated
     */
    public void setCashierId(Long cashierId) {
        this.cashierId = cashierId;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.user_contract_no
     *
     * @return the value of bububao_cashier_help_pay_detail.user_contract_no
     * @mbggenerated
     */
    public String getUserContractNo() {
        return userContractNo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.user_contract_no
     *
     * @param userContractNo the value for
     *            bububao_cashier_help_pay_detail.user_contract_no
     * @mbggenerated
     */
    public void setUserContractNo(String userContractNo) {
        this.userContractNo = userContractNo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.dk_source
     *
     * @return the value of bububao_cashier_help_pay_detail.dk_source
     * @mbggenerated
     */
    public String getDkSource() {
        return dkSource;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.dk_source
     *
     * @param dkSource the value for bububao_cashier_help_pay_detail.dk_source
     * @mbggenerated
     */
    public void setDkSource(String dkSource) {
        this.dkSource = dkSource;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.biz_time
     *
     * @return the value of bububao_cashier_help_pay_detail.biz_time
     * @mbggenerated
     */
    public Date getBizTime() {
        return bizTime;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.biz_time
     *
     * @param bizTime the value for bububao_cashier_help_pay_detail.biz_time
     * @mbggenerated
     */
    public void setBizTime(Date bizTime) {
        this.bizTime = bizTime;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.biz_status
     *
     * @return the value of bububao_cashier_help_pay_detail.biz_status
     * @mbggenerated
     */
    public Long getBizStatus() {
        return bizStatus;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.biz_status
     *
     * @param bizStatus the value for bububao_cashier_help_pay_detail.biz_status
     * @mbggenerated
     */
    public void setBizStatus(Long bizStatus) {
        this.bizStatus = bizStatus;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.biz_channel
     *
     * @return the value of bububao_cashier_help_pay_detail.biz_channel
     * @mbggenerated
     */
    public String getBizChannel() {
        return bizChannel;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.biz_channel
     *
     * @param bizChannel the value for
     *            bububao_cashier_help_pay_detail.biz_channel
     * @mbggenerated
     */
    public void setBizChannel(String bizChannel) {
        this.bizChannel = bizChannel;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.extra_info
     *
     * @return the value of bububao_cashier_help_pay_detail.extra_info
     * @mbggenerated
     */
    public String getExtraInfo() {
        return extraInfo;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.extra_info
     *
     * @param extraInfo the value for bububao_cashier_help_pay_detail.extra_info
     * @mbggenerated
     */
    public void setExtraInfo(String extraInfo) {
        this.extraInfo = extraInfo;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.creator
     *
     * @return the value of bububao_cashier_help_pay_detail.creator
     * @mbggenerated
     */
    public String getCreator() {
        return creator;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.creator
     *
     * @param creator the value for bububao_cashier_help_pay_detail.creator
     * @mbggenerated
     */
    public void setCreator(String creator) {
        this.creator = creator;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.gmt_created
     *
     * @return the value of bububao_cashier_help_pay_detail.gmt_created
     * @mbggenerated
     */
    public Date getGmtCreated() {
        return gmtCreated;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.gmt_created
     *
     * @param gmtCreated the value for
     *            bububao_cashier_help_pay_detail.gmt_created
     * @mbggenerated
     */
    public void setGmtCreated(Date gmtCreated) {
        this.gmtCreated = gmtCreated;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.modifier
     *
     * @return the value of bububao_cashier_help_pay_detail.modifier
     * @mbggenerated
     */
    public String getModifier() {
        return modifier;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.modifier
     *
     * @param modifier the value for bububao_cashier_help_pay_detail.modifier
     * @mbggenerated
     */
    public void setModifier(String modifier) {
        this.modifier = modifier;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.gmt_modified
     *
     * @return the value of bububao_cashier_help_pay_detail.gmt_modified
     * @mbggenerated
     */
    public Date getGmtModified() {
        return gmtModified;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.gmt_modified
     *
     * @param gmtModified the value for
     *            bububao_cashier_help_pay_detail.gmt_modified
     * @mbggenerated
     */
    public void setGmtModified(Date gmtModified) {
        this.gmtModified = gmtModified;
    }

    /**
     * This method returns the value of the database column
     * bububao_cashier_help_pay_detail.is_deleted
     *
     * @return the value of bububao_cashier_help_pay_detail.is_deleted
     * @mbggenerated
     */
    public String getIsDeleted() {
        return isDeleted;
    }

    /**
     * Sets the value of the database column
     * bububao_cashier_help_pay_detail.is_deleted
     *
     * @param isDeleted the value for bububao_cashier_help_pay_detail.is_deleted
     * @mbggenerated
     */
    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }
}
