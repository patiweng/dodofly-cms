package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import lombok.extern.slf4j.Slf4j;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.zhongan.app.run.cms.bean.bo.RaffleActivityBO;
import com.zhongan.app.run.cms.bean.dataobject.BububaoActivityDO;
import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.repo.RaffleActivityRepo;
import com.zhongan.app.run.cms.bean.web.ActivityListPageDTO;
import com.zhongan.app.run.cms.bean.web.RaffleActivityDTO;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.common.enums.AppErrEnum;
import com.zhongan.app.run.cms.dao.BububaoActivityDAO;
import com.zhongan.app.run.cms.repository.RaffleActivityRepository;
import com.zhongan.app.run.cms.service.RaffleActivityService;
import com.zhongan.app.run.common.utils.RedisUtil;
import com.zhongan.app.run.common.utils.ThreadLocalUtil;

@Service
@Slf4j
public class RaffleActivityServiceImpl implements RaffleActivityService {

    @Resource
    private RaffleActivityRepository raffleActivityRepository;
    @Resource
    private BububaoActivityDAO       raffleActivityDAO;
    @Resource
    private RedisUtil                redisUtil;

    @Override
    public ResultBase<List<RaffleActivityDTO>> selectActivityData(RaffleActivityBO raffleActivityBO) {
        ResultBase<List<RaffleActivityDTO>> result = new ResultBase<List<RaffleActivityDTO>>();
        log.info("{}-raffleActivity select begin...");
        try {
            RaffleActivityRepo raffleActivityRepo = new RaffleActivityRepo();
            BeanUtils.copyProperties(raffleActivityBO, raffleActivityRepo);
            result = raffleActivityRepository.selectActivityList(raffleActivityRepo);
            if (result.getValue().size() > 0) {
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00002.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00002.getValue());
            } else {
                result.setSuccess(true);
                result.setValue(null);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_NO_DATA.getValue());
            }
        } catch (Exception e) {
            log.error("{}-raffleActivity select fail,please find error to..."
                    + "error location polynomial : RaffleActivityServiceImpl--selectActivityData()" + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00002.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00002.getValue());
            log.info("{}-fail。。。select...");
        }
        return result;
    }

    @Override
    public ResultBase<String> insertActivityData(RaffleActivityBO raffleActivityBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RaffleActivityRepo raffleActivityRepo = new RaffleActivityRepo();
            BeanUtils.copyProperties(raffleActivityBO, raffleActivityRepo);
            result = raffleActivityRepository.saveActivity(raffleActivityRepo);

            if (result.isSuccess()) {
                //缓存对象key：Id   value：dto
                BububaoActivityDO bububaoActivityDO = raffleActivityDAO.selectOneDataById(result.getValue());
                redisUtil.put("bububao_activity:" + result.getValue(), JSONObject.toJSONString(bububaoActivityDO));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_10001.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....save-- ActivityPresent...."
                    + "error location polynomial : RaffleActivityServiceImpl--insertActivityData()" + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_10001.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_10001.getValue());
        }
        return result;
    }

    //分页查询信息
    @Override
    public ActivityListPageDTO selectActivityListPage(Page<RaffleActivityDTO> raffleActivityListPage) {
        ActivityListPageDTO activityListPageDTO = new ActivityListPageDTO();
        Page<RaffleActivityRepo> raffleActivityRepoPage = new Page<RaffleActivityRepo>();
        BeanUtils.copyProperties(raffleActivityListPage, raffleActivityRepoPage);
        raffleActivityRepoPage = raffleActivityRepository.selectActivityDataPage(raffleActivityRepoPage);
        List<RaffleActivityRepo> raffleActivityRepolist = raffleActivityRepoPage.getResultList();
        List<RaffleActivityDTO> raffleActivityDTOList = Lists.newArrayList();
        if (raffleActivityRepolist != null && raffleActivityRepolist.size() > 0) {
            RaffleActivityDTO raffleActivityDTO = null;
            for (RaffleActivityRepo raffleActivityRepos : raffleActivityRepolist) {
                raffleActivityDTO = new RaffleActivityDTO();
                BeanUtils.copyProperties(raffleActivityRepos, raffleActivityDTO);
                String startTime = raffleActivityRepos.getStartTime();
                String endTime = raffleActivityRepos.getEndTime();
                String st = startTime.substring(0, startTime.length() - 2);
                String et = endTime.substring(0, endTime.length() - 2);
                raffleActivityDTO.setStartTime(st);
                raffleActivityDTO.setEndTime(et);
                raffleActivityDTOList.add(raffleActivityDTO);
            }
        }
        raffleActivityListPage.setResultList(raffleActivityDTOList);
        raffleActivityListPage.setTotalItem(raffleActivityRepoPage.getTotalItem());
        activityListPageDTO.setRaffleActivityDTOPage(raffleActivityListPage);
        return activityListPageDTO;
    }

    @Override
    public ResultBase<String> updateActivityData(RaffleActivityBO raffleActivityBO) {
        ResultBase<String> result = new ResultBase<String>();
        try {
            RaffleActivityRepo raffleActivityRepo = new RaffleActivityRepo();
            BeanUtils.copyProperties(raffleActivityBO, raffleActivityRepo);
            result = raffleActivityRepository.updateActivityList(raffleActivityRepo);
            if (result.isSuccess()) {
                //缓存对象key：Id   value：dto
                BububaoActivityDO bububaoActivityDO = raffleActivityDAO.selectOneDataById(raffleActivityRepo.getId());
                redisUtil.put("bububao_activity:" + raffleActivityRepo.getId(),
                        JSONObject.toJSONString(bububaoActivityDO));
                result.setSuccess(true);
                result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00003.getValue());
            } else {
                result.setSuccess(false);
                result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
                result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
            }
        } catch (Exception e) {
            log.error("{}-fail....update--ActivityPresent...."
                    + "error location polynomial : RaffleActivityServiceImpl--updateActivityData()" + "exception：" + e);
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00003.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00003.getValue());
        }
        return result;
    }

    @Override
    public RaffleActivityDTO selectDataByid(String id) {
        //根据主键查询单条记录 后台
        log.info("{}-raffleActivity selectone begin...");
        RaffleActivityDTO raffleActivityDTO = raffleActivityRepository.selectActivityByid(id);
        String startTime = raffleActivityDTO.getStartTime();
        String endTime = raffleActivityDTO.getEndTime();
        String st = startTime.substring(0, startTime.length() - 2);
        String et = endTime.substring(0, endTime.length() - 2);
        raffleActivityDTO.setStartTime(st);
        raffleActivityDTO.setEndTime(et);
        return raffleActivityDTO;
    }

    //删除
    @Override
    public ResultBase<String> deleteActivity(String id) {
        log.info("{}-delete activity info。。。serviceImpl...", ThreadLocalUtil.getRequestNo());
        ResultBase<String> result = new ResultBase<String>();
        try {
            result = raffleActivityRepository.deleteByid(id);
            //删除缓存
            if (result.isSuccess()) {
                redisUtil.delete("bububao_activity:" + id);
            }
            result.setErrorCode(AppErrEnum.SUCCESS_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.SUCCESS_RUNUSER_00004.getValue());
            result.setSuccess(true);
        } catch (Exception e) {
            log.error("{}-ChannelList delete fail,please find error to...。"
                    + "error location polynomial:RaffleActivityServiceImpl--deleteActivity()" + "exception：" + e,
                    ThreadLocalUtil.getRequestNo());
            result.setSuccess(false);
            result.setErrorCode(AppErrEnum.ERROR_RUNUSER_00004.getCode());
            result.setErrorMessage(AppErrEnum.ERROR_RUNUSER_00004.getValue());
        }
        return result;
    }
}
