package com.zhongan.app.run.cms.common.enums;

public enum MarketTypeEnum {

    /*** 公共 ***/
    MARKET_TYPE_01("1", "运营活动"),
    MARKET_TYPE_02("2", "线下活动"),
    MARKET_TYPE_03("3", "tip消息"),
    MARKET_TYPE_04("4", "开屏广告"),
    MARKET_TYPE_05("5", "支付完成海报"),
    MARKET_TYPE_06("6", "落地页"),
    MARKET_TYPE_07("7", "尊享e生-运动版"),
    MARKET_TYPE_08("8", "以赠代销"),
    MARKET_TYPE_10("10", "众推广产品"),
    MARKET_TYPE_11("11", "推荐文章"),
    MARKET_TYPE_12("12", "尊享e生-月缴版"),
    MARKET_TYPE_14("14", "运营活动,首页不展示"), ;

    private String code;
    private String value;

    private MarketTypeEnum(String code, String value) {
        this.code = code;
        this.value = value;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
