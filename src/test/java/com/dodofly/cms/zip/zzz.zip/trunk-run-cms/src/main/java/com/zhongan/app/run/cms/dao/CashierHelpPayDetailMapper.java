package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDetailCriteria;
import com.zhongan.app.run.cms.dao.bean.CashierHelpPayDetailDO;

public interface CashierHelpPayDetailMapper {
    /** @mbggenerated
     */
    int countByCriteria(CashierHelpPayDetailCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(CashierHelpPayDetailCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from bububao_cashier_help_pay_detail", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into bububao_cashier_help_pay_detail (id, cashier_id, ", "user_contract_no, dk_source, ",
            "biz_time, biz_status, ", "biz_channel, extra_info, ", "creator, gmt_created, modifier, ",
            "gmt_modified, is_deleted)", "values (#{id,jdbcType=BIGINT}, #{cashierId,jdbcType=BIGINT}, ",
            "#{userContractNo,jdbcType=VARCHAR}, #{dkSource,jdbcType=VARCHAR}, ",
            "#{bizTime,jdbcType=TIMESTAMP}, #{bizStatus,jdbcType=BIGINT}, ",
            "#{bizChannel,jdbcType=VARCHAR}, #{extraInfo,jdbcType=VARCHAR}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), #{isDeleted,jdbcType=CHAR})" })
    int insert(CashierHelpPayDetailDO record);

    /** @mbggenerated
     */
    int insertSelective(CashierHelpPayDetailDO record);

    /** @mbggenerated
     */
    List<CashierHelpPayDetailDO> selectByCriteriaWithPage(@Param("criteria") CashierHelpPayDetailCriteria criteria,
                                                          @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<CashierHelpPayDetailDO> selectByCriteria(CashierHelpPayDetailCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select", "id, cashier_id, user_contract_no, dk_source, biz_time, biz_status, biz_channel, ",
            "extra_info, creator, gmt_created, modifier, gmt_modified, is_deleted",
            "from bububao_cashier_help_pay_detail", "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    CashierHelpPayDetailDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") CashierHelpPayDetailDO record,
                                  @Param("criteria") CashierHelpPayDetailCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") CashierHelpPayDetailDO record,
                         @Param("criteria") CashierHelpPayDetailCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(CashierHelpPayDetailDO record);

    /** @mbggenerated
     */
    @Update({ "update bububao_cashier_help_pay_detail", "set cashier_id = #{cashierId,jdbcType=BIGINT},",
            "user_contract_no = #{userContractNo,jdbcType=VARCHAR},", "dk_source = #{dkSource,jdbcType=VARCHAR},",
            "biz_time = #{bizTime,jdbcType=TIMESTAMP},", "biz_status = #{bizStatus,jdbcType=BIGINT},",
            "biz_channel = #{bizChannel,jdbcType=VARCHAR},", "extra_info = #{extraInfo,jdbcType=VARCHAR},",
            "creator = #{creator,jdbcType=VARCHAR},", "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(CashierHelpPayDetailDO record);
}
