package com.zhongan.app.run.cms.service.qrcode;

import com.zhongan.app.run.cms.bean.qrcode.dto.ParamDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultOrgDto;
import com.zhongan.app.run.cms.bean.qrcode.model.BububaoThirdOrgDO;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 机构管理接口 service
 * 
 * @author lichao002
 * @date 2018-06-04
 */
public interface BububaoThirdOrgService {

    /**
     * 批量保存机构
     * 
     * @param request
     * @param fileName
     * @param fileFormat
     * @return
     */
    public BaseResult<String> insertBatchOrgs(HttpServletRequest request, String fileName, String fileFormat);

    /**
     * 根据条件分页查询机构
     * 
     * @param param
     * @return
     */
    public BaseResult<PageDTO<ResultOrgDto>> findOrgsPage(ParamDto param);

    /**
     * 批量删除机构
     * 
     * @param params
     * @return
     */
    public BaseResult<String> deleteBatchOrgs(List<ParamDto> params);

    /**
     * 导出机构信息
     * 
     * @param param
     * @return
     */
    public BaseResult<String> exportOrgs(ParamDto param);

    public BaseResult<List<BububaoThirdOrgDO>> selectCondition(Long orgId);
}
