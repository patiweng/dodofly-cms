package com.zhongan.app.run.cms.bean.web;

import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
public class AnalysisMonitorDTO implements Cloneable {

    /***** id *****/
    private Long    id;
    /***** 渠道编码 *****/
    private String  sourceCode;
    /***** 渠道名称 *****/
    private String  sourceName;
    /***** 统计日期 *****/
    private String  analysDate;
    /***** 欢迎页面访问用户数 *****/
    private String  helloindexCount;
    /***** 注册档位访问用户数 *****/
    private String  stallindexCount;
    /***** 投保页面访问用户数 *****/
    private String  insureindexCount;
    /***** 投保成功数 *****/
    private String  insuresucCount;
    /**** 投保失败数 ******/
    private String  insureerrCount;
    /***** 档位跳转率 *****/
    private String  stallconverRate;
    /***** 投保跳转率 *****/
    private String  insureconverRate;
    /***** 投保成功率 *****/
    private String  insuresucRate;
    /***** 投保失败率 *****/
    private String  insureerrRate;
    /***** 是否完成 0-否 1-是 *****/
    private String  isDone;

    private Integer pageSize;
    private Integer currentPage;
    private String  sdate;
    private String  edate;
    private String  bopsFlag;

    @Override
    public Object clone() {
        try {
            return super.clone();
        } catch (CloneNotSupportedException e) {
            log.error("clone  fail===={}", e);
        }
        return null;
    }
}
