package com.zhongan.app.run.cms.dao;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.ResultMap;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelProductCriteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelProductDO;

public interface RunElifeChannelProductMapper {
    /** @mbggenerated
     */
    int countByCriteria(RunElifeChannelProductCriteria criteria);

    /** @mbggenerated
     */
    int deleteByCriteria(RunElifeChannelProductCriteria criteria);

    /** @mbggenerated
     */
    @Delete({ "delete from run_elife_channel_product", "where id = #{id,jdbcType=BIGINT}" })
    int deleteByPrimaryKey(Long id);

    /** @mbggenerated
     */
    @Insert({ "insert into run_elife_channel_product (id, channel_id, ", "channel_name, product_id, ",
            "product_name, campaign_def_id, ", "campaign_def_name, extra_info, ", "creator, gmt_created, modifier, ",
            "gmt_modified, is_deleted)", "values (#{id,jdbcType=BIGINT}, #{channelId,jdbcType=BIGINT}, ",
            "#{channelName,jdbcType=VARCHAR}, #{productId,jdbcType=BIGINT}, ",
            "#{productName,jdbcType=VARCHAR}, #{campaignDefId,jdbcType=BIGINT}, ",
            "#{campaignDefName,jdbcType=VARCHAR}, #{extraInfo,jdbcType=VARCHAR}, ",
            "ifnull(#{creator,jdbcType=VARCHAR}, 'system'), now(), ifnull(#{modifier,jdbcType=VARCHAR}, 'system'), ",
            "now(), #{isDeleted,jdbcType=CHAR})" })
    int insert(RunElifeChannelProductDO record);

    /** @mbggenerated
     */
    int insertSelective(RunElifeChannelProductDO record);

    /** @mbggenerated
     */
    List<RunElifeChannelProductDO> selectByCriteriaWithPage(@Param("criteria") RunElifeChannelProductCriteria criteria,
                                                            @Param("pageInfo") PageInfo pageInfo);

    /** @mbggenerated
     */
    List<RunElifeChannelProductDO> selectByCriteria(RunElifeChannelProductCriteria criteria);

    /** @mbggenerated
     */
    @Select({ "select", "id, channel_id, channel_name, product_id, product_name, campaign_def_id, campaign_def_name, ",
            "extra_info, creator, gmt_created, modifier, gmt_modified, is_deleted", "from run_elife_channel_product",
            "where id = #{id,jdbcType=BIGINT}" })
    @ResultMap("BaseResultMap")
    RunElifeChannelProductDO selectByPrimaryKey(@Param("id") Long id);

    /** @mbggenerated
     */
    int updateByCriteriaSelective(@Param("record") RunElifeChannelProductDO record,
                                  @Param("criteria") RunElifeChannelProductCriteria criteria);

    /** @mbggenerated
     */
    int updateByCriteria(@Param("record") RunElifeChannelProductDO record,
                         @Param("criteria") RunElifeChannelProductCriteria criteria);

    /** @mbggenerated
     */
    int updateByPrimaryKeySelective(RunElifeChannelProductDO record);

    /** @mbggenerated
     */
    @Update({ "update run_elife_channel_product", "set channel_id = #{channelId,jdbcType=BIGINT},",
            "channel_name = #{channelName,jdbcType=VARCHAR},", "product_id = #{productId,jdbcType=BIGINT},",
            "product_name = #{productName,jdbcType=VARCHAR},", "campaign_def_id = #{campaignDefId,jdbcType=BIGINT},",
            "campaign_def_name = #{campaignDefName,jdbcType=VARCHAR},", "extra_info = #{extraInfo,jdbcType=VARCHAR},",
            "creator = #{creator,jdbcType=VARCHAR},", "gmt_created = #{gmtCreated,jdbcType=TIMESTAMP},",
            "modifier = ifnull(#{modifier,jdbcType=VARCHAR}, 'system'),", "gmt_modified = now(),",
            "is_deleted = #{isDeleted,jdbcType=CHAR}", "where id = #{id,jdbcType=BIGINT}" })
    int updateByPrimaryKey(RunElifeChannelProductDO record);
}
