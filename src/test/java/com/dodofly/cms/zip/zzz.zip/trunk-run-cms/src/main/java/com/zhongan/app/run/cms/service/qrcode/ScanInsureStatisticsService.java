package com.zhongan.app.run.cms.service.qrcode;

import java.util.List;






import com.zhongan.app.run.cms.bean.page.Page;
import com.zhongan.app.run.cms.bean.qrcode.dto.BububaoExportLogDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultInsureDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.ResultDto;
import com.zhongan.app.run.cms.bean.qrcode.dto.StatisticsParamDto;
import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.health.common.share.bean.BaseResult;
import com.zhongan.health.common.share.bean.PageDTO;

/**
 * 类ScanInsureStatisticsService.java的实现描述：扫码投保统计接口
 * 
 * @author zhangjin 2018年6月5日 下午4:42:04
 */
public interface ScanInsureStatisticsService {

    /**
     * 异步查询历史
     * 
     * @param page
     * @return
     */

    public BaseResult<PageDTO<BububaoExportLogDto>> asyncQueryHistory(BububaoExportLogDto bububaoExportLogDto);

    /**
     * 根据主键删除导出管理信息表
     * 
     * @param id
     * @return
     */

    public BaseResult<String> deleteExportLog(Long id);

    /**
     * 导出投保统计信息
     * 
     * @param param
     * @return
     */

    public BaseResult<String> downLoadReports(StatisticsParamDto param);
    
    /**
     * 投保统计分页
     * @param page
     * @return
     */
    public  BaseResult<PageDTO<ResultInsureDto>> selectStatisticsPage(StatisticsParamDto param);

}
