package com.zhongan.app.run.cms.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.stereotype.Service;

import com.taobao.tddl.client.sequence.Sequence;
import com.zhongan.app.run.cms.bean.page.PageInfo;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductQueryDTO;
import com.zhongan.app.run.cms.bean.web.RunElifeChannelProductResDTO;
import com.zhongan.app.run.cms.conver.RunElifeConvert;
import com.zhongan.app.run.cms.dao.RunElifeChannelProductMapper;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelProductCriteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelProductCriteria.Criteria;
import com.zhongan.app.run.cms.dao.bean.RunElifeChannelProductDO;
import com.zhongan.app.run.cms.service.IRunElifeChannelProductService;
import com.zhongan.health.common.share.bean.PageDTO;
import com.zhongan.health.common.share.enm.YesOrNo;

/**
 * 类RunElifeChannelProductServiceImpl.java的实现描述：TODO 类实现描述
 * 
 * @author chenqiang 2018年6月28日 下午2:16:33
 */
@Service("runElifeChannelProductService")
public class RunElifeChannelProductServiceImpl implements IRunElifeChannelProductService {

    @Resource
    private RunElifeChannelProductMapper mapper;

    @Resource
    private Sequence                     seqRunElifeChannelProduct;

    @Override
    public PageDTO<RunElifeChannelProductResDTO> queryList(RunElifeChannelProductQueryDTO dto) throws Exception {
        PageDTO<RunElifeChannelProductResDTO> pageDTO = new PageDTO<RunElifeChannelProductResDTO>();
        int size = dto.getPageSize();
        int currentPage = dto.getCurrentPage() < 1 ? 1 : dto.getCurrentPage();
        pageDTO.setCurrentPage(currentPage);
        pageDTO.setPageSize(size);
        int count = mapper.countByCriteria(buildCriteria(RunElifeConvert.convertChannelProductDTO(dto)));
        if (count > 0) {
            int start = (currentPage - 1) * size;
            PageInfo pageInfo = new PageInfo();
            pageInfo.setOffset(start);
            pageInfo.setSize(size);
            List<RunElifeChannelProductDO> channelProductDOs = mapper.selectByCriteriaWithPage(
                    buildCriteria(RunElifeConvert.convertChannelProductDTO(dto)), pageInfo);
            pageDTO.setResultList(RunElifeConvert.convertChannelProductResDTOs(channelProductDOs));
            pageDTO.setTotalItem(count);
        }
        return pageDTO;
    }

    @Override
    public Integer saveOrUpdate(RunElifeChannelProductDTO dto) throws Exception {
        List<RunElifeChannelProductDO> channelProductDOs = mapper.selectByCriteria(buildCriteria(dto));
        if (CollectionUtils.isEmpty(channelProductDOs)) {
            RunElifeChannelProductDO converChannelProductDo = RunElifeConvert.converChannelProductDo(dto);
            converChannelProductDo.setId(seqRunElifeChannelProduct.nextValue());
            return mapper.insert(converChannelProductDo);
        } else {
            return mapper.updateByPrimaryKeySelective(RunElifeConvert.converChannelProductDo(dto));
        }
    }

    @Override
    public List<RunElifeChannelProductResDTO> queryByCondition(RunElifeChannelProductDTO dto) throws Exception {
        return RunElifeConvert.convertChannelProductDTO(mapper.selectByCriteria(buildCriteria(dto)));
    }

    @Override
    public Integer getCount(RunElifeChannelProductDTO dto) throws Exception {
        return mapper.countByCriteria(buildCriteria(dto));
    }

    @Override
    public Integer deleteById(Long id) throws Exception {
        RunElifeChannelProductDO dto = new RunElifeChannelProductDO();
        dto.setId(id);
        dto.setIsDeleted(YesOrNo.YES.getCode());
        return mapper.updateByPrimaryKeySelective(dto);
    }

    private RunElifeChannelProductCriteria buildCriteria(RunElifeChannelProductDTO dto) {
        RunElifeChannelProductCriteria channelProductCriteria = new RunElifeChannelProductCriteria();
        Criteria criteria = channelProductCriteria.createCriteria();
        if (null != dto.getProductId()) {
            criteria.andProductIdEqualTo(dto.getProductId());
        }
        if (null != dto.getChannelId()) {
            criteria.andChannelIdEqualTo(dto.getChannelId());
        }
        if (null != dto.getCampaignDefId()) {
            criteria.andCampaignDefIdEqualTo(dto.getCampaignDefId());
        }
        criteria.andIsDeletedEqualTo(YesOrNo.NO.getCode());
        return channelProductCriteria;
    }

    @Override
    public RunElifeChannelProductResDTO queryById(Long id) throws Exception {
        return RunElifeConvert.convertChannelProductResDTO(mapper.selectByPrimaryKey(id));
    }
}
