package com.zhongan.app.run.cms.service;

import java.util.List;

import com.zhongan.app.run.cms.bean.web.ResultBase;
import com.zhongan.app.run.cms.bean.web.ActivityShareDTO;

public interface ActivityShareService {

    ResultBase<List<ActivityShareDTO>> queryActivityShareInfoByCdt(ActivityShareDTO info);

    ResultBase<String> inOrUpUserActivityShareInfoByCdt(ActivityShareDTO info);

}
