package com.zhongan.app.run.cms.bean.web;

import java.util.Date;

import lombok.Data;

@Data
public class CashierHelpPayDTO {
    /**
     * 主键
     */
    private Long   id;

    /**
     * 用户ID
     */
    private Long   unionid;

    /**
     * 用户名
     */
    private String userName;

    /**
     * 目标步数
     */
    private Long   userTarget;

    /**
     * 用户合同号
     */
    private String userContractNo;

    /**
     * 支付渠道
     */
    private String payChannelCode;

    /**
     * 原始渠道ID
     */
    private String originalChannelId;

    /**
     * 支付渠道账户号
     */
    private String payChannelUserNo;

    /**
     * 手机号
     */
    private String phone;

    /**
     * 证件类型
     */
    private String certType;

    /**
     * 证件号码
     */
    private String certNo;

    /**
     * 开通活动来源
     */
    private String bizActivity;

    /**
     * 业务来源
     */
    private String bizSource;

    /**
     * 代扣来源
     */
    private String dkSource;

    /**
     * 开通渠道
     */
    private String openChannel;

    /**
     * 开通状态(1:已开通 2:未开通)
     */
    private Long   openStauts;

    /**
     * 开通时间
     */
    private Date   openTime;

    /**
     * 关闭时间
     */
    private Date   closeTime;

    /**
     * 是否关闭过
     */
    private String isClosed;

}
